/**
 * Created by Administrator on 2015/12/14.
 */


var GameLoginModule = ModuleBase.extend({

    _currentUI:null,
    _uiPanel:null,

    ctor: function ()
    {
        this._super();
    },

    initUI: function ()
    {
        var backImg = new ccui.ImageView();
        backImg.setAnchorPoint(0.5,0.5);
        backImg.loadTexture("login/denglu_di.png", ccui.Widget.PLIST_TEXTURE);
        var pos = cc.p(0,0);
        backImg.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(true) );
        pos.x = GameMgr.inst().viewSize.width >> 1;
        pos.y = GameMgr.inst().viewSize.height >> 1;
        backImg.setPosition( pos );
        this.addChild( backImg );

        this._uiPanel = new cc.Node();
        this.addChild( this._uiPanel );
    },


    show:function( data )
    {
        this.showUI( data );
    },

    close:function()
    {

    },

    showUI:function( data )//{"ui":"verify","ip":account}
    {
        if (data == undefined) data = {"ui":"login","ip":null};
        var uiName = data.ui;
        //if( uiName == undefined ) uiName = "login";
        if( uiName != "treaty" )
        {
            this._uiPanel.removeAllChildren();
            this._currentUI = null;
        }
        var ui = null;
        switch( uiName )
        {
            case "login":       //登录界面
                ui = new LoginUI();
                break;
            case "register":    //注册界面
                ui = new RegisterUI();
                break;
            case "mobile":      //手机找回密码界面
                ui = new MobileUI();
                break;
            case "verify":      //验证码界面
                ui = new VerifyUI(data.ip,data.cd);
                break;
            case "set":         //设置密码界面
                ui = new SetUI(data.ip,data.rg);
                break;
            case "treaty":      //用户协议
                ui = new TreatyUI();
                break;
            case "loading":     //加载loading
                ui = new LoadingUI(data);
                break;
            case "key":     //激活码
                ui = new KeyUI(data.ip,data.tk);
                break;
        }

        if( ui != null && uiName!= "treaty" )
        {
            this._uiPanel.addChild( ui );
        }
        else if( ui != null )
        {
            this.addChild( ui );
        }
    },

    destroy:function(){

    }

});