/**
 * 监听地图数据
 * @constructor
 */
var MapDataCommand = function () {
    NetMgr.inst().addEventListener(393, this.recvResource, this);
    NetMgr.inst().addEventListener(397, this.recvCastleArmyData, this);
    NetMgr.inst().addEventListener(398, this.recvEarthData, this);
    NetMgr.inst().addEventListener(392, this.recvRemoveResource, this);
    NetMgr.inst().addEventListener(396, this.recvRemoveCastleArmy, this);
    NetMgr.inst().addEventListener(391, this.recvMoveOver, this);
    NetMgr.inst().addEventListener(399, this.recvServerList, this);
    NetMgr.inst().addEventListener(390, this.recvAttackInfo, this);
    NetMgr.inst().addEventListener(388, this.recvFightResource, this);
    NetMgr.inst().addEventListener(387, this.recvRemoveFightResource, this);
    NetMgr.inst().addEventListener(385, this.recvArmyPath, this);
    NetMgr.inst().addEventListener(384, this.recvDropItemInfo, this);
    NetMgr.inst().addEventListener(0, this.errorBack, this);
    mainData.enemyList.addListener("add", this.onAddEnemy, this);
    mainData.enemyList.addListener("del", this.onDelEnemy, this);
    mainData.uiData.map.addListener("inFight", this.changeFightState, this);
}

MapDataCommand.prototype.errorBack = function (cmd, data) {
    data.resetCMDData();
    var cmd = data.readUint();
}

/*
 更新城堡或部队信息
 */
MapDataCommand.prototype.recvCastleArmyData = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    trace("刷新城堡或部队", info.id, info.type, info.coordX, info.coordY, info.userAccount, mainData.playerData.account);
    var mapData = mainData.mapData;
    var position = MapUtils.transPointToPosition(info.coordX, info.coordY);
    info.showX = position.x;
    info.showY = position.y;
    /*if (info.attributes) {
     trace("有属性:", info.attributes.length);
     for (var i = 0; i < info.attributes.length; i++) {
     var attribute = info.attributes.getItemAt(i);
     trace("属性", attribute.type, attribute.value);
     }
     }*/
    if (info.type == 1205001) { //城堡
        //繁荣度
        if (info.attributes.getItem("type", 2500001) == null) {
            var fr = modelMgr.call("Table", "getTableItemByValue", ["Public", 100056]).numerical || 0;
            info.attributes.push({"type": 2500001, "value": fr});
        }
        if (info.attributes.getItem("type", 2500007) == null) {
            info.attributes.push({"type": 2500007, "value": 1});
        }
        info.level = info.attributes.getItem("type", 2500007).value;
        if (info.userAccount == mainData.playerData.account) {
            info.relation = "myself";
        } else {
            if (mainData.enemyList.getItem("account", info.userAccount)) {
                info.relation = "enemy";
            } else {
                info.relation = "other";
            }
        }

        var build = mapData.castleList.getItem("id", info.id);
        if (!build) {
            //info.name = modelMgr.call("ValidText","replaceText",[info.name]);
            build = mapData.myCastleList.getItem("id", info.id);
            if (!build) {
                build = DataManager.getInstance().getNewData("MapCastleData");
                build.receive(info);
                build.createTime = (new Date()).getTime();
                this.addBalk(info.id, info.type, build.coordX, build.coordY);
                if (build.userAccount == mainData.playerData.account) {
                    mapData.myCastleList.push(build);
                }
            } else {
                build.receive(info);
                this.addBalk(info.id, info.type, build.coordX, build.coordY);
            }
            if (build.userAccount == mainData.playerData.account) {
                if (mainData.uiData.currentCastleId == "") {
                    mainData.uiData.currentCastleId = info.id;
                    var pos = MapUtils.transPointToPosition(build.coordX, build.coordY);
                    pos.x = pos.x - mainData.systemData.screenWidth / 2;
                    pos.y = pos.y - mainData.systemData.screenHeight / 2;
                    mapData.cameraData.x = pos.x;
                    mapData.cameraData.y = pos.y;
                    var start = MapUtils.transPositionToPoint(pos.x - mainData.systemData.screenWidth, pos.y - mainData.systemData.screenHeight);
                    var end = MapUtils.transPositionToPoint(pos.x + mainData.systemData.screenWidth * 2, pos.y + mainData.systemData.screenHeight * 2);
                    mapData.cameraData.viewPort.x = start.x;
                    mapData.cameraData.viewPort.y = start.y;
                    mapData.cameraData.viewPort.width = end.x - start.x;
                    mapData.cameraData.viewPort.height = end.y - start.y;
                    var msg = new SocketBytes();
                    msg.writeUint(301);
                    msg.writeInt(start.x);
                    msg.writeInt(start.y);
                    msg.writeUint(end.x - start.x);
                    msg.writeUint(end.y - start.y);
                    NetMgr.inst().send(msg);
                }
            }
            mapData.castleList.push(build);
        } else {
            this.delBalk(info.id, info.type, build.coordX, build.coordY);
            build.receive(info);
            this.addBalk(info.id, info.type, build.coordX, build.coordY);
        }
    } else { //部队
        var roler = mapData.armyList.getItem("id", info.id);
        info.level = info.type % 100;
        var config = modelMgr.call("Table", "getTableItemByValue", ["Arm", info.type]);
        if(config) {
            info.resource = (info.attributes.getItem("type", 2500096)?info.attributes.getItem("type", 2500096).value:0) +
                (info.attributes.getItem("type", 2500097)?info.attributes.getItem("type", 2500097).value:0) +
                (info.attributes.getItem("type", 2500098)?info.attributes.getItem("type", 2500098).value:0) +
                (info.attributes.getItem("type", 2500099)?info.attributes.getItem("type", 2500099).value:0) +
                (info.attributes.getItem("type", 2500100)?info.attributes.getItem("type", 2500100).value:0) +
                (info.attributes.getItem("type", 2500101)?info.attributes.getItem("type", 2500101).value:0) +
                (info.attributes.getItem("type", 2500102)?info.attributes.getItem("type", 2500102).value:0);
            info.blood = info.attributes.getItem("type",2500011)?info.attributes.getItem("type",2500011).value:0;
            info.maxResource = Math.floor(config.arm_load*info.blood);

            info.maxBlood = info.attributes.getItem("type",2500077)?info.attributes.getItem("type",2500077).value:0;
            info.force = 0;
            var blood = info.blood;
            var atk = info.attributes.getItem("type", 2500106)?info.attributes.getItem("type", 2500106).value:0;
            var def = info.attributes.getItem("type", 2500106)?info.attributes.getItem("type", 2500107).value:0;
            var miss = info.attributes.getItem("type", 2500106)?info.attributes.getItem("type", 2500108).value:0;
            var circ = info.attributes.getItem("type", 2500106)?info.attributes.getItem("type", 2500109).value:0;
            var circa = info.attributes.getItem("type", 2500106)?info.attributes.getItem("type", 2500110).value:0;
            info.force = Math.floor((blood+ atk*10+ def*8 + (atk+def)*(miss+circ +(circa-1)*500)/1000 ));
            //（兵力+ 攻击*10+ 防御*8 + （攻击+防御）* （闪避率+暴击 +（暴击倍数-1）*500）/1000 ）
        } else {
        }
        if (!roler) {
            roler = mapData.myArmyList.getItem("id", info.id);
            if (!roler) {
                roler = DataManager.getInstance().getNewData("MapRolerData");
                info.config = modelMgr.call("Table", "getTableItemByValue", ["Arm", info.type]);
                if (!info.config) {
                    info.config = modelMgr.call("Table", "getTableItemByValue", ["monster", info.type]);
                    info.relation = "monster";
                    info.showBlood = true;
                    trace("怪物!!!", info.coordX, info.coordY, info.type);
                } else {
                    if (info.userAccount == mainData.playerData.account) {
                        info.relation = "myself";
                        info.showBlood = mainData.uiData.map.inFight;
                    } else {
                        trace("敌人部队", mainData.enemyList.getItem("account", info.userAccount));
                        if (mainData.enemyList.getItem("account", info.userAccount)) {
                            info.relation = "enemy";
                            info.showBlood = true;
                            trace("显示血量");
                        } else {
                            info.relation = "other";
                            info.showBlood = false;
                            trace("不显示血量");
                        }
                    }
                }
                roler.receive(info);
                this.addBalk(info.id, info.type, roler.coordX, roler.coordY);
                if (roler.userAccount == mainData.playerData.account) {
                    mapData.myArmyList.push(roler);
                }
            } else {
                //this.delBalk(info.id, info.type, roler.coordX, roler.coordY);
                roler.receive(info);
                this.addBalk(info.id, info.type, roler.coordX, roler.coordY);
            }
            if (roler.inCity == false) {
                mapData.armyList.push(roler);
            }
        } else {
            var coordX = roler.coordX;
            var coordY = roler.coordY;
            this.delBalk(info.id, info.type, roler.coordX, roler.coordY);
            roler.receive(info);
            this.addBalk(info.id, info.type, roler.coordX, roler.coordY);
            if (roler.inCity == true) {
                this.delBalk(info.id, info.type, roler.coordX, roler.coordY);
                mapData.armyList.delItem("id", roler.id);
                roler.selected = false;
            }
            if (coordX != roler.coordX || coordY != roler.coordY) {
                roler.positionChange++;
            }
        }
        if (roler.userAccount == mainData.playerData.account) {
            this.rolerPathChange(roler);
        }
        if(roler.userAccount == mainData.playerData.account) {
            this.countCastleForce(roler);
        }
    }
}

MapDataCommand.prototype.countCastleForce = function(armyData) {
    var castleData = mainData.mapData.myCastleList.getItem("id",armyData.castleId);
    var armyList = mainData.mapData.myArmyList.getItems("castleId",castleData.id);
    var force = 0;
    for(var i = 0; i < armyList.length; i++) {
        armyData = armyList[i];
        force += armyData.force;
    }
    castleData.force = force;
    trace("城堡战斗力:",castleData.force,armyList.length);
}

MapDataCommand.prototype.rolerPathChange = function (roler) {
    var rolerPath = mainData.mapData.myRolerPathList.getItem("rolerData", roler);
    if (rolerPath) {
        if (rolerPath.endPoint.x == roler.coordX && rolerPath.endPoint.y == roler.coordY) {
            mainData.mapData.myRolerPathList.delItem("rolerData", roler);
        } else {
            var path = rolerPath.path;
            var find = false;
            for (var i = 0; i < path.length; i++) {
                var point = path.getItemAt(i);
                if (point.x == roler.coordX && point.y == roler.coordY) {
                    find = true;
                    break;
                } else {
                    path.delItemAt(i);
                    i--;
                }
            }
            if (!find) {
                trace("没有找到对应的点，所以删除", roler.coordX, roler.coordY, flower.ObjectDo.toString(path));
                mainData.mapData.myRolerPathList.delItem("rolerData", roler);
            }
        }
    }
}

MapDataCommand.prototype.recvRemoveCastleArmy = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    if (info.type == 1205001) {
        mainData.mapData.myCastleList.delItem("id", info.id);
        mainData.mapData.castleList.delItem("id", info.id);
    } else {
        var army = mainData.mapData.myArmyList.delItem("id", info.id);
        mainData.mapData.armyList.delItem("id", info.id);
        if(army) {
            mainData.mapData.myRolerPathList.delItem("rolerData", army);
            if(ModelManager.getInstance().call("Table","getTableItemByValue",["sounds",army.config.arm_type + "_die.mp3"])) {
                SoundPlay.playEffect("res/sounds/" + army.config.arm_type + "_die.mp3");
            }
            if(army.userAccount == mainData.playerData.account) {
                this.countCastleForce(army);
            }
        }
    }
}

/*
 地块信息
 */
MapDataCommand.prototype.recvEarthData = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    var position = MapUtils.transPointToPosition(info.coordX, info.coordY);
    info.showX = position.x;
    info.showY = position.y;
    info.capacity = info.capacity||1;
    var testTable = modelMgr.call("Table", "getTableItemByValue", ["item", info.earthCard]);
    info.level = parseInt(testTable.type);
    info.config = ModelManager.getInstance().call("Table","getTableItemByValue",["Territory_levelup",info.earthCard]);

    if (info.user == mainData.playerData.account) {
        info.relation = "myself";
    } else {
        if (mainData.enemyList.getItem("account", info.user)) {
            info.relation = "enemy";
        } else {
            info.relation = "other";
        }
    }
    var mapData = mainData.mapData;
    var earth = mapData.earthList.getItem("coordX", info.coordX, "coordY", info.coordY);
    if (!earth) {
        earth = mapData.myEarthList.getItem("coordX", info.coordX, "coordY", info.coordY);
        if (!earth) {
            earth = DataManager.getInstance().getNewData("MapEarthData");
            earth.receive(info);
            if (info.user == mainData.playerData.account) {
                mapData.myEarthList.push(earth);
            }
        } else {
            earth.receive(info);
        }
        if (info.user != mainData.playerData.account) {
            this.addBalk("", 0, earth.coordX, earth.coordY);
        }
        mapData.earthList.push(earth);
    } else {
        if (info.user == mainData.playerData.account) {
            earth.receive(info);
        } else {
            this.delBalk("", 0, earth.coordX, earth.coordY);
            earth.receive(info);
            this.addBalk("", 0, earth.coordX, earth.coordY);
        }
    }
}

/**
 *
 * @param type 类型为 1205001 则是城堡，其它占地1格
 * @param x
 * @param y
 */
MapDataCommand.prototype.addBalk = function (id, type, x, y) {
    var flag = -1;
    var rect = mainData.mapData.cameraData.viewPort;
    x -= rect.x;
    y -= rect.y;
    var width = mainData.mapData.pathData.width;
    var paths = mainData.mapData.pathData.paths;
    if (!paths.length) return;
    var points = [];
    if (type == 1205001) {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            paths[x + y * width].list.push(id);
            points.push(x + y * width);
            points.push(x - 1 + y * width);
            points.push(x + 1 + y * width);
            if (y % 2 == 0) {
                points.push(x - 1 + (y - 1) * width);
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x - 1 + (y + 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
            } else {
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x + 2 + (y - 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
                points.push(x + 2 + (y + 1) * width);
            }
        }
    } else {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            paths[x + y * width].list.push(id);
            points.push(x + y * width);
        }
    }
    for (var i = 0; i < points.length; i++) {
        if (points[i] >= 0 && points[i] < paths.length) {
            paths[points[i]].path += flag;
        }
    }
}

MapDataCommand.prototype.delBalk = function (id, type, x, y) {
    var flag = 1;
    var rect = mainData.mapData.cameraData.viewPort;
    x -= rect.x;
    y -= rect.y;
    var width = mainData.mapData.pathData.width;
    var paths = mainData.mapData.pathData.paths;
    if (!paths.length) return;
    var points = [];
    if (type == 1205001) {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            //16  18  32  1120  592
            var list = paths[x + y * width].list;
            var find = false;
            for (var i = 0; i < list.length; i++) {
                if (list[i] == id) {
                    list.splice(i, 1);
                    find = true;
                    break;
                }
            }
            if (!find) return;
            points.push(x + y * width);
            points.push(x - 1 + y * width);
            points.push(x + 1 + y * width);
            if (y % 2 == 0) {
                points.push(x - 1 + (y - 1) * width);
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x - 1 + (y + 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
            } else {
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x + 2 + (y - 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
                points.push(x + 2 + (y + 1) * width);
            }

        }
    } else {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            var list = paths[x + y * width].list;
            var find = false;
            for (var i = 0; i < list.length; i++) {
                if (list[i] == id) {
                    list.splice(i, 1);
                    find = true;
                    break;
                }
            }
            if (!find) return;
            points.push(x + y * width);
        }
    }
    for (var i = 0; i < points.length; i++) {
        if (points[i] >= 0 && points[i] < paths.length) {
            paths[points[i]].path += flag;
        }
    }
}

MapDataCommand.prototype.recvResource = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    var mapRemove = ServerMapConfig.getInstance().getRemoveByKey(info.key);
    trace("收到可移除资源:", info.key, info.serverX, info.serverY);
    var mapRemovePos = MapUtils.transPointToPosition(mapRemove.blocks[0].x, mapRemove.blocks[0].y);
    info.coordX = mapRemove.blocks[0].x + info.serverX;
    info.coordY = mapRemove.blocks[0].y + info.serverY;
    var serverPos = MapUtils.transPointToPosition(info.serverX, info.serverY);
    info.showX = serverPos.x + mapRemovePos.x;
    info.showY = serverPos.y + mapRemovePos.y;
    trace("可移除", info.coordX, info.coordY, mapRemove.type);
    var tableConfig = modelMgr.call("Table", "getTableItemByValue", ["remove", mapRemove.type]);
    if (tableConfig) {
        info.product = tableConfig.product;
        info.allResource = mapRemove.count * tableConfig.number;
    }
    info.config = mapRemove;
    var resource = mainData.mapData.resourceList.getItem("showX", info.showX, "showY", info.showY);
    if (!resource) {
        resource = DataManager.getInstance().getNewData("MapResourceData");
        resource.receive(info);
        mainData.mapData.resourceList.push(resource);
    } else {
        resource.receive(info);
    }
    resource.points.removeAll();
    for (var i = 0; i < mapRemove.blocks.length; i++) {
        var point = DataManager.getInstance().getNewData("PointData");
        point.x = mapRemove.blocks[i].x + info.serverX;
        point.y = mapRemove.blocks[i].y + info.serverY;
        resource.points.push(point);
    }
    trace("发现可移除物资:", resource.config, resource.coordX, resource.coordY);//,flower.ObjectDo.toString(resource.points));
    //trace("发现可移除物资:", resource.config, resource.coordX, resource.coordY, resource.showX, resource.showY, resource.product, resource.allResource, mapRemove.blocks[0].x, mapRemove.blocks[0].y);
}

MapDataCommand.prototype.recvRemoveResource = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    var mapRemove = ServerMapConfig.getInstance().getRemoveByKey(info.key);
    var mapRemovePos = MapUtils.transPointToPosition(mapRemove.blocks[0].x, mapRemove.blocks[0].y);
    info.coordX = mapRemove.blocks[0].x + info.serverX;
    info.coordY = mapRemove.blocks[0].y + info.serverY;
    var serverPos = MapUtils.transPointToPosition(info.serverX, info.serverY);
    info.showX = serverPos.x + mapRemovePos.x;
    info.showY = serverPos.y + mapRemovePos.y;
    var item = mainData.mapData.resourceList.delItem("showX", info.showX, "showY", info.showY);
    trace("移除对象", info.showX, info.showY, info.coordX, info.coordY, item);
}

MapDataCommand.prototype.recvMoveOver = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    //trace("移动结束",info.id, info.action, info.errorCode, info.errorMessage);
    var rolerPath = mainData.mapData.myRolerPathList.getItemFunction(function (item) {
        return item.rolerData.id == info.id ? true : false;
    });
    if (rolerPath) {
        mainData.mapData.myRolerPathList.delItem("rolerData", rolerPath.rolerData);
    }
}

MapDataCommand.prototype.recvServerList = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    trace(info.list.len);
    for (var i = 0; i < info.list.length; i++) {
        var serverInfo = info.list.getItemAt(i);
        var server = DataManager.getInstance().getNewData("ServerData");
        server.pointX = serverInfo.x;
        server.pointY = serverInfo.y;
        server.x = serverInfo.x / info.width;
        server.y = serverInfo.y / info.height;
        server.width = info.width;
        server.height = info.height;
        server.name = serverInfo.name;
        server.positionX = server.x * ServerMapConfig.getInstance().serverMapWidth;
        server.positionY = server.y * ServerMapConfig.getInstance().serverMapHeight;
        server.positionWidth = ServerMapConfig.getInstance().serverMapWidth;
        server.positionHeight = ServerMapConfig.getInstance().serverMapHeight;
        mainData.serverList.push(server);
        trace("[服务器]", server.x, server.y, server.width, server.height, server.name, server.positionX, server.positionY);
    }
}

MapDataCommand.prototype.recvAttackInfo = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    var attack = DataManager.getInstance().getNewData("AttackData");
    attack.receive(info);
    attack.roler = mainData.mapData.armyList.getItem("id", info.rolerId);
    attack.aim = mainData.mapData.armyList.getItem("id", info.aimId);
    if (attack.roler) {
        trace("攻击消息:", attack.roler.id, attack.roler.coordX, attack.roler.coordY, attack.aimX, attack.aimY);
    } else {
        return;
    }
    mainData.mapData.attack = attack;
}

MapDataCommand.prototype.recvFightResource = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    var resource = mainData.mapData.fightResourceList.getItem("coordX", info.coordX, "coordY", info.coordY);
    if (resource == null) {
        var pos = MapUtils.transPointToPosition(info.coordX, info.coordY);
        info.showX = pos.x;
        info.showY = pos.y;
        resource = DataManager.getInstance().getNewData("MapFightResourceData");
        resource.receive(info);
        mainData.mapData.fightResourceList.push(resource);
    } else {
        resource.receive(info);
    }
    trace("战略资源", info.coordX, info.coordY, mainData.mapData.fightResourceList.length);
}

MapDataCommand.prototype.recvRemoveFightResource = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    mainData.mapData.fightResourceList.delItem("coordX", info.coordX, "coordY", info.coordY);
}

MapDataCommand.prototype.onAddEnemy = function (enemyData) {
    var armyList = mainData.mapData.armyList.getItems("userAccount", enemyData.account);
    for (var i = 0; i < armyList.length; i++) {
        var army = armyList[i];
        army.relation = "enemy";
        army.showBlood = true;
    }
    var castleList = mainData.mapData.castleList.getItems("userAccount", enemyData.account);
    for (var i = 0; i < castleList.length; i++) {
        var castle = castleList[i];
        castle.relation = "enemy";
    }
    var earthList = mainData.mapData.earthList.getItems("user", enemyData.account);
    for (var i = 0; i < earthList.length; i++) {
        var earth = earthList[i];
        earth.relation = "enemy";
    }
}

MapDataCommand.prototype.onDelEnemy = function (enemyData) {
    var armyList = mainData.mapData.armyList.getItems("userAccount", enemyData.account);
    for (var i = 0; i < armyList.length; i++) {
        var army = armyList[i];
        army.relation = "other";
        army.showBlood = false;
    }
    var castleList = mainData.mapData.castleList.getItems("userAccount", enemyData.account);
    for (var i = 0; i < castleList.length; i++) {
        var castle = castleList[i];
        castle.relation = "other";
    }
    var earthList = mainData.mapData.earthList.getItems("user", enemyData.account);
    for (var i = 0; i < earthList.length; i++) {
        var earth = earthList[i];
        earth.relation = "other";
    }
}

MapDataCommand.prototype.changeFightState = function (bool) {
    var armyList = mainData.mapData.myArmyList;
    for (var i = 0; i < armyList.length; i++) {
        var army = armyList.getItemAt(i);
        army.showBlood = bool;
    }
}

MapDataCommand.prototype.recvArmyPath = function (cmd, data) {
    var info = NetCompiler.decode(cmd, data);
    //if (info.action == 0) {
    //    return;
    //}
    var army = mainData.mapData.myArmyList.getItem("id", info.id);
    if (army) {
        mainData.mapData.myRolerPathList.delItem("rolerData", army);
        var rolerPath = DataManager.getInstance().getNewData("RolerPath");
        rolerPath.rolerData = army;
        rolerPath.action = info.action;
        var x = info.coordX;
        var y = info.coordY;
        for (var i = 0; i < info.path.length; i++) {
            var searchPoint = DataManager.getInstance().getNewData("PointData");
            var coord = info.path.getItemAt(i);
            x += coord.x;
            y += coord.y;
            searchPoint.x = x;
            searchPoint.y = y;
            if (i == info.path.length - 1) {
                rolerPath.endPoint = searchPoint;
            } else {
                rolerPath.path.push(searchPoint);
            }
        }
        //trace("rolerPath:", flower.ObjectDo.toString(rolerPath.path));
        mainData.mapData.myRolerPathList.push(rolerPath);
    }
}


MapDataCommand.prototype.recvDropItemInfo = function(cmd,data) {
    var info = NetCompiler.decode(cmd, data);
    trace("物品掉落啦啦啦");
    for(var i = 0; i < info.items.length; i++) {
        var itemInfo = info.items.getItemAt(i);
        var item = DataManager.getInstance().getNewData("ItemData");
        item.id = itemInfo.id;
        item.count = itemInfo.count;
        trace("物品掉落",item.id);
        mainData.mapData.dropItem = item;
    }
    for(var i = 0; i < info.items2.length; i++) {
        var itemInfo = info.items2.getItemAt(i);
        var item = DataManager.getInstance().getNewData("ItemData");
        item.id = itemInfo.id;
        item.count = itemInfo.count;
        trace("物品掉落",item.id);
        mainData.mapData.dropItem = item;
    }
}
