function ServerMapConfig() {
    ServerMapConfig.instance = this;
    //地图配置
    this.config = null;
    //获取地图配置等待返回列表 item:{back:Function,thisObj:any}
    this.loadList = [];

    //地图列表
    this.maps = null;

    this.path = "res/fight/maps/server0.json";

    //源地图配置
    this.mapsources = null;
    //一个服务器地图的像素宽
    this.serverMapWidth = null;
    //一个服务器地图的像素高
    this.serverMapHeight = null;
    //一个服务器的格子宽
    this.serverCoordWidth = null;
    //一个服务器的格子高
    this.serverCoordHeight = null;
    //所有背景列表，二维数组，以 MapUtils.singleWidth 和 MapUtils.singleHeight 划分
    this.background = null;
    //所有地块信息
    this.blocks = null;
    //可移除对象
    this.removes = null;
    //寻路
    this.astar = null;
    var _this = this;
    //注意这里的cc.loader 实际上是立刻返回的。
    cc.loader.loadJson(this.path, function (error, data) {
        if (error) {
            console.log("加载配置失败:" + _this.path);
        } else {
            console.log("服务器地图加载完毕");
            _this.config = data;
            _this.loadConfigBack();
            _this.initMapInfo();
        }
    });
}

ServerMapConfig.prototype.initMapInfo = function () {
    this.serverMapWidth = this.getMapCountCol() * MapUtils.mapWidth;
    this.serverMapHeight = this.getMapCountRow() * MapUtils.mapHeight;
    this.serverCoordWidth = this.getMapCountCol() * MapUtils.blockWidth;
    this.serverCoordHeight = this.getMapCountCol() * MapUtils.blockHeight;
    trace("地图配置:", this.getMapCountRow(), MapUtils.mapHeight,this.serverMapWidth,this.serverMapHeight);
    var list = [
        "map_0_0","map_0_1",
        "map_3_4","map_3_5",
        "map_4_5","map_4_15",
        "map_5_3",
        "map_6_7","map_6_8",
        "map_7_6",
        "map_8_6",
        "map_10_9","map_10_12",
        "map_11_7","map_11_8","map_11_12",
        "map_12_7","map_12_8","map_12_12",
        "map_13_15",
        "map_14_3","map_14_4",
        "map_15_4","map_15_5","map_15_15"];

    this.mapsources = {};
    for (var i = 0; i < list.length; i++) {
        this.mapsources[list[i]] = new MapSourceConfig(list[i]);
    }
    this.background = [];
    this.blocks = [];
    this.removes = [];
    var sources = [
        {
            width: MapUtils.singleWidth,
            height: MapUtils.singleHeight,
            moreX: 1,
            moreY: 1,
            col: 3,
            row: 3,
            source: null,
            list: []
        },
        {
            width: MapUtils.singleWidth / 2,
            height: MapUtils.singleHeight / 2,
            moreX: 1,
            moreY: 1,
            col: 6,
            row: 6,
            source: null,
            list: []
        }
    ];
    //地图阵列 (fight/maps/server0.json).map
    var maps = this.maps;
    var iy;
    for (var s = 0; s < sources.length; s++) {
        for (var y = 0; y < maps.length + sources[s].moreY; y++) {
            iy = (y + maps.length) % maps.length;
            for (var x = 0; x < maps[iy].length + sources[s].moreX; x++) {
                var ix = (x + maps[iy].length) % maps[iy].length;
                //var map = this.mapsources[maps[iy][ix]];
                var map = this.mapsources[maps[iy][ix]];
                if (s == 0 && y < maps.length && x < maps[iy].length) {
                    var blocks = map.blocks;
                    for (var by = 0; by < blocks.length; by++) {
                        for (var bx = 0; bx < blocks[by].length; bx++) {
                            if (!this.blocks[by + y * MapUtils.blockHeight]) {
                                this.blocks[by + y * MapUtils.blockHeight] = [];
                            }
                            this.blocks[by + y * MapUtils.blockHeight][bx + x * MapUtils.blockWidth] = blocks[by][bx];
                        }
                    }
                    var removes = map.removes;
                    for (var r = 0; r < removes.length; r++) {
                        var remove = removes[r];
                        var newRemove = {
                            key: x + "_" + y + remove.key,
                            type: remove.type,
                            count: remove.count,
                            blocks: [],
                            items: []
                        };
                        //trace(" ");
                        //trace(" ");
                        //trace("新的移除组:", newRemove.key, newRemove.type);
                        for (var rb = 0; rb < remove.blocks.length; rb++) {
                            newRemove.blocks.push({
                                x: remove.blocks[rb].x + x * MapUtils.blockWidth,
                                y: remove.blocks[rb].y + y * MapUtils.blockHeight
                            });
                            //trace("新的移除格子:",rb, newRemove.blocks[newRemove.blocks.length - 1].x, newRemove.blocks[newRemove.blocks.length - 1].y);
                        }
                        for (var ri = 0; ri < remove.items.length; ri++) {
                            newRemove.items[ri] = [];
                            for (var index = 0; index < remove.items[ri].length; index++) {
                                newRemove.items[ri][index] = remove.items[ri][index];
                            }
                            //newRemove.items[ri][1] += x * MapUtils.blockWidth * MapUtils.width;
                            //newRemove.items[ri][2] += y * MapUtils.blockHeight * MapUtils.height;
                            //trace("新的移除物品:",ri, newRemove.items[ri][0], newRemove.items[ri][1], newRemove.items[ri][2]);
                        }
                        this.removes.push(newRemove);
                    }
                }
                sources[0].source = map.background;
                sources[1].source = map.items;
                var bg;
                if (!this.background[s]) {
                    this.background[s] = sources[s];
                }
                bg = this.background[s].list;
                for (var i = 0; i < sources[s].source.length; i++) {
                    var item = sources[s].source[i];
                    var bgx, bgy;
                    bgx = item.coordX;
                    bgy = item.coordY;
                    bgx += x * sources[s].col;
                    bgy += y * sources[s].row;
                    if (!bg[bgy]) {
                        bg[bgy] = [];
                    }
                    bg[bgy][bgx] = {
                        offX: x * MapUtils.mapWidth,
                        offY: y * MapUtils.mapHeight,
                        item: item
                    };
                }
            }
        }
    }

    //寻路路点信息
    /*var str;
     var paths = [];
     var pathArray = [];
     for (y = 0; y < this.blocks.length; y++) {
     paths[y] = [];
     str = "["
     for (x = 0; x < this.blocks[y].length; x++) {
     this.blocks[y][x].type = this.blocks[y][x].type;
     pathArray.push(this.blocks[y][x].type == 1608001 ? 0 : 1);
     paths[y][x] = this.blocks[y][x].type == 1608001 ? 0 : 1;
     str += this.blocks[y][x].type + (x < this.blocks[y].length - 1 ? "," : "");
     }
     str += "]" + (y < this.blocks.length - 1 ? "," : "");
     //trace(str);
     }
     //trace("]}");
     mainData.mapData.pathData.width = this.blocks[0].length;
     mainData.mapData.pathData.height = this.blocks.length;
     mainData.mapData.pathData.paths = pathArray;*/
    //trace("服务器地图数据：",mainData.mapData.pathData.width,mainData.mapData.pathData.height,this.blocks[1].length);
    this.astar = new AStarSix();//mainData.mapData.pathData.paths, mainData.mapData.pathData.width, mainData.mapData.pathData.height);

    mainData.mapData.cameraData.addListener("viewPort", this.viewPortChange, this);
}

ServerMapConfig.prototype.viewPortChange = function () {

    var rect = mainData.mapData.cameraData.viewPort;
    var block;
    var blocks = [];
    trace("重新设置路点", rect.x, rect.y, rect.width, rect.height);
    for (var y = rect.y; y < rect.y + rect.height; y++) {
        for (var x = rect.x; x < rect.x + rect.width; x++) {
            block = this.getBlock(x, y);
            if (x == -51 && y == 314) {
                trace(x, y, block.type, blocks.length);
            }
            blocks.push({"path": block.type == 1608001 ? 0 : 1, "list": []});
        }
    }
    var list = mainData.mapData.castleList;
    var item;
    for (var i = 0; i < list.length; i++) {
        item = list.getItemAt(i);
        this.addPath(blocks, rect.width, rect, item.id, item.type, item.coordX, item.coordY);
    }
    list = mainData.mapData.armyList;
    for (i = 0; i < list.length; i++) {
        item = list.getItemAt(i);
        this.addPath(blocks, rect.width, rect, item.id, item.type, item.coordX, item.coordY);
    }
    mainData.mapData.pathData.width = rect.width;
    mainData.mapData.pathData.height = rect.height;
    mainData.mapData.pathData.paths = blocks;
    this.astar.setBlocks(blocks, rect.width, rect.height, rect.x, rect.y);
}

/**
 *
 * @param type 类型为 1205001 则是城堡，其它占地1格
 * @param x
 * @param y
 */
ServerMapConfig.prototype.addPath = function (paths, width, rect, id, type, x, y) {
    x -= rect.x;
    y -= rect.y;
    if (!paths.length) return;
    var points = [];
    if (type == 1205001) {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            paths[x + y * width].list.push(id);
            points.push(x + y * width);
            points.push(x - 1 + y * width);
            points.push(x + 1 + y * width);
            if (y % 2 == 0) {
                points.push(x - 1 + (y - 1) * width);
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x - 1 + (y + 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
            } else {
                points.push(x + 0 + (y - 1) * width);
                points.push(x + 1 + (y - 1) * width);
                points.push(x + 2 + (y - 1) * width);
                points.push(x + 0 + (y + 1) * width);
                points.push(x + 1 + (y + 1) * width);
                points.push(x + 2 + (y + 1) * width);
            }
        }
    } else {
        if (x >= 0 && x < rect.width && y >= 0 && y < rect.height) {
            var find = false;
            paths[x + y * width].list.push(id);
            points.push(x + y * width);
        }
    }
    for (var i = 0; i < points.length; i++) {
        if (points[i] >= 0 && points[i] < paths.length) {
            paths[points[i]].path += -1;
        }
    }
}

ServerMapConfig.prototype.loadConfigBack = function () {
    console.log("服务器配置：" + this.config);
    this.maps = this.config.maps;
}

ServerMapConfig.prototype.getMapCountCol = function () {
    return this.maps[0].length;
}

ServerMapConfig.prototype.getMapCountRow = function () {
    return this.maps.length;
}

/**
 * 获取服务器信息
 * @param x
 * @param y
 * @returns ServerData
 */
ServerMapConfig.prototype.getServerData = function (x, y) {
    for (var i = 0; i < mainData.serverList.length; i++) {
        var server = mainData.serverList.getItemAt(i);
        if (x >= server.pointX && x < server.pointX + server.width &&
            y >= server.pointY && y < server.pointY + server.height) {
            return server;
        }
    }
    return null;
}


/**
 * 获得一个区域范围内的背景列表
 * @param x
 * @param y
 * @param width
 * @param height
 */
ServerMapConfig.prototype.getBackgroundList = function (index, x, y, width, height) {
    var info = this.background[index];
    //trace("info:", info.width, info.height);
    var background = info.list;
    var blockWidth = info.width;
    var blockHeight = info.height;
    //trace("获取区域内背景" + index + "：", x, y, width, height, background.length, blockWidth, blockHeight);
    var addX = x;
    var addY = y;
    if (x < 0) {
        while (x < 0) {
            x += this.serverMapWidth;
        }
    } else {
        x = x % this.serverMapWidth;
    }
    if (y < 0) {
        while (y < 0) {
            y += this.serverMapHeight;
        }
    } else {
        y = y % this.serverMapHeight;
    }
    //trace("转换后坐标:", x, y, this.serverMapWidth, this.serverMapHeight);
    addX = addX - x;
    addY = addY - y;
    var ex = x + width;
    var ey = y + height;
    //trace("获取区域内背景" + index + "：", x, y, ex, ey);
    x = Math.floor(x / blockWidth);
    y = Math.floor(y / blockHeight);
    ex = Math.floor(ex / blockWidth);
    ey = Math.floor(ey / blockHeight);
    var list = [];
    //trace("遍历" + index + "：", x, y, ex, ey, addX, addY);
    for (var j = y; j <= ey; j++) {
        for (var i = x; i <= ex; i++) {
            list = list.concat(background[j][i]);
            //trace("背景：", background[j][i].item.url, background[j][i].offX + background[j][i].item.x,
            //    background[j][i].offY + background[j][i].item.y, j, i, background[j][i].offX, background[j][i].offY);
        }
    }
    //trace("获取完毕");
    return {
        addX: addX,
        addY: addY,
        list: list
    };
}

/**
 * 返回区域内的所有可移除对象
 * @param x
 * @param y
 * @param ex
 * @param ey
 */
ServerMapConfig.prototype.getRemovesList = function (x, y, ex, ey) {
    trace("获取范围内可移除资源：", x, y, ex, ey);
    var remove;
    var list = [];
    for (var i = 0; i < this.removes.length; i++) {
        remove = this.removes[i];
        var blocks = remove.blocks;
        for (var b = 0; b < blocks.length; b++) {
            var block = blocks[b];
            if (block.x >= x && block.x <= ex && block.y >= y && block.y <= ey) {
                list.push(remove);
                break;
            }
        }
    }
    return list;
}

/**
 * 根据坐标查找可移除对象
 * @param x
 * @param y
 * @returns {*}
 */
ServerMapConfig.prototype.getRemoveByKey = function (key) {
    var remove;
    for (var i = 0; i < this.removes.length; i++) {
        remove = this.removes[i];
        if (remove.key == key) {
            return remove;
        }
    }
    return null;
}

ServerMapConfig.hill = {
    "type": 1608001
}
/**
 * 获取地块地形信息
 * @param x 坐标 x，不要传位置坐标，传格子坐标
 * @param y
 * @returns {type:地形类型}
 */
ServerMapConfig.prototype.getBlock = function (x, y) {
    var maxX = MapUtils.blockWidth * this.getMapCountCol();
    var maxY = MapUtils.blockHeight * this.getMapCountRow();
    if (x < 0) {
        while (x < 0) {
            x += maxX;
        }
    } else {
        x = x % maxX;
    }
    if (y < 0) {
        while (y < 0) {
            y += maxY;
        }
    } else {
        y = y % maxY;
    }
    if (x <= 1 || x >= maxX - 2 || y <= 1 || y >= maxY - 2) {
        return ServerMapConfig.hill;
    }
    return this.blocks[y][x];
}

/**
 * 获取地块地形信息
 * @param x 坐标 x，不要传位置坐标，传格子坐标
 * @param y
 * @returns {*}
 */
ServerMapConfig.prototype.isPath = function (x, y) {
    var rect = mainData.mapData.cameraData.viewPort;
    var width = rect.width;
    x -= rect.x;
    y -= rect.y;
    return mainData.mapData.pathData.paths[x + y * width].path <= 0 ? false : true;
}

ServerMapConfig.prototype.isPathOnlyHas = function (x, y, id) {
    var rect = mainData.mapData.cameraData.viewPort;
    var width = rect.width;
    var ox = x;
    var oy = y;
    x -= rect.x;
    y -= rect.y;
    var list = mainData.mapData.pathData.paths[x + y * width].list;
    if (ox == -11 && oy == 449) {
        trace("判断点上是否有这个id", ox, oy, list.length, list[0], list[1]);
    }
    if (list.length == 1 && list[0] == id) {
        return true;
    }
    return false;
}

ServerMapConfig.prototype.getServerCoord = function (x, y) {
    return {
        x: Math.floor(x / this.serverCoordWidth),
        y: Math.floor(y / this.serverCoordHeight)
    };
}

ServerMapConfig.prototype.changeToServerPoint = function (x, y) {
    if (x >= 0) {
        x = x % this.serverCoordWidth;
    } else {
        x = x % this.serverCoordWidth + this.serverCoordWidth;
    }
    if (y >= 0) {
        y = y % this.serverCoordHeight;
    } else {
        y = y % this.serverCoordHeight + this.serverCoordHeight;
    }
    return {
        x: x,
        y: y
    };
}

ServerMapConfig.instance = null;

ServerMapConfig.getInstance = function () {
    return ServerMapConfig.instance;
}