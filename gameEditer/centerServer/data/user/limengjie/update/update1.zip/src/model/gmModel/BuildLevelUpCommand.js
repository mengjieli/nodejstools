function BuildLevelUpCommand() {
    console.log("进入自动升级命令");

    //string      mapObjectUuid   //
    //uint        buildingBaseId  // 地图内地基 ID
    var list = [];
    for (var i = 0; i < 13; i++) {
        list.push(
            {
                "type": "level",
                "id": 16
            }
        );
        list.push(
            {
                "type": "speed",
                "id": 16,
                "itemId": 2001003,
                "count": 30
            }
        );


        list.push(
            {
                "type": "level",
                "id": 9
            }
        );
        list.push(
            {
                "type": "speed",
                "id": 9,
                "itemId": 2001003,
                "count": 30
            }
        );


        list.push(
            {
                "type": "level",
                "id": 10
            }
        );
        list.push(
            {
                "type": "speed",
                "id": 10,
                "itemId": 2001003,
                "count": 30
            }
        );


        list.push(
            {
                "type": "level",
                "id": 15
            }
        );
        list.push(
            {
                "type": "speed",
                "id": 15,
                "itemId": 2001003,
                "count": 30
            }
        );
    }
    var castleId = mainData.uiData.currentCastleId;
    var func = function () {
        var item = list.shift();
        if(item.type == "level") {
            var msg = new SocketBytes();
            msg.writeUint(403);
            msg.writeString(castleId);
            msg.writeUint(item.id);
            NetMgr.inst().send(msg);
        } else if(item.type == "speed") {
            var msg = new SocketBytes();
            msg.writeUint(415);
            msg.writeString(castleId);
            msg.writeUint(item.id);
            msg.writeUint(item.itemId);
            msg.writeUint(item.count);
            NetMgr.inst().send(msg);
        }
        if(list.length) {
            setTimeout(func, 500);
        } else {
            console.log("执行完毕");
        }
    };
    setTimeout(func, 500);
}