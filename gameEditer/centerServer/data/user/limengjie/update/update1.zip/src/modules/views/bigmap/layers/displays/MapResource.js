var MapResource = MapDisplayBase.extend({
    shaderLayer: null,
    data: null,
    show: null,
    label: null,
    count: null,
    animation:null,
    countTxt:null,
    ctor: function (shaderLayer, data) {
        this._super(MapDisplayType.Resource);
        this.shaderLayer = shaderLayer;
        //可移除对象
        /*{
         key: "0_0_1",
         type: 1610001,
         blocks: [{
         x:24,
         y:15
         }],
         items: [[
         "item_2_128",//图片名称
         2140, //位置 x
         1752, //位置 y
         0, //旋转
         1, //缩放 x
         1, //缩放 y
         1, //透明度
         162, //层次
         3  //可移除索引
         ]]
         }*/
        this.data = data;
        this.setPos(this.data.showX, this.data.showY);

        var config = this.data.config;
        trace(" ");
        //trace("添加可砍伐资源", this.data.showX, this.data.showY);
        for (var i = 0; i < config.items.length; i++) {
            trace("资源",config.items[i][0]);
            var show = new cc.Sprite("res/fight/mapsource/item/" + config.items[i][0] + ".png");
            this.addChild(show);
            show.setAnchorPoint(0, 1);
            //trace(config.items[i][0],config.items[i][1],config.items[i][2]);
            show.setPosition(config.items[i][1], config.items[i][2]);
            show.setRotation(config.items[i][3]);
            show.setScaleX(config.items[i][4]);
            show.setScaleY(config.items[i][5]);
            show.setOpacity(config.items[i][6] * 255);
        }

        this.count = this.data.resource;

        this.data.addListener("resource", this.updateResourceCount, this);
    },
    updateResourceCount: function () {
        //trace("资源数量改变");
        if (this.data.resource == 0) {
            var a = new Animation(MapResource.cfg);
            this.shaderLayer.addChild(a);
            a.setPosition(this.px, this.py);
            a.play(1);
        } else {
            if (this.count > this.data.resource) {
                if(this.animation && this.animation.disposeFlag == false) {
                    this.animation.play(4);
                    this.countTxt.setString(this.data.resource);
                } else {
                    var a = new Animation(MapResource.resource[this.data.product]);
                    var sp = new cc.Sprite("res/fight/ui/resourceBg.png");
                    a.bg.addChild(sp);

                    //var msc = new cc.Sprite("res/fight/ui/resourceBg.png");

                    this.addChild(a);
                    a.play(4);
                    this.animation = a;

                    var countSp = new cc.Sprite("res/fight/ui/resourceCountBg.png");
                    var txt = new ccui.Text();
                    txt.setString(this.data.resource);
                    txt.setPosition(42+13,18);
                    txt.setFontSize(16);
                    txt.setColor({r:253,g:253,b:134,a:255});
                    this.countTxt = txt;
                    countSp.addChild(txt);
                    a.addChild(countSp);
                    countSp.setPosition(0,40);
                }
            }
            this.count = this.data.resource;
        }
    },
    isTouch: function (x, y) {
        var blocks = this.data.config.blocks;
        for (var i = 0; i < blocks.length; i++) {
            if (this.data.coordX + blocks[i].x - blocks[0].x == x && this.data.coordY + blocks[i].y - blocks[0].y == y) {
                return true;
            }
        }
        return false;
    },
    dispose:function(){
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
        this.data.removeListener("resource", this.updateResourceCount, this);
    }
});

MapResource.cfg = {
    plist: "res/fight/effect/resource/resourceComplete.plist",
    name: "resouceComplete_00",
    format: "png",
    start: 0,
    end: 4,
    frameRate: 6,
    x: 0,
    y: 0
};

MapResource.resource = {
    1101001: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 20,
        end: 27,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1101002: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 1,
        end: 8,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1101003: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 20,
        end: 27,
        frameRate: 12,
        x: 0,
        y: 0
    }
};