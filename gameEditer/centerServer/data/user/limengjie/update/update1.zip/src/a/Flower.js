var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Flower = (function (_super) {
    __extends(Flower, _super);
    function Flower() {
        _super.call(this);
        if (System.IDE == "flash") {
            System.stage = this["stage"];
        }
        new flower.Engine();
    }
    return Flower;
})(Sprite);
//# sourceMappingURL=Flower.js.map