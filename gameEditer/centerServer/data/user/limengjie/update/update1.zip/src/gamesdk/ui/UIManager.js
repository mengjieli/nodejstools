//var UIManager = (function (_super) {
//    __extends(UIManager, _super);
//    function UIManager() {
//        _super.call(this);
//    }
//
//    var d = __define, c = UIManager, p = c.prototype;
//
//    return UIManager;
//})(jc.B);