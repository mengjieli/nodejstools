var MapSprite = MapDisplayBase.extend({
    show: null,
    ctor: function (url) {
        this._super(MapDisplayType.BackGround);
        this.show = cc.Sprite(url);
        this.show.setAnchorPoint(0, 0);
        this.url = url
        this.addChild(this.show);
        if (MapSprite.useImage[url] == null) {
            MapSprite.useImage[url] = 0;
            //trace("添加新资源" , this.url);
        }
        MapSprite.useImage[url]++;
    },
    dispose: function () {
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
        MapSprite.useImage[this.url]--;
        if (MapSprite.useImage[this.url] == 0) {
            //trace("移除旧资源" , this.url);
            var txt = cc.TextureCache.getInstance().getTextureForKey(this.url);
            cc.TextureCache.getInstance().removeTexture(txt);
        }
    }
});

MapSprite.useImage = [];