var flower;
(function (flower) {
    var ArrayValue = (function () {
        function ArrayValue(initList) {
            this._key = "";
            this._rangeMinKey = "";
            this._rangeMaxKey = "";
            this._events = {};
            this.list = initList || [];
            this._length = this.list.length;
        }
        ArrayValue.prototype.push = function (item) {
            this.list.push(item);
            this.length = this._length + 1;
            this.dispatch("add", item);
        };
        ArrayValue.prototype.addItemAt = function (item, index) {
            index = +index & ~0;
            this.list.splice(index, 0, item);
            this.length = this._length + 1;
            this.dispatch("add", item);
        };
        ArrayValue.prototype.shift = function () {
            var item = this.list.shift();
            this.length = this._length - 1;
            this.dispatch("del", item);
        };
        ArrayValue.prototype.splice = function (startIndex, delCount) {
            if (delCount === void 0) { delCount = 0; }
            var args = [];
            for (var i = 0; i < arguments.length; i++) {
                if (i < 2)
                    continue;
                args.push(arguments[i]);
            }
            var i;
            delCount = +delCount & ~0;
            if (delCount <= 0) {
                var args = [];
                for (var i = 0; i < arguments.length; i++) {
                    if (i < 2)
                        continue;
                    args.push(arguments[i]);
                }
                for (i = 0; i < args.length; i++) {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        if (i < 2)
                            continue;
                        args.push(arguments[i]);
                    }
                    this.list.splice(startIndex, 0, args[i]);
                }
                this.length = this._length + 1;
                for (i = 0; i < args.length; i++) {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        if (i < 2)
                            continue;
                        args.push(arguments[i]);
                    }
                    this.dispatch("add", args[i]);
                }
            }
            else {
                var args = [];
                for (var i = 0; i < arguments.length; i++) {
                    if (i < 2)
                        continue;
                    args.push(arguments[i]);
                }
                var list = this.list.splice(startIndex, delCount);
                this.length = this._length - delCount;
                for (i = 0; i < list.length; i++) {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        if (i < 2)
                            continue;
                        args.push(arguments[i]);
                    }
                    this.dispatch("del", list[i]);
                }
            }
        };
        ArrayValue.prototype.slice = function (startIndex, end) {
            return flower.ArrayValue.create(this.list.slice(startIndex, end));
        };
        ArrayValue.prototype.pop = function () {
            var item = this.list.pop();
            this.length = this._length - 1;
            this.dispatch("del", item);
        };
        ArrayValue.prototype.removeAll = function () {
            while (this.length) {
                var item = this.list.pop();
                this.length = this._length - 1;
                this.dispatch("del", item);
            }
        };
        ArrayValue.prototype.delItemAt = function (index) {
            index = +index & ~0;
            var item = this.list.splice(index, 1)[0];
            this.length = this._length - 1;
            this.dispatch("del", item);
        };
        ArrayValue.prototype.delItem = function (key, value, key2, value2) {
            if (key2 === void 0) { key2 = ""; }
            if (value2 === void 0) { value2 = null; }
            var item;
            var i;
            if (key2 != "") {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value) {
                        item = this.list.splice(i, 1)[0];
                        break;
                    }
                }
            }
            else {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value && this.list[i][key2] == value2) {
                        item = this.list.splice(i, 1)[0];
                        break;
                    }
                }
            }
            if (!item) {
                return;
            }
            this.length = this._length - 1;
            this.dispatch("del", item);
            return item;
        };
        ArrayValue.prototype.getItem = function (key, value, key2, value2) {
            if (key2 === void 0) { key2 = ""; }
            if (value2 === void 0) { value2 = null; }
            var i;
            if (key2 != "") {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value) {
                        return this.list[i];
                    }
                }
            }
            else {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value && this.list[i][key2] == value2) {
                        return this.list[i];
                    }
                }
            }
            return null;
        };
        ArrayValue.prototype.getItemFunction = function (func, thisObj) {
            var args = [];
            for (var i = 0; i < arguments.length; i++) {
                if (i < 2)
                    continue;
                args.push(arguments[i]);
            }
            for (var i = 0; i < this.list.length; i++) {
                var args = [];
                for (var i = 0; i < arguments.length; i++) {
                    if (i < 2)
                        continue;
                    args.push(arguments[i]);
                }
                args.push(this.list[i]);
                var r = func.apply(thisObj, args);
                args.pop();
                if (r == true) {
                    var args = [];
                    for (var i = 0; i < arguments.length; i++) {
                        if (i < 2)
                            continue;
                        args.push(arguments[i]);
                    }
                    return this.list[i];
                }
            }
            return null;
        };
        ArrayValue.prototype.getItems = function (key, value, key2, value2) {
            if (key2 === void 0) { key2 = ""; }
            if (value2 === void 0) { value2 = null; }
            var result = [];
            var i;
            if (key2 != "") {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value) {
                        result.push(this.list[i]);
                    }
                }
            }
            else {
                for (i = 0; i < this.list.length; i++) {
                    if (this.list[i][key] == value && this.list[i][key2] == value2) {
                        result.push(this.list[i]);
                    }
                }
            }
            return result;
        };
        ArrayValue.prototype.setItemsAttribute = function (findKey, findValue, setKey, setValue) {
            if (setKey === void 0) { setKey = ""; }
            if (setValue === void 0) { setValue = null; }
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i][findKey] == findValue) {
                    this.list[i][setKey] = setValue;
                }
            }
        };
        ArrayValue.prototype.getItemsFunction = function (func, thisObj) {
            if (thisObj === void 0) { thisObj = null; }
            var _arguments__ = [];
            for (var argumentsLength = 0; argumentsLength < arguments.length; argumentsLength++) {
                _arguments__ = arguments[argumentsLength];
            }
            var result = [];
            var args = [];
            if (_arguments__.length && _arguments__.length > 2) {
                args = [];
                for (var a = 2; a < _arguments__.length; a++) {
                    args.push(_arguments__[a]);
                }
            }
            for (var i = 0; i < this.list.length; i++) {
                args.push(this.list[i]);
                var r = func.apply(thisObj, args);
                args.pop();
                if (r == true) {
                    result.push(this.list[i]);
                }
            }
            return result;
        };
        ArrayValue.prototype.sort = function () {
            var _arguments__ = [];
            for (var argumentsLength = 0; argumentsLength < arguments.length; argumentsLength++) {
                _arguments__ = arguments[argumentsLength];
            }
            this.list.sort.apply(this.list.sort, _arguments__);
            this.dispatch("update");
        };
        ArrayValue.prototype.getItemAt = function (index) {
            return this.list[index];
        };
        ArrayValue.prototype.getItemByValue = function (value) {
            if (this.key == "") {
                return null;
            }
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i][this.key] == value) {
                    return this.list[i];
                }
            }
            return null;
        };
        ArrayValue.prototype.getItemByRange = function (value) {
            if (this.key == "" || this.rangeMinKey == "" || this.rangeMaxKey == "") {
                return null;
            }
            for (var i = 0; i < this.list.length; i++) {
                var min = this.list[i][this.rangeMinKey];
                var max = this.list[i][this.rangeMaxKey];
                if (value >= min && value <= max) {
                    return this.list[i];
                }
            }
            return null;
        };
        ArrayValue.prototype.getItemsByRange = function (value) {
            if (this.key == "" || this.rangeMinKey == "" || this.rangeMaxKey == "") {
                return null;
            }
            var list = [];
            for (var i = 0; i < this.list.length; i++) {
                var min = this.list[i][this.rangeMinKey];
                var max = this.list[i][this.rangeMaxKey];
                if (value >= min && value <= max) {
                    list.push(this.list[i]);
                }
            }
            return list;
        };
        Object.defineProperty(ArrayValue.prototype, "key", {
            get: function () {
                return this._key;
            },
            set: function (val) {
                this._key = val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ArrayValue.prototype, "rangeMinKey", {
            get: function () {
                return this._rangeMinKey;
            },
            set: function (val) {
                this._rangeMinKey = val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ArrayValue.prototype, "rangeMaxKey", {
            get: function () {
                return this._rangeMaxKey;
            },
            set: function (val) {
                this._rangeMaxKey = val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ArrayValue.prototype, "length", {
            get: function () {
                return this._length;
            },
            set: function (val) {
                val = +val & ~0;
                if (this._length == val) {
                    return;
                }
                else {
                    if (val == this.list.length) {
                        this._length = val;
                        this.dispatch("length");
                        this.dispatch("update");
                    }
                    else {
                        while (this.list.length > val) {
                            this.pop();
                        }
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        ArrayValue.prototype._addListener = function (type, listener, thisObject) {
            if (!this._events[type]) {
                this._events[type] = [];
            }
            var list = this._events[type];
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    return;
                }
            }
            list.push({ "listener": listener, "thisObject": thisObject, "del": false });
        };
        ArrayValue.prototype.removeListener = function (type, listener, thisObject) {
            var list = this._events[type];
            if (!list) {
                return;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    list[i].listener = null;
                    list[i].thisObject = null;
                    list[i].del = true;
                    break;
                }
            }
        };
        ArrayValue.prototype.removeAllListener = function () {
            this._events = {};
        };
        ArrayValue.prototype.hasListener = function (type) {
            var list = this._events[type];
            if (!list) {
                return false;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].del == false) {
                    return true;
                }
            }
            return false;
        };
        ArrayValue.prototype.dispatch = function (type, item) {
            if (item === void 0) { item = null; }
            var list = this._events[type];
            if (!list) {
                return;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].del == false) {
                    var listener = list[i].listener;
                    var thisObj = list[i].thisObject;
                    if (item) {
                        listener.call(thisObj, item);
                    }
                    else {
                        listener.call(thisObj);
                    }
                }
            }
            for (i = 0; i < list.length; i++) {
                if (list[i].del == true) {
                    list.splice(i, 1);
                    i--;
                }
            }
        };
        ArrayValue.prototype.dispose = function () {
            this._events = null;
            this.list = null;
            this._length = 0;
        };
        ArrayValue.create = function (initValue) {
            if (initValue === void 0) { initValue = null; }
            var value;
            if (flower.ArrayValue.pool.length) {
                value = flower.ArrayValue.pool.pop();
                value._events = {};
                value.list = value.list || [];
                value._length = value.list.length;
            }
            else {
                value = new flower.ArrayValue(initValue);
            }
            return value;
        };
        ArrayValue.release = function (array) {
            array.dispose();
            flower.ArrayValue.pool.push(array);
        };
        return ArrayValue;
    })();
    flower.ArrayValue = ArrayValue;
})(flower || (flower = {}));
flower.ArrayValue.ADD = "add";
flower.ArrayValue.DEL = "del";
flower.ArrayValue.LENGTH = "length";
flower.ArrayValue.UPDATE = "update";
flower.ArrayValue.pool = new Array();
//# sourceMappingURL=ArrayValue.js.map