var TopLayer = cc.Sprite.extend({
    buildCastle: null,
    ctor: function () {
        this._super();
        //this.addChild(this.buildCastle = new MapBuildCastle());
        mainData.mapData.addListener("weapon", this.addWeapon, this);
    },
    updateShow: function (camera) {
        this.setPosition(-camera.x, -camera.y);
    },
    addWeapon: function (weaponData) {
        this.addChild(new WeaponArrow(weaponData));
    },
    dispose:function(){
        mainData.mapData.removeListener("weapon", this.addWeapon, this);
    }
});