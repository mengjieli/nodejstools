function SoundPlay() {

}

/**
 * 播放背景音乐
 * @param url
 */
SoundPlay.playMusic = function (url) {
    var temp = SoundPlay.fetchSoundOption();
    if(temp && temp.music=="0"){
        return;
    }
    cc.audioEngine.playMusic(url,true);
}

SoundPlay.stopMusic = function () {
    cc.audioEngine.stopMusic();
}

/**
 * 播放特效
 * @param url
 */
SoundPlay.playEffect = function (url) {
    var temp = SoundPlay.fetchSoundOption();
    if(temp && temp.effect=="0"){
        return;
    }
    cc.audioEngine.playEffect(url);
}

/**
 * 读取本地数据
 */
SoundPlay.fetchSoundOption = function () {
    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
    var fileExist = jsb.fileUtils.isFileExist(storagePath + "sound");
    if(fileExist)
    {
        var string = jsb.fileUtils.getValueMapFromFile(storagePath + "sound");
        //cc.log("sound:" + JSON.stringify(string["music"]) + "_" + (string["effect"]));
        return {"music":string["music"], "effect":string["effect"]};
    }
    return null;
}