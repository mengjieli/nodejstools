/**
 * Created by cgMu on 2015/11/27.
 */

var BlockInfoModule = ModuleBase.extend({
    root: null,

    territoryId: null,
    earthid: null,
    earthData:null,

    baseResList: null,
    strategyResList: null,
    normalTag:true,

    ctor: function () {
        this._super();
        this.baseResList = [1101001,1101002,1101003];
        this.strategyResList = [1102001,1102002,1102003,1102004];
    },

    initUI: function () {
        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255 * 0.8));
        this.addChild(colorbg);

        var root = ccs.load("res/images/ui/Block/BlockInfoLayer.json", "res/images/ui/").node;
        this.addChild(root);
        this.root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1 = root.getChildByName("Panel_1");
        sizeAutoLayout(Panel_1);
        posAutoLayout(Panel_1, 0.5);
        var Panel_myinfo = root.getChildByName("Panel_myinfo");
        sizeAutoLayout(Panel_myinfo);
        posAutoLayout(Panel_myinfo, 0.5);
        var Panel_otherinfo = root.getChildByName("Panel_otherinfo");
        sizeAutoLayout(Panel_otherinfo);
        posAutoLayout(Panel_otherinfo, 0.5);
        var Panel_normalinfo = root.getChildByName("Panel_normalinfo");
        sizeAutoLayout(Panel_normalinfo);
        posAutoLayout(Panel_normalinfo, 0.5);
        var Panel_strategyinfo = root.getChildByName("Panel_strategyinfo");
        sizeAutoLayout(Panel_strategyinfo);
        posAutoLayout(Panel_strategyinfo, 0.5);

        this.root.getChildByName("Panel_myinfo").setVisible(false);
        this.root.getChildByName("Panel_otherinfo").setVisible(false);
        this.root.getChildByName("Panel_normalinfo").setVisible(false);
        this.root.getChildByName("Panel_strategyinfo").setVisible(false);

        var title = ccui.helper.seekWidgetByName(root, "Text_8");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("dikuai_2"));
        title.setVisible(false);//nouse

        var label = ccui.helper.seekWidgetByName(root, "Text_1");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("denglu_73"));
        label.setVisible(false);//nouse

        label = ccui.helper.seekWidgetByName(root, "Text_2");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("denglu_74"));
        label.setVisible(false);//nouse

        label = ccui.helper.seekWidgetByName(root, "Text_14");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("block_1"));
        label.setVisible(false);

        var closeButton = ccui.helper.seekWidgetByName(root, "Button_1");
        closeButton.addTouchEventListener(this.touchCallback, this);

        var resex = root.getChildByName("Panel_1").getChildByName("Sprite_4_0");
        resex.setVisible(false);
        var remaincounts = ccui.helper.seekWidgetByName(root, "Text_15");
        remaincounts.ignoreContentAdaptWithSize(true);
        remaincounts.setVisible(false);

    },

    destroy: function () {

    },

    show: function (data) {
        cc.log("data---------->"+data.resourceid+" ------>"+data.territoryid,data.earthid);
        cc.log(this.root.x+"xy"+this.root.y);
        this.territoryId = data.territoryid;
        this.resourceid = data.resourceid;
        this.earthid = data.earthid;//土地使用券ID
        //cc.log("out put earthid --------------> "+data.earthid+" data.certificateid-->"+data.certificateid);
        if(this.resourceid) cc.log("资源名"+ResMgr.inst().getString(this.resourceid + "2"));
        this.earthData = data.earthData;

        var name = ccui.helper.seekWidgetByName(this.root, "Text_3");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(this.territoryId + "0"));
        if(this.strategyResList.indexOf(this.resourceid)!=-1){
            //战略资源地块
            this.normalTag = false;
            var lb = ccui.helper.seekWidgetByName(this.root, "Text_2");
            lb.setString(ResMgr.inst().getString("denglu_75"));//战略资源产量

            var title = ccui.helper.seekWidgetByName(this.root, "Text_3");
            title.setString(ResMgr.inst().getString(this.resourceid + "0"));
            //剩余资源量
            var label = ccui.helper.seekWidgetByName(this.root, "Text_14");
            //label.setVisible(true);
            var remaincounts = ccui.helper.seekWidgetByName(this.root, "Text_15");
            //remaincounts.setVisible(true);
            remaincounts.setString(StringUtils.getUnitNumber(this.earthData.count));
            //show战略资源
            this.root.getChildByName("Panel_strategyinfo").setVisible(true);
            this.root.getChildByName("Panel_1").getChildByName("Image_4").setVisible(false);
            this.root.getChildByName("Panel_1").getChildByName("Text_4").setVisible(false);
            this.root.getChildByName("Panel_1").getChildByName("Panel_2").setVisible(false);

            var detail = ccui.helper.seekWidgetByName(this.root, "Text_strategyInfo");
            detail.setString(ResMgr.inst().getString(this.territoryId + "1"));
            var remain = ccui.helper.seekWidgetByName(this.root, "Text_strategy_remain");
            remain.setString(ResMgr.inst().getString("block_1"));
            var remainValue = ccui.helper.seekWidgetByName(this.root, "Text_strategy_value");
            remainValue.setString(StringUtils.getUnitNumber(this.earthData.count));
            //Image_strategy
            var image_strategy = ccui.helper.seekWidgetByName(this.root, "Image_strategy");
            image_strategy.loadTexture(ResMgr.inst()._icoPath+data.resourceid+"4.png");
            //data.resourceid

        }
        else{
            this.root.getChildByName("Panel_1").getChildByName("Image_4").setVisible(true);
            this.root.getChildByName("Panel_1").getChildByName("Text_4").setVisible(true);
            this.root.getChildByName("Panel_1").getChildByName("Panel_2").setVisible(true);
        }


        var productData = modelMgr.call("Table", "getTableItemByValue", ["Territory_product", this.territoryId]);

        //data

        //土地等级
        var level = ccui.helper.seekWidgetByName(this.root, "Text_13");

        var icon = ccui.helper.seekWidgetByName(this.root, "Image_3");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(this.territoryId));
        //icon.loadTexture(ResMgr.inst().getIcoPath(data.resourceid));

        var detail = ccui.helper.seekWidgetByName(this.root, "Text_4");
        detail.setString(ResMgr.inst().getString(this.territoryId + "1"));

        var res = this.root.getChildByName("Panel_1").getChildByName("Sprite_4");
        res.setVisible(false);//nouse
        //res.setTexture(ResMgr.inst()._icoPath+productData.production+"0.png");
        cc.log("data.resource???"+data.resource+"id"+data.resourceid);
        if(data.resource)
            res.setTexture(ResMgr.inst()._icoPath + data.resource.product + "0.png");
        else
            res.setTexture(ResMgr.inst()._icoPath+(data.resourceid||productData.production)+"0.png");


        var counts = ccui.helper.seekWidgetByName(this.root, "Text_5");
        counts.ignoreContentAdaptWithSize(true);
        counts.setVisible(false);//nouse

        var Image_2 = ccui.helper.seekWidgetByName(this.root, "Image_2");
        Image_2.setVisible(false);//nouse
        if (this.earthid) {
            var productUpData = modelMgr.call("Table", "getTableItemByValue", ["Territory_levelup", this.earthid]);
            //土地等级
            var level_ = modelMgr.call("Table", "getTableItemByValue", ["item", this.earthid]).type;
            level.ignoreContentAdaptWithSize(true);
            //level.setString(ResMgr.inst().getString("block_4") + level_ + ResMgr.inst().getString("block_5"));
            level.setString("LV." + level_ );

            var percent = 1;
            //cc.log("resid -> "+data.resourceid + "production-> "+productData.production);
            if (data.resourceid != productData.production) {
                percent = modelMgr.call("Table", "getTableItemByValue", ["Public",100004]).numerical;
            }
            var double = 1;
            //if(data.certificateid)
            //{
            //    double = 2;
            //}
            var output = productData.output_perminute * 60 * productUpData.output_multiple * percent*double;

            cc.log("productUpData.output_multiple---------------->"+double);
            counts.setString("+" + Math.floor(output+0.001) + "/"+ResMgr.inst().getString("useScroll_2"));
            //cc.log("output_perminute "+productData.output_perminute+" productUpData.output_multiple "+productUpData.output_multiple);

            var title = ccui.helper.seekWidgetByName(this.root, "Text_3");
            title.setString(ResMgr.inst().getString(this.resourceid + "2"));

            //1208101   7
            var index=this.baseResList.indexOf(this.resourceid)+1;
            var icon = ccui.helper.seekWidgetByName(this.root, "Image_3");
            icon.loadTexture(ResMgr.inst()._icoPath+"1208"+index+"017.png");


            if(data.mine){
                this.root.getChildByName("Panel_myinfo").setVisible(true);
                cc.log(data.certificateid+"data.mine  data.certificateid"+output);
                //this.setOutPut(this.territoryId,this.resourceid,output,data.certificateid,this.earthData.castle);
                //我的产量
                var name = ccui.helper.seekWidgetByName(this.root, "Text_myFloor");
                name.ignoreContentAdaptWithSize(true);
                name.setString(ResMgr.inst().getString(this.territoryId + "0"));
                name.setVisible(true);

                var myCounts = ccui.helper.seekWidgetByName(this.root, "Text_myProduce");
                myCounts.ignoreContentAdaptWithSize(true);
                myCounts.setString("+" + Math.floor(output+0.001) + "/"+ResMgr.inst().getString("useScroll_2"));

                var myProduce = this.root.getChildByName("Panel_myinfo").getChildByName("Sprite_myProduce");
                var urlString="";
                var myResourceId="";
                if(data.resource){
                    urlString=ResMgr.inst()._icoPath + data.resource.product + "0.png";
                    myResourceId=data.resource.product;
                }
                else{
                    urlString=ResMgr.inst()._icoPath+(data.resourceid||productData.production)+"0.png";
                    myResourceId=data.resourceid||productData.production;
                }
                myProduce.setTexture(urlString);
                for(var i=0;i<this.baseResList.length;i++){
                    var myIconRes=this.root.getChildByName("Panel_myinfo").getChildByName("Sprite_myProduce_"+this.baseResList[i]);
                    myIconRes.setTexture(ResMgr.inst()._icoPath+this.baseResList[i]+"0.png");
                    var myImgArrow= ccui.helper.seekWidgetByName(this.root, "Image_myProduce_"+this.baseResList[i]);
                    if(this.baseResList[i]==myResourceId) myImgArrow.loadTexture("Block/shangsheng.png", ccui.Widget.PLIST_TEXTURE);
                    else myImgArrow.loadTexture("Block/xiajiang.png", ccui.Widget.PLIST_TEXTURE);
                }
                this.showMyInfo(this.territoryId,this.resourceid,output,data.certificateid,this.earthData.castle);

                //mainData.mapData.myEarthList.getItems("castle",mainData.uiData.currentCastleId,"productionResourceId",id)    //getSingleCeiling
                var list = mainData.mapData.myEarthList.getItems("castle",mainData.uiData.currentCastleId,"productionResourceId",this.resourceid);
                cc.log(list.length+"<<<this.resourceid");
                for(var i=0;i<list.length;i++){
                    var dataList=list[i];
                    cc.error(this.earthData.coordX+"id"+dataList.coordX)
                    if(this.earthData.coordX==dataList.coordX&&this.earthData.coordY==dataList.coordY){
                        var dqjrNum=( StringUtils.getUnitNumber(dataList.resourceAmount) );
                        var maxN = this.getSingleCeiling( this.territoryId,this.resourceid, data.earthid );
                        if(dataList.useAccelerationCard)
                        {
                            maxN *=2 ;
                        }
                        maxN= StringUtils.getUnitNumber(maxN);
                        //Text_myProduceMax
                        var Text_myProduceMax= ccui.helper.seekWidgetByName(this.root, "Text_myProduceMax");
                        Text_myProduceMax.setString(dqjrNum+"/"+maxN);
                        //cc.error(dqjrNum+"num"+maxN);
                        break;
                    }
                }


            }
            else{
                this.root.getChildByName("Panel_otherinfo").setVisible(true);
                //this.earthData.user;
                //其他玩家地块 仓库上限 暂时屏蔽
                ccui.helper.seekWidgetByName(this.root, "Image_otherProduceMax").setVisible(false);
                ccui.helper.seekWidgetByName(this.root, "Text_otherProduceMax").setVisible(false);

                var name = ccui.helper.seekWidgetByName(this.root, "Text_otherFloor");
                name.ignoreContentAdaptWithSize(true);
                name.setString(ResMgr.inst().getString(this.territoryId + "0"));
                name.setVisible(true);

                var otherCounts = ccui.helper.seekWidgetByName(this.root, "Text_otherProduce");
                otherCounts.ignoreContentAdaptWithSize(true);
                otherCounts.setString("+" + Math.floor(output+0.001) + "/"+ResMgr.inst().getString("useScroll_2"));

                var otherProduce = this.root.getChildByName("Panel_otherinfo").getChildByName("Sprite_otherProduce");
                var urlString="";
                var otherResourceId="";
                if(data.resource){
                    urlString=ResMgr.inst()._icoPath + data.resource.product + "0.png";
                    otherResourceId=data.resource.product;
                }
                else{
                    urlString=ResMgr.inst()._icoPath+(data.resourceid||productData.production)+"0.png";
                    otherResourceId=data.resourceid||productData.production;
                }
                otherProduce.setTexture(urlString);
                for(var i=0;i<this.baseResList.length;i++){
                    var otherIconRes=this.root.getChildByName("Panel_otherinfo").getChildByName("Sprite_otherProduce_"+this.baseResList[i]);
                    otherIconRes.setTexture(ResMgr.inst()._icoPath+this.baseResList[i]+"0.png");
                    var otherImgArrow= ccui.helper.seekWidgetByName(this.root, "Image_otherProduce_"+this.baseResList[i]);
                    if(this.baseResList[i]==otherResourceId) otherImgArrow.loadTexture("Block/shangsheng.png", ccui.Widget.PLIST_TEXTURE);
                    else otherImgArrow.loadTexture("Block/xiajiang.png", ccui.Widget.PLIST_TEXTURE);
                }
                //其他玩家地块信息
                //if(castleData.attributes.getItem("type",2500001)){//繁荣度
                //    data_2 = castleData.attributes.getItem("type",2500001).value;
                //}

                if(this.earthData&&this.earthData.user){
                    var playerInfo=mainData.playerDataList.getItem("account",this.earthData.user);
                    //cc.error(playerInfo.nick);
                    var label = ccui.helper.seekWidgetByName(this.root, "Text_otherName");
                    label.ignoreContentAdaptWithSize(true);
                    label.setString("所属玩家："+playerInfo.nick);//ResMgr.inst().getString("dikuai_6")

                    //var heavy=mapData.castleDataList.getItem("id",this.earthData.castle);
                    var label = ccui.helper.seekWidgetByName(this.root, "Text_otherHeavy");
                    label.setTouchEnabled(true);
                    label.addTouchEventListener(this.moveToCastle, this);
                    label.ignoreContentAdaptWithSize(true);
                    label.setString("所属城堡坐标："+"（X："+this.earthData.castleCoordX+" Y："+this.earthData.castleCoordY+"）");

                    var label = ccui.helper.seekWidgetByName(this.root, "Text_otherUnion");
                    label.ignoreContentAdaptWithSize(true);
                    label.setString("所属联盟：");

                }
            }
        }
        else {//普通地块详情
            level.setVisible(false);
            if(this.strategyResList.indexOf(this.resourceid)==-1) this.root.getChildByName("Panel_normalinfo").setVisible(true);
            var normalResourceId;
            if(!data.resource)
            {
                var output = productData.output_perminute * 60;
                counts.setString("+" + Math.floor(output+0.001) + "/"+ResMgr.inst().getString("useScroll_2"));
                normalResourceId=data.resourceid||productData.production;
            }
            else
            {
                normalResourceId=data.resource.product;
                if(data.resource.resource)
                    counts.setString(data.resource.resource);
                else
                    counts.setString(data.resource.allResource);

                counts.setPositionX(name.getPositionX());

                res.setVisible(false);
                var lb = ccui.helper.seekWidgetByName(this.root, "Text_2");
                lb.setString(ResMgr.inst().getString("block_1"));
            }
            Image_2.setVisible(false);
            //普通地块显示
            cc.error(normalResourceId+"<<<<<<<<<<<normalResourceId");
            for(var i=0;i<this.baseResList.length;i++){
                var normalIconRes=this.root.getChildByName("Panel_normalinfo").getChildByName("icon_normal"+i).getChildByName("Image_3");
                //normalIconRes.loadTexture(ResMgr.inst().getIcoPath(this.baseResList[i]));
                normalIconRes.loadTexture(ResMgr.inst()._icoPath+this.baseResList[i]+"0.png");
                var normalImgArrow= ccui.helper.seekWidgetByName(this.root, "Image_normal"+i);
                if(this.baseResList[i]==normalResourceId) normalImgArrow.loadTexture("Block/shangsheng.png", ccui.Widget.PLIST_TEXTURE);
                else normalImgArrow.loadTexture("Block/xiajiang.png", ccui.Widget.PLIST_TEXTURE);
                //Text_normal0_0
                var normalTf= ccui.helper.seekWidgetByName(this.root, "Text_normal"+i+"_0");
                if(this.baseResList[i]==normalResourceId) {
                    normalTf.setString(counts.getString());
                }
                else{
                    if(!data.resource){
                        var output = productData.output_perminute * 60;
                        normalTf.setString("+" + parseInt( Math.floor(output+0.001)/2 ) + "/"+ResMgr.inst().getString("useScroll_2"));
                    }
                    else{
                        if(data.resource.resource)
                            normalTf.setString(data.resource.resource/2);
                        else
                            normalTf.setString(data.resource.allResource/2);
                    }
                }
            }


        }

    },
    //屏幕移动到城堡
    moveToCastle:function(target, type){
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                //cc.log("selectMain>>>select"+target);
                modelMgr.call("BigMap", "cameraLookAt", [this.earthData.castleCoordX,this.earthData.castleCoordY]);
                ModuleMgr.inst().closeModule("BlockInfoModule");
                break;
        }
    },
    /**
     * 获取产出上限
     * @param landId  地块
     * @param resId     资源
     * @param tiredId   倦
     */
    getSingleCeiling:function( landId, resId, tiredId )
    {
        var config = modelMgr.call("Table", "getTableItemByValue", ["Territory_product",landId ])
        if( config == null ) return 0;
        var v = Number(config.resource_max);
        var percent = 1;
        if( config.production != resId )
        {
            percent = modelMgr.call("Table", "getTableItemByValue", ["Public",100005]).numerical;
        }
        v = v * percent;
        var tiredConfig = modelMgr.call("Table", "getTableItemByValue", ["Territory_levelup",tiredId ]);
        var m = Number(tiredConfig.resource_multiple);
        var n = v * m;
        //cc.error(landId+"landId"+resId+"resId"+tiredId+"tiredId"+n);
        return Math.floor(n);
    },

    close: function () {

    },

    touchCallback: function (sender, type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                ModuleMgr.inst().closeModule("BlockInfoModule");
                SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    setOutPut: function (landid, resid, output, certificateid,castleid) {
        var label = ccui.helper.seekWidgetByName(this.root, "Text_2_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_6"));
        label.setVisible(true);

        label = ccui.helper.seekWidgetByName(this.root, "Text_2_0_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_7"));
        label.setVisible(true);

        label = ccui.helper.seekWidgetByName(this.root, "Text_2_0_1");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_8"));
        label.setVisible(true);

        cc.log("@setOutPut",landid,resid,output,certificateid);
        //科技加成
        var value = this.getTechOutPut(landid,resid, 1,castleid);
        var countsex = ccui.helper.seekWidgetByName(this.root, "Text_5_0");
        countsex.setVisible(true);
        countsex.ignoreContentAdaptWithSize(true);
        countsex.setString(this.getString(value));

        //官职加成
        value = this.getAddPercentByVip();
        var label = ccui.helper.seekWidgetByName(this.root,"Text_5_0_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(this.getString(value));
        label.setVisible(true);

        //效率卡
        var temp = modelMgr.call("Table", "getTableItemByValue", ["Public",100006]).numerical;
        if(certificateid){
            value = Math.floor(temp*100+0.001)+"%";
        }
        else{
            value = ResMgr.inst().getString("dikuai_9");
        }

        label = ccui.helper.seekWidgetByName(this.root,"Text_5_0_1");
        label.ignoreContentAdaptWithSize(true);
        label.setString(value);
        label.setVisible(true);


    },
    //我的地块详情
    showMyInfo:function(landid, resid, output, certificateid,castleid){


        //加成部分
        var label = ccui.helper.seekWidgetByName(this.root, "Text_myTech_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_6"));
        label.setVisible(true);

        label = ccui.helper.seekWidgetByName(this.root, "Text_myOffice_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_7"));
        label.setVisible(true);

        label = ccui.helper.seekWidgetByName(this.root, "Text_myEficiency_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("dikuai_8"));
        label.setVisible(true);

        //cc.log("@setOutPut",landid,resid,output,certificateid);
        //科技加成
        var value = this.getTechOutPut(landid,resid, 1,castleid);
        var countsex = ccui.helper.seekWidgetByName(this.root, "Text_myTech");
        countsex.setVisible(true);
        countsex.ignoreContentAdaptWithSize(true);
        countsex.setString(this.getString(value));

        //官职加成
        value = this.getAddPercentByVip();
        var label = ccui.helper.seekWidgetByName(this.root,"Text_myOffice");
        label.ignoreContentAdaptWithSize(true);
        label.setString(this.getString(value));
        label.setVisible(true);

        //效率卡
        var temp = modelMgr.call("Table", "getTableItemByValue", ["Public",100006]).numerical;
        if(certificateid){
            value = Math.floor(temp*100+0.001)+"%";
        }
        else{
            value = ResMgr.inst().getString("dikuai_9");
        }

        label = ccui.helper.seekWidgetByName(this.root,"Text_myEficiency");
        label.ignoreContentAdaptWithSize(true);
        label.setString(value);
        label.setVisible(true);


    },

    getString: function (output) {
        return "+" + Math.floor(100*output+0.001)+"%";// + "/"+ResMgr.inst().getString("useScroll_2")
    },

    getAddPercentByVip: function () {
        var data = modelMgr.call("Table", "getTableItemByValue", ["vip", mainData.playerData.promotionLevel]);
        return data.vip_buff;
    },

    getTechOutPut: function (landid, resid, output,castleid) {
        //output = 1;
        //科技加成 根据产出资源ID获得对应的科技ID
        var techid = this.getTechIdByResId(resid);
        var value = this.getAddPercentByTech(techid,castleid)*output;
        //全产量科技加成 ID 1301008
        value += this.getAddPercentByTech(1301008,castleid)*output;

        //开发沙漠 id 1301009
        if(landid==1603001 || landid == 1604001 || landid==1609001 || landid==1610001){
            value += this.getAddPercentByTech(1301009,castleid)*output;
        }
        //开发荒原 id 1301010
        if(landid==1602001 || landid == 1611001 || landid==1612001){
            value += this.getAddPercentByTech(1301010,castleid)*output;
        }
        //开发草原 id 1301011
        if(landid==1601001 || landid == 1605001 || landid==1606001 || landid==1607001){
            value += this.getAddPercentByTech(1301011,castleid)*output;
        }
        return value;
    },

    getAddPercentByTech: function (techid,castleid) {
        var info = 0;
        var data = ModuleMgr.inst().getData("CastleModule").getNetTech(castleid);
        if(techid && data[techid] && data[techid]._tech_level > 0){
            var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+techid+","+data[techid]._tech_level+"]" ]);
            var jsondata = eval("(" + tech_data.tech_effect + ")");
            for(var k in jsondata) {
                info = jsondata[k];
            }
        }
        return info;
    },

    getTechIdByResId: function (resId) {
        var techid = null;
        switch (parseInt(resId)){
            case 1101001:
                techid = 1301001;
                break;
            case 1101002:
                techid = 1301002;
                break;
            case 1101003:
                techid = 1301003;
                break;
        }
        return techid;
    },

});