var flower;
(function (flower) {
    var ResType = (function () {
        function ResType() {
        }
        return ResType;
    })();
    flower.ResType = ResType;
})(flower || (flower = {}));
flower.ResType.TEXTURE = "Texture";
flower.ResType.TEXT = "Text";
flower.ResType.JSON = "Json";
//# sourceMappingURL=ResType.js.map