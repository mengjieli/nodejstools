﻿/*
 **登陆/注册模块 2015-09-01 shenwei
 */
var LoadingModule = cc.Scene.extend({

    _scene: null,
    _panel: null,

    //partI
    _preUpTip: null,
    _preUpTipEffectCtrl: null,

    _preDownTip: null,
    _preDownTipEffectCtrl: null,

    _bkg: null,
    _logo: null,
    _logoEffectCtrl: null,

    //partII
    _beauty: null,
    _beautyEffectCtrl: null,

    _deskLeft: null,
    _deskLeftEffectCtrl: null,

    _deskRight: null,
    _deskRightEffectCtrl: null,

    _deskMid: null,
    _deskMidEffectCtrl: null,

    _loadingBarBkg: null,
    _loadingBarBkgEffectCtrl: null,
    _loadingBar: null,
    _loadingTip: null,
    _loadingTipEffectCtrl: null,

    _waitingTipUp: null,
    _waitingTipUpEffectCtrl: null,

    _waitingTipDown: null,
    _waitingTipDownEffectCtrl: null,

    _delayTimer: null,

    _updateCount: null,//配置表更新计数
    _updateConfigTablesTimer: null,

    ctor: function () {
        this._super();

        this._delayTimer = -1;
        this._updateCount = 0;
        this._updateConfigTablesTimer = -1;

        this.initUI();
    },

    initUI: function () {
        this._scene = ccs.load("res/loadingAndLogining/loadingUI.json").node;
        this.addChild( this._scene );

        this._panel = this._scene.getChildByName("panel");
        //适配
        this.stretch(this._panel, 3, true, 3);
        this.resetNode(this._panel);

        this.updateLoadingPanel();
    },

    stretch: function (node,stretchType,isCenter,type) {
        var scaleX = cc.view.getScaleX();
        var scaleY = cc.view.getScaleY();

        var frameSize = cc.view.getFrameSize();

        //先求出缩放后大小，然后再用当然屏幕尺寸求出该缩放多少
        {
            node.setScaleX(frameSize.width / (node.width * scaleX));
            node.setScaleY(frameSize.height / (node.height * scaleY));
        }

        this.setCenter(node,type);
    },

    setCenter: function (node,type,target) {
        if(type == undefined || type == null || type == 3)
        {
            node.setPosition(this.getCenterP(node,target));
        }
    },

    getCenterP: function (node,target) {
        var frameSize = cc.view.getFrameSize();
        //系统缩放因子
        var scaleX = cc.view.getScaleX();
        var scaleY = cc.view.getScaleY();
        var size = this.getRealySize(node);
        var targetSize;
        var x;
        var y;
        if(target == null || target == undefined)
        {
            x = (((frameSize.width - size.width) / 2) + node.anchorX * size.width) * (1 / scaleX);
            y = (((frameSize.height - size.height) / 2) + node.anchorY * size.height) * (1 / scaleY);
        }

        size = null;
        targetSize = null;
        return node.parent.convertToNodeSpace(cc.p(x,y));
    },

    getRealySize: function (node) {
        //系统缩放因子
        var scaleX = cc.view.getScaleX();
        var scaleY = cc.view.getScaleY();
        //现在宽度,现在高度(计算了缩放后的大小)
        var nowWidht = node.scaleX * node.width * scaleX;
        var nowHeight = node.scaleY * node.height * scaleY;

        return cc.size(nowWidht,nowHeight);
    },

    resetNode: function (node) {
        var obj;
        if(node.userData == undefined)//资源缓存导致位置变化
        {
            obj = {};
            obj.x = node.x;
            obj.y = node.y;
            obj.scaleX = node.scaleX;
            obj.scaleY = node.scaleY;
            obj.opacity = node.getOpacity();
            node.userData = obj;
        }
        else
        {
            node.x = node.userData.x;
            node.y = node.userData.y;
            node.setScaleX(node.userData.scaleX);
            node.setScaleY(node.userData.scaleY);
            node.setOpacity(node.userData.opacity);
        }
        return node;
    },

    //设置显示对象
    updateLoadingPanel: function () {
        if (!this._panel) {
            cc.error("获取显示对象失败");
            return;
        }

        this._bkg = this._panel.getChildByName("bkg");

        this._preUpTip = this._panel.getChildByName("loading_text_up");
        this._preDownTip = this._panel.getChildByName("loading_text_down");
        this._preDownTip.ignoreContentAdaptWithSize(true);
        this._logo = this._panel.getChildByName("logo");
        this._beauty = this._panel.getChildByName("beauty");
        this._beauty.setVisible(false);
        this._deskLeft = this._panel.getChildByName("desk_left");
        this._deskLeft.setVisible(false);
        this._deskRight = this._panel.getChildByName("desk_right");
        this._deskRight.setVisible(false);
        this._deskMid = this._panel.getChildByName("desk_mid");
        this._deskMid.setVisible(false);
        this._loadingBarBkg = this._panel.getChildByName("loading_bar_bkg");
        this._loadingBarBkg.setVisible(false);
        this._loadingBar = this._loadingBarBkg.getChildByName("loading_bar");
        this._loadingBar.setVisible(true);
        this._loadingTip = this._panel.getChildByName("loading_tip");
        this._loadingTip.setVisible(false);
        this._waitingTipUp = this._panel.getChildByName("waiting_tip_up");
        this._waitingTipUp.setVisible(false);
        this._waitingTipDown = this._panel.getChildByName("waiting_tip_down");
        this._waitingTipDown.setVisible(false);

        //var tip = ModuleMgr.inst().getData("Loading").getNextTip();
        //this._waitingTipUp.setString(tip.up);
        //this._waitingTipDown.setString(tip.down);
    },

    onEnter: function () {
        this._super();
        this.show();
    },

    show: function () {
        //this._preUpTip.setVisible(false);
        //this._preDownTip.setVisible(false);
        //this._logo.setVisible(false);
        this.play(this._preUpTip,1.2,2,50);
        this.play(this._preDownTip,1.2,3,50);
        this.play(this._logo,1.2,3,50);

        var delay = (1.2 + 2) * 1000;
        this._delayTimer = setTimeout(this.checkNetworkStatus, delay, this);
    },

    play : function(target, duration, direction, distance)
    {
        target.stopAllActions();
        var endPo = cc.p(target.x, target.y);
        target.setOpacity(0);
        var beginPo = this.getBeginPoByMoveDirection(target, direction, distance);
        target.x = beginPo.x;
        target.y = beginPo.y;

        target.runAction(cc.Sequence(
            cc.Spawn(
                cc.moveTo(duration, endPo.x, endPo.y),
                cc.fadeTo(duration, 255)
            )
        ));
    },

    getBeginPoByMoveDirection: function (target, direction, distance) {
        if(!target) return;
        distance = distance < 0 ? 0 : distance;
        var beginPo = cc.p(0, 0);
        switch(direction)
        {
            case 0:
                beginPo.x = target.x - distance;
                beginPo.y = target.y;
                break;
            case 1:
                beginPo.x = target.x + distance;
                beginPo.y = target.y;
                break;
            case 2:
                beginPo.x = target.x;
                beginPo.y = target.y + distance;
                break;
            case 3:
                beginPo.x = target.x;
                beginPo.y = target.y - distance;
                break;
            default:
                break;
        }
        return beginPo;
    },

    checkNetworkStatus: function (owner) {
        //if (!SysCall.isNetworkAvailable()) {
        //    //var value = ResMgr.inst().getString("denglu_16");
        //    //ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
        //}
        //else {
        //    owner.isServerConnected();
        //}
        //TODO: 跳过网络检测
        owner.preloadedDone();
    },

    isServerConnected: function () {
        var url = "http://" + GameConfig.serverIP_2 + GameConfig.testHttpPort;
        NetMgr.inst().sendHttp(url, null, false, function (data, param) {
                var valid = data.match("Connection refused");
                if (null != valid) {
                    ModuleMgr.inst().getData("Loading").serverConnectedFailedTip();
                }
                else {
                    cc.error("游戏加载正常");
                    param.loadend.apply(param.owner);
                }
            },
            function (url, response) {
                if ("" == response) {
                    cc.error("服务器连接失败");
                    ModuleMgr.inst().getData("Loading").serverConnectedFailedTip();
                }
            },
            {"loadend": this.preloadedDone, "owner": this});
    },

    //连接验证完毕
    preloadedDone: function () {
        //this._preUpTip.setVisible(false);
        //this._preDownTip.setVisible(false);
        //this._logo.setVisible(false);

        cc.log("@@welcome paik");
        //启动热更新
        var scene = new UpdateCocos2dx();
        scene.load();

    },

    clean: function () {
        //NodeUtils.removeUI("res/loadingAndLogining/loadingUI.json");

        //this._preUpTipEffectCtrl.destroy();
        //this._preUpTipEffectCtrl = null;
        this._preUpTip = null;

        //this._preDownTipEffectCtrl.destroy();
        //this._preDownTipEffectCtrl = null;
        this._preDownTip = null;

        //this._logoEffectCtrl.destroy();
        //this._logoEffectCtrl = null;
        this._logo = null;

        this._loadingBarBkg = null;

        this._loadingTip = null;

        this._bkg = null;
        this._loadingBar = null;
        this._scene = null;
        this._panel = null;

        if (-1 <= this._delayTimer) {
            clearTimeout(this._delayTimer);
            this._delayTimer = null;
        }

        this._updateCount = null;

        if (-1 <= this._updateConfigTablesTimer) {
            clearTimeout(this._updateConfigTablesTimer);
            this._updateConfigTablesTimer = null;
        }

        LoadingModule.IS_OPEN = false;
    },

    onExit: function () {
        this._super();
        this.clean();
    }
});
LoadingModule.IS_OPEN = false;
LoadingModule.CASTLE_ID = "4321";
LoadingModule.CANCEL_AUTO_LOGIN = false;