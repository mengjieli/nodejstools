var TestScene = cc.Scene.extend({
    labels:null,
    ctor: function () {
        this._super();
        var url = "res/test/testColor.jpg";

        var sp = new cc.Sprite(url);
        sp.setAnchorPoint(0,0);
        this.addChild(sp);
        sp.setPosition(50,100);

        var sp = new cc.Sprite(url);
        sp.setAnchorPoint(0,0);
        this.addChild(sp);
        sp.setPosition(450,100);

        this.loadColor(sp,"R"); //红色
        //this.loadColor(sp,"G"); //绿色
        //this.loadColor(sp,"O"); //橙色
        //
        //this.loadColor(sp,"P"); //紫色
        //this.loadColor(sp,"BG"); //蓝绿色
    },
    loadColor:function(sp,name) {
        this.shader = new cc.GLProgram("res/shaders/sprite.vsh", "res/shaders/sprite" + name + ".fsh");
        this.shader.retain();
        this.shader.link();
        this.shader.updateUniforms();
        var program = this.shader.getProgram();
        sp.shaderProgram = this.shader;
    }
});