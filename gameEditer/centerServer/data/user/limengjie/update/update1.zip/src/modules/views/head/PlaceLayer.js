/**
 * Created by cgMu on 2016/1/27.
 */

var PlaceLayer = cc.Node.extend({
    pageRoot:null,
    pageview:null,
    _leftBtn:null,
    _rightBtn:null,

    dataList:null,
    itemIndex:null,
    itemCounts:null,

    ctor: function () {
        this._super();

        this.initData();

        var root = ccs.load("res/images/ui/HeadModule/PlaceLayer.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1_0 = root.getChildByName("Panel_1_0");
        posAutoLayout(Panel_1_0,0.5);

        var closeButton = ccui.helper.seekWidgetByName(root, "Button_1");
        closeButton.addTouchEventListener(this.touchCallback,this);

        var title = Panel_1_0.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("head_32"));

        var PageView_1 = Panel_1_0.getChildByName("PageView_1");
        PageView_1.addEventListener(this.pageViewEvent,this);
        this.pageview = PageView_1;

        var Panel_7 = Panel_1_0.getChildByName("Panel_7");
        Panel_7.setVisible(false);
        this.pageRoot = Panel_7;

        var rightBtn = Panel_1_0.getChildByName("Button_7");
        rightBtn.addTouchEventListener(this.rightCallback,this);
        var leftBtn = Panel_1_0.getChildByName("Button_7_0");
        leftBtn.addTouchEventListener(this.leftCallback,this);
        this._leftBtn = leftBtn;
        this._rightBtn = rightBtn;

        this.initContent();
    },

    initData: function () {
        this.dataList = {};
        var before = modelMgr.call("Table", "getTableItemByValue", ["vip", mainData.playerData.promotionLevel-1]);
        if(before){
            this.dataList[0]=before;
        }
        var data = modelMgr.call("Table", "getTableItemByValue", ["vip", mainData.playerData.promotionLevel]);
        if(data){
            this.dataList[1]=data;
        }
        var after = modelMgr.call("Table", "getTableItemByValue", ["vip", mainData.playerData.promotionLevel+1]);
        if(after){
            this.dataList[2]=after;
        }
    },

    initContent: function () {
        this.pageview.removeAllPages();

        var counts = 0;
        for(var key in this.dataList){
            counts++;
            var it = this.pageRoot.clone();
            it.setVisible(true);
            this.setPage(it,key,this.dataList[key]);
            this.pageview.addPage(it);
        }

        this.itemCounts = counts-1;
        if(counts==3){
            this.itemIndex = 1;
        }
        else{
            if(this.dataList[0]){
                this.itemIndex=1;
            }
            else{
                this.itemIndex=0;
            }
        }
        this.resetBtnState();
        //this.pageview.scrollToPage(this.itemIndex);
        this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function (sender) {
            sender.pageview.scrollToPage(sender.itemIndex);
        })));
    },

    pageViewEvent: function (pageView,type) {
        switch (type){
            case ccui.PageView.EVENT_TURNING:
                this.itemIndex = pageView.getCurPageIndex();
                this.resetBtnState();
                break;
            default:
                break;
        }
    },

    touchCallback: function (sender,type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                this.removeFromParent(true);
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5) );
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    rightCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED) {
            this.itemIndex++;
            if(this.itemIndex>this.itemCounts){
                this.itemIndex=this.itemCounts;
            }
            this.pageview.scrollToPage(this.itemIndex);
        }
    },

    leftCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED) {
            if(type==ccui.Widget.TOUCH_ENDED) {
                this.itemIndex--;
                if(this.itemIndex<0){
                    this.itemIndex=0;
                }
                this.pageview.scrollToPage(this.itemIndex);
            }
        }
    },

    //index：0 上个等级 1 当前等级 2 下个等级
    setPage: function (root,index,data) {
        var string = "";
        if(index == 0){
            string = ResMgr.inst().getString("head_33");
        }
        else if(index == 1){
            string = ResMgr.inst().getString("head_34");
        }
        else if(index = 2){
            string = ResMgr.inst().getString("head_35");
        }
        var Text_2 = root.getChildByName("Text_2");
        Text_2.ignoreContentAdaptWithSize(true);
        Text_2.setString(string);

        var Text_2_0 = root.getChildByName("Text_2_0");
        Text_2_0.ignoreContentAdaptWithSize(true);
        Text_2_0.setString(ResMgr.inst().getString("head_36"));

        var Text_2_0_0 = root.getChildByName("Text_2_0_0");
        Text_2_0_0.ignoreContentAdaptWithSize(true);
        Text_2_0_0.setString(ResMgr.inst().getString("head_37"));

        var Text_2_1_0 = root.getChildByName("Text_2_1_0");
        Text_2_1_0.ignoreContentAdaptWithSize(true);
        Text_2_1_0.setString(ResMgr.inst().getString("head_38"));

        var Text_2_1_0_0 = root.getChildByName("Text_2_1_0_0");
        Text_2_1_0_0.ignoreContentAdaptWithSize(true);
        Text_2_1_0_0.setString(ResMgr.inst().getString("head_39"));

        var Text_2_1_0_1 = root.getChildByName("Text_2_1_0_1");
        Text_2_1_0_1.ignoreContentAdaptWithSize(true);
        Text_2_1_0_1.setString(ResMgr.inst().getString("head_40"));

        var Text_2_1 = root.getChildByName("Text_2_1");
        Text_2_1.ignoreContentAdaptWithSize(true);
        Text_2_1.setString( ResMgr.inst().getString(data.vip_id+"0") );

        var Text_16 = root.getChildByName("Text_16");
        Text_16.ignoreContentAdaptWithSize(true);
        Text_16.setString(Math.round(data.vip_buff*100)+"%");

        var Text_16_0 = root.getChildByName("Text_16_0");
        Text_16_0.ignoreContentAdaptWithSize(true);
        Text_16_0.setString(data.immigrant_limit);

        var Text_18 = root.getChildByName("Text_18");
        Text_18.ignoreContentAdaptWithSize(true);
        Text_18.setString(mainData.mapData.myCastleList.length - 1);

        var Image_93_0_0 = root.getChildByName("Image_93_0_0");
        Image_93_0_0.setScale(0.8);
        Image_93_0_0.ignoreContentAdaptWithSize(true);
        Image_93_0_0.loadTexture(ResMgr.inst().getIcoPath(data.vip_id));
    },

    setButtonEnabled: function (node,enabled) {
        if(node){
            node.setBright(enabled);
            node.setTouchEnabled(enabled);
        }
    },

    resetBtnState: function () {
        if(this.itemIndex==0){
            this.setButtonEnabled(this._leftBtn,false);
        }
        else{
            this.setButtonEnabled(this._leftBtn,true);
        }
        if(this.itemIndex==this.itemCounts){
            this.setButtonEnabled(this._rightBtn,false);
        }
        else{
            this.setButtonEnabled(this._rightBtn,true);
        }
    },
});