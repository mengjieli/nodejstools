function Shader() {

}

Shader.rolerColors = {};

Shader.getRolerColor = function (name) {
    var shader = Shader.rolerColors[name];
    if (!shader) {
        shader = new cc.GLProgram("res/shaders/sprite.vsh", "res/shaders/sprite" + name + ".fsh");
        shader.retain();
        shader.link();
        shader.updateUniforms();
        shader.getProgram();
        Shader.rolerColors[name] = shader;
    }
    return shader;
}