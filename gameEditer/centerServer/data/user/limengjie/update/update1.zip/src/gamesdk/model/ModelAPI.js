var ModelAPI = function(name,params) {
    this.name = "";
    this.params = [];
    this.caller = [];
}

ModelAPI.prototype.addListener = function(func,thisObj) {
    this.caller.push({
        "func":func,
        "thisObj":thisObj
    });
}

ModelAPI.prototype.removeListener = function(func,thisObj) {
    this.caller.push({
        "func":func,
        "thisObj":thisObj
    });
}

ModelAPI.prototype.excute = function(params) {
    var list = this.caller.concat();
    for(var i = 0; i < list.length; i++) {
        list[i].func.apply(list[i].thisObj,params);
    }
}

