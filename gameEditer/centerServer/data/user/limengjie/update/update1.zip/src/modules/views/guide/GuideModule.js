/**
 * Created by Administrator on 2015/12/22/0022.
 */
var GuideModule = ModuleBase.extend({
    _ui: null,
    _bg:null,//背景点击区域
    _hand:null,//手指图片
    _effectHand:null,//手指点击特效
    _effectWords:null,//文本点击特效
    _arrow_up:null,//箭头上
    _arrow_down:null,//箭头下
    _speakPanel:null,//说话窗
    _tfSpeek:null,//说话文本

    _effectLayer:null,//特殊显示特效层
    _size:null,//屏幕尺寸

    _speekInterval:null,//时间间隔
    _isInterval:null,//是否间隔
    _intervalTime:null,//间隔
    _guideBean:null,//引导数据
    _guideData:null,//引导data


    ctor: function ()
    {
        this._super();
    },

    initUI: function ()
    {
        this._guideData = ModuleMgr.inst().getData("GuideModule");
        cc.log("guidemodule initUI################");
        EventMgr.inst().addEventListener("next_guide", this.doNextGuide, this);
        EventMgr.inst().addEventListener("remove_guide", this.doRemoveGuide, this);
        EventMgr.inst().addEventListener("guide_handP", this.doHandP, this);
        EventMgr.inst().addEventListener("guide_arrowP", this.doArrowP, this);

        this._ui = ccs.load("res/images/ui/guide/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );
        this._bg = this._ui.getChildByName("Panel_1");
        this._bg.addTouchEventListener(this.onBgTouch,this);

        this._effectLayer=new cc.Layer();
        this.addChild(this._effectLayer);

        this._arrow_up= this._ui.getChildByName("arrow_up");
        this._arrow_down= this._ui.getChildByName("arrow_down");
        this._speakPanel=this._ui.getChildByName("speak_panel");
        this._tfSpeek=this._speakPanel.getChildByName("tf_msg");

        var csvHand = ResMgr.inst().getCSV("animationConfig","guide_handtouch");
        this._effectHand=new AnimationSprite();
        this._effectHand.setName("guide_handtouch");
        this._effectHand.setAnimationByCount(csvHand,0);
        this.addChild(this._effectHand);

        this._hand=new ccui.ImageView("guide/dianji_shouzhi_01.png",ccui.Widget.PLIST_TEXTURE);
        this.addChild(this._hand);

        var csvWords = ResMgr.inst().getCSV("animationConfig","guide_wordstouch");
        this._effectWords=new AnimationSprite();
        this._effectWords.setName("guide_wordstouch");
        this._effectWords.setAnimationByCount(csvWords,0);
        this.addChild(this._effectWords);


        this._size = cc.director.getVisibleSize();
        this._ui.setContentSize( this._size );
        ccui.helper.doLayout( this._ui );
    },
    show:function( data )
    {
        cc.log("guidemodule show$$$$$$$$$$$$$$$$$$$$"+mainData.playerData.guide);
        if(data==undefined||data==null) this.showGuide("1_1");
        else {
            if(data.handP!=undefined)this.showGuide(data.id,data.handP);
            else {
                this.showGuide(data.id);
            }
        }

    },
    showGuide:function(idStep,handP){
        cc.log("showGuideshowGuideshowGuideshowGuide#####################################"+idStep);
        if(GuideModule.IS_CLOSE){
            if(this._bg)this._bg.setTouchEnabled(false);
            //this.removeAllChildren();
            this.doRemoveGuide(null);
            //var msg = new SocketBytes();
            //msg.writeUint(201);//设置账号属性
            //msg.writeUint(198);//引导
            //msg.writeString("1_1");//重置引导第一步
            //NetMgr.inst().send(msg);
            return;
        }
        //if(idStep) ModuleMgr.inst().openModule("AlertString",{str:idStep,color:null,time:null,pos:null});//引导提示文字
        if(idStep&&(idStep==GuideModule.END_GUIDE_ALL)){//暂时用4_1 要改   //||idStep=="3_11"||idStep=="3_6"
            EventMgr.inst().dispatchEvent("guide_event" ,GuideModule.END_GUIDE_ALL );
            if(this._bg)this._bg.setTouchEnabled(false);
            var msg = new SocketBytes();
            msg.writeUint(201);//设置账号属性
            msg.writeUint(198);//引导
            msg.writeString("5_1");
            NetMgr.inst().send(msg);
            this.doRemoveGuide(null);
            return;
        }
        //else{
        //    var msg = new SocketBytes();
        //    msg.writeUint(201);//设置账号属性
        //    msg.writeUint(198);//引导
        //    msg.writeString("1_1");//重置引导第一步
        //    NetMgr.inst().send(msg);
        //    return;
        //}
        //适配
        var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down = down * (1/GameMgr.inst().scaleX);
        down=parseInt(down/2);
        down=0;
        //cc.log(1/GameMgr.inst().scaleX+"适配 差值 高%%%%%"+down);
        //cc.log(GameMgr.inst().frameSize.height+"适配"+GameMgr.inst().scaleViewSize.height);
        //var arrJudge=["1_4","1_7"];
        var csvGuide = ResMgr.inst().getCSV("guideConfig",idStep);
        this.removeEffect();
        this._guideBean=new GuideBean(csvGuide);
        this._guideData._guideBean=this._guideBean;
        //保存引导关键步骤
        if(this._guideBean._idStep=="3_4") down=down*2;
        var arrSave=["1_1","1_6","2_1","2_2","2_8","2_14","3_1","3_2","3_6","3_8","4_1","4_3","4_4","5_1"];//暂时4_1引导结束
        if(this._guideBean){
            var indexJudge=arrSave.indexOf(this._guideBean._idStep);
            if(indexJudge>-1){
                cc.log("保存引导>>>>"+arrSave[indexJudge]);//arrJudge[indexJudge]+
                var msg = new SocketBytes();
                msg.writeUint(201);//设置账号属性
                msg.writeUint(198);//引导
                msg.writeString(arrSave[indexJudge]);
                NetMgr.inst().send(msg);
            }
        }

        var arr=["2_1","2_3","2_9","2_15","3_1","4_1","4_2","4_5","4_7","5_1"];//可自由操作引导  4_2确定 4_5 4_7半身
        this._bg.setTouchEnabled(arr.indexOf(this._guideBean._idStep)==-1);//是否是自由操作

        this._arrow_up.setVisible(false);
        this._arrow_down.setVisible(false);
        this._speakPanel.setVisible(false);
        this._effectHand.setVisible(false);
        this._effectWords.setVisible(false);
        this._hand.setVisible(false);
        //var moveAction = cc.moveTo(1,cc.p(this._guideBean._hand_x,this._guideBean._hand_y));
        //var seq=new cc.Sequence(cc.moveTo(0.5,cc.p(this._guideBean._hand_x,this._guideBean._hand_y)) ,new cc.CallFunc(function(){this._hand.setPosition(cc.p(this._guideBean._hand_x+100,this._guideBean._hand_y-100));},this)).repeatForever();
        if(this._guideBean._effect_name==""){

        }else{
            cc.log("有单个特殊特效显示！！！！！！！！！");
            var csvEffect = ResMgr.inst().getCSV("animationConfig",this._guideBean._effect_name);
            var eff=new AnimationSprite();
            eff.setName(this._guideBean._effect_name);
            eff.setPosition(cc.p(this._guideBean._effect_x,this._guideBean._effect_y+down));
            eff.setAnimationByCount(csvEffect,0);
            //if(this._guideBean._effect_name=="guide_upcolumn")  eff.scaleX=eff.scaleY=2;//特殊处理 放大特效
            this._effectLayer.addChild(eff);
        }
        //手指特效
        if( (this._guideBean._hand_x==0&&this._guideBean._hand_y==0) && handP==undefined){

        }
        else{
            cc.log("有手指点击特效"+this._hand.getNumberOfRunningActions());
            //if(this._hand) this._hand.removeAction();

            if(this._hand.getNumberOfRunningActions()>0) {
                this._hand.stopAllActions();
            }
            this._effectHand.setVisible(true);
            this._hand.setVisible(true);
            this._effectHand.setPosition(cc.p(this._guideBean._hand_x,this._guideBean._hand_y+down));
            if(this._guideBean._hand_x==-1&&this._guideBean._hand_y==-1){
                if(!this._size) this._size = cc.director.getVisibleSize();
                this._effectHand.setPosition(cc.p(this._size.width/2,this._size.height/2+down));
            }
            this._hand.setPosition(cc.p(this._effectHand.x+50,this._effectHand.y-60+down));
            if(handP!=undefined){
                handP=cc.p(handP.x,handP.y+down);
                this._effectHand.setPosition(handP);
                this._hand.setPosition(cc.p(this._effectHand.x+50,this._effectHand.y-60));//+down
            }
            var movehand=cc.moveBy(0.5,cc.p(40,-50));
            var seq=new cc.Sequence(movehand,movehand.reverse() ).repeatForever();
            this._hand.runAction(seq);
        }


        cc.log(this._guideBean._speak_msg+"<<<this._guideBean.speak_msg"+this._guideBean._speak_msg=="");
        //对话窗
        if(this._guideBean._speak_msg==""){

        }
        else{
            cc.log("有说话文本：：：");
            this._speakPanel.setVisible(true);
            this._effectWords.setVisible(true);
            this._effectWords.setPosition(cc.p(this._size.width-100,this._speakPanel.y+50+down));
            this._speakPanel.getChildByName("tf_name").setString(ResMgr.inst().getString(this._guideBean._speak_name));
            this._tfSpeek.setString("");
            //this._speakPanel.getChildByName("tf_msg").setString(this._guideBean._speak_msg);
            this._speekInterval=setInterval(this.doSpeekInterval, 100,this);

        }

        cc.log(this._guideBean._arrow_direction+"arrowname:"+"_arrow_ 玩家的引导数据￥￥￥￥￥￥￥￥￥￥￥￥￥"+mainData.playerData.guide);
        if(this._guideBean._arrow_x!=0||this._guideBean._arrow_y!=0){
            this["_arrow_"+String(this._guideBean._arrow_direction)].setPosition(cc.p(this._guideBean._arrow_x,this._guideBean._arrow_y+down));
            this["_arrow_"+String(this._guideBean._arrow_direction)].setVisible(true);
            this["_arrow_"+String(this._guideBean._arrow_direction)].getChildByName("tf").setString(ResMgr.inst().getString(this._guideBean._arrow_msg));
            if(this["_arrow_"+String(this._guideBean._arrow_direction)].getNumberOfRunningActions()>0) {
                this["_arrow_"+String(this._guideBean._arrow_direction)].stopAllActions();
            }
            var moveArrow=cc.moveBy(0.5,cc.p(0,this._guideBean._arrow_direction=="up"?-20:20));
            var seq=new cc.Sequence(moveArrow,moveArrow.reverse() ).repeatForever();
            this["_arrow_"+String(this._guideBean._arrow_direction)].runAction(seq);
        }


        this._isInterval=true;
        if(this._intervalTime) clearInterval(this._intervalTime);
        this._intervalTime = setTimeout(this.doInterval, this._guideBean._delaytime*1000,this);

        EventMgr.inst().dispatchEvent("guide_event" ,this._guideBean._idStep );
    },
    //移除引导显示特效等
    removeEffect:function(){
        if(this._guideBean&&this._guideBean._effect_name!=""){
            var effect=this._effectLayer.getChildByName(this._guideBean._effect_name);
            if(effect!=null){
                effect.removeData();
                effect.removeFromParent();
                effect=null;
            }
        }
        if(this._intervalTime)  clearTimeout(this._intervalTime);
    },
    //间隔函数
    doInterval:function(owner){
        owner._isInterval=false;
        clearTimeout(owner._intervalTime);
    },
    //说话文字显示
    doSpeekInterval:function(owner){
        cc.log("说话文字逐字显示！！");
        if(owner._guideBean._speak_msg.length>0){
            var len=owner._tfSpeek.getString().length+1;
            if(len>ResMgr.inst().getString(owner._guideBean._speak_msg).length){
                clearInterval(owner._speekInterval);
                return;
            }
            owner._tfSpeek.setString(ResMgr.inst().getString(owner._guideBean._speak_msg).substr(0,len));
        }

    },

    //--------------事件
    onBgTouch:function(target,type) {
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log("onBgTouch"+this._isInterval);
                //引导  强制 切换地图  特殊处理
                if(this._guideBean&&this._guideBean._idStep=="4_3"){
                    if(mainData.uiData.showMap == MapChangeModule.CASTLE) {
                        if(this._arrow_down)    this._arrow_down.setVisible(false);
                        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
                        ModuleMgr.inst().openModule("MapChangeModule",{"type":MapChangeModule.MAP});
                        if(this._bg) this._bg.setTouchEnabled(false);
                    }
                    return;
                }

                if(this._guideBean._speak_msg!=""&&this._tfSpeek.getString().length!=ResMgr.inst().getString(this._guideBean._speak_msg).length){
                    this._tfSpeek.setString(ResMgr.inst().getString(this._guideBean._speak_msg));
                    return;
                }
                if(this._isInterval){
                    cc.log("CD中 无法跳过引导步骤")
                    return;
                }
                this.doNextGuide();
                break;
        }
    },
    //执行引导
    doNextGuide:function(type,guideId){

            var nextStep=this._guideBean._id+"_"+(this._guideBean._step+1);
            if(this._guideBean._step==this._guideBean._stepnum) nextStep=(this._guideBean._id+1)+"_1"
            cc.log(mainData.playerData.guide+"其他模块调用引导执行下一步:"+nextStep);
            cc.log(this._guideBean._step+"id step"+this._guideBean._id);
            if(nextStep=="4_1"||this._guideBean._id==4) {
                this._guideBean._idStep="5_1";
                this._guideBean._step=1;
                this._guideBean._id=5;
                nextStep="5_1";
            }//暂时第四步移民出城引导去除；
            this.removeEffect();
            this.showGuide(nextStep);
            //发包
    },
    //移除上次引导显示内容 切换内外城使用
    doRemoveGuide:function(type){
        if(this._arrow_up)cc.log("doRemoveGuide+++Guidemodule"+this._arrow_up)
        if(this._arrow_up)  this._arrow_up.setVisible(false);
        if(this._arrow_down)  this._arrow_down.setVisible(false);
        if(this._speakPanel)  this._speakPanel.setVisible(false);
        if(this._effectHand)  this._effectHand.setVisible(false);
        if(this._effectWords)  this._effectWords.setVisible(false);
        if(this._hand)  this._hand.setVisible(false);
        this.removeEffect();

    },
    //设置引导手指点击位置
    doHandP:function(type,handP){
        if(this._hand.getNumberOfRunningActions()>0) {
            this._hand.stopAllActions();
        }
        this._effectHand.setVisible(true);
        this._hand.setVisible(true);
        if(handP!=undefined){
            //handP=cc.p(handP.x,handP.y+down);
            this._effectHand.setPosition(handP);
            this._hand.setPosition(cc.p(this._effectHand.x+50,this._effectHand.y-60));//+down
        }
        var movehand=cc.moveBy(0.5,cc.p(40,-50));
        var seq=new cc.Sequence(movehand,movehand.reverse() ).repeatForever();
        this._hand.runAction(seq);
    },
    doArrowP:function(type,direction,handP){
        var hasEffect=false;
        if(this._guideBean&&this._guideBean._effect_name){
            var effect=this._effectLayer.getChildByName(this._guideBean._effect_name);
            if(effect!=null){
                effect.setPosition(handP);
                hasEffect=true;
            }
        }

        if(hasEffect) this["_arrow_"+String(direction)].setPosition(cc.p(effect.x,effect.y-100));
        else this["_arrow_"+String(direction)].setPosition(handP);
        //this["_arrow_"+String(direction)].setVisible(true);
        //this["_arrow_"+String(direction)].getChildByName("tf").setString(ResMgr.inst().getString(this._guideBean._arrow_msg));
        if(this["_arrow_"+String(direction)].getNumberOfRunningActions()>0) {
            this["_arrow_"+String(direction)].stopAllActions();
        }
        var moveArrow=cc.moveBy(0.5,cc.p(0,this._guideBean._arrow_direction=="up"?-20:20));
        var seq=new cc.Sequence(moveArrow,moveArrow.reverse() ).repeatForever();
        this["_arrow_"+String(direction)].runAction(seq);
    },
    destroy:function()
    {
        EventMgr.inst().removeEventListener("next_guide", this.doNextGuide, this);
        EventMgr.inst().removeEventListener("remove_guide", this.doRemoveGuide, this);
        EventMgr.inst().removeEventListener("guide_handP", this.doHandP, this);
    },

});

//静态属性
GuideModule.END_GUIDE="4_1";//强制引导结束
GuideModule.END_GUIDE_ALL="5_1";//全部引导结束
GuideModule.IS_CLOSE=false;//关闭引导  改成true