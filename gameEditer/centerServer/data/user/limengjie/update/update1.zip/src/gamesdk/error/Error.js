var Error = function () {

}

Error.registerError = function () {

}

Error.throw = function (msg) {
    throw msg;
}

GameSDK.Error = Error;