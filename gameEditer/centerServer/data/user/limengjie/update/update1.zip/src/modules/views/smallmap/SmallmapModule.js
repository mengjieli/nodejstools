/**
 * Created by cgMu on 2016/2/23.
 */

var SmallmapModule = ModuleBase.extend({
    _tagPanel:null,
    _mapPanel:null,
    _borderPanel:null,
    _borderPanel2:null,
    _borderPanelTB:null,
    _pageview:null,
    _serverNameLabel:null,

    tagpanel:false,
    tagList:null,
    itemIndex:0,
    itemCounts:0,
    //startPos:null,
    checkPos:null,
    serverData:null,
    model:null,
    centerPoint:null,//屏幕中心格子坐标
    centerPosition:null,//屏幕中心小地图坐标
    tagMove: false,
    castleList:null,

    mapX:null,
    mapY:null,
    totalWidth:null,
    totalHeight:null,
    mapX_min:null,
    mapY_min:null,
    _width:null,
    _height:null,

    imageUrlList:null,

    ctor:function() {
        this._super();
        this.checkPos = cc.p(0,0);
        this.centerPoint = cc.p(0,0);

        this.castleList = [];
        this.imageUrlList = [];
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.netCallback,this);
        EventMgr.inst().addEventListener("Search_Map",this.searchMapCallback,this);
        mainData.smallMapData.castlesList.addListener("add", this.addCastle, this);
    },

    initUI:function() {
        var container = new cc.Node();
        this.addChild(container);

        var root = ccs.load("res/images/ui/smallmap/Layer.json", "res/images/ui/").node;
        this.addChild(root);

        //适配
        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var serviceName = root.getChildByName("Image_3").getChildByName("Text_2");
        serviceName.ignoreContentAdaptWithSize(true);
        this._serverNameLabel = serviceName;

        this._mapPanel = container;

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this),
            onTouchMoved: this.onTouchMoved.bind(this),
            onTouchEnded: this.onTouchEnded.bind(this)
        }, container);

        //top,bottom
        var Image_11 = root.getChildByName("Image_11");
        Image_11.setTouchEnabled(true);
        Image_11.setVisible(false);
        var Text_8 = Image_11.getChildByName("Text_8");
        Text_8.ignoreContentAdaptWithSize(true);
        var Button_5_0 = Image_11.getChildByName("Button_5_0");
        Button_5_0.addTouchEventListener(this.borderBtnCallback,this);
        Button_5_0.setTag(1000);
        this._borderPanelTB = Image_11;

        //left,right
        var Panel_1 = root.getChildByName("Image_9");
        Panel_1.setTouchEnabled(true);
        Panel_1.setVisible(false);
        var Button_5 = Panel_1.getChildByName("Button_5");
        Button_5.setTag(1001);
        Button_5.addTouchEventListener(this.borderBtnCallback,this);
        posAutoLayout(Button_5,0.5);
        this._borderPanel = Panel_1;
        var Image_10 = this._borderPanel.getChildByName("Image_10");
        posAutoLayout(Image_10,0.5);
        var Text_7 = this._borderPanel.getChildByName("Text_7");
        Text_7.ignoreContentAdaptWithSize(true);
        posAutoLayout(Text_7,0.5);

        var Image_7 = root.getChildByName("Image_7");
        Image_7.setVisible(false);
        var Button_7_0 = Image_7.getChildByName("Button_7_0");
        Button_7_0.setTag(1101);//lr
        Button_7_0.addTouchEventListener(this.borderBtnCallback,this);
        posAutoLayout(Button_7_0,0.5);
        var Button_7 = Image_7.getChildByName("Button_7");
        Button_7.setTag(1100);//tb
        Button_7.addTouchEventListener(this.borderBtnCallback,this);
        var Image_8_0 = Image_7.getChildByName("Image_8_0");
        posAutoLayout(Image_8_0,0.5);
        var Text_9 = Image_7.getChildByName("Text_9");
        Text_9.ignoreContentAdaptWithSize(true);
        posAutoLayout(Text_9,0.5);
        this._borderPanel2 = Image_7;

        var panel = root.getChildByName("Panel_2");
        var Text_3 = panel.getChildByName("Text_3");
        Text_3.ignoreContentAdaptWithSize(true);
        Text_3.setString(ResMgr.inst().getString("smallmap_5"));
        var Button_6 = panel.getChildByName("Button_6");
        Button_6.addTouchEventListener(this.panelBtnCallback,this);
        var txt = Button_6.getChildByName("Text_4");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("smallmap_6"));
        this._tagPanel = panel;
        this._tagPanel.setVisible(false);
        this.setTagPanel();

        var tagBtn = root.getChildByName("Button_1");
        tagBtn.addTouchEventListener(this.tagCallback,this);

        var searchBtn = root.getChildByName("Button_2");
        searchBtn.addTouchEventListener(this.searchCallback,this);

        var deleteBtn = root.getChildByName("Button_3");
        deleteBtn.addTouchEventListener(this.deleteCallback,this);
        var title = deleteBtn.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("smallmap_1"));

        this.initSmallMap();

        //mainData.smallMapData.cameraX
        var pos = MapUtils.transPositionToPoint(mainData.smallMapData.cameraX,mainData.smallMapData.cameraY);
        var castle = {"coordX":pos.x,"coordY":pos.y};//mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
        //var pos = MapUtils.transPointToPosition(castle.coordX, castle.coordY);
        //cc.log("@SmallmapModule",pos.x,pos.y,ServerMapConfig.getInstance().serverMapWidth,ServerMapConfig.getInstance().serverMapHeight);
        cc.log("@SmallmapModule",mainData.smallMapData.cameraX,mainData.smallMapData.cameraY,pos.x,pos.y);

        var server = ServerMapConfig.getInstance().getServerData(castle.coordX, castle.coordY);
        serviceName.setString(server.name);
        this.serverData = server;
        //cc.log("@SmallmapModule",server.pointX,server.pointY,server.x,server.y,server.width,server.height,server.positionX,server.positionY);

        this.centerPoint = cc.p(castle.coordX, castle.coordY);
        //cc.log("@centerPoint",this.centerPoint.x,this.centerPoint.y);

        var pos = this.getCastlePosition(castle.coordX, castle.coordY);
        this.centerPosition = pos;

        //cc.log("@SmallmapModule",castle.coordX,castle.coordY,mainData.uiData.currentCastleId);
        //this._mapPanel.setPosition(cc.p(-(pos.x-size.width*0.5),-(pos.y-size.height*0.5)));
        //this.addCastleImage(pos.x,pos.y,true);
        this.setMapPanel(-(pos.x-size.width*0.5),-(pos.y-size.height*0.5));

        this.sendMsg(pos.x,pos.y);
    },

    //格子坐标转换成小地图上的坐标
    getCastlePosition: function (cx, cy) {
        var size = this._mapPanel.getContentSize();

        var pos = MapUtils.transPointToPosition(cx, cy);
        var x = pos.x - this.serverData.positionX;
        var y = pos.y - this.serverData.positionY;

        var sx = x / ServerMapConfig.getInstance().serverMapWidth * size.width;
        var sy = y / ServerMapConfig.getInstance().serverMapHeight * size.height;
        return cc.p(sx,sy);
    },

    setMapPanel: function (px,py) {
        if(px>this.mapX) px = this.mapX;
        if(px<this.mapX_min) {
            px = this.mapX_min;
        }
        if(py>this.mapY) py = this.mapY;
        if(py<this.mapY_min) {
            py = this.mapY_min;
        }

        this.showBorderPanel(px,py);

        this._mapPanel.setPosition(cc.p(px,py));
    },

    destroy:function() {
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.netCallback,this);
        EventMgr.inst().removeEventListener("Search_Map",this.searchMapCallback,this);
        mainData.smallMapData.castlesList.removeListener("add", this.addCastle, this);
        mainData.smallMapData.castlesList.removeAll();

        this.removeAllChildren(true);
        //release res
        for(var i in this.imageUrlList){
            var url = this.imageUrlList[i];
            //cc.log("@&&&&&&&&&&&",url);
            var txt = cc.TextureCache.getInstance().getTextureForKey(url);
            cc.TextureCache.getInstance().removeTexture(txt);
        }
    },

    _testText:null,

    show:function( data ) {

        /*cc.log("@SmallmapModule",mainData.smallMapData.left,mainData.smallMapData.bottom);
        var txt = new ccui.Text();
        txt.setTextBinding("玩家名称:{mainData.playerData.nick},地图:{mainData.playerData.account}");
        //txt.setTextBinding("玩家名称：{ mainData.smallMapData.left - mainData.smallMapData.bottom  }");

        //txt.setTextBindingEx("玩家名称:{0},{1}",mainData.playerData.nick,mainData.playerData.account);
        txt.setPosition(cc.p(mainData.systemData.screenWidth*0.5,mainData.systemData.screenHeight*0.5));
        this.addChild(txt);
        this._testText = txt;*/

        //this._testText = mainData.playerData;
        //cc.log("@ --------- ",this._testText.nick);
        //
        //mainData.playerData.nick = "*******";
        //cc.log("@ --------- ",this._testText.nick);
    },

    close:function() {

    },

    getTagData: function () {
        var array = [];
        var list = mainData.favoritesData;
        for(var i=0;i<list.length;i++){
            var it = list.getItemAt(i);
            if(it.tag){
                array.push(it);
            }
        }
        return array;
    },

    setTagPanel: function () {
        var arr = this.getTagData();
        this.tagList = arr;
        var counts = arr.length;

        var pageview = this._tagPanel.getChildByName("PageView_1");
        var root_it = this._tagPanel.getChildByName("Panel_9");
        if(counts==0){
            pageview.setVisible(false);
            root_it.setVisible(true);

            this.setTagItem(root_it);
        }
        else{
            this._pageview = pageview;
            pageview.addEventListener(this.pageviewEvent,this);
            root_it.setVisible(false);
            var left_btn = this._tagPanel.getChildByName("Button_4");
            left_btn.setTag(0);
            left_btn.addTouchEventListener(this.tagBtnCallback,this);
            var right_btn = this._tagPanel.getChildByName("Button_4_0");
            right_btn.setTag(1);
            right_btn.addTouchEventListener(this.tagBtnCallback,this);

            for(var i = 0; i < counts; i++) {
                var it = root_it.clone();
                it.setPosition(cc.p(0,0));
                it.setVisible(true);
                pageview.addPage(it);

                this.setTagItem(it,arr[i]);
            }

            this.itemCounts = counts-1;
            if(this.itemIndex>this.itemCounts){
                this.itemIndex=this.itemCounts;
            }

        }
    },

    setTagItem: function (node, data) {
        var label1 = node.getChildByName("Text_5");

        var label2 = node.getChildByName("Text_6");
        label2.ignoreContentAdaptWithSize(true);
        label2.setVisible(true);
        var label3 = node.getChildByName("Text_6_0");
        label3.ignoreContentAdaptWithSize(true);
        label3.setVisible(true);
        var label4 = node.getChildByName("Text_6_0_0");

        if(data==null){
            label1.setString(ResMgr.inst().getString("smallmap_7"));
            label2.setVisible(false);
            label3.setVisible(false);
            label4.setString(ResMgr.inst().getString("smallmap_8"));
        }
        else{
            label1.setString(ResMgr.inst().getItemName(data.type));
            label2.setString("X:"+data.x);
            label3.setString("Y:"+data.y);
            label4.setString(ResMgr.inst().getString("smallmap_12")+data.name);
        }
    },

    tagBtnCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var tag = sender.getTag();
            cc.log("@tagBtnCallback",this.itemIndex,this.itemCounts);
            if(tag==1){
                this.itemIndex++;
            }
            else{
                this.itemIndex--;
            }
            if(this.itemIndex<0){
                this.itemIndex=0;
            }
            if(this.itemIndex>this.itemCounts){
                this.itemIndex=this.itemCounts;
            }
            this._pageview.scrollToPage(this.itemIndex);
        }
    },

    pageviewEvent: function (sender, type) {
        switch (type){
            case ccui.PageView.EVENT_TURNING:
                this.itemIndex = sender.getCurPageIndex();
                break;
            default:
                break;
        }
    },

    setBorderPanel: function (panel,serverlist) {
        var Text_7 = panel.getChildByName("Text_7");
        Text_7.setString(serverlist[0]?serverlist[0].name:ResMgr.inst().getString("smallmap_11"));
        var Button_5 = panel.getChildByName("Button_5");
        Button_5.setTouchEnabled(serverlist[0]?true:false);
        //Button_5.setUserData();
    },

    setBorderPanelTB: function (panel,serverlist) {
        var Text_8 = panel.getChildByName("Text_8");
        Text_8.setString(serverlist[0]?serverlist[0].name:ResMgr.inst().getString("smallmap_11"));
        var Button_5_0 = panel.getChildByName("Button_5_0");
        Button_5_0.setTouchEnabled(serverlist[0]?true:false);
    },

    //先左右后上下
    setBorderPanel2: function (panel,serverlist) {
        var Text_9 = panel.getChildByName("Text_9");
        var Text_10 = panel.getChildByName("Text_10");
        Text_9.setString(serverlist[0]?serverlist[0].name:ResMgr.inst().getString("smallmap_11"));
        Text_10.setString(serverlist[1]?serverlist[1].name:ResMgr.inst().getString("smallmap_11"));
        var Button_7_0 = panel.getChildByName("Button_7_0");
        Button_7_0.setTouchEnabled(serverlist[0]?true:false);
        var Button_7 = panel.getChildByName("Button_7");
        Button_7.setTouchEnabled(serverlist[1]?true:false);
    },

    tagCallback: function (sender,type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            this.tagpanel = !this.tagpanel;
            this._tagPanel.setVisible(this.tagpanel)
        }
    },

    searchCallback: function (sender,type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var layer = new SearchLayer(this.serverData.name,this.centerPoint,this.serverData);
            ModuleMgr.inst().addNodeTOLayer(layer,ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    searchMapCallback: function (event, x, y) {
        //cc.log("@searchMapCallback",x,y);
        //mainData.uiData.operateMode=="1"
        //ModuleMgr.inst().getData("BattleUIModule").switchUI(false);

        var pos = MapUtils.transPointToPosition(x,y);
        ModuleMgr.inst().openModule("MapChangeModule", {
            "type": MapChangeModule.MAP,
            moduleData: {x: pos.x, y: pos.y}
        });
        ModuleMgr.inst().closeModule("SmallmapModule");
    },

    deleteCallback: function (sender,type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var list = this.getTagData();
            var _this = this;
            ModuleMgr.inst().openModule("AlertCostModule",{"text":ResMgr.inst().getString("smallmap_13"),"func": function () {
                cc.log("@全部删除~");
                if(list.length==0) return;
                for(var i in list){
                    var it = list[i];
                    ModuleMgr.inst().getData("CollectModule").ncUpdate( it.id, it.name, it.type, false );
                }
                _this.setTagPanel();
            },"title":ResMgr.inst().getString("smallmap_14")});
        }
    },

    panelBtnCallback: function (sender,type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            if(this.tagList.length==0) return;

            var it = this.tagList[this.itemIndex];
            //cc.log("@panelBtnCallback "+it.id,it.name,it.type,it.tag);
            ModuleMgr.inst().getData("CollectModule").ncUpdate( it.id, it.name, it.type, false );


        }
    },

    borderBtnCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var tag = sender.getTag();//1000 tb,1001 lr,1100,1101
            //切换服务器地图，更新 this.serverData
            var sp = this.getServerPos(this.model,tag);
            var server = this.getServer(sp.x,sp.y);
            if(server) this.serverData = server;
            cc.log("@server",this.serverData.x,this.serverData.y,sp.x,sp.y);

            var data = this.resetModel(this.model,tag);
            cc.log("@borderBtnCallback",this.model,data.model);
            this.model = data.model;
            this.setMapPanel(data.pos.x,data.pos.y);

            this.refreshContent(data);
        }
    },

    resetModel: function (model,tag) {
        var dir = this.model;
        var pos = this._mapPanel.getPosition();
        switch (model){
            case "top":
                dir = "bottom";
                pos.y = this.mapY;
                break;
            case "bottom":
                dir = "top";
                pos.y = this.mapY_min;
                break;
            case "left_top":

                if(tag==1100){
                    //top
                    dir = "left_bottom";
                    pos.y = this.mapY;
                }
                else if(tag==1101){
                    //left
                    dir = "right_top";
                    pos.x = this.mapX_min;
                }

                break;
            case "left_bottom":

                if(tag==1100){
                    //top
                    dir = "left_top";
                    pos.y = this.mapY_min;
                }
                else if(tag==1101){
                    //left
                    dir = "right_bottom";
                    pos.x = this.mapX_min;
                }

                break;
            case "right_bottom":

                if(tag==1100){
                    //top
                    dir = "right_top";
                    pos.y = this.mapY_min;
                }
                else if(tag==1101){
                    //left
                    dir = "left_bottom";
                    pos.x = this.mapX;
                }

                break;
            case "right_top":

                if(tag==1100){
                    //top
                    dir = "right_bottom";
                    pos.y = this.mapY;
                }
                else if(tag==1101){
                    //left
                    dir = "left_top";
                    pos.x = this.mapX;
                }

                break;
            case "left":
                dir = "right";
                pos.x = this.mapX_min;
                break;
            case "right":
                dir = "left";
                pos.x = this.mapX;
                break;
        }
        return {"model":dir,"pos":pos};
    },

    getServerPos: function (model, tag) {
        var x = this.serverData.x;
        var y = this.serverData.y;

        if(tag == 1000){
            //top or bottom
            if(model=="top"){
                cc.log("@向上");
                y += 1;
            }
            else{
                cc.log("@向下");
                y -= 1;
            }
        }

        if(tag==1001){
            if(model=="left"){
                cc.log("@向左");
                x -= 1;
            }
            else{
                cc.log("@向→");
                x += 1;
            }
        }

        if(tag == 1100){
            if(model=="right_top" || model=="left_top"){
                cc.log("@向↑");
                y += 1;
            }
            else{
                cc.log("@向↓");
                y -= 1;
            }
        }

        if(tag == 1101){
            if(model=="right_top" || model=="right_bottom"){
                cc.log("@@向→");
                x += 1;
            }
            else{
                cc.log("@向←");
                x -= 1;
            }
        }
        return cc.p(x,y);

    },

    refreshContent: function (data) {
        //服务器名称
        this._serverNameLabel.setString(this.serverData.name);
        //清空上一地图上的城堡
        for(var i in this.castleList){
            this.castleList[i].removeFromParent(true);
        }
        this.castleList=[];
        mainData.smallMapData.castlesList.removeAll();

        //
        this.sendMsg(mainData.systemData.screenHeight*0.5-data.pos.x,mainData.systemData.screenHeight*0.5-data.pos.y);
    },

    onTouchBegan: function (touch, event) {
        //this.startPos = touch.getLocation();
        //cc.log("@onTouchBegan",mainData.systemData.screenWidth,mainData.systemData.screenHeight);
        if(this._tagPanel.isVisible()){
            this.tagpanel = false;
            this._tagPanel.setVisible(false);
        }
        this.tagMove = false;
        return true;
    },

    onTouchMoved: function (touch, event) {
        var pos = touch.getLocation();
        var delt = touch.getDelta();

        var location = this._mapPanel.getPosition();
        var px = location.x+delt.x;
        var py = location.y+delt.y;

        this.setMapPanel(px,py);

        //屏幕中心对应小地图坐标：
        var sx = mainData.systemData.screenWidth*0.5 - px;
        var sy = mainData.systemData.screenHeight*0.5 - py;

        this.centerPosition = cc.p(sx,sy);

        this.centerPoint = this.transPositionToPoint(sx,sy);
        //cc.log("@centerPoint",this.centerPoint.x,this.centerPoint.y);
        this.tagMove = true;

        if(Math.abs(sx-this.checkPos.x)>mainData.systemData.screenWidth*0.5
        ||Math.abs(sy-this.checkPos.y)>mainData.systemData.screenHeight*0.5){
            this.sendMsg(sx,sy);
        }
    },

    onTouchEnded: function (touch, event) {
        if(this.tagMove){
            this.tagMove=false;
            return;
        }
        var pos = touch.getLocation();
        pos.x -= mainData.systemData.screenWidth*0.5;
        pos.y -= mainData.systemData.screenHeight*0.5;

        pos.x += this.centerPosition.x;
        pos.y += this.centerPosition.y;

        var p = this.transPositionToPoint(pos.x,pos.y);

        cc.log("@centerPosition",this.centerPosition.x,this.centerPosition.y,pos.x,pos.y,"------>", p.x, p.y);

        EventMgr.inst().dispatchEvent("Search_Map", p.x, p.y);
    },
    
    initSmallMap: function () {
        var data = ResMgr.inst().getJSON("server","maps");
        var height = data.length;
        var width = data[0].length;

        this.mapX = SmallMapData.MAPIMAGE_WIDTH;//小地图x坐标最大值
        this.mapY = SmallMapData.MAPIMAGE_HEIGHT;//小地图y坐标最大值
        this.totalWidth = (width+1)*SmallMapData.MAPIMAGE_WIDTH;//小地图长；额外加上外围一圈
        this.totalHeight = (height+1)*SmallMapData.MAPIMAGE_HEIGHT;//小地图宽

        this._width = width*SmallMapData.MAPIMAGE_WIDTH;
        this._height = height*SmallMapData.MAPIMAGE_HEIGHT;

        this.mapX_min = mainData.systemData.screenWidth-this.totalWidth;
        this.mapY_min = mainData.systemData.screenHeight-SmallMapData.TOPBAR_HEIGHT-this.totalHeight;

        this._mapPanel.setContentSize(cc.size(this._width,this._height));
        //cc.log("@小地图尺寸：",this.totalWidth,this.totalHeight);

        for(var i = 0; i < height; i++) {
            for(var j = 0; j < width; j++) {
                this.createImage(data[i][j],j,i);
            }
        }

        //bottom
        var list_bottom = data[height-1];
        for(var i = 0; i < list_bottom.length; i++) {
            this.createImage(list_bottom[i],i,-1,true);
        }

        //top
        var list_top = data[0];
        for(var i = 0; i < list_top.length; i++) {
            this.createImage(list_top[i],i,height,true);
        }

        //left
        for(var i = 0; i < height; i++) {
            this.createImage(data[i][width-1],-1,i,true);
        }

        //right
        for(var i = 0; i < height; i++) {
            this.createImage(data[i][0],width,i,true);
        }

        this.createImage(data[0][width-1],-1,height,true);
        this.createImage(data[0][0],width,height,true);
        this.createImage(data[height-1][0],width,-1,true);
        this.createImage(data[height-1][width-1],-1,-1,true);
    },

    createImage: function (url, lx, ly,border) {
        var path = "res/images/ui/smallmap/scale/"+url+".png";
        var image = new ccui.ImageView();
        image.loadTexture(path);
        image.setAnchorPoint(cc.p(0,0));
        image.setPosition(this.getImagePosition(lx,ly));
        this._mapPanel.addChild(image);

        var exist = false;
        for(var i in this.imageUrlList){
            if(path==this.imageUrlList[i]){
                exist = true;
                break;
            }
        }
        if(!exist){
            this.imageUrlList.push(path);
        }


        //if(border){
        //    //var size = image.getContentSize();
        //    var shadow = new ccui.ImageView();
        //    shadow.loadTexture("shengjidi1.png",ccui.Widget.PLIST_TEXTURE);
        //    shadow.setScale9Enabled(true);
        //    shadow.setCapInsets(cc.rect(10,10,10,10));
        //    shadow.setAnchorPoint(cc.p(0,0));
        //    shadow.setPosition(image.getPosition());
        //    shadow.setContentSize(image.getContentSize());
        //    this._mapPanel.addChild(shadow);
        //}
    },

    getImagePosition: function (x, y) {
        var posx = SmallMapData.MAPIMAGE_WIDTH * x;
        var posy = SmallMapData.MAPIMAGE_HEIGHT * y;
        return cc.p(posx,posy);
    },

    //屏幕中心的小地图坐标
    sendMsg: function (x,y) {
        var size = this._mapPanel.getContentSize();
        var tempx = x-mainData.systemData.screenWidth;
        var tempy = y-mainData.systemData.screenHeight;
        if(tempx<0) tempx = 0;
        if(tempy<0) tempy = 0;
        var posx = tempx/size.width * ServerMapConfig.getInstance().serverMapWidth + this.serverData.positionX;
        var posy = tempy/size.height * ServerMapConfig.getInstance().serverMapHeight + this.serverData.positionY;

        //cc.log("@sendMsg#",x,y,x-mainData.systemData.screenWidth,y-mainData.systemData.screenHeight);

        var pos = MapUtils.transPositionToPoint(posx,posy);

        var left = pos.x;
        var bottom = pos.y;

        this.checkPos = cc.p(x,y);

        var endx = x+mainData.systemData.screenWidth;
        var endy = y+mainData.systemData.screenHeight;
        if(endx>size.width) endx = size.width;
        if(endy>size.height) endy = size.height;
        var width = endx / size.width * ServerMapConfig.getInstance().serverMapWidth + this.serverData.positionX;
        var height = endy / size.height * ServerMapConfig.getInstance().serverMapHeight + this.serverData.positionY;
        var areaSize = MapUtils.transPositionToPoint(width,height);

        var msg = new SocketBytes();
        msg.writeUint(313);
        msg.writeInt(left);
        msg.writeInt(bottom);
        msg.writeUint(areaSize.x-left);
        msg.writeUint(areaSize.y-bottom);
        NetMgr.inst().send(msg);
        //cc.log("@sendMsg",left,bottom,areaSize.x-left,areaSize.y-bottom);

    },

    //小地图上的坐标转换格子坐标
    transPositionToPoint: function (x,y) {
        if(x<0) x = 0;
        if(x>this._width) x = this._width;
        if(y<0) y = 0;
        if(y>this._height) y = this._height;

        var width = x / this._width * ServerMapConfig.getInstance().serverMapWidth + this.serverData.positionX;
        var height = y / this._height * ServerMapConfig.getInstance().serverMapHeight + this.serverData.positionY;
        var areaSize = MapUtils.transPositionToPoint(width,height);
        return areaSize;
    },

    netCallback: function (event, data) {
        if(data == 313){
            cc.log("@netCallback 313");
        }
        if(data == 201){
            cc.log("@netCallback 201");
            this._pageview.removePageAtIndex(this.itemIndex);
            this.itemCounts--;
            if(this.itemIndex-1<0) this.itemIndex=0;
            if(this.itemIndex>this.itemCounts) this.itemIndex=this.itemCounts;
            if(this.itemCounts<0) this.setTagPanel();
            this.tagList = this.getTagData();
            cc.log("@panelBtnCallback",this.itemIndex,this.itemCounts,this.tagList.length);
        }
    },

    addCastle: function (it) {
        //cc.log("@addCastle",it.x,it.y,it.uuid);
        var pos = this.getCastlePosition(it.x,it.y);

        if(it.uuid==mainData.playerData.account){
            cc.log("@addCastle",it.x,it.y,"-------->",pos.x,pos.y);
        }

        this.addCastleImage(pos.x,pos.y,it.uuid==mainData.playerData.account);
    },

    addCastleImage: function (x, y, self) {
        var url = "smallmap/xdt_chengbao1.png";
        if(self){
            url = "smallmap/xdt_chengbao2.png"
        }

        var image = new ccui.ImageView();
        image.loadTexture(url,ccui.Widget.PLIST_TEXTURE);
        image.setPosition(cc.p(x,y));
        this._mapPanel.addChild(image);
        this.castleList.push(image);

        //cc.log("@addCastleImage",x,y);
    },

    showBorderPanel: function (x, y) {
        this._borderPanel.setVisible(false);
        this._borderPanel2.setVisible(false);
        this._borderPanelTB.setVisible(false);
        this.model = null;

        //right
        if(x==this.mapX_min) {
            this.model = "right";
            this.setPanelFlip_Left_Right("right");
        }

        //left
        if(x==this.mapX) {
            //this._borderPanel.setVisible(true);
            this.model = "left";
            this.setPanelFlip_Left_Right("left");
        }

        //top
        if(y==this.mapY_min){
            this.model = "top";
            this.setPanelFlip_Top_Bottom("top");
        }

        //bottom
        if(y==this.mapY){
            this.model = "bottom";
            this.setPanelFlip_Top_Bottom("bottom");
        }

        //right_top
        if(x==this.mapX_min&&
            y==this.mapY_min) {
            this.model = "right_top";
            this.setPanelFlip2("right_top");
        }

        //right_bottom
        if(x==this.mapX_min&&
            y==this.mapY) {
            this.model = "right_bottom";
            this.setPanelFlip2("right_bottom");
        }

        //left_top
        if(x==this.mapX&&
            y==this.mapY_min) {
            this.model = "left_top";
            this.setPanelFlip2("left_top");
        }

        //left_bottom
        if(x==this.mapX&&
            y==this.mapY) {
            this.model = "left_bottom";
            this.setPanelFlip2("left_bottom");
        }
    },

    setPanelFlip2: function (str) {
        this._borderPanel.setVisible(false);
        this._borderPanelTB.setVisible(false);

        this._borderPanel2.setVisible(true);
        this._borderPanel2.setFlippedX(false);
        this._borderPanel2.setFlippedY(false);

        var Text_9 = this._borderPanel2.getChildByName("Text_9");
        var Text_10 = this._borderPanel2.getChildByName("Text_10");

        switch (str) {
            case "right_bottom":
                this._borderPanel2.setFlippedY(true);
                Text_9.setFlippedY(true);
                Text_10.setFlippedY(true);
                Text_9.setFlippedX(false);
                Text_10.setFlippedX(false);
                break;
            case "left_top":
                this._borderPanel2.setFlippedX(true);
                Text_9.setFlippedX(true);
                Text_10.setFlippedX(true);
                Text_9.setFlippedY(false);
                Text_10.setFlippedY(false);
                break;
            case "left_bottom":
                this._borderPanel2.setFlippedX(true);
                this._borderPanel2.setFlippedY(true);
                Text_9.setFlippedX(true);
                Text_10.setFlippedX(true);
                Text_9.setFlippedY(true);
                Text_10.setFlippedY(true);
                break;
            default :
                //cc.log("@right_top");
                Text_9.setFlippedY(false);
                Text_10.setFlippedY(false);
                Text_9.setFlippedX(false);
                Text_10.setFlippedX(false);
                break;
        }

        this.setBorderPanel2(this._borderPanel2,this.getBorderServerData(this.model));
    },

    setPanelFlip_Left_Right: function (str) {
        this._borderPanel.setVisible(true);
        var Text_7 = this._borderPanel.getChildByName("Text_7");

        if(str=="left"){
            this._borderPanel.setFlippedX(true);
            this._borderPanel.setPositionX(0);
            Text_7.setFlippedX(true);
        }
        else{
            this._borderPanel.setFlippedX(false);
            this._borderPanel.setPositionX(960);
            Text_7.setFlippedX(false);
        }

        this.setBorderPanel(this._borderPanel,this.getBorderServerData(this.model));
    },

    setPanelFlip_Top_Bottom: function (str) {
        this._borderPanelTB.setVisible(true);
        var Text_8 = this._borderPanelTB.getChildByName("Text_8");

        if(str=="bottom"){
            this._borderPanelTB.setFlippedX(true);
            this._borderPanelTB.setPositionY(0);
            Text_8.setFlippedY(true);
        }
        else{
            var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
            down = down * (1 / GameMgr.inst().scaleX);
            this._borderPanelTB.setFlippedX(false);
            this._borderPanelTB.setPositionY(594+down);
            Text_8.setFlippedY(false);
        }

        this.setBorderPanelTB(this._borderPanelTB,this.getBorderServerData(this.model));
    },

    getBorderServerData: function (dir) {
        var x = this.serverData.x;
        var y = this.serverData.y;

        var list = [];

        switch (dir){
            case "top":
                list.push(cc.p(x,y+1));
                break;
            case "bottom":
                list.push(cc.p(x,y-1));
                break;
            case "left_top":
                list.push(cc.p(x-1,y));
                list.push(cc.p(x,y+1));
                break;
            case "left_bottom":
                list.push(cc.p(x-1,y));
                list.push(cc.p(x,y-1));
                break;
            case "right_bottom":
                list.push(cc.p(x+1,y));
                list.push(cc.p(x,y-1));
                break;
            case "right_top":
                list.push(cc.p(x+1,y));
                list.push(cc.p(x,y+1));
                break;
            case "left":
                list.push(cc.p(x-1,y));
                break;
            case "right":
                list.push(cc.p(x+1,y));
                break;
        }

        var server = [];
        for(var i in list){
            var pos = list[i];
            var s = this.getServer(pos.x,pos.y);
            if(s){
                server.push(s);
            }
        }
        return server;
    },

    getServer: function (x,y) {
        for(var i = 0; i < mainData.serverList.length; i++) {
            var server = mainData.serverList.getItemAt(i);
            if(server.x==x && server.y==y) {
                return server;
            }
        }
        return null;
    }
});

SmallMapData={};
SmallMapData.MAPIMAGE_WIDTH = 150;
SmallMapData.MAPIMAGE_HEIGHT = 104;
SmallMapData.TOPBAR_HEIGHT = 46;