var MapCollection = MapSprite.extend({
    ctor: function (collectionData) {
        this._super("res/fight/ui/collectionIcon.png");
        this.data = collectionData;
        var pos = MapUtils.transPointToPosition(collectionData.x, collectionData.y);
        this.setPosition(pos.x - 18, pos.y);
    }
});