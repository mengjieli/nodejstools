var BigMapClickCommand = (function (_super) {
    __extends(BigMapClickCommand, _super);

    function BigMapClickCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
        this.count = 0;
    }

    var d = __define, c = BigMapClickCommand;
    p = c.prototype;


    /**
     * 初始化
     * @param params Object
     *  @subparam x 点击的坐标 x
     *  @subparam y 点击的坐标 y
     */
    p.init = function (params) {
        var x = params.x;
        var y = params.y;
        this.point = {"x": x, "y": y};
        var longTouch = params.longTouch;
        var mode = mainData.uiData.operateMode;
        var playerList = mainData.mapData.myArmyList;
        var selectList = [];
        var selectAim = "";
        for (var i = 0; i < playerList.length; i++) {
            var player = playerList.getItemAt(i);
            if (player.selected) {
                selectList.push(player);
                var look = modelMgr.call("Table", "getTableItemByValue", ["Arm", player.type]).arm_type;
                if (look == 1207001) {
                    selectAim = "farmer";
                } else {
                    selectAim = "army";
                }
            }
        }
        var clickInfo = this.getClickAim(x, y);
        var clickAim = clickInfo.type;
        var clickData = clickInfo.data;
        this.selectAim = selectAim;
        this.clickAim = clickAim;
        this.clickData = clickData;
        var menu = this.getClickMenu(mode, selectAim, clickAim);
        if (!menu) {
            trace(x, y, mode, selectAim, clickAim);//,flower.ObjectDo.toString(menu)
            return;
        }
        //trace("!",flower.ObjectDo.toString(menu));
        if (mode == 1 || (mode == 2 && longTouch && menu.enterSelectionMode == "")) { //弹出UI菜单
            if (mainData.uiData.clickMenuVisible) {
                this.hideClickMenu();
                return;
            }
            if (mainData.uiData.map.showCastleRange != "") {
                mainData.uiData.map.showCastleRange = "";
            }
            if (clickAim != "myCastle" && clickAim.slice(clickAim.length - "Castle".length, clickAim.length) == "Castle") {
                //显示其它城堡的势力范围
                var castle = this.clickData;
                if (castle.userAccount != mainData.playerData.account) {
                    mainData.uiData.map.showCastleRange = castle.id;
                }
            }
            var clickMenu = [];
            var list = [menu.clickMenu1, menu.clickMenu2, menu.clickMenu3, menu.clickMenu4, menu.clickMenu5];
            var isGuide = false;//引导土地券点击判断
            for (var i = 0; i < list.length; i++) {
                if (list[i].length == 2 || list[i].length == 3) {
                    var funcName = list[i][list[i].length - 1];
                    if (list[i].length == 3) {
                        var checkMenuFunction = list[i][1];
                        if (this[checkMenuFunction]() == false) {
                            continue;
                        }
                    }
                    clickMenu.push({id: parseInt(list[i][0]), back: this[funcName].bind(this)});
                    var guideData = ModuleMgr.inst().getData("GuideModule");
                    if (parseInt(list[i][0]) == 1501014) isGuide = true;
                }
            }
            var position = MapUtils.transPointToPosition(x, y);
            if (clickMenu.length) {
                if (clickAim.slice(clickAim.length - "Castle".length, clickAim.length) == "Castle") {
                    this.point.x = this.clickData.coordX;
                    this.point.y = this.clickData.coordY;
                    position = MapUtils.transPointToPosition(clickData.coordX, clickData.coordY);
                    position.x += MapUtils.width / 2;
                }
                var text = this.getClickMenuText();
                this.resetCameraPos(position);
                //土地券引导触发 判断
                //cc.error(guideData._guideBean._idStep+"guideData._guideBean._idStep");
                if (isGuide && (guideData._guideBean && (guideData._guideBean._idStep == "2_3" || guideData._guideBean._idStep == "2_9" || guideData._guideBean._idStep == "2_15"))) {
                    EventMgr.inst().dispatchEvent("next_guide");
                    EventMgr.inst().dispatchEvent("guide_handP", cc.p((position.x - MapCamera.getInstance().x) * MapCamera.getInstance().screenScaleX + 85, (position.y - MapCamera.getInstance().y) * MapCamera.getInstance().screenScaleY - 70));
                }
                if (!guideData._guideBean || (isGuide && (guideData._guideBean && (guideData._guideBean._idStep == "2_3" || guideData._guideBean._idStep == "2_9" || guideData._guideBean._idStep == "2_15"))  ) || (guideData._guideBean && (guideData._guideBean._idStep != "2_3" && guideData._guideBean._idStep != "2_9" && guideData._guideBean._idStep != "2_15"))) {
                    ModuleMgr.inst().openModule("TileMenuModule", {
                        title: text.title,
                        name: text.name,
                        player: text.player,
                        res: text.res,
                        px: x,
                        py: y,
                        x: (position.x - MapCamera.getInstance().x) * MapCamera.getInstance().screenScaleX ,
                        y: (position.y - MapCamera.getInstance().y) * MapCamera.getInstance().screenScaleY,
                        list: clickMenu
                    });
                    mainData.uiData.clickMenuVisible = true;
                }
            }
            mainData.uiData.map.showImage = "";
            mainData.uiData.map.shineGrid = "";
            mainData.uiData.map.shineGridX = position.x;
            mainData.uiData.map.shineGridY = position.y;
            mainData.uiData.map.showImage = menu.showImage;
            mainData.uiData.map.shineGrid = menu.shineColor;
        } else if (mode == 2 && longTouch && menu.enterSelectionMode != "") { //指令模式下长按特殊处理
            this.execute(menu.enterSelectionMode);
        } else { //执行点击函数
            //if (mainData.uiData.clickMenuVisible) {
            //    this.hideClickMenu();
            //}
            var text = this.getClickMenuText();
            var position = MapUtils.transPointToPosition(x, y);
            this.resetCameraPos(position);
            ModuleMgr.inst().openModule("TileMenuModule", {
                title: text.title,
                name: text.name,
                player: text.player,
                res: text.res,
                px: x,
                py: y,
                hide: true,
                x: (position.x - MapCamera.getInstance().x) * MapCamera.getInstance().screenScaleX,
                y: (position.y - MapCamera.getInstance().y) * MapCamera.getInstance().screenScaleY,
                list: []
            });
            mainData.uiData.clickMenuVisible = true;
            if (selectAim == "") {
                this.execute(menu.noSelectClick, false);
            } else {
                this.execute(menu.selectClick, false);
            }
        }
    }

    p.resetCameraPos = function(position) {
        var menuX = position.x - mainData.mapData.cameraData.x;
        var menuY = position.y - mainData.mapData.cameraData.y;
        var cameraX = mainData.mapData.cameraData.x + mainData.systemData.screenWidth/2;
        var cameraY = mainData.mapData.cameraData.y + mainData.systemData.screenHeight/2;
        var moveX = 0;
        var moveY = 0;
        if(menuX < 200) {
            moveX = 200 - menuX;
            cameraX -= moveX;
            modelMgr.call("BigMap", "cameraLookAt", [cameraX,cameraY]);
        }
        else if(menuX > mainData.systemData.screenWidth - 200) {
            moveX = mainData.systemData.screenWidth - 200 - menuX;
            cameraX -= moveX;
            modelMgr.call("BigMap", "cameraLookAt", [cameraX,cameraY]);
        }
        if(menuY < 100) {
            moveY = 100 - menuY;
            cameraY -= moveY;
            modelMgr.call("BigMap", "cameraLookAt", [cameraX,cameraY]);
        }
        else if(menuY > mainData.systemData.screenHeight - 150) {
            moveY = mainData.systemData.screenHeight - 150 - menuY;
            cameraY -= moveY;
            modelMgr.call("BigMap", "cameraLookAt", [cameraX,cameraY]);
        }
    }

    /**
     * 空地详情
     */
    p.showBlockInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var blockInfo = this.clickData;
        var earth = null;
        ModuleMgr.inst().openModule("BlockInfoModule", {
            "territoryid": blockInfo.type,
            "resourceid": null,
            "earthid": null,
            "certificateid": null,
            "mine": null,
            "earthData": null
        });
    }

    /**
     * 显示战略资源详情
     */
    p.showWarResourceInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var blockInfo = ServerMapConfig.getInstance().getBlock(this.point.x, this.point.y);
        var earth = this.clickData;
        ModuleMgr.inst().openModule("BlockInfoModule", {
            "territoryid": blockInfo.type,
            "resourceid": earth.type,
            "earthid": null,
            "certificateid": null,
            "mine": earth.user == mainData.playerData.account ? true : false,
            "earthData": earth
        });
    }

    /**
     * 采集战略资源
     */
    p.collecteWarResource = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i],
                "action": 5
            }]);
        }
    }

    /**
     * 地块详情
     */
    p.showEarthInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var blockInfo = ServerMapConfig.getInstance().getBlock(this.point.x, this.point.y);
        var earth = this.clickData;
        ModuleMgr.inst().openModule("BlockInfoModule", {
            "territoryid": blockInfo.type,
            "resourceid": earth.productionResourceId,
            "earthid": earth.earthCard,
            "certificateid": earth.useAccelerationCard,
            "mine": earth.user == mainData.playerData.account ? true : false,
            "earthData": earth
        });
    }

    /**
     * 地块是否可以升级
     * @returns {boolean}
     */
    p.isEarthCanLevelUp = function (hide) {
        var earth = this.clickData;
        var testTable = modelMgr.call("Table", "getTableItemByValue", ["item", earth.earthCard]);
        var level = parseInt(testTable.type);
        if (level < MapConfigUtils.getMaxEatrhLevel()) {
            return true;
        }
        return false;
    }

    /**
     * 升级地块
     */
    p.levelUpEarth = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var blockInfo = ServerMapConfig.getInstance().getBlock(this.point.x, this.point.y);
        var earth = this.clickData;
        var point = this.point;
        ModuleMgr.inst().openModule("BlockLevelupModule", {
            "earthData": earth,
            "territoryid": blockInfo.type,
            "resourceid": earth.productionResourceId,
            "earthid": earth.earthCard,
            "certificateid": earth.useAccelerationCard,
            x: point.x,
            y: point.y
        });
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
    }

    /**
     * 是否可以使用效率卡
     * @returns {boolean}
     */
    p.canUseAcclerationCard = function (hide) {
        var earth = this.clickData;
        return !earth.useAccelerationCard;
    }

    /**
     * 使用效率卡
     */
    p.useAcclerationCard = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var point = this.point;
        var msg = new SocketBytes();
        msg.writeUint(308);
        msg.writeInt(point.x);
        msg.writeInt(point.y);
        NetMgr.inst().send(msg);
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
    }

    /**
     * 添加收藏夹
     */
    p.addCollection = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }

        var result = ModuleMgr.inst().getData("CollectModule").checkCollected(this.point.x, this.point.y);
        if (result) {
            ModuleMgr.inst().openModule("AlertString", {
                str: ResMgr.inst().getString("collect_13"),
                color: null,
                time: null,
                pos: null
            });
        }
        else {
            var blockInfo = ServerMapConfig.getInstance().getBlock(this.point.x, this.point.y);
            var clickAim = this.clickAim;
            var earth = clickAim.slice(clickAim.length - "Earth".length, clickAim.length) == "Earth" ? this.clickData : null;
            var title = ResMgr.inst().getString(blockInfo.type + "0");
            ModuleMgr.inst().openModule("AddCollectModule", {
                "id": null,
                "name": earth ? ResMgr.inst().getString(earth.productionResourceId + "2") : title,
                "pos": {x: this.point.x, y: this.point.y}
            });
        }
    }

    /**
     * 检查地块是否在城堡范围内
     * @returns {boolean}
     */
    p.checkBlankInCastle = function () {
        var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
        var lv = castle.attributes.getItem("type", 2500007).value;
        var testTable = modelMgr.call("Table", "getTableItemByValue", ["City_Castel", lv]);
        var range = testTable.range;
        var distance = MapUtils.getDistance(castle.coordX, castle.coordY, this.point.x, this.point.y);
        if (distance <= range) {
            return true;
        }
        return false;
    }

    /**
     * 购买地块
     */
    p.buyEarth = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var blockInfo = this.clickData;
        var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
        ModuleMgr.inst().openModule("UseScrollModule", {
            id: blockInfo.type,
            castleId: castle.id,
            x: this.point.x,
            y: this.point.y
        });//关闭弹框
    }

    /**
     * 收获单个地块
     */
    p.harvestEarth = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var msg = new SocketBytes();
        msg.writeUint(314);
        msg.writeInt(this.clickData.coordX);
        msg.writeInt(this.clickData.coordY);
        NetMgr.inst().send(msg);
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
    }


    /**
     * 是否显示建城按钮
     */
    p.canBuildCastle = function () {
        if(mainData.mapData.myCastleList.getItem("castleId", mainData.uiData.currentCastleId) == null) {
            if(ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(1901001)[0]._building_level >= 12) {
                return true;
            }
        }
        return  false;
    }

    /**
     * 建立城堡
     * @param hide
     */
    p.buildCastle = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var point = DataManager.getInstance().getNewData("PointData");
        point.x = this.point.x;
        point.y = this.point.y;
        mainData.uiData.map.buildCastle = point;
    }

    /**
     * 显示城堡信息
     */
    p.showCastleInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        ModuleMgr.inst().openModule("CastleInfoModule", {"data": this.clickData});
    }

    /**
     * 是否显示出征按钮
     */
    p.checkArmyPanel = function () {
        var castleData = this.clickData;
        return castleData.id == mainData.uiData.currentCastleId ? true : false;
    }

    /**
     * 出征
     */
    p.showArmyPanel = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        ModuleMgr.inst().openModule("CorpsAssembledModule", this.clickData.id);
    }

    /**
     * 显示军队信息
     */
    p.showArmyInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }

        cc.log("@showArmyInfo >> ",this.clickData.relation);
        if(this.clickData.relation=="monster"){
            ModuleMgr.inst().openModule("MonsterInfoModule", {"data": this.clickData});
        }
        else{
            ModuleMgr.inst().openModule("ArmyInfoModule", {"data": this.clickData});
        }
    }

    /**
     * 选择部队
     */
    p.selecteRoler = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var roler = this.clickData;
        if (roler.castleId == mainData.uiData.currentCastleId) {
            roler.selected = !roler.selected;
        } else {
            ModuleMgr.inst().openModule("AlertString", {
                str: ResMgr.inst().getString("selectCurrentArmy"),
                color: null,
                time: null,
                pos: null
            });
        }
    }

    /**
     * 移动到某个点
     */
    p.moveTo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i]
            }]);
        }
    }

    /**
     * 回城
     */
    p.goBackCastle = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i],
                "action": 4
            }]);
        }
    }

    /**
     * 砍伐资源
     */
    p.collecteResource = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i],
                "action": 3
            }]);
        }
    }

    /**
     * 显示资源详情
     */
    p.showResourceInfo = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var point = this.point;
        var resource = this.clickData;
        ModuleMgr.inst().openModule("BlockInfoModule", {
            "territoryid": ServerMapConfig.getInstance().getBlock(point.x, point.y).type,
            "resource": resource
        });
    }

    /**
     * 攻击敌方部队
     */
    p.attackArmy = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i],
                "action": 1,
                "param": this.clickData.id
            }]);
        }
    }

    /**
     * 攻击怪物
     */
    p.attackMonster = function (hide) {
        if (hide != false) {
            this.hideClickMenu();
        }
        var playerList = mainData.mapData.myArmyList.getItems("selected", true);
        for (var i = 0; i < playerList.length; i++) {
            ModelManager.getInstance().call("BigMap", "execute", ["moveTo", {
                "x": this.point.x,
                "y": this.point.y,
                "data": playerList[i],
                "action": 1,
                "param": this.clickData.id
            }]);
        }
    }

    /**
     * 进入多选模式
     */
    p.enterSelectionMode = function () {
        //ModuleMgr.inst().openModule("AlertString",{str:"多选模式正在开发中",color:null,time:null,pos:null});
        if (this.clickData.castleId == mainData.uiData.currentCastleId) {
            mainData.uiData.map.selectionMode = true;
            mainData.uiData.map.addListener("touch", this.onTouchChange, this);
            this.clickData.selected = true;
        } else {
            ModuleMgr.inst().openModule("AlertString", {
                str: ResMgr.inst().getString("selectCurrentArmy"),
                color: null,
                time: null,
                pos: null
            });
        }
    }

    /**
     * 点击完成
     */
    p.onTouchChange = function () {
        if (mainData.uiData.map.touch == false) {
            mainData.uiData.map.removeListener("touch", this.onTouchChange, this);
            mainData.uiData.map.selectionMode = false;
        }
    }

    /**
     * 是否选择了角色
     * @returns {boolean}
     */
    p.hasSelectRoler = function () {
        return this.selectAim == "" ? false : true;
    }

    /**
     * 根据配置的函数名称执行函数，tip:xxxx 这样的是特殊情况
     * @param funcName
     */
    p.execute = function (funcName, hide) {
        if (funcName == "") {
            return;
        }
        if (funcName.split(":").length == 2) {
            var type = funcName.split(":")[0];
            var value = funcName.split(":")[1];
            if (type == "tip") { //显示文字提示
                ModuleMgr.inst().openModule("AlertString", {
                    str: ResMgr.inst().getString(value),
                    color: null,
                    time: null,
                    pos: null
                });
            }
        } else {
            trace("执行函数", funcName);
            this[funcName](hide);
        }
    }

    /**
     * 获取按钮菜单文字，很难做成配置，所以直接写成代码了
     * @returns {{title: string, player: string, name: string}}
     */
    p.getClickMenuText = function () {
        var text = {
            title: "",
            player: "",
            res: null,
            name: ""
        }
        if (this.clickAim == "blank") {
            text.title = ResMgr.inst().getString(this.clickData.type + "0");
        }
        else if (this.clickAim.slice(this.clickAim.length - "Castle".length, this.clickAim.length) == "Castle") {
            if (this.clickAim != "myCastle") {
                text.player = mainData.playerDataList.getItem("account", this.clickData.userAccount).nick;
            }
        } else if (this.clickAim.slice(this.clickAim.length - "Earth".length, this.clickAim.length) == "Earth") {
            var earth = this.clickData;
            var testTable = modelMgr.call("Table", "getTableItemByValue", ["item", earth.earthCard]);
            var level = parseInt(testTable.type);
            text.title = ResMgr.inst().getString(earth.productionResourceId + "2") + ": " + ResMgr.inst().getString("Lv") + level;
            if (this.clickAim != "myEarth") {
                var playerData = mainData.playerDataList.getItem("account", earth.user);
                if (playerData) {
                    text.player = playerData.nick;
                }
            }
        } else if (this.clickAim.slice(this.clickAim.length - "WarResource".length, this.clickAim.length) == "WarResource") {
            var warResource = this.clickData;
            text.title = ResMgr.inst().getString(warResource.type + "0");
            text.res = {id: warResource.type, num: warResource.count};
        } else if (this.clickAim == "resource") {
            var resourceData = this.clickData;
            text.title = ResMgr.inst().getString("production") + ResMgr.inst().getString(resourceData.product + "0") + ": " + resourceData.resource;
        }
        text.name = ServerMapConfig.getInstance().getServerData(this.point.x, this.point.y).name;
        return text;
    }

    /**
     * 隐藏按钮菜单
     */
    p.hideClickMenu = function () {
        mainData.uiData.map.showImage = "";
        mainData.uiData.map.shineGrid = "";
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
        mainData.uiData.clickMenuVisible = false;
    }

    /**
     * 获取点击对象
     * @param x
     * @param y
     * @returns {{type: string, data: null}}
     */
    p.getClickAim = function (x, y) {
        var res = {
            "type": "",
            "data": null
        };
        var roler = mainData.mapData.armyList.getItem("coordX", x, "coordY", y);
        if (roler) {
            res.type = "Army";
            res.data = roler;
            if (roler.userAccount == mainData.playerData.account) {
                res.type = "my" + res.type;
            } else {
                res.type = "other" + res.type;
            }
            return res;
        }
        var _this = this;
        var castle = mainData.mapData.castleList.getItemFunction(this.isClickCastle, this, x, y);
        if (castle) {
            res.type = "Castle";
            res.data = castle;
            if (castle.userAccount == mainData.playerData.account) {
                res.type = "my" + res.type;
            } else {
                res.type = "other" + res.type;
            }
            return res;
        }
        var earth = mainData.mapData.earthList.getItem("coordX", x, "coordY", y);
        if (earth) {
            res.type = "Earth";
            res.data = earth;
            if (earth.user == mainData.playerData.account) {
                res.type = "my" + res.type;
            } else {
                res.type = "other" + res.type;
            }
            return res;
        }
        var resource = mainData.mapData.resourceList.getItemFunction(function (item) {
            //trace("资源信息",item.coordX,item.coordY,flower.ObjectDo.toString(item.points));
            if (item.points.getItem("x", x, "y", y)) {
                return true;
            }
            return false;
        });
        if (resource) {
            res.type = "resource";
            res.data = resource;
            return res;
        }
        var warResource = mainData.mapData.fightResourceList.getItem("coordX", x, "coordY", y);
        if (warResource) {
            res.type = "myWarResource";
            res.data = warResource;
            return res;
        }
        var block = ServerMapConfig.getInstance().getBlock(x, y);
        if (block.type == 1608001) {
            res.type = "block";
            res.data = block;
        } else {
            res.type = "blank";
            res.data = block;
        }
        return res;
    }

    /**
     * 是否点击了城堡，因为点击城堡周围9格都算点击城堡，需要特殊计算
     * @param x
     * @param y
     * @param castleData
     * @returns {boolean}
     */
    p.isClickCastle = function (x, y, castleData) {
        //trace(x,y,castleData.coordX,castleData.coordY);
        if (x == castleData.coordX && y == castleData.coordY ||
            x == castleData.coordX - 1 && y == castleData.coordY ||
            x == castleData.coordX + 1 && y == castleData.coordY ||
            x == castleData.coordX + 2 && y == castleData.coordY ||
            (castleData.coordY % 2 == 0 && (
            x == castleData.coordX - 1 && y == castleData.coordY - 1 ||
            x == castleData.coordX && y == castleData.coordY - 1 ||
            x == castleData.coordX + 1 && y == castleData.coordY - 1 ||
            x == castleData.coordX - 1 && y == castleData.coordY + 1 ||
            x == castleData.coordX && y == castleData.coordY + 1 ||
            x == castleData.coordX + 1 && y == castleData.coordY + 1)) ||
            (castleData.coordY % 2 != 0 && (
            x == castleData.coordX && y == castleData.coordY - 1 ||
            x == castleData.coordX + 1 && y == castleData.coordY - 1 ||
            x == castleData.coordX + 2 && y == castleData.coordY - 1 ||
            x == castleData.coordX && y == castleData.coordY + 1 ||
            x == castleData.coordX + 1 && y == castleData.coordY + 1 ||
            x == castleData.coordX + 2 && y == castleData.coordY + 1))) {
            return true;
        }
        return false;
    }

    /**
     * 获取点击配置
     * @param mode
     * @param selectAim
     * @param clickAim
     * @returns {*}
     */
    p.getClickMenu = function (mode, selectAim, clickAim) {
        var list = BigMapClickCommand.menuConfig;
        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            var find = false;
            for (var j = 0; j < item.mode.length; j++) {
                if (item.mode[j] == mode) {
                    find = true;
                    break;
                }
            }
            if (!find) {
                continue;
            }
            find = false;
            for (var j = 0; j < item.selectAim.length; j++) {
                if (item.selectAim[j] == selectAim) {
                    find = true;
                    break;
                }
            }
            if (!find) {
                continue;
            }
            find = false;
            for (var j = 0; j < item.clickAim.length; j++) {
                if (item.clickAim[j] == clickAim) {
                    find = true;
                    break;
                }
            }
            if (!find) {
                continue;
            }
            return item;
        }
        return null;
    }

    BigMapClickCommand.menuConfig = null;

    return BigMapClickCommand;
})(CycleCommand);