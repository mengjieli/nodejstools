var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var IOErrorEvent = (function (_super) {
        __extends(IOErrorEvent, _super);
        function IOErrorEvent(type) {
            _super.call(this, type);
        }
        return IOErrorEvent;
    })(flower.Event);
    flower.IOErrorEvent = IOErrorEvent;
})(flower || (flower = {}));
flower.IOErrorEvent.ERROR = "error";
//# sourceMappingURL=IOErrorEvent.js.map