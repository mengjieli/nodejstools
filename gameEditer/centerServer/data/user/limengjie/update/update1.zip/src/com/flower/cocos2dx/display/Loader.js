var jc;
(function (jc) {
    var Loader = (function (_super) {
        __extends(Loader, _super);
        function Loader(url) {
            _super.call(this);
        }

        var d = __define, c = Loader;
        p = c.prototype;

        return Loader;
    })(flower.DisplayObjectContainer);
    jc.Loader = Loader;
})(jc || (jc = {}));