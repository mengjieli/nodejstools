var ModelBase = (function (_super) {
    __extends(ModelBase, _super);

    function ModelBase(name) {
        _super.call(this);
        this.name = name;
        this.views = [];
        this.commands = {};
        this.commandPool = {};
        this.commandCycler = new ModelCycler();
        this.commandCycler.addEventListener(ModelCycler.CYCLE_COMMAND,this.onCycleCommand,this);
    }

    var d = __define, c = ModelBase;
    p = c.prototype;

    /**
     * @param config 模块的配置文件
     */
    p.init = function (config) {
    }

    /**
     * 加载模块相关数据
     */
    p.load = function () {
        //加载完毕
        this.dispatchEvent(new flower.Event(flower.Event.COMPLETE));
    }

    /**
     * model 相关内容全部准备完毕
     */
    p.ready = function() {

    }

    /**
     * 加载界面
     */
    p.loadView = function () {

    }

    /**
     * 打开界面
     */
    p.openView = function () {

    }

    /**
     * 关闭界面
     */
    p.closeView = function () {
    }

    /**
     * 执行命令
     * @name 逻辑名
     * @params 参数 Object
     */
    p.execute = function(name,params) {
        var buffer = this.commandPool[name];
        var command;
        if(buffer && buffer.length) {
            command = buffer.pop();
        } else {
            command = new this.commands[name](name,this.commandCycler);
        }
        command.init(params);
    }

    p.onCycleCommand = function(e) {
        var command = e.data;
        if(!command) {
            return;
        }
        var name = command.name;
        if(!this.commandPool[name]) {
            this.commandPool[name] = [];
        }
        this.commandPool[name].push(command);
    }

    return ModelBase;
})(flower.EventDispatcher);