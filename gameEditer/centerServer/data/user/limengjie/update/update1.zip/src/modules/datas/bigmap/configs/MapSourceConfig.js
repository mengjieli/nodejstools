function MapSourceConfig(name) {
    //源地图名称
    this.name = name;
    //源地图路径
    this.path = "res/fight/mapsource/" + name + ".json";
    //配置文件
    this.config = null;
    //背景层 [{url:string,x:number,y:number}]
    this.background = null;
    //物品层 [{url:string,x:number,y:number,rotation:number,scaleX:number,scaleY:number,alpha:number}]
    this.items = null;
    //六边形格子信息
    this.blocks = null;
    //获取地图配置等待返回列表 item:{back:Function,thisObj:any}
    this.loadList = [];

    var _this = this;
    //注意这里的cc.loader 实际上是立刻返回的。
    cc.loader.loadJson(this.path, function (error, data) {
        if (error) {
            console.log("加载配置失败:" + _this.path);
        } else {
            _this.config = data;
            _this.loadConfigBack();
        }
    });
}

/**
 * 地图配置文件加载完毕，进行解析
 */
MapSourceConfig.prototype.loadConfigBack = function () {
    //解析配置文件
    //1 解析背景层
    var list = this.config.bottom;
    this.background = [];
    for (var i = 0; i < list.length; i++) {
        this.background.push({
            url: "res/fight/mapsource/item/" + list[i][0] + ".png",//"map_static_" + list[i][0] + ".png",
            x: list[i][1],
            y: list[i][2],
            coordX: list[i][3],
            coordY: list[i][4]
        });
    }
    //2 解析物品层
    list = this.config.first;
    this.items = [];
    for (i = 0; i < list.length; i++) {
        this.items.push({
            url: "res/fight/mapsource/item/" + list[i][0] + ".png",
            //url: "res/fight/mapsource/item/" + this.name + "_" + list[i][0] + ".png",
            x: list[i][1],
            y: list[i][2],
            coordX: list[i][3],
            coordY: list[i][4]
        });
    }
    //3 解析六边形格子信息
    list = this.config.six;
    list.reverse();
    this.blocks = [];
    //trace("单个地图:",this.name,list.length);
    for (i = 0; i < list.length; i++) {
        if (i % MapUtils.blockWidth == 0) {
            if (this.blocks.length) {
                this.blocks[this.blocks.length - 1].reverse();
            }
            this.blocks.push([]);
        }
        this.blocks[this.blocks.length - 1].push({
            type: parseInt(list[i][1]),
            x: MapUtils.blockWidth - this.blocks[this.blocks.length - 1].length - 1,
            y: this.blocks.length - 1,
            rx: list[i][2],
            ry: list[i][3]
        });
    }
    //4 分析可移除对象
    list = this.config.group;
    this.removes = [];
    for (i = 0; i < list.length; i++) {
        var removeType;
        //for (var t = 0; t < this.config.six.length; t++) {
        //    if (this.config.six[t][5] == list[i][0]) {
        //        removeType = parseInt(this.config.six[t][0]);
        //    }
        //}
        var removeIndex = this.config.six.length-1-list[i][0];
        removeType = parseInt(this.config.six[removeIndex][0]);
        //console.log(this.name,list[i][0],removeType);
        //if(this.config.six[removeIndex][0] == "" || removeType == null){
        //    trace("...",i,list[i][0],removeIndex,this.config.six[removeIndex][4],this.config.six[removeIndex][5])
        //    trace("??!!!!!!!!!!",this.name,i,list[i][0],this.config.six[list[i][0]][1],this.config.six[list[i][0]][4],this.config.six[list[i][0]][5]);
        //}
        var remove = {
            key: "_" + i,
            type: removeType,
            count: list[i].length,
            blocks: [],
            items: []
        }
        this.removes.push(remove);
        for (var b = 0; b < list[i].length; b++) {
            remove.blocks.push({
                x: list[i][b] % MapUtils.blockWidth,
                y: MapUtils.blockHeight - 1 - Math.floor(list[i][b] / MapUtils.blockWidth)
            });
        }
        var startPos = MapUtils.transPointToPosition(remove.blocks[0].x,remove.blocks[0].y);
        for (var f = 0; f < this.config.remove.length; f++) {
            if (this.config.remove[f][8] == i) {
                this.config.remove[f][1] = this.config.remove[f][1] - startPos.x;
                this.config.remove[f][2] = this.config.remove[f][2] - startPos.y;
                //trace("切换资源位置",startPos.x,startPos.y,this.config.remove[f][0],this.config.remove[f][1],this.config.remove[f][2]);
                remove.items.push(this.config.remove[f]);
            }
        }
    }
}