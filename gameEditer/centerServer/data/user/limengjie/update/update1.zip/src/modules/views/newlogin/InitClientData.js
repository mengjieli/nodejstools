function InitClientData(back, thisObj) {
    /**
     * 初始化数据管理器
     */
    GameSDK.DataManager.init();
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/flower/ProgressData.json");

    GameSDK.DataManager.getInstance().loadDataDefine("res/data/LoadingData.json");

    GameSDK.DataManager.getInstance().loadDataDefine("res/data/MainData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/net/NetData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/server/ServerData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/system/SystemData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/ui/MapUI.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/ui/UIData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapCastleData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapRolerData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapEarthData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapResourceData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/CameraData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/PathData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/WeaponData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/AttackData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/RolerPath.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/map/MapFightResourceData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/player/PlayerData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/player/FavorityData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/player/EnemyData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/bag/BagData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/bag/ItemData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/utils/PointData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/utils/RectData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/task/TaskData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/smallmap/SmallCastleData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/smallmap/SmallmapData.json");

    //zwp
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/announcement/AnnouncementData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/CastleData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/TechData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/CastleBlockItemData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/ResourceItemData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/ArmyData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/city/ArmyTrainData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/email/EmailData.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/email/MailItemData.json");

    GameSDK.DataManager.getInstance().loadDataDefine("res/data/log/BattleLog.json");
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/log/LogData.json");

    GameSDK.DataManager.getInstance().addData("data", "MainData");
    mainData = GameSDK.DataManager.getInstance().data;

    GameSDK.DataManager.getInstance().addData("loadingData", "LoadingData");

    if (back) {
        back.apply(thisObj);
    }
}