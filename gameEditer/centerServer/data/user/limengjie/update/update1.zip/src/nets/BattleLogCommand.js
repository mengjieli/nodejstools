/**
 * Created by cgMu on 2016/3/10.
 */

var BattleLogCommand = function () {
    NetMgr.inst().addEventListener(1399, this.recevBattleLogList, this);
};

BattleLogCommand.prototype.recevBattleLogList = function (cmd, data) {
    if(cmd == 1399) {
        data.resetCMDData();
        var totalCount = data.readUint();
        var begin = data.readUint();

        mainData.logData.totalCount = totalCount;
        mainData.logData.begin = begin;

        if(mainData.logData.begin==0){
            mainData.logData.logList.removeAll();
        }

        var counts = data.readUint();
        for(var i = 0; i < counts; i++){
            var log = DataManager.getInstance().getNewData("BattleLog");
            log.timestamp = data.readUint();
            log.type = data.readUint();
            log.coordX = data.readInt();
            log.coordY = data.readInt();
            log.accountUuid = data.readString();
            log.accountType = data.readUint();
            log.accountCoordX = data.readInt();
            log.accountCoordY = data.readInt();
            log.resultType = data.readInt();
            log.resultParam1 = data.readInt();
            log.resultParam2 = data.readInt();
            log.damaged = data.readUint();
            log.remaining = data.readUint();

            //cc.log("@log data----------->",log.accountCoordX,log.accountCoordY,log.resultType,log.remaining);

            mainData.logData.logList.push(log);
        }

        //cc.log("@recevBattleLogList----->",totalCount,begin,counts,"*******",mainData.logData.begin);
    }
};