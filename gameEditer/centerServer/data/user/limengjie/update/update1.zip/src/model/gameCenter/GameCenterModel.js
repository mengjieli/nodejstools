var GameCenterModel = (function (_super) {
    __extends(GameCenterModel, _super);

    function GameCenterModel() {
        _super.call(this, "GameCenter");
        GameCenterModel.ist = this;
    }

    var d = __define, c = GameCenterModel;
    p = c.prototype;

    p.login = function (loginBack, thisObj) {
        this.loginBack = loginBack;
        this.loginBackThis = thisObj;
        this.socket = new flower.WebSocket();
        this.socket.addEventListener(flower.Event.CONNECT, this.onConnect, this);
        this.socket.addEventListener(flower.Event.CONNECT_ERROR, this.onConnectError, this);
        this.socket.connect("ws://192.168.0.103:9500");
    }

    p.onConnect = function () {
        this.socket.register(501, this.onReceiveTask, this);
        this.startLogin();
    }

    p.onConnectError = function () {
        if (this.loginBack) {
            this.loginBack.call(this.loginBackThis);
            this.loginBack = null;
            this.loginBackThis = null;
        }
    }

    p.onReceiveTask = function (cmd, msg) {
        msg.position = 0;
        msg.readUIntV();
        var taskId = msg.readUIntV();
        var cmd = msg.readUIntV();
        trace("收到任务消息", taskId);
        switch (cmd) {
            case 2004:
                new GCConnectTask(this.socket, cmd, taskId, msg);
                break;
        }
    }

    p.startLogin = function () {
        var bytes = new flower.VByteArray();
        bytes.writeUIntV(1);
        bytes.writeUTFV("game");
        //bytes.writeUTFV(mainData.playerData.nick);
        this.sendData(bytes);
        this.socket.onceZero(1, this.onReceiveLogin, this);
    }

    p.onReceiveLogin = function (cmd, errorCode) {
        trace("消息",cmd,errorCode);
        if(errorCode != 0) {
            this.socket.close();
            ModuleMgr.inst().openModule("AlertPanel", {
                txt: "链接中心服务器失败:" + errorCode
            });
            this.callLoginBack();
            return;
        }
        var linkName = GameCenterConfig.getConfig(GameCenterConfig.LINK_CLIENT);
        if(!linkName) {
            this.callLoginBack();
        } else {
            var bytes = new flower.VByteArray();
            bytes.writeUIntV(1004);
            bytes.writeUTFV(linkName);
            this.sendData(bytes);
            this.socket.onceZero(1004,this.onAutoLinkBack,this);
        }
    }

    p.onAutoLinkBack = function(cmd,errorCode) {
        gmcolorlog(0xff0000,"自动链接 flash 客户端返回");
        this.callLoginBack();
    }

    p.callLoginBack = function() {
        if (this.loginBack) {
            this.loginBack.call(this.loginBackThis);
            this.loginBack = null;
            this.loginBackThis = null;
        }
    }

    p.sendData = function (bytes) {
        if (this.socket) {
            this.socket.send(bytes);
        }
    }

    return GameCenterModel;
})(ModelBase);