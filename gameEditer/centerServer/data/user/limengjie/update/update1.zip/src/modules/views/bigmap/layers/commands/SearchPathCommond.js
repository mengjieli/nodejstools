var SearchPathCommand = function () {
    
}