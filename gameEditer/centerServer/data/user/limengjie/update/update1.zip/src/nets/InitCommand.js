var mainData = null;

function InitCommand(back, thisObj) {

    new SystemDataCommand();
    new PlayerDataCommand();
    new BagDataCommand();
    new EmailDataCommand();
    new FavoritesDataCommand();
    new TaskDataCommand();
    new CastleDataCommand();
    new MapDataCommand();
    new UIDataCommand();
    new SmallmapDataCommand();
    new BattleLogCommand();

    if (back) {
        back.apply(thisObj);
    }
}