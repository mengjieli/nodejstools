/**
 * Created by Administrator on 2015/11/09/0009.
 */
var CastleParticularsUI=cc.Node.extend({

    _ui:null,
    _id:0,
    _blockId:null,
    _info:null,
    _demandItems:null,
    _resourceItems:null,

    isOnePage: null,
    scrol: null,
    scrollbar: null,
    scrollPosY: 0,
    barTotalHeight: 0,
    barPercent_total: 0,

    ctor: function ( id, blockId )
    {
        this._super();
        this._id = id;
        this._blockId = blockId;

        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        var info = null;
        if( data )
        {
            list = data.getNetBlock( );
        }
        if( list != null && list[this._blockId] != null )
        {
            this._info = list[this._blockId];
        }

        this.initUI();
    },

    initUI:function()
    {
        this._ui = ccs.load("res/images/ui/castleParticulars/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        //适配
        var Image_3 = this._ui.getChildByName("Image_3");
        sizeAutoLayout(Image_3);

        var Image_4 = this._ui.getChildByName("Image_4");
        sizeAutoLayout(Image_4);
        var Image_5 = this._ui.getChildByName("Image_5");
        posAutoLayout(Image_5);
        this.scrollbar = Image_5;//滑块
        this.scrollPosY = this.scrollbar.getPositionY();//滑块初始位置
        this.barTotalHeight = Image_4.getContentSize().height;//滑块滑动区间

        var Image_2 = this._ui.getChildByName("Image_2");
        sizeAutoLayout(Image_2);

        var control = this._ui.getChildByName("Image_1");
        posAutoLayout(control);

        control = this._ui.getChildByName("Panel0");
        posAutoLayout(control);

        control = this._ui.getChildByName("ScrollView_1");
        sizeAutoLayout(control);
        this.scrol = control;

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        var txt = this._ui.getChildByName("Panel0").getChildByName("Text_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_2") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_1");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_12") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_2");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_14") );

        var item0 = this._ui.getChildByName("item0");
        item0.setVisible(false);
        var scroll = this._ui.getChildByName("ScrollView_1");
        scroll.addEventListener(this.scrollOneCall, this );

        this.updateConfig();

    },

    updateConfig:function()
    {
        if( this._demandItems )
        {
            for( var i in this._demandItems )
            {
                var item = this._demandItems[i];
                item.removeFromParent();
            }
        }

        this._demandItems = [];

        var item0 = this._ui.getChildByName("item0");
        item0.setVisible(false);
        var scroll = this._ui.getChildByName("ScrollView_1");

        var config = modelMgr.call("Table","getTableList",["City_Castel"]);
        var level = this._info._building_level;
        var dataList = [];

        for( var i in config )
        {
            dataList.push( config[i] );
        }
        var len = dataList.length;
        for( var i=0; i<len; i++  )
        {
            var it = item0.clone();
            scroll.addChild( it );
            it.setVisible(true);
            this._demandItems.push( it );

            var data = dataList[i];
            it.info = {};
            it.info.level = data.castel_level;

            var itemData = dataList[i];
            var itemUI = it.getChildByName("txt0");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( itemData.castel_level );
            itemUI = it.getChildByName("txt1");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( itemData.territory_number );
            itemUI = it.getChildByName("txt2");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( itemData.prosperity );
        }
        this.updateDemandScrollItemPos( 0 );
        this.updateScrollviewSelecting( scroll, len,item0.getContentSize().height, level );
    },

    scrollOneCall:function( node, type )
    {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                this.setScrollbar();
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    //更新滑块位置
    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY - (this.barTotalHeight- 20 - this.scrollbar.height) * percent / 100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },

    //更新滚动层里的item坐标
    updateDemandScrollItemPos:function( n )
    {

        var item0 = null;
        var scroll = null;
        var list = null;
        if( n == 0 )
        {
            list = this._demandItems;
            item0 = this._ui.getChildByName("item0");
            scroll = this._ui.getChildByName("ScrollView_1");
        }
        else
        {
            list = this._resourceItems;
            item0 = this._ui.getChildByName("item1");
            scroll = this._ui.getChildByName("ScrollView_2");
        }

        var gap = 3;
        var len  = list.length;
        var itemH = item0.getContentSize().height;
        var h = len * itemH + (len+1)*gap;
        var size = scroll.getContentSize();
        size.height = h > size.height ? h : size.height;
        for( var i =0; i<len; i++ )
        {
            var it = list[i];
            it.setPosition( 0, (size.height - itemH-gap) - i*(itemH+gap) );
        }

        var level = this._info._building_level;
        var select = scroll.getChildByName("select");
        select.setVisible(true);
        select.setPosition(0, (size.height - itemH-gap)- ((level -1)*(gap+itemH))-2 );
        select.setLocalZOrder(10);

        scroll.setInnerContainerSize( size );
        scroll.jumpToTop();

        //重置滑块位置
        var innerContainerSize = this.scrol.getInnerContainerSize();
        var pos = this.scrol.getInnerContainer().getPosition();
        this.barPercent_total = Math.abs(pos.y);
        if (innerContainerSize.height < size.height) {
            this.isOnePage = true;
        }
        else {
            this.isOnePage = false;
        }
        if (this.isOnePage) {
            this.refreshScrollbarState(100);
        }
        else {
            this.refreshScrollbarState(0);
        }
    },


    updateScroll:function( n )
    {
        var scroll = null;
        var up = null;
        var down = null;

        if( n == 0 )
        {
            scroll = this._ui.getChildByName("ScrollView_1");
            up = this._ui.getChildByName("up0");
            down = this._ui.getChildByName("down0");
        }
        else
        {
            scroll = this._ui.getChildByName("ScrollView_2");
            up = this._ui.getChildByName("up1");
            down = this._ui.getChildByName("down1");
        }

        var scrollSize = scroll.getContentSize();
        var size = scroll.getInnerContainerSize();

        var inner = scroll.getInnerContainer();
        var pos = inner.getPosition();

        up.setVisible(false);
        down.setVisible( false );

        if( size.height <= scrollSize.height )
        {
            up.setVisible( false );
            down.setVisible( false );
        }
        else
        {
            if( pos.y >= 0 && size.height <= scrollSize.height )
            {
                up.setVisible( false );
            }
            else
            {
                up.setVisible( pos.y >= 0 ? false : true );
            }

            var endY = scrollSize.height - size.height;

            down.setVisible( pos.y <= endY ? false : true );
        }
    },

    updateScrollviewSelecting: function (scrollview, length,itemH,selecting)
    {
        var size = scrollview.getContentSize();
        var h = scrollview.getInnerContainerSize().height;
        var number = parseInt(size.height / (itemH+3));
        if (selecting> length-number)
        {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function () {
                scrollview.jumpToBottom();
            })));
        }
        else
        {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function (sender) {
                //var size = scrollview.getContentSize();
                var percent = (selecting-1)*(itemH+3) / (h- size.height) * 100;
                scrollview.jumpToPercentVertical(percent);

                sender.setScrollbar();//刷新滑块位置
            })));
        }
    },

    setScrollbar: function () {
        var pos = this.scrol.getInnerContainer().getPosition();
        var number = this.barPercent_total + pos.y;
        var per = number * 100 / this.barPercent_total;
        if (per < 0) {
            per = 0
        }
        if (per > 100) {
            per = 100
        }
        this.refreshScrollbarState(per);
    }

})