var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var Bitmap = (function (_super) {
        __extends(Bitmap, _super);
        function Bitmap(texture) {
            if (texture === void 0) { texture = null; }
            _super.call(this);
            this._show = System.getNativeShow("Bitmap");
            this.texture = texture;
        }
        Bitmap.prototype._setTexture = function (val) {
            this._texture = val;
            this._width = this._texture.width;
            this._height = this._texture.height;
            this._texture.addCount();
            var p = flower.Bitmap.bitmapProperty.texture;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._texture.$nativeTexture]);
                if (System.IDE == IDE.COCOS2DX) {
                    this._show.setAnchorPoint(0, 1);
                }
            }
            else {
                this._show[p.atr] = this._texture.$nativeTexture;
            }
        };
        Bitmap.prototype._setWidth = function (val) {
            this.scaleX = val / this._width;
        };
        Bitmap.prototype._setHeight = function (val) {
            this.scaleY = val / this._height;
        };
        Object.defineProperty(Bitmap.prototype, "texture", {
            get: function () {
                return this._texture;
            },
            set: function (val) {
                if (val == this._texture) {
                    return;
                }
                if (val == null) {
                    flower.DebugInfo.debug("Bitmap.texture 不能设置为空，详情见引擎说明", flower.DebugInfo.WARN);
                    return;
                }
                this._setTexture(val);
            },
            enumerable: true,
            configurable: true
        });
        Bitmap.prototype.dispose = function () {
            _super.prototype.dispose.call(this);
            if (this._texture) {
                this._texture.delCount();
            }
        };
        return Bitmap;
    })(flower.DisplayObject);
    flower.Bitmap = Bitmap;
})(flower || (flower = {}));
flower.Bitmap.bitmapProperty = System.Bitmap;
//# sourceMappingURL=Bitmap.js.map