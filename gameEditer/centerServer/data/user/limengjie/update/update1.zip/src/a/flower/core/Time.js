var flower;
(function (flower) {
    var Time = (function () {
        function Time() {
        }
        Time.$run = function (gap) {
            flower.Time.lastTimeGap = gap;
            flower.Time.currentTime += gap;
            flower.EnterFrame.$update(flower.Time.currentTime, gap);
            flower.Engine.getInstance().$onFrameEnd();
        };
        Time.getTime = function () {
            return flower.Time.getTime();
        };
        return Time;
    })();
    flower.Time = Time;
})(flower || (flower = {}));
flower.Time.currentTime = 0;
flower.Time.lastTimeGap = 0;
//# sourceMappingURL=Time.js.map