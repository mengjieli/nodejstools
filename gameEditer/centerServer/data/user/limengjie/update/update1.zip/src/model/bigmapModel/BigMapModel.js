var BigMapModel = (function (_super) {
    __extends(BigMapModel, _super);

    function BigMapModel() {
        _super.call(this, "BigMap");
        this.camera = null;
        this.commands["click"] = BigMapClickCommand;
        this.commands["moveTo"] = RolerMoveCommand;
        this.commands["selectionMode"] = SelectionModelCommand;
        this.commands["buildCastle"] = ShowBuildCastleCommand;
        this.commands["battleMode"] = BattleModeCommand;
        this.commands["dropItem"] = DropItemCommand;
    }

    var d = __define, c = BigMapModel;
    p = c.prototype;

    /**
     * model 相关内容全部准备完毕
     */
    p.ready = function() {
        this.execute("selectionMode");
        this.execute("buildCastle");
        this.execute("battleMode");
        this.execute("dropItem");
    }

    p.cameraLookAt = function (x, y) {
        if(this.camera) {
            this.camera.lookAt(x,y);
        }
    }

    p.registerCamera = function(camera) {
        this.camera = camera;
    }

    return BigMapModel;
})(ModelBase);