/**
 *
 * 文件名: DataBase.js
 * 创建时间: 2015/3/27- 14:41
 *
 * 功能说明:
 * 数据基类，所有模块数据都必需继承该类
 */

var DataBase = cc.Class.extend({

	ctor:function()
	{

	},
	
	init:function()
	{
		return true;
	},
	
	destroy:function()
	{
		
	}
});