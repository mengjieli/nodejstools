/**
 * Created by cgMu on 2016/1/20.
 */

TrainingEvent = {};
TrainingEvent.UNLOCK_SUCCESS = "army_unlock_success";

var TrainingData = DataBase.extend({
    campId:null,

    newArmList:null,//兵营可以训练的兵种列表
    armList:null,//训练士兵列表
    tabDesDict:null,
    lockInfo:null,

    ctor: function () {
        this._super();

        this.tabDesDict = {};
        this.tabDesDict[1902001] = [ResMgr.inst().getString("train_13"),ResMgr.inst().getString("train_14")];
        this.tabDesDict[1902002] = [ResMgr.inst().getString("train_20"),ResMgr.inst().getString("train_21")];
        this.tabDesDict[1902003] = [ResMgr.inst().getString("train_22"),ResMgr.inst().getString("train_23")];
        this.tabDesDict[1902004] = [ResMgr.inst().getString("train_24")];

        this.lockInfo = {};
        this.lockInfo[1902001] = ResMgr.inst().getString("train_15");
        this.lockInfo[1902002] = ResMgr.inst().getString("train_25");
        this.lockInfo[1902003] = ResMgr.inst().getString("train_26");
        this.lockInfo[1902004] = ResMgr.inst().getString("train_27");
    },

    init:function()
    {
        return true;
    },

    initData: function () {
        this.newArmList = [];
        this.armList = [];
        if(this.campId==null) return;

        var data1 = [];
        var data2 = [];

        var config = modelMgr.call("Table","getTableList",["Arm"]);
        for(var i in config){
            if(parseInt(config[i].city_camp)==this.campId){
                if(parseInt(config[i].city_camp_type)==1){
                    data1.push(config[i].arm_id);
                }
                else{
                    data2.push(config[i].arm_id);
                }
            }
        }

        this.newArmList = this.tabDesDict[this.campId];

        if(data1.length>0) this.armList.push(data1);
        if(data2.length>0) this.armList.push(data2);

        //this.armList.push([1202101,1202102,1202103,1202104]);
        //this.armList.push([1202201,1202202,1202203]);

    },

    destroy:function() {
        this.campId=null;
        this.newArmList=null;
        this.armList=null;
    },

    getResIconUrl: function (campid) {
        var url = null;
        switch (campid){
            case 1902001:
                url = 1102002;
                break;
            case 1902002:
                url = 1102001;
                break;
            case 1902003:
                url = 1102003;
                break;
            case 1902004:
                url = 1102004;
                break;
        }
        return url;
    }
});