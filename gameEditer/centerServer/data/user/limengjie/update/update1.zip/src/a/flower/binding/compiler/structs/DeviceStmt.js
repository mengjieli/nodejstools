var flower;
(function (flower) {
    var DeviceStmt = (function () {
        function DeviceStmt() {
        }
        return DeviceStmt;
    })();
    flower.DeviceStmt = DeviceStmt;
})(flower || (flower = {}));
//# sourceMappingURL=DeviceStmt.js.map