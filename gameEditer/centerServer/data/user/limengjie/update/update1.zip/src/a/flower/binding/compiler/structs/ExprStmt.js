var flower;
(function (flower) {
    var ExprStmt = (function () {
        function ExprStmt(expr) {
            this.type = "stmt_expr";
            this.expr = expr;
        }
        ExprStmt.prototype.checkPropertyBinding = function (checks, commonInfo) {
            this.expr.checkPropertyBinding(checks, commonInfo);
        };
        return ExprStmt;
    })();
    flower.ExprStmt = ExprStmt;
})(flower || (flower = {}));
//# sourceMappingURL=ExprStmt.js.map