var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var Engine = (function (_super) {
        __extends(Engine, _super);
        function Engine() {
            _super.call(this);
            this.touchList = [];
            if (flower.Engine.ist) {
                return;
            }
            flower.Engine.ist = this;
            System.start(this._show, this);
            flower.Engine.global = System.global;
            flower.JSON.parser = System.JSON_parser;
            flower.JSON.stringify = System.JSON_stringify;
            System.runTimeLine(flower.Time.$run);
            this._width = System.width;
            this._height = System.height;
        }
        Engine.prototype._setX = function (val) {
            flower.DebugInfo.debug("|类Engine| set x 不能设置其位置", flower.DebugInfo.ERROR);
            return;
        };
        Engine.prototype._setY = function (val) {
            flower.DebugInfo.debug("|类Engine| set y 不能设置其位置", flower.DebugInfo.ERROR);
            return;
        };
        Engine.prototype.getMouseTarget = function (touchX, touchY, mutiply) {
            var matrix = flower.Matrix.$matrix;
            matrix.identity();
            matrix.tx = touchX;
            matrix.ty = touchY;
            var target = this._getMouseTarget(matrix, mutiply) || this;
            return target;
        };
        Engine.prototype.onMouseDown = function (id, x, y) {
            var mouse = { id: 0, mutiply: false, startX: 0, startY: 0, moveX: 0, moveY: 0, target: null };
            mouse.id = id;
            mouse.startX = x;
            mouse.startY = y;
            mouse.mutiply = this.touchList.length == 0 ? false : true;
            this.touchList.push(mouse);
            var target = this.getMouseTarget(x, y, mouse.mutiply);
            mouse.target = target;
            target.addListener(flower.Event.REMOVE, this.onMouseTargetRemove, this);
            var eventList;
            var event = new flower.TouchEvent(flower.TouchEvent.TOUCH_BEGIN);
            event.stageX = x;
            event.stageY = y;
            if (target) {
                event.$target = target;
                var dis = target;
                eventList = [];
                while (dis) {
                    eventList.push(dis);
                    dis = dis.parent;
                }
            }
            if (eventList) {
                while (eventList.length) {
                    event.$currentTarget = eventList.shift();
                    event.touchX = Math.floor(event.currentTarget.touchX);
                    event.touchY = Math.floor(event.currentTarget.touchY);
                    event.currentTarget.dispatch(event);
                }
            }
        };
        Engine.prototype.onMouseMove = function (id, x, y) {
            var mouse;
            for (var i = 0; i < this.touchList.length; i++) {
                if (this.touchList[i].id == id) {
                    mouse = this.touchList[i];
                    break;
                }
            }
            if (mouse == null)
                return;
            if (mouse.moveX == x && mouse.moveY == y)
                return;
            this.getMouseTarget(x, y, mouse.mutiply);
            mouse.moveX = x;
            mouse.moveY = y;
            var target = mouse.target;
            var eventList;
            var event = new flower.TouchEvent(flower.TouchEvent.TOUCH_MOVE);
            event.stageX = x;
            event.stageY = y;
            if (target) {
                event.$target = target;
                var dis = target;
                eventList = [];
                while (dis) {
                    eventList.push(dis);
                    dis = dis.parent;
                }
            }
            if (eventList) {
                while (eventList.length) {
                    event.$currentTarget = eventList.shift();
                    event.touchX = Math.floor(event.currentTarget.touchX);
                    event.touchY = Math.floor(event.currentTarget.touchY);
                    event.currentTarget.dispatch(event);
                }
            }
        };
        Engine.prototype.onMouseUp = function (id, x, y) {
            var mouse;
            for (var i = 0; i < this.touchList.length; i++) {
                if (this.touchList[i].id == id) {
                    mouse = this.touchList.splice(i, 1)[0];
                    break;
                }
            }
            if (mouse == null)
                return;
            var target = mouse.target;
            var eventList;
            var event = new flower.TouchEvent(flower.TouchEvent.TOUCH_END);
            event.stageX = x;
            event.stageY = y;
            if (target) {
                event.$target = target;
                var dis = target;
                eventList = [];
                while (dis) {
                    eventList.push(dis);
                    dis = dis.parent;
                }
            }
            if (eventList) {
                while (eventList.length) {
                    event.$currentTarget = eventList.shift();
                    event.touchX = Math.floor(event.currentTarget.touchX);
                    event.touchY = Math.floor(event.currentTarget.touchY);
                    event.currentTarget.dispatch(event);
                }
            }
        };
        Engine.prototype.onMouseTargetRemove = function (e) {
            for (var i = 0; i < this.touchList.length; i++) {
                if (this.touchList[i].target == e.target) {
                    this.touchList.splice(i, 1)[0];
                    break;
                }
            }
        };
        Engine.getInstance = function () {
            return flower.Engine.ist;
        };
        return Engine;
    })(flower.Sprite);
    flower.Engine = Engine;
})(flower || (flower = {}));
flower.Engine.DEBUG = true;
//# sourceMappingURL=Engine.js.map