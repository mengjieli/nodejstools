var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var ResTexture = (function (_super) {
        __extends(ResTexture, _super);
        function ResTexture() {
            _super.call(this);
            this.disposeTime = 0;
            this.type = "Bitmap";
        }
        return ResTexture;
    })(flower.ResItem);
    flower.ResTexture = ResTexture;
})(flower || (flower = {}));
//# sourceMappingURL=ResTexture.js.map