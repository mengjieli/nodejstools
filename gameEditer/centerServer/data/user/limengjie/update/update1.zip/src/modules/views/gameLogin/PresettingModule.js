/*
**预设面板 2015-9-14 shenwei
*/
var PresettingModule = ModuleBase.extend({

    _scene : null,
    _nicknameInput : null,
    _nicknameInputError : null,

    ctor : function() {
        this._super();
    },

    initUI : function() {
        this._super();

        var backImg = new ccui.ImageView();
        backImg.setAnchorPoint(0.5,0.5);
        backImg.loadTexture("login/denglu_di.png", ccui.Widget.PLIST_TEXTURE);
        var pos = cc.p(0,0);
        backImg.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(true) );
        pos.x = GameMgr.inst().viewSize.width >> 1;
        pos.y = GameMgr.inst().viewSize.height >> 1;
        backImg.setPosition( pos );
        this.addChild( backImg );

        this._scene = ccs.load( "res/images/ui/login/key.json", "res/images/ui/" ).node;//NodeUtils.getUI("res/loadingAndLogining/presettingUI.json");
        if(null == this._scene)
        {
            cc.error("PresettingModule模块加载presettingUI.json失败");
            return;
        }
        this.addChild(this._scene);

        var uiPanel = this._scene.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._scene.setContentSize( size );
        ccui.helper.doLayout( this._scene );

        //提交按钮
        var but = this._scene.getChildByName( "ui_mainban" ).getChildByName( "denglu" );
        but.addTouchEventListener( this.nextCall, this );
        but.setTitleText( ResMgr.inst().getString("login_32"));

        //输入框
        this._nicknameInput = this._scene.getChildByName( "ui_mainban" ).getChildByName( "TextField_2" );
        this._nicknameInput.addEventListener(this.inputCallback,this);
        this._nicknameInput.setPlaceHolder( ResMgr.inst().getString("login_33") );
        this._nicknameInput.setMaxLengthEnabled(true);
        this._nicknameInput.setMaxLength(12);

        var txt = this._scene.getChildByName("ui_mainban" ).getChildByName("Text_2_0_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("denglu_51") );
        txt.setVisible(false);
        this._nicknameInputError = txt;
    },

    nextCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            //下一步
            this.checkUserPresettings();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    inputCallback: function (node, type) {
        switch (type){
            case ccui.TextField.EVENT_ATTACH_WITH_IME:
                this._nicknameInputError.setVisible(false);
                break;
        }
    },

    presetPersonalInfo : function(){
        //昵称
        var nickname = this._nicknameInput.getString();
        var msg = new SocketBytes();
        msg.writeUint(LoginingNetEvent.PEC_NICKNAME);
        msg.writeString(nickname);
        NetMgr.inst().send(msg);
    },

    isValidNickname : function(){
        var valid = false;
        var input = this._nicknameInput.getString();
        var ret = CD.validNameByRule(input);
        if(1 != ret) {
            valid = false;
        }
        else {
            valid = true;
        }
        return valid;
    },

    checkUserPresettings : function() {
        var nickname = this._nicknameInput.getString();
        var len = this.strlen(nickname);

        if(len >=4 && len <=12 && this.isValidNickname()) {
            this.presetPersonalInfo();
        }
        else {
            this._nicknameInputError.setVisible(true);
        }
    },

    show : function(data) {
        if(null != data && undefined != data) {
            this._super(data.data, data.openSound);
        }
        else {
            this._super(null, true);
        }
    },

    close : function(data) {
        if(null != data && undefined != data)
        {
            this._super(data.closeSound);
        }
        else
        {
            this._super(true);
        }
    },

    clean : function() {
        this._nicknameInput = null;
        this._nicknameInputError = null;

        if(-1 != this._delayTimer)
        {
            clearTimeout(this._delayTimer);
            this._delayTimer = null;
        }

        this._scene = null;
    },

    destroy : function() {
        this._super();
        this.clean();
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },

    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    //判断中英文字符长度
    strlen: function (str) {
        var len = 0;
        for (var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            //单字节加1
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                len++;
            }
            else {
                len += 2;
            }
        }
        return len;
    }

});
