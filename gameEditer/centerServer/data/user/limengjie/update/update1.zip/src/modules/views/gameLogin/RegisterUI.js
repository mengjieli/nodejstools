/**
 * Created by Administrator on 2015/12/14.
 */

var RegisterUI = cc.Node.extend({

    _ui: null,

    _mobileNumberInput: null,
    _inviteCodeInput: null,
    _messageLabel: null,
    _messageLabelEx: null,

    _loginCtlTimer: null,
    _commonQuitCtrl: null,

    ctor: function () {
        this._super();
        this._loginCtlTimer = -1;
    },

    onEnter: function () {
        this._super();
        this._ui = ccs.load("res/images/ui/login/register.json", "res/images/ui/").node;
        this.addChild(this._ui);

        var uiPanel = this._ui.getChildByName("ui_mainban");
        uiPanel.setScale(1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(false));

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize(size);
        ccui.helper.doLayout(this._ui);

        //注册按钮
        var but = this._ui.getChildByName("ui_mainban").getChildByName("Button_2");
        but.addTouchEventListener(this.registerCall, this);

        //手机号码，邀请码，输入文本框
        this._mobileNumberInput = this._ui.getChildByName("ui_mainban").getChildByName("TextField_1");
        this._inviteCodeInput = this._ui.getChildByName("ui_mainban").getChildByName("TextField_2");

        //用户协议
        var verify = this._ui.getChildByName("ui_mainban").getChildByName("xieyi");
        verify.addTouchEventListener(this.verifyCall, this);

        //返回登录
        var reg = this._ui.getChildByName("ui_mainban").getChildByName("yongh_zhuce");
        reg.addTouchEventListener(this.loginCall, this);
        reg.ignoreContentAdaptWithSize(true);
        reg.setString(ResMgr.inst().getString("login_11"));
        var reg_x = reg.getChildByName("Panel_3");
        var s = reg.getContentSize();
        s.height = 2;
        reg_x.setContentSize(s);

        //找回密码
        var pass = this._ui.getChildByName("ui_mainban").getChildByName("xieyi_0");
        pass.addTouchEventListener(this.passwordCall, this);
        pass.ignoreContentAdaptWithSize(true);
        pass.setString(ResMgr.inst().getString("login_9"));
        pass.setVisible(false);
        var pass_x = pass.getChildByName("Panel_3_0");
        var s = pass.getContentSize();
        s.height = 2;
        pass_x.setContentSize(s);
        this._messageLabelEx = pass;

        var pass_one = this._ui.getChildByName("ui_mainban").getChildByName("xieyi_shuoming_0");
        pass_one.setString(ResMgr.inst().getString("login_27"));
        pass_one.setColor(cc.color(161, 131, 88));
        pass_one.ignoreContentAdaptWithSize(true);
        this._messageLabel = pass_one;

        var pos_x = pass_one.getPositionX();
        pass.setPositionX(pos_x + pass_one.getContentSize().width + 5);

        but.setTitleText(ResMgr.inst().getString("login_10"));
        this._mobileNumberInput.setPlaceHolder(ResMgr.inst().getString("login_0"));
        this._inviteCodeInput.setPlaceHolder(ResMgr.inst().getString("login_7"));

        var verify_one = this._ui.getChildByName("ui_mainban").getChildByName("xieyi_shuoming");
        var verify_two = this._ui.getChildByName("ui_mainban").getChildByName("xieyi");
        verify_one.ignoreContentAdaptWithSize(true);
        verify_two.ignoreContentAdaptWithSize(true);
        verify_one.setString(ResMgr.inst().getString("login_3"));
        verify_two.setString(ResMgr.inst().getString("login_4"));
        var w_x = verify_one.getContentSize().width + verify_two.getContentSize().width + 5;
        w_x = -(w_x >> 1);
        verify_one.setPositionX(w_x);
        var onePos = verify_one.getPositionX();
        verify_two.setPositionX(onePos + verify_one.getContentSize().width + 5);

        this._commonQuitCtrl = new CommonQuitGame(this);
        SysCall.setCustomIMEMode(1);

        NetMgr.inst().addEventListener(0, this.netGetError, this);
    },

    onExit: function () {
        this._super();
        if (-1 != this._loginCtlTimer) {
            clearTimeout(this._loginCtlTimer);
            this._loginCtlTimer = null;
        }
        NetMgr.inst().removeEventListener(0, this.netGetError, this);

        this._commonQuitCtrl.destroy();
        this._commonQuitCtrl = null;
        SysCall.closeCustomIMEMode();
    },

    min: function (node) {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1, 0.95);
        node.runAction(ac);
    },
    max: function (node) {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1, 1);
        node.runAction(ac);
    },


    /*******************************
     * 控件回调
     */


    /**
     * 注册按钮回调
     * @param node
     * @param type
     */
    registerCall: function (node, type) {
        if (type == ccui.Widget.TOUCH_BEGAN) {
            this.min(node);
        }
        else if (type == ccui.Widget.TOUCH_ENDED) {
            this.max(node);
            //登录
            if (this.isValidAccountIdLength()) {
                this.sendAccountRequest();
            }
            else {
                var value = ResMgr.inst().getString("denglu_30");
                ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
            }
        }
        else if (type == ccui.Widget.TOUCH_CANCELED) {
            this.max(node);
        }
    },

    /**
     * 用户协议
     * @param node
     * @param type
     */
    verifyCall: function (node, type) {
        if (type == ccui.Widget.TOUCH_BEGAN) {
            //this.min( node );
        }
        else if (type == ccui.Widget.TOUCH_ENDED) {
            ModuleMgr.inst().openModule("GameLoginModule", "treaty");
        }
        else if (type == ccui.Widget.TOUCH_CANCELED) {
            //this.max( node );
        }
    },

    /**
     * 返回登录
     * @param node
     * @param type
     */
    loginCall: function (node, type) {
        if (type == ccui.Widget.TOUCH_BEGAN) {
            //this.min( node );
        }
        else if (type == ccui.Widget.TOUCH_ENDED) {
            //登录
            ModuleMgr.inst().openModule("GameLoginModule");
        }
        else if (type == ccui.Widget.TOUCH_CANCELED) {
            //this.max( node );
        }
    },

    /**
     * 用户找回密码
     * @param node
     * @param type
     */
    passwordCall: function (node, type) {
        if (type == ccui.Widget.TOUCH_BEGAN) {
            //this.min( node );
        }
        else if (type == ccui.Widget.TOUCH_ENDED) {
            ModuleMgr.inst().openModule("GameLoginModule", "mobile");
        }
        else if (type == ccui.Widget.TOUCH_CANCELED) {
            //this.max( node );
        }
    },

    isValidAccountIdLength: function () {
        var phone = this._mobileNumberInput.getString();
        var isValidRange = CD.isPhoneNum(phone);

        if (0 == phone.length || !isValidRange) {
            return false;
        }
        return true;
    },

    //账号注册申请
    sendAccountRequest: function () {
        //ModuleMgr.inst().openModule("NetworkWaitModule");
        cc.log("账号注册申请");
        var account = this._mobileNumberInput.getString();
        var token = CD.genRandToken();
        var platform = "";
        if (cc.sys.os == cc.sys.OS_ANDROID) {
            platform = "android";
        }
        else if (cc.sys.os == cc.sys.OS_IOS) {
            platform = "ios";
        }
        else {
            platform = "others";
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "create";
        var url = head;
        url += "?accountName=" + encodeString(account);
        url += "&token=" + encodeString(token);
        url += "&remarks=" + "from:" + encodeString(platform);

        NetMgr.inst().sendHttp(url, null, false, function (data, param) {
                cc.log("接收:" + data);
                var ret = JSON.parse(data);
                if (ret) {
                    switch (ret.errCode) {
                        case 0:
                            cc.log("注册成功", param.objs[2], param.objs[3]);
                            param.owner.recordUserInfo([param.objs[2], "", param.objs[3]]);
                            param.owner.loginRequest(param.objs[2], "", param.objs[3]);
                            break;
                        case 80104://用户名已存在
                            //var value = ResMgr.inst().getString("denglu_31");
                            //ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                            param.errorReminder[0].setString(ResMgr.inst().getString("login_8"));
                            param.errorReminder[0].setColor(cc.color(255, 0, 0));
                            param.errorReminder[1].setVisible(true);
                            break;
                        case 80105:
                            var value = ResMgr.inst().getString("denglu_33");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
                            break;
                        case 80107:
                            var value = ResMgr.inst().getString("denglu_34");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
                            break;
                        case 80109:
                            var value = ResMgr.inst().getString("denglu_35");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
                        default:
                            break;
                    }
                }
                else {
                    var value = ResMgr.inst().getString("denglu_36");
                    ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
                }
            },
            function (url, response) {
                if ("" == response) {
                    cc.error("服务器连接失败");
                    var value = ResMgr.inst().getString("denglu_16");
                    ModuleMgr.inst().openModule("AlertPanel", {
                        "txt": value, "type": 2, "okFun": function () {
                            cc.director.end()
                        }
                    });
                }
            },
            {"objs": [0, 0, account, token], "errorReminder": [this._messageLabel, this._messageLabelEx], "owner": this}
        );
    },

    //本地存储账号信息
    recordUserInfo: function (info) {
        cc.log("info:" + JSON.stringify(info));
        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var file = jsb.fileUtils.writeToFile({
            "lastLoginName": info[0],
            "lastLoginPassword": info[1],
            "lastLoginToken": info[2]
        }, storagePath + "cache");
    },

    loginRequest: function (v1, v2, v3) {
        //TODO: 验证账号是否激活-->
        if (ModuleMgr.inst().getData("GameLoginModule").isActivateAccount()) {
            ReconnectionMgr.getInstance();
            NetMgr.inst().connectWebSocket(GameConfig.serverAddress);
            NetMgr.inst().addEventListener(NetEvent.socket.SOCKET_CONNECT, function () {
                var account = v1;
                var password = v2;
                var token = v3;
                cc.error("token:" + token);
                cc.error("account:" + account);
                cc.error("password:" + password);

                var msg = new SocketBytes();
                msg.writeUint(200);//账号登录
                msg.writeUint(GameConfig.PLATFORM_DEFAULT_ID);
                msg.writeString(account);
                msg.writeString(token);
                NetMgr.inst().send(msg);

            }, this);
        }
        else {
            ModuleMgr.inst().openModule("GameLoginModule", {"ui": "key", "ip": null});
        }
    },

    netGetError: function (cmd, data) {
        if (cmd == 0) {
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            trace(data0,data1);
            if (data0 == 200 && data1 == 0) {
                //设置昵称
                ModuleMgr.inst().openModule("Presetting", {
                    "data": null,
                    "openSound": true,
                    "loginAccount": null,
                    "loginToken": null
                });
            }
            //账号名称设置
            if (data0 == 202 && data1 == 0) {
                ModuleMgr.inst().closeModule("Presetting", {"closeSound": false});
                ModuleMgr.inst().openModule("GameLoginModule", {"ui": "loading", "login": false});
                startGameData.step = 6;
            }
        }
    }


});