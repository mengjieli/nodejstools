var NetWaitingModel = (function (_super) {
    __extends(NetWaitingModel, _super);

    function NetWaitingModel() {
        _super.call(this,"NetWiating");
        this.views = ["NetWaitView"];
        this.hasConnect = true;
        this.opens = {};
        mainData.netData.addListener("isConnect",this.onConnectClose,this);
    }

    var d = __define, c = NetWaitingModel;
    p = c.prototype;

    p.openView = function (index) {
        index = index || 0;
        if(this.opens[index]) {
            return;
        }
        this.opens[index] = true;
        ModuleMgr.inst().openModule(this.views[index]);
    }

    p.closeView = function (index) {
        index = index || 0;
        if(this.opens[index]) {
            delete this.opens[index];
            ModuleMgr.inst().closeModule(this.views[index]);
        }
    }

    p.onConnectClose = function(val) {
        if(val == false) {
            this.hasConnect = false;
            this.openView();
        } else {
            if(this.hasConnect == false) {
                this.closeView();
                //重链后设定视野
                var rect = mainData.mapData.cameraData.viewPort;
                var msg = new SocketBytes();
                msg.writeUint(301);
                msg.writeInt(rect.x);
                msg.writeInt(rect.y);
                msg.writeUint(rect.width);
                msg.writeUint(rect.height);
                NetMgr.inst().send(msg);
            }
            this.hasConnect = true;
        }
    }

    return NetWaitingModel;
})(ModelBase);