/**
 * Created by cgMu on 2015/11/3.
 */

HEADEVENT = {};
HEADEVENT.CHANGE_HEAD_SUCCESS = "change_head_success";
HEADEVENT.CHANGE_NAME_SUCCESS = "change_name_success";

HEADEVENT.CHANGE_NAME_NET = "change_name_net";
HEADEVENT.CHANGE_HEAD_NET = "change_head_net";

var HeadModule = ModuleBase.extend({
    musicBtn: true,
    soundBtn: true,

    headIcon: null,
    _panel_part1: null,

    ctor: function () {
        this._super();
        //修改头像成功事件监听
        EventMgr.inst().addEventListener(HEADEVENT.CHANGE_HEAD_SUCCESS, this.updateHeadIcon, this);
        EventMgr.inst().addEventListener(HEADEVENT.CHANGE_NAME_SUCCESS, this.updateName, this);
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netUpdate, this);

        var data = SoundPlay.fetchSoundOption();
        var value1 = "1";
        var value2 = "1";
        if(data){
            value1 = data.music;
            value2 = data.effect;
        }

        cc.log("@设置:",value1,value2);
        this.musicBtn = this.getBoolenValue(value1);
        this.soundBtn = this.getBoolenValue(value2);
        cc.log("@设置 music:",this.musicBtn,"effect:",this.soundBtn);
    },

    initUI: function () {
        var root_ = ccs.load("res/images/ui/HeadModule/HeadLayer.json", "res/images/ui/").node;
        this.addChild(root_);

        var size = cc.director.getVisibleSize();
        root_.setContentSize(size);
        ccui.helper.doLayout(root_);

        //背景容器
        var Panel_1 = root_.getChildByName("Panel_1");
        sizeAutoLayout(Panel_1);
        var root = Panel_1;

        var Panel_55 = root.getChildByName("Panel_55");
        sizeAutoLayout(Panel_55);

        var Image_8 = root.getChildByName("Image_8");
        sizeAutoLayout(Image_8);

        var Image_10 = root.getChildByName("Image_10");
        posAutoLayout(Image_10);

        //第一部分
        var panel_part1 = root.getChildByName("Panel_3");
        posAutoLayout(panel_part1);
        this._panel_part1 = panel_part1;

        var Image_16 = root.getChildByName("Image_16");
        posAutoLayout(Image_16);

        //第二部分
        var panel_part2 = root.getChildByName("Panel_4");
        sizeAutoLayout(panel_part2, 0.5);
        posAutoLayout(panel_part2, 0.5);

        var Image_16_0 = root.getChildByName("Image_16_0");
        posAutoLayout(Image_16_0, 0.5);

        var des1 = panel_part2.getChildByName("Image_18");
        des1.ignoreContentAdaptWithSize(true);
        posAutoLayout(des1,0.4);
        des1.setVisible(false);

        var des2 = panel_part2.getChildByName("Image_18_0");
        des2.ignoreContentAdaptWithSize(true);
        posAutoLayout(des2,0.25);
        //des2.setVisible(false);
        var data_2 = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId).attributes.getItem("type",2500001).value;
        var val2 = des2.getChildByName("Text_4_0");
        val2.ignoreContentAdaptWithSize(true);
        val2.setString(ResMgr.inst().getString("head_14")+data_2);

        var des3 = panel_part2.getChildByName("Image_18_1");
        des3.ignoreContentAdaptWithSize(true);
        posAutoLayout(des3,0.1);
        des3.setVisible(false);

        //第三部分
        var panel_part3 = root.getChildByName("Panel_5");
        sizeAutoLayout(panel_part3, 0.25);
        posAutoLayout(panel_part3, 0.25);

        var Image_16_0_0 = root.getChildByName("Image_16_0_0");
        posAutoLayout(Image_16_0_0, 0.25);

        var musicLabel = panel_part3.getChildByName("Text_9");
        musicLabel.ignoreContentAdaptWithSize(true);
        musicLabel.setString(ResMgr.inst().getString("head_17"));
        posAutoLayout(musicLabel, 1 / 8);

        var soundLabel = panel_part3.getChildByName("Text_9_0");
        soundLabel.ignoreContentAdaptWithSize(true);
        soundLabel.setString(ResMgr.inst().getString("head_16"));
        posAutoLayout(soundLabel, 1 / 8);

        var Image_2 = panel_part3.getChildByName("Image_2");
        posAutoLayout(Image_2, 1 / 8);
        var Image_2_0 = panel_part3.getChildByName("Image_2_0");
        posAutoLayout(Image_2_0, 1 / 8);

        //第四部分
        var label = panel_part1.getChildByName('Text_2');
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("head_1"));

        label = panel_part1.getChildByName('Text_2_0');
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("head_2"));
        //label.setVisible(false);

        label = panel_part1.getChildByName('Text_2_1');
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("head_3"));
        //label.setVisible(false);

        var changeBtn1 = panel_part1.getChildByName("Button_3");
        changeBtn1.addTouchEventListener(this.changeBtnCallback, this);
        //changeBtn1.setVisible(false);

        var changeBtn2 = panel_part1.getChildByName("Button_3_0");
        changeBtn2.addTouchEventListener(this.changeBtnCallback2, this);
        //changeBtn2.setVisible(false);

        var changeBtn3 = panel_part1.getChildByName("Button_3_1");
        changeBtn3.setVisible(false);

        //head icon
        this.headIcon = panel_part1.getChildByName("Image_6_0");
        this.headIcon.setScale(0.55);
        this.headIcon.ignoreContentAdaptWithSize(true);
        var headname = mainData.playerData.headid;
        cc.log("@$$$$$$$$$$$$$$$$$$",headname);
        if (headname == undefined || headname == "") {
            headname = ResMgr.inst().getCSV("head", 1).head_id;//默认配置第一个  var headArray = ResMgr.inst().getCSV("head");
        }
        this.setHeadIconView(headname);
        cc.log("@@###############",headname);

        label = panel_part1.getChildByName('Text_2_5');
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("head_5"));
        //label.setVisible(false);

        var btn1 = panel_part1.getChildByName("Button_1");
        btn1.addTouchEventListener(this.btn1, this);
        var title = btn1.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("head_6"));
        //btn1.setVisible(false);

        var btn2 = root.getChildByName("Button_2");
        btn2.addTouchEventListener(this.btnCallback, this);
        posAutoLayout(btn2, 1 / 8);
        btn2.setTag(HeadModule.BUTTON_LEFT_TAG);
        title = btn2.getChildByName("Text_11");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("head_7"));

        var btn3 = root.getChildByName("Button_2_0");
        btn3.addTouchEventListener(this.btnCallback, this);
        posAutoLayout(btn3, 1 / 8);
        btn3.setTag(HeadModule.BUTTON_RIGHT_TAG);
        title = btn3.getChildByName("Text_11");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("head_8"));

        var left1 = panel_part1.getChildByName("Text_3");
        left1.ignoreContentAdaptWithSize(true);
        left1.setString(mainData.playerData.nick);

        var left2 = panel_part1.getChildByName("Text_3_0");
        left2.ignoreContentAdaptWithSize(true);
        left2.setString(mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId).name);//主城昵称
        //left2.setVisible(false);

        var left3 = panel_part1.getChildByName("Text_8");
        left3.ignoreContentAdaptWithSize(true);
        left3.setString(this.getPromotionName(mainData.playerData.promotionLevel));
        //left3.setVisible(false);

        var right1 = panel_part1.getChildByName('Text_3_0_0');
        right1.ignoreContentAdaptWithSize(true);
        right1.setString("");
        //right1.setVisible(false);

        var right3 = panel_part1.getChildByName('Text_3_1');
        right3.ignoreContentAdaptWithSize(true);
        right3.setString("");
        //right3.setVisible(false);

        var text2 = panel_part1.getChildByName("Text_2_0_0");
        text2.ignoreContentAdaptWithSize(true);
        text2.setString(ResMgr.inst().getString("head_24"));

        //di
        var di = panel_part1.getChildByName("Image_11_0");
        di.setVisible(true);
        di = panel_part1.getChildByName("Image_11_1");
        //di.setVisible(false);
        di = panel_part1.getChildByName("Image_11_2");
        //di.setVisible(false);
        di = panel_part1.getChildByName("Image_11_3");
        //di.setVisible(false);

        //官职
        var Button_4 = panel_part1.getChildByName("Button_4");
        Button_4.addTouchEventListener(this.placeCallback,this);
        //Button_4.setVisible(false);

        var chooseBtn1 = panel_part3.getChildByName("Image_2_0");
        chooseBtn1.setTouchEnabled(true);
        chooseBtn1.setTag(HeadModule.CHOOSE_SOUND_TAG);
        chooseBtn1.addTouchEventListener(this.chooseBtnCallback, this);
        this.setChooseBtnState(chooseBtn1, this.soundBtn,true);

        var Text_0 = chooseBtn1.getChildByName("Text_0");//开启
        Text_0.ignoreContentAdaptWithSize(true);
        Text_0.setString(ResMgr.inst().getString("head_22"));

        var Text = chooseBtn1.getChildByName("Text");//关闭
        Text.ignoreContentAdaptWithSize(true);
        Text.setString(ResMgr.inst().getString("head_23"));

        var chooseBtn2 = panel_part3.getChildByName("Image_2");
        chooseBtn2.setTouchEnabled(true);
        chooseBtn2.setTag(HeadModule.CHOOSE_MUSIC_TAG);
        chooseBtn2.addTouchEventListener(this.chooseBtnCallback, this);
        this.setChooseBtnState(chooseBtn2, this.musicBtn,true);

        Text_0 = chooseBtn2.getChildByName("Text_0");//开启
        Text_0.ignoreContentAdaptWithSize(true);
        Text_0.setString(ResMgr.inst().getString("head_22"));

        Text = chooseBtn2.getChildByName("Text");//关闭
        Text.ignoreContentAdaptWithSize(true);
        Text.setString(ResMgr.inst().getString("head_23"));
    },

    show: function (value) {

    },

    close: function () {

    },

    destroy: function () {
        EventMgr.inst().removeEventListener(HEADEVENT.CHANGE_HEAD_SUCCESS, this.updateHeadIcon, this);
        EventMgr.inst().removeEventListener(HEADEVENT.CHANGE_NAME_SUCCESS, this.updateName, this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netUpdate, this);
    },

    placeCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var layer = new PlaceLayer();
            ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    btn1: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            //cc.log("btn 1 touch ended");
            var layer = new SelectingLayer();
            ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOP);
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
        }
    },

    btnCallback: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            var tag = sender.getTag();
            switch (tag) {
                case HeadModule.BUTTON_LEFT_TAG://注销
                    var user = this.fetchUserName();
                    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
                    var file = jsb.fileUtils.writeToFile({
                        "lastLoginName":user//mainData.playerData.user
                    }, storagePath + "cache");

                    cc.log("btn 注销 touch ",user);
                    cc.director.end();

                    //ModuleMgr.inst().openModule("GameOverModule");
                    break;
                case HeadModule.BUTTON_RIGHT_TAG://退出
                    SoundPlay.stopMusic();
                    cc.director.end();
                    break;
            }
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
        }
    },

    chooseBtnCallback: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            switch (sender.getTag()) {
                case HeadModule.CHOOSE_MUSIC_TAG:
                    this.setChooseBtnState(sender, !this.musicBtn);
                    this.musicBtn = !this.musicBtn;
                    if (this.musicBtn) {
                        cc.error("音乐开启");
                        this.recordSoundInfo("music","1");
                        SoundPlay.playMusic(ResMgr.inst().getSoundPath(2))
                    }
                    else {
                        cc.error("音乐关闭");
                        this.recordSoundInfo("music","0");
                        SoundPlay.stopMusic();
                    }

                    break;
                case HeadModule.CHOOSE_SOUND_TAG:
                    this.setChooseBtnState(sender, !this.soundBtn);
                    this.soundBtn = !this.soundBtn;
                    if (this.soundBtn) {
                        cc.error("音效开启");
                        this.recordSoundInfo("effect","1");
                    }
                    else {
                        cc.error("音效关闭");
                        this.recordSoundInfo("effect","0");
                    }
                    break;
            }
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
        }
    },

    //state : 1,on ; 0,off
    setChooseBtnState: function (btn, state,init) {
        var block = btn.getChildByName("block");

        if(init){
            if(state){
                //on
                //btn.loadTexture("HeadModule/touxiang_youxiyinxiao.png",ccui.Widget.PLIST_TEXTURE);
                //block.runAction(cc.MoveBy(0.1, cc.p(-53, 0)));
            }
            else{
                //off
                btn.loadTexture("HeadModule/touxiang_youxiyinyue.png",ccui.Widget.PLIST_TEXTURE);
                //block.runAction(cc.MoveBy(0.1, cc.p(53, 0)));
                block.x +=53;
            }
            return
        }

        if (state) {
            //on
            btn.loadTexture("HeadModule/touxiang_youxiyinxiao.png",ccui.Widget.PLIST_TEXTURE);
            block.runAction(cc.MoveBy(0.1, cc.p(-53, 0)));
        }
        else {
            //off
            btn.loadTexture("HeadModule/touxiang_youxiyinyue.png",ccui.Widget.PLIST_TEXTURE);
            block.runAction(cc.MoveBy(0.1, cc.p(53, 0)));
        }
    },

    netUpdate: function (event, data) {
        if (data == 201) {
            //设置账号属性返回
            EventMgr.inst().dispatchEvent(HEADEVENT.CHANGE_HEAD_SUCCESS);
        }
        if (data == 202) {
            //设置昵称返回
            EventMgr.inst().dispatchEvent(HEADEVENT.CHANGE_NAME_SUCCESS);
        }
    },

    setHeadIconView: function (headname) {
        var data = headname;
        if (this.headIcon) {
            if (!data) {
                data = mainData.playerData.headid;
            }
            this.headIcon.loadTexture(ResMgr.inst().getIcoPath(data));
        }
    },

    updateHeadIcon: function (event) {
        this.setHeadIconView();

        //头像特效
        var size = cc.director.getVisibleSize();
        var csv = ResMgr.inst().getCSV("animationConfig","head_change");
        var effect =new AnimationSprite();
        effect.setPosition(this.headIcon.getPosition());
        effect.setName("head_change");
        effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
        this._panel_part1.addChild(effect);
    },

    effectCallback: function (sender) {
        sender.removeFromParent(true);
    },

    updateName: function (event) {
        var left1 = this._panel_part1.getChildByName("Text_3");
        left1.ignoreContentAdaptWithSize(true);
        left1.setString(mainData.playerData.nick);
    },

    changeBtnCallback: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            var layer = new ChangeNameLayer();
            ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    changeBtnCallback2: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            //cc.log("changeBtnCallback");
            var layer = new ChangeCastleNameLayer();
            ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    recordSoundInfo: function (type, value) {
        //cc.sys.localStorage.setItem(type,value);
        var effect = "1";
        var music = "1";
        var temp = SoundPlay.fetchSoundOption();
        if(temp){
            effect = temp.effect;
            music = temp.music;
        }

        if(type=="effect"){
            effect = value;
        }
        else if(type=="music"){
            music = value;
        }

        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var file = jsb.fileUtils.writeToFile({"music":music,"effect":effect}, storagePath + "sound");
    },

    getBoolenValue: function (value) {
        var b = true;
        if(value &&parseInt(value)==0){
            b = false;
        }
        return b;
    },

    fetchUserName : function() {
        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var fileExist = jsb.fileUtils.isFileExist(storagePath + "cache");
        if(fileExist)
        {
            var string = jsb.fileUtils.getValueMapFromFile(storagePath + "cache");
            cc.log("cache:" + JSON.stringify(string["lastLoginName"]) + "_" + (string["lastLoginPassword"]) + "_" + (string["lastLoginToken"]));
            return string["lastLoginName"];//{"username":string["lastLoginName"], "password":string["lastLoginPassword"], "token":string["lastLoginToken"]};
        }
        return null;
    },

    getPromotionName: function (lv) {
        if(lv==0) return "";
        var data = modelMgr.call("Table", "getTableItemByValue", ["vip", lv]);
        var string = ResMgr.inst().getString(data.vip_id+"0");
        return string;
    }
});

HeadModule.BUTTON_LEFT_TAG = 1001;
HeadModule.BUTTON_RIGHT_TAG = 1002;
HeadModule.CHOOSE_MUSIC_TAG = 1003;
HeadModule.CHOOSE_SOUND_TAG = 1004;