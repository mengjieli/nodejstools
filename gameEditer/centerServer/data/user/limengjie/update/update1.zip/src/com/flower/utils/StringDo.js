var flower;
(function (flower) {
    var StringDo = (function () {

        function StringDo() {
        }

        var d = __define, c = StringDo;
        p = c.prototype;

        StringDo.replace = function (content, findText, replaceText) {
            var findLen = findText.length;
            var replaceLen = replaceText.length;
            var contentLen = content.length;
            for (var i = 0; i < content.length; i++) {
                if (content.slice(i, i + findLen) == findText) {
                    content = content.slice(0, i) + replaceText + content.slice(i + findLen, contentLen);
                    i--;
                }
            }
            return content;
        }

        return StringDo;
    })();
    flower.StringDo = StringDo;
})(flower || (flower = {}));