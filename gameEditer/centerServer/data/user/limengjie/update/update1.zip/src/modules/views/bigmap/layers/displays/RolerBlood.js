var RolerBlood = cc.Sprite.extend({
    ctor: function (data) {
        this._super();
        this.data = data; //MapRolerData

        this.selectBg = new cc.Sprite("res/fight/ui/head/selected.png");
        this.addChild(this.selectBg);
        this.selectBg.setPosition(0,0);

        var bloodBg = new cc.Sprite("res/fight/ui/head/bloodbg.png");
        this.addChild(bloodBg);
        bloodBg.setPosition(9,7);

        this.blood = new ccui.ImageView();
        this.addChild(this.blood);
        this.blood.setAnchorPoint(0,0.5);
        this.blood.setPosition(100-51-10-26-22,100-87-6);

        this.bg = new ccui.ImageView();
        this.addChild(this.bg);
        this.bg.setPosition(1,4);

        var head = new cc.Sprite("res/fight/ui/head/" + this.data.config.arm_image + "7.png");
        this.addChild(head);
        head.setPosition(-26,9);

        this.headFront = new ccui.ImageView();
        this.addChild(this.headFront);
        this.headFront.setPosition(0,3);

        this.levelTxt = new BorderText();
        this.addChild(this.levelTxt);
        this.levelTxt.setFontSize(14);
        this.levelTxt.setAnchorPoint(0.5,0);
        this.levelTxt.setPosition(-27 + 2,-20 - 6);

        this.tipTxt = new BorderText();
        this.addChild(this.tipTxt);
        this.tipTxt.setFontSize(14);
        this.tipTxt.setAnchorPoint(0,0);
        this.tipTxt.setPosition(50,0);
        this.tipTxt.setPosition(-27 + 42,-21);

        this.setVisible(this.data.showBlood);
        this.data.addListener("showBlood",this.onShowBloodChange,this);

        this.initData();

    },
    initData: function () {
        if(this.data.relation == "myself") {
            this.changeType("my");
        } else {
            if(this.data.relation == "monster") {
                this.changeType("monster");
            } else if(this.data.relation == "boss") {
                this.changeType("boss");
            } else {
                this.changeType("enemy");
            }
        }
        this.changeBlood();
        this.addListener();
    },
    /**
     * 切换状态
     * @param type my.蓝色(自己的) enemy.红色的(敌方) monster.野怪 boss.Boss野怪
     */
    changeType: function (type) {
        this.type = type;
        this.blood.loadTexture("res/fight/ui/head/" + type + "Blood.png");
        this.changeBlood();
        if(type == "my" || type == "enemy") {

            var icon = new cc.Sprite("res/fight/ui/head/" + this.data.config.city_camp + ".png");
            this.addChild(icon);
            icon.setPosition(2,-13);

            this.bg.loadTexture("res/fight/ui/head/" + this.data.level + ".png");
            if(this.data.level == 8 || this.data.level == 10) {
                this.headFront.loadTexture("res/fight/ui/head/" + this.data.level + "-1.png");
            }
        } else if(type == "monster"){
            this.bg.loadTexture("res/fight/ui/head/" + type + ".png");
            this.bg.setPosition(-4,2);
        }
        this.levelTxt.setString(this.data.level + "");
    },
    addListener: function() {
        this.data.addListener("attributes",this.changeBlood,this);
    },
    removeListener: function() {
        this.data.removeListener("attributes",this.changeBlood,this);
    },
    changeBlood:function() {
        var blood = this.data.attributes.getItem("type",2500011).value;
        var fullBlood = this.data.attributes.getItem("type",2500077).value;
        //trace("血量",blood,fullBlood);
        var scale = blood/fullBlood;
        if(scale < 0) scale = 0;
        if(scale > 1) scale = 1;
        this.blood.setScaleX(50*scale);
        //if(this.type == "my" || this.type == "enemy") {
        //    var id = ModelManager.getInstance().call("Table","getTableItemByRange",["arm_display",blood]).id;
        //    this.tipTxt.setString(ResMgr.inst().getString(id + "0"));
        //}
        this.tipTxt.setString(blood + "");
    },
    onShowBloodChange:function(val) {
        this.setVisible(val);
    },
    dispose:function() {
        this.data.removeListener("showBlood",this.onShowBloodChange,this);
        this.removeListener();
    }
});