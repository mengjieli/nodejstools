var flower;
(function (flower) {
    var Setting = (function () {
        function Setting() {
        }
        return Setting;
    })();
    flower.Setting = Setting;
})(flower || (flower = {}));
flower.Setting.warnInfo = true;
flower.Setting.errorInfo = true;
flower.Setting.tipInfo = true;
flower.Setting.resrict = true;
//# sourceMappingURL=Setting.js.map