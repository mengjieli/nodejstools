/**
 * Created by Administrator on 2015/2/4.
 */

TaskEvent = {};
TaskEvent.TASK_UPDATE_TASK = "task_update_task";
TaskEvent.TASK_SEND_TASK = "task_send_task";
TaskEvent.TASK_TASK_REWARD = "task_task_reward";
//TaskEvent.SHOW_ANNOUNCEMENT_BG = "show_task_bg";
//通讯部分
TaskNetEvent = {};
TaskNetEvent.SEND_TASK=1200;//发送任务列表请求
TaskNetEvent.SEND_TASK_REWARD=1201;//任务奖励
TaskNetEvent.GET_TASK=1299;//收到任务信息

var TaskData = DataBase.extend({

    _dailyTaskList:null,//每日任务列表数据

    ctor:function()
    {
        this._super();

        this._dailyTaskList = [1,2,3,4,5];
        //this.resetAnnouncement();

    },

    init:function()
    {
        //NetMgr.inst().addEventListener( ProtoclId.DZSLogin , this.transactionHandler, this);
        EventMgr.inst().addEventListener(TaskEvent.TASK_SEND_TASK, this.onSendTask, this);
        EventMgr.inst().addEventListener(TaskEvent.TASK_TASK_REWARD, this.onTaskReward, this);
        //NetMgr.inst().addEventListener(AnnouncementNetEvent.GET_ANNOUNCEMENT, this.netGetAnnouncement, this);
        //var csvblock = modelMgr.call("Table","getTableList",["castle_block"]);
    },

    //任务请求
    onSendTask: function (type) {
        cc.log("SEND_TASK ################################################################################################# 任务请求");
        var msg = new SocketBytes();
        msg.writeUint(TaskNetEvent.SEND_TASK);
        NetMgr.inst().send(msg);
    },
    //领取任务奖励
    onTaskReward: function (type,taskId) {
        var msg = new SocketBytes();
        msg.writeUint(TaskNetEvent.SEND_TASK_REWARD);
        msg.writeUint(taskId);
        NetMgr.inst().send(msg);
    },
    //收到服务端传得公告信息
    netGetTask:function(cmd,data){
        //if(AnnouncementData.TEST_LOG)   cc.log("收到公告信息");
        if (TaskNetEvent.GET_TASK == cmd) {
            data.resetCMDData();
            var id=data.readString();
            var languageId=data.readUint();
            var createdTime=data.readUint();
            var leftTime=data.readUint();
            var period=data.readUint();
            var len = data.readUint();
            var message=[];
            for (var i = 0; i < len; i++) {
                var slot = data.readUint();
                var value = data.readString();
                message.push([slot,value]);
            }
            //var arrData=[data.readString(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint()];
            var arrData=[id,languageId,createdTime,leftTime,period,message];
            this.addNetAnnouncement(arrData);

            //判断是否当前播放列表空 直接公告
        }
    },



});
//静态属性
//TaskData.TEST_LOG=false;//测试Log信息true