var ShaderLayer = cc.Sprite.extend({
    ctor: function () {
        this._super();
        mainData.uiData.map.addListener("showCastleRange", this.onShowCastleRange, this);
        this.castleRange = null;
    },
    updateShow: function (camera) {
        this.setPosition(-camera.x, -camera.y);
    },
    onShowCastleRange: function (castleId) {
        if(mainData.uiData.map.showCastleRange == "") {
            if(this.castleRange) {
                this.castleRange.dispose();
                this.castleRange = null;
            }
        } else {
            var castle = mainData.mapData.castleList.getItem("id",castleId);
            if(castle) {
                this.castleRange = new MapBuildRange(castle);
                this.castleRange.setPosition(castle.showX,castle.showY);
                this.addChild(this.castleRange);
            }
        }
    },
    dispose: function () {
        if(this.castleRange) {
            this.castleRange.dispose();
            this.castleRange = null;
        }
        mainData.uiData.map.removeListener("showCastleRange", this.onShowCastleRange, this);
    }
});