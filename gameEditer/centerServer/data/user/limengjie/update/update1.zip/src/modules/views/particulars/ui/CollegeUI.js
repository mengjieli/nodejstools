/**
 * Created by cgMu on 2015/10/27.
 */

var CollegeUI = cc.Node.extend({
    _ui:null,
    _id:0,
    _index:0,
    _level:0,

    isOnePage: null,
    scrol: null,
    scrollbar: null,
    scrollPosY: 0,
    barTotalHeight: 0,
    barPercent_total: 0,

    ctor:function( id,index )
    {
        this._super();
        this._id = id;
        this._index = index;
        this._level = ModuleMgr.inst().getData("CastleModule").getNetBlock()[this._index]._building_level;

        var data =  modelMgr.call("Table","getTableList",["City_College"]);
        var inde = data.length;

        this._ui = ccs.load("res/images/ui/TheWall/Wall_Particulars_Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        //适配
        var size1 = cc.director.getVisibleSize();
        this._ui.setContentSize( size1 );
        ccui.helper.doLayout( this._ui );

        var Image_2 = this._ui.getChildByName("Image_2");
        sizeAutoLayout(Image_2);

        var Image_6 = this._ui.getChildByName("Image_6");
        sizeAutoLayout(Image_6);
        posAutoLayout(Image_6,0.5);

        var Image_3 = this._ui.getChildByName("Image_3");
        posAutoLayout(Image_3);

        //scrolbar_bg
        var Image_4 = this._ui.getChildByName("Image_4");
        posAutoLayout(Image_4);
        sizeAutoLayout(Image_4);
        //scrolbar
        var Image_5 = this._ui.getChildByName("Image_5");
        posAutoLayout(Image_5);
        this.scrollbar = Image_5;//滑块
        this.scrollPosY = this.scrollbar.getPositionY();//滑块初始位置
        this.barTotalHeight = Image_4.getContentSize().height;//滑块滑动区间

        var labe1 = this._ui.getChildByName("Image_3").getChildByName("Text_1");
        labe1.ignoreContentAdaptWithSize( true );
        labe1.setString( ResMgr.inst().getString("xiangqing_1") );

        var labe2 = this._ui.getChildByName("Image_3").getChildByName("Text_1_0");
        labe2.ignoreContentAdaptWithSize( true );
        labe2.setString( ResMgr.inst().getString("xiangqing_20") );

        var labe3 = this._ui.getChildByName("Image_3").getChildByName("Text_1_1");
        labe3.ignoreContentAdaptWithSize( true );
        labe3.setString( ResMgr.inst().getString("xiangqing_14") );

        var scrollview = this._ui.getChildByName("ScrollView_1");
        scrollview.addEventListener(this.scrollCall, this );
        sizeAutoLayout(scrollview);
        var item0 = scrollview.getChildByName("Panel_1");
        item0.setVisible(false);
        this.scrol = scrollview;

        var gap = 3;
        var size = scrollview.getContentSize();
        var counts = inde;
        var itemH = item0.getContentSize().height;
        var h = counts * itemH + (counts + 1) * gap;
        h = h > size.height ? h : size.height;

        for( var i=1; i<=counts ; i++ )
        {
            var it = item0.clone();
            scrollview.addChild( it );
            it.setVisible(true);
            it.setPosition( 0,h - i*(itemH+gap) );

            var select = it.getChildByName("Image_1_0");
            select.setVisible(false);
            if(i == this._level) {
                select.setVisible(true);
            }

            var data = modelMgr.call("Table", "getTableItemByValue", ["City_College",i ]);

            var text1 = it.getChildByName("Text_4");
            text1.ignoreContentAdaptWithSize(true);
            text1.setString( data.college_level );
            var text2 = it.getChildByName("Text_4_0");
            text2.ignoreContentAdaptWithSize(true);
            if (i == 1) {
                text2.setString( ResMgr.inst().getString("college_2") );
            }
            else {
                text2.setString( "——" );
            }
            var text3 = it.getChildByName("Text_4_0_0");
            text3.ignoreContentAdaptWithSize(true);
            text3.setString( data.prosperity );
        }

        size.height = h > size.height ? h : size.height;
        scrollview.setInnerContainerSize( size );

        var pos = scrollview.getInnerContainer().getPosition();
        this.barPercent_total = Math.abs(pos.y);

        this.updateScrollviewSelecting(scrollview,counts,itemH,this._level);

        //重置滑块位置
        var innerContainerSize = scrollview.getInnerContainerSize();


        if (innerContainerSize.height < size.height) {
            this.isOnePage = true;
        }
        else {
            this.isOnePage = false;
        }
        if (this.isOnePage) {
            this.refreshScrollbarState(100);
        }
        else {
            this.refreshScrollbarState(0);
        }
    },

    scrollCall:function( node, type )
    {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                this.setScrollbar();
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    //更新滑块位置
    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY - (this.barTotalHeight- 20 - this.scrollbar.height) * percent / 100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },

    updateScrollviewSelecting: function (scrollview, length,itemH,selecting) {
        var size = scrollview.getContentSize();
        var h = scrollview.getInnerContainerSize().height;
        var number = parseInt(size.height / (itemH+3));
        if (selecting> length-number) {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function () {
                scrollview.jumpToBottom();
            })));
        }
        else {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function (sender) {
                //var size = scrollview.getContentSize();
                var percent = (selecting-1)*(itemH+3) / (h- size.height) * 100;
                scrollview.jumpToPercentVertical(percent);

                sender.setScrollbar();//刷新滑块位置
            })));
        }
    },

    setScrollbar: function () {
        var pos = this.scrol.getInnerContainer().getPosition();
        var number = this.barPercent_total + pos.y;
        var per = number * 100 / this.barPercent_total;
        if (per < 0) {
            per = 0
        }
        if (per > 100) {
            per = 100
        }
        this.refreshScrollbarState(per);
    }
});