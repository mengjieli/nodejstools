var HillLayer = cc.Sprite.extend({
    listv: null,
    listh:null,
    ctor: function () {
        this._super();

        this.listv = [];
        this.listh = [];
    },
    updateShow: function (camera) {
        this.setPosition(-camera.x, -camera.y);
        var minX = camera.x;
        var maxX = camera.x + camera.width;
        var minY = camera.y;
        var maxY = camera.y + camera.height;
        for(var i = 0; i < this.listv.length; i++) {
            this.listv[i].setVisible(false);
        }
        for(var i = 0; i < this.listh.length; i++) {
            this.listh[i].setVisible(false);
        }
        //有纵向的
        var h = 0;
        var childIndex = 0;
        if (Math.abs((minX + maxX) / 2) < 200 + camera.width/2) {
            var down = Math.floor(minY / 800);
            var up = Math.floor(maxY / 800);
            for (var i = up; i >= 0 && i >= down; i--) {
                if (h < this.listh.length) {
                    this.listh[h].setVisible(true);
                    this.listh[h].setPosition(-383, -100 + i*800);
                } else {
                    var sp = new cc.Sprite("res/fight/mapsource/hill/hill1.png");
                    this.listh.push(sp);
                    this.addChild(sp);
                    sp.setAnchorPoint(0, 0);
                    sp.setPosition(-383, -100 + i*800);
                }
                this.listh[h].setLocalZOrder(childIndex);
                childIndex++;
                h++;
            }
        }
        //有横向的
        if (Math.abs((minY + maxY) / 2) < 200 + camera.height/2) {
            var left = Math.floor(minX / 860);
            var right = Math.floor(maxX / 860);
            var v = 0;
            for (var i = right; i >= left; i--) {
                if (v < this.listv.length) {
                    this.listv[v].setVisible(true);
                    this.listv[v].setPosition(-257 + 860 * i, -200);
                } else {
                    var sp = new cc.Sprite("res/fight/mapsource/hill/hill2.png");
                    this.listv.push(sp);
                    this.addChild(sp);
                    sp.setAnchorPoint(0, 0);
                    sp.setPosition(-257 + 860 * i, -200);
                }
                this.listv[v].setLocalZOrder(childIndex);
                childIndex++;
                v++;
            }
        }
        //有纵向的
        if (Math.abs((minX + maxX) / 2) < 200 + camera.width/2) {
            var down = Math.floor(minY / 800);
            var up = Math.floor(maxY / 800);
            for (var i = -1; i < 0 && i >= down; i--) {
                if (h < this.listh.length) {
                    this.listh[h].setVisible(true);
                    this.listh[h].setPosition(-383, -100 + i*800);
                } else {
                    var sp = new cc.Sprite("res/fight/mapsource/hill/hill1.png");
                    this.listh.push(sp);
                    this.addChild(sp);
                    sp.setAnchorPoint(0, 0);
                    sp.setPosition(-383, -100 + i*800);
                }
                this.listh[h].setLocalZOrder(childIndex);
                childIndex++;
                h++;
            }
        }
        //var sp = new cc.Sprite("res/fight/mapsource/hill/hill1.png");
        //this.addChild(sp);
        //sp.setAnchorPoint(0, 0);
        //sp.setPosition(-340,-100);
        //
        //var sp = new cc.Sprite("res/fight/mapsource/hill/hill1.png");
        //this.addChild(sp);
        //sp.setAnchorPoint(0, 0);
        //sp.setPosition(-340,-900);
    }
});