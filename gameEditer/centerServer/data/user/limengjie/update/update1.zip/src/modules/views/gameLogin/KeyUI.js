/**
 * Created by cgMu on 2015/12/17.
 */

var KeyUI = cc.Node.extend({
    _ui: null,
    _errorLabel:null,

    _input: null,
    _account:null,
    _token:null,

    ctor: function(ip,tk)
    {
        this._super();
        this._account = ip;
        this._token = tk;

    },

    onEnter: function()
    {
        this._super();
        this._ui = ccs.load( "res/images/ui/login/key.json", "res/images/ui/" ).node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //提交按钮
        var but = this._ui.getChildByName( "ui_mainban" ).getChildByName( "denglu" );
        but.addTouchEventListener( this.nextCall, this );
        but.setTitleText( ResMgr.inst().getString("login_28"));

        //输入框
        this._input = this._ui.getChildByName( "ui_mainban" ).getChildByName( "TextField_2" );
        this._input.addEventListener(this.inputCallback,this);
        this._input.setPlaceHolder( ResMgr.inst().getString("login_29") );
        this._input.addEventListener(this.onTfInput, this);

        var txt = this._ui.getChildByName("ui_mainban" ).getChildByName("Text_2_0_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("login_30") );
        txt.setVisible(false);
        this._errorLabel = txt;

        NetMgr.inst().addEventListener(0, this.netGetError, this);
    },

    onExit: function()
    {
        this._super();
        NetMgr.inst().removeEventListener(0, this.netGetError, this);
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },

    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /**
     * 按钮回调
     * @param node
     * @param type
     */
    nextCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            //下一步
            this.nextStep();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    inputCallback: function (node, type) {
        switch (type){
            case ccui.TextField.EVENT_ATTACH_WITH_IME:
                this._errorLabel.setVisible(false);
                break;
        }
    },

    nextStep: function () {
        var activationCode = this._input.getString();
        if(0 == activationCode.length)
        {
            this._errorLabel.setVisible(true);
            return;
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "activate";
        var url = head;
        url += "?loginName=" + encodeString(this._account);
        url += "&activationCode=" + encodeString(activationCode);

        cc.log("@KeyUI account",this._account,"key",activationCode);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
                cc.log("activationCode data:" + data);
                var ret = JSON.parse(data);
                if(ret)
                {
                    if(0 == ret.err_code)
                    {
                        ModuleMgr.inst().getData("GameLoginModule").recordUserInfo([param.owner._account, "", param.owner._token]);

                        ReconnectionMgr.getInstance();
                        NetMgr.inst().connectWebSocket(GameConfig.serverAddress);
                        NetMgr.inst().addEventListener(NetEvent.socket.SOCKET_CONNECT, function () {
                            var account = param.owner._account;
                            //var password = v2;
                            var token = param.owner._token;
                            //cc.error("token:" + token);
                            cc.error("account:" + account,token,GameConfig.PLATFORM_DEFAULT_ID);
                            //cc.error("password:" + password);

                            var msg = new SocketBytes();
                            msg.writeUint(200);//账号登录
                            msg.writeUint(GameConfig.PLATFORM_DEFAULT_ID);
                            msg.writeString(account);
                            msg.writeString(token);
                            NetMgr.inst().send(msg);
                        },this);
                    }
                    else if(71216 == ret.err_code)
                    {
                        var value = ResMgr.inst().getString("denglu_78");
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                    }
                    else{
                        var value = ResMgr.inst().getString(ret.err_code);
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                    }
                }
            }, null, {"objs":null, "onAccountStatus":null, "owner":this}
        );
    },

    netGetError : function (cmd,data) {
        if(cmd == 0){
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            cc.log("@netGetError",data0,data1,data2);
            if(data0 == 200 && data1 == 0){
                //ModuleMgr.inst().openModule("GameLoginModule",{"ui":"loading","login":true});
                //startGameData.step = 6;
                //设置昵称
                ModuleMgr.inst().openModule("Presetting", {
                    "data": null,
                    "openSound": true,
                    "loginAccount": null,
                    "loginToken": null
                });
            }
            //账号名称设置
            if (data0 == 202 && data1 == 0) {
                ModuleMgr.inst().closeModule("Presetting", {"closeSound": false});
                ModuleMgr.inst().openModule("GameLoginModule", {"ui": "loading", "login": false});
                startGameData.step = 6;
            }
        }
    },

    //文本响应事件
    onTfInput: function (node, type) {
        //cc.log(cc.sys.platform+"sys"+cc.sys.os+(cc.sys.os=="Windows"));
        if(cc.sys.os=="Windows") return;//电脑调试return
        if (type == ccui.TextField.EVENT_ATTACH_WITH_IME) {
            cc.log("焦点定位到文本 可输入文本"+node.getString());
            ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
        }
        else if (type == ccui.TextField.EVENT_DETACH_WITH_IME) {
            //cc.log("焦点delete@@@@@@@@@@@@@@@@@@@@@%%%%%%%%%%%%%%");
            ModuleMgr.inst().closeModule("TextboxModule");
        }
        else if (type == ccui.TextField.EVENT_INSERT_TEXT) {
            //cc.log("文本事件：EVENT_INSERT_TEXT");
            //ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
            EventMgr.inst().dispatchEvent("show_text",node.getString());
        }
        else if (type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            //cc.log("文本事件：EVENT_DELETE_BACKWARD");
            //ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
            EventMgr.inst().dispatchEvent("show_text",node.getString());
        }

    }
});