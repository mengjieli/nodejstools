var ErrorModel = (function (_super) {
    __extends(ErrorModel, _super);

    function ErrorModel() {
        _super.call(this, "Error");

        /*mainData.netData.addListener("isConnect", function () {
            var msg = new SocketBytes();
            msg.writeUint(301);
            msg.writeInt(start.x);
            msg.writeInt(start.y);
            msg.writeUint(end.x - start.x);
            msg.writeUint(end.y - start.y);
            NetMgr.inst().send(msg);
        },null);*/
        NetMgr.inst().addEventListener(0, this.receiveErrorCode, this);//更新道具
    }

    var d = __define, c = ErrorModel;
    p = c.prototype;

    p.receiveErrorCode = function (cmd, data) {


        data.resetCMDData();
        var cmd = data.readUint();
        var errorCode = data.readInt();
        //trace("消息返回:", cmd, errorCode);
        if (errorCode < 0) {
            //trace("错误码","error" + (-errorCode),ResMgr.inst().getString("error" + (-errorCode)));
            var content = ResMgr.inst().getString("error" + (-errorCode));
            if (content == "" || content == null) {
                content = ResMgr.inst().getString("rrorTip") + ":" + errorCode;
            }
            ModuleMgr.inst().openModule("AlertPanel", {
                txt: content,
                type: 2,
                owner: this,
                okFun: function () {
                    cc.director.end();
                }
            });
        }
    }

    return ErrorModel;
})(ModelBase);