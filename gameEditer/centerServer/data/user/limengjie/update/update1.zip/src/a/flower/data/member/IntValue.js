var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var IntValue = (function (_super) {
        __extends(IntValue, _super);
        function IntValue(initValue) {
            if (initValue === void 0) { initValue = 0; }
            _super.call(this);
            this._value = 0;
            if (initValue) {
                initValue = +initValue & ~0;
                this._value = initValue;
            }
        }
        Object.defineProperty(IntValue.prototype, "value", {
            get: function () {
                return this._value;
            },
            set: function (val) {
                val = +val & ~0;
                if (this._value == val) {
                    return;
                }
                var old = this._value;
                this._value = val;
                if (!this._events) {
                    this._events = [];
                }
                var list = this._events;
                for (var i = 0, len = list.length; i < len; i++) {
                    if (list[i].del == false) {
                        var listener = list[i].listener;
                        var thisObj = list[i].thisObject;
                        if (list[i].once) {
                            list[i].listener = null;
                            list[i].thisObject = null;
                            list[i].del = true;
                        }
                        listener.call(thisObj, this._value, old);
                    }
                }
                for (i = 0; i < list.length; i++) {
                    if (list[i].del == true) {
                        list.splice(i, 1);
                        i--;
                    }
                }
            },
            enumerable: true,
            configurable: true
        });
        IntValue.prototype.once = function (listener, thisObject) {
            this._addListener(listener, thisObject, true);
        };
        IntValue.prototype.addListener = function (listener, thisObject) {
            this._addListener(listener, thisObject, false);
        };
        IntValue.prototype._addListener = function (listener, thisObject, once) {
            if (!this._events) {
                this._events = [];
            }
            var list = this._events;
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    return;
                }
            }
            list.push({ "listener": listener, "thisObject": thisObject, "once": once, "del": false });
        };
        IntValue.prototype.removeListener = function (listener, thisObject) {
            if (!this._events) {
                return;
            }
            var list = this._events;
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    list[i].listener = null;
                    list[i].thisObject = null;
                    list[i].del = true;
                    break;
                }
            }
        };
        IntValue.prototype.removeAllListener = function () {
            this._events = [];
        };
        IntValue.prototype.dispose = function () {
            this._events = null;
        };
        IntValue.create = function (initValue) {
            if (initValue === void 0) { initValue = null; }
            var value;
            if (flower.IntValue.pool.length) {
                value = flower.IntValue.pool.pop();
                value._events = [];
                value._value = +initValue & ~0;
            }
            else {
                value = new flower.IntValue(initValue);
            }
            return value;
        };
        IntValue.release = function (value) {
            value.dispose();
            flower.IntValue.pool.push(value);
        };
        return IntValue;
    })(flower.Value);
    flower.IntValue = IntValue;
})(flower || (flower = {}));
flower.IntValue.pool = new Array();
//# sourceMappingURL=IntValue.js.map