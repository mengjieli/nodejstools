var flower;
(function (flower) {
    var ExprAtrItem = (function () {
        function ExprAtrItem(type, val) {
            this.type = type;
            this.val = val;
        }
        ExprAtrItem.prototype.print = function () {
            if (this.type == "()") {
                return "(?)";
            }
            if (this.type == "string") {
                return this.val;
            }
            if (this.type == "id") {
                return this.val;
            }
            if (this.type == ".") {
                return "." + this.val;
            }
            if (this.type == "call") {
                return "(call?)";
            }
            return "[?" + this.type + ":" + this.val + "?]";
        };
        return ExprAtrItem;
    })();
    flower.ExprAtrItem = ExprAtrItem;
})(flower || (flower = {}));
//# sourceMappingURL=ExprAtrItem.js.map