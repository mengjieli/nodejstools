var GCTaskBase = (function () {

    function GCTaskBase(socket,cmd,taskId,msg) {
        this.socket = socket;
        this.cmd = cmd;
        this.bytes = new flower.VByteArray();
        this.bytes.writeUIntV(502);
        this.bytes.writeUIntV(taskId);
        this.doTask(cmd, msg, this.bytes);
    }

    var d = __define, c = GCTaskBase;
    p = c.prototype;

    /**
     * 执行任务
     * @param cmd 协议号
     * @param msg 从服务器接收的任务消息
     * @param bytes 返回给服务器的消息
     */
    p.doTask = function (cmd, msg, bytes) {
    }

    /**
     * 完成任务
     */
    p.completeTask = function() {
        if (this.bytes) {
            this.sendData(this.bytes);
        }
    }

    p.sendData = function (bytes) {
        this.socket.send(bytes);
    }

    return GCTaskBase;
})();