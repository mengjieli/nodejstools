/**
 * Created by Administrator on 2015/12/10.
 */


var ServerTimeData = DataBase.extend({

    _time:null,     //服务器时间
    _delay:0,       //本地与服务器之间的延时
    _interId:null,
    ctor:function()
    {
        this._super();
        this._interId = setInterval( this.update.bind( this ), 15000 );
    },

    init:function()
    {
        NetMgr.inst().addEventListener( 296, this.serverTimeCall, this );
        EventMgr.inst().addEventListener("serverTime", this.getServerTime, this );
    },

    destroy:function()
    {
        if(this._interId) clearInterval( this._interId )
    },

    update:function()
    {
        if (NetMgr.inst().isConnection() == true) {
            var msg = new SocketBytes();
            msg.writeUint(206);
            msg.writeString("abc");
            NetMgr.inst().send(msg);
        }
    },

    serverTimeCall:function( cmd, msg )
    {
        msg.resetCMDData();
        var str     = msg.readString();
        var time    = msg.readUint();
        this._time = time;
        var localityTime = (new Date()).getTime();
        this._delay = localityTime - this._time;
        //cc.log( this._delay );
        //cc.log( (new Date(time)).toString() );
    },

    getServerTime:function( e )
    {
        var dateTime = (new Date()).getTime();
        var t = dateTime - this._delay;
        return t;
    }

});