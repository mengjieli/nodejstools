/**
 * Created by Administrator on 2015/12/22/0022.
 */
var GuideBean = cc.Class.extend({
    _data:null,

    _idStep:null,
    _id:null,
    _step:null,
    _stepnum:null,
    _hand_x:null,
    _hand_y:null,
    _arrow_direction:null,
    _arrow_x:null,
    _arrow_y:null,
    _arrow_msg:null,
    _delaytime:null,
    _effect_name:null,
    _effect_x:null,
    _effect_y:null,
    _speak_name:null,
    _speak_msg:null,
    _dir_x:null,
    _dir_y:null,
    _dir_w:null,
    _dir_h:null,



    ctor:function(data)
    {
        //cc.log(data+"guidebean data"+data.idstep)
        this._data=data;
        this._idStep = data.idstep;
        var arrId=data.idstep.split("_");
        this._id = parseInt(arrId[0]);
        this._step = parseInt(arrId[1]);
        this._stepnum = parseInt(data.stepnum);
        this._hand_x = parseInt(data.hand_x);
        this._hand_y = parseInt(data.hand_y);
        this._arrow_direction = data.arrow_direction;
        this._arrow_x = parseInt(data.arrow_x);
        this._arrow_y = parseInt(data.arrow_y);
        this._arrow_msg = data.arrow_msg;
        this._delaytime = data.delaytime;
        this._effect_name = data.effect_name;
        this._effect_x = parseInt(data.effect_x);
        this._effect_y = parseInt(data.effect_y);
        this._speak_name=data.speak_name;
        this._speak_msg=data.speak_msg;


    },




});