var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var DisplayObject = (function (_super) {
        __extends(DisplayObject, _super);
        function DisplayObject() {
            _super.call(this);
            this._x = 0;
            this._y = 0;
            this._width = 0;
            this._height = 0;
            this._alpha = 1;
            this._parentAlpha = 1;
            this._visible = true;
            this._touchEnabled = true;
            this._mutiplyTouchEnabled = true;
            this._touchX = 0;
            this._touchY = 0;
            this._nestLevel = 0;
            this._id = flower.DisplayObject.id++;
            this._displayFlags = 0;
            this._DisplayObject = { 0: 1, 1: 1, 2: 0, 3: 0, 4: 0, 5: "" };
        }
        DisplayObject.prototype.$setFlag = function (pos, value) {
            if (value) {
                this._displayFlags |= pos;
            }
            else {
                this._displayFlags &= ~pos;
            }
        };
        DisplayObject.prototype.$addFlag = function (pos) {
            this._displayFlags |= pos;
        };
        DisplayObject.prototype.$removeFlag = function (pos) {
            this._displayFlags &= ~pos;
        };
        DisplayObject.prototype.$getFlag = function (pos) {
            return this._displayFlags & pos ? true : false;
        };
        DisplayObject.prototype.$setParent = function (parent) {
            var p = this._parent;
            this._parent = parent;
            if (parent) {
                this._parent["$nativeShow"].addChild(this._show);
            }
            else {
                p["$nativeShow"].removeChild(this._show);
            }
        };
        DisplayObject.prototype.$onAddToStage = function (stage, nestLevel) {
            this._stage = stage;
            this._nestLevel = nestLevel;
            flower.Sprite._EVENT_ADD_TO_STAGE_LIST.push(this);
        };
        DisplayObject.prototype.$onRemoveFromStage = function () {
            this._nestLevel = 0;
            flower.Sprite._EVENT_REMOVE_FROM_STAGE_LIST.push(this);
        };
        DisplayObject.prototype._setX = function (val) {
            this._x = val;
            var p = flower.DisplayObject.showProperty.x;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._x]);
            }
            else {
                this._show[p.atr] = this._x;
            }
        };
        DisplayObject.prototype._setY = function (val) {
            this._y = val;
            var p = flower.DisplayObject.showProperty.y;
            if (p.func) {
                this._show[p.func].apply(this._show, [System.receverY ? -this.y : this._y]);
            }
            else {
                this._show[p.atr] = this._y;
            }
        };
        DisplayObject.prototype._setScaleX = function (val) {
            this._DisplayObject[0] = val;
            var p = flower.DisplayObject.showProperty.scaleX;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._DisplayObject[0]]);
            }
            else {
                this._show[p.atr] = this._DisplayObject[0];
            }
        };
        DisplayObject.prototype._setScaleY = function (val) {
            this._DisplayObject[1] = val;
            var p = flower.DisplayObject.showProperty.scaleY;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._DisplayObject[1]]);
            }
            else {
                this._show[p.atr] = this._DisplayObject[1];
            }
        };
        DisplayObject.prototype._setRotation = function (val) {
            this._DisplayObject[4] = val;
            var p = flower.DisplayObject.showProperty.rotation;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._DisplayObject[4] * p.scale]);
            }
            else {
                this._show[p.atr] = this._DisplayObject[4] * p.scale;
            }
        };
        DisplayObject.prototype._setAlpha = function (val) {
            this._alpha = val;
            this._alphaChange();
        };
        DisplayObject.prototype._alphaChange = function () {
            var p = flower.DisplayObject.showProperty.alpha;
            if (p.func) {
                this._show[p.func].apply(this._show, [this._alpha * this._parentAlpha * p.scale]);
            }
            else {
                this._show[p.atr] = this._alpha * this._parentAlpha * p.scale;
            }
        };
        DisplayObject.prototype._setParentAlpha = function (val) {
            this._parentAlpha = val;
            this._alphaChange();
        };
        DisplayObject.prototype._setWidth = function (val) {
            this._width = val;
        };
        DisplayObject.prototype._setHeight = function (val) {
            this._height = val;
        };
        DisplayObject.prototype.$isMouseTarget = function (matrix, mutiply) {
            if (this.touchEnabled == false || this._visible == false)
                return false;
            matrix.save();
            matrix.translate(-this._x, -this._y);
            if (this.rotation)
                matrix.rotate(-this.radian);
            if (this.scaleX != 1 || this.scaleY != 1)
                matrix.scale(1 / this.scaleX, 1 / this.scaleY);
            this._touchX = matrix.tx;
            this._touchY = matrix.ty;
            if (this._touchX >= 0 && this._touchY >= 0 && this._touchX < this._width && this._touchY < this._height) {
                return true;
            }
            matrix.restore();
            return false;
        };
        DisplayObject.prototype.$getSize = function () {
        };
        DisplayObject.prototype.$onFrameEnd = function () {
        };
        DisplayObject.prototype.dispose = function () {
            if (this.parent) {
                this.parent.removeChild(this);
            }
            _super.prototype.dispose.call(this);
            this.$setFlag(1, true);
        };
        Object.defineProperty(DisplayObject.prototype, "id", {
            get: function () {
                return this._id;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "name", {
            get: function () {
                return this._DisplayObject[5];
            },
            set: function (value) {
                this._DisplayObject[5] = value;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "x", {
            get: function () {
                return this._x;
            },
            set: function (val) {
                val = +val || 0;
                if (this._x == val) {
                    return;
                }
                this._setX(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "y", {
            get: function () {
                return this._y;
            },
            set: function (val) {
                val = +val || 0;
                if (this._y == val) {
                    return;
                }
                this._setY(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "width", {
            get: function () {
                if (this.$getFlag(1)) {
                    this.$getSize();
                }
                return this._width;
            },
            set: function (val) {
                val = +val & ~0;
                if (this._width == val) {
                    return;
                }
                this._setWidth(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "height", {
            get: function () {
                if (this.$getFlag(1)) {
                    this.$getSize();
                }
                return this._height;
            },
            set: function (val) {
                val = +val & ~0;
                if (this._height == val) {
                    return;
                }
                this._setHeight(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "scaleX", {
            get: function () {
                return this._DisplayObject[0];
            },
            set: function (val) {
                val = +val || 0;
                if (this._DisplayObject[0] == val) {
                    return;
                }
                this._setScaleX(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "scaleY", {
            get: function () {
                return this._DisplayObject[1];
            },
            set: function (val) {
                val = +val || 0;
                if (this._DisplayObject[1] == val) {
                    return;
                }
                this._setScaleY(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "rotation", {
            get: function () {
                return this._DisplayObject[4];
            },
            set: function (val) {
                val = +val || 0;
                this._setRotation(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "radian", {
            get: function () {
                return this._DisplayObject[4] * Math.PI / 180;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "alpha", {
            get: function () {
                return this._alpha;
            },
            set: function (val) {
                val = +val || 0;
                if (val < 0) {
                    val = 0;
                }
                if (val > 1) {
                    val = 1;
                }
                this._setAlpha(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "$parentAlpha", {
            get: function () {
                return this._parentAlpha;
            },
            set: function (val) {
                this._setParentAlpha(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "visible", {
            get: function () {
                return this._visible;
            },
            set: function (val) {
                this._visible = !!val;
                var p = flower.DisplayObject.showProperty.visible;
                if (p.func) {
                    this._show[p.func].apply(this._show, [this._visible]);
                }
                else {
                    this._show[p.atr] = this._visible;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "touchEnabled", {
            get: function () {
                return this._touchEnabled;
            },
            set: function (val) {
                this._touchEnabled = !!val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "mutiplyTouchEnabled", {
            get: function () {
                return this._mutiplyTouchEnabled;
            },
            set: function (val) {
                this._mutiplyTouchEnabled = !!val;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "touchX", {
            get: function () {
                return this._touchX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "touchY", {
            get: function () {
                return this._touchY;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "parent", {
            get: function () {
                return this._parent;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "stage", {
            get: function () {
                return this._stage;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "disposeFlag", {
            get: function () {
                return this.$getFlag(1);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(DisplayObject.prototype, "$nativeShow", {
            get: function () {
                return this._show;
            },
            enumerable: true,
            configurable: true
        });
        return DisplayObject;
    })(flower.EventDispatcher);
    flower.DisplayObject = DisplayObject;
})(flower || (flower = {}));
flower.DisplayObject.showProperty = System.DisplayObject;
flower.DisplayObject.id = 0;
//# sourceMappingURL=DisplayObject.js.map