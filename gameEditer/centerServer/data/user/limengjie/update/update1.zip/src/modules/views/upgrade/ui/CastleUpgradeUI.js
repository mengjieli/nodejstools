/**
 * Created by Administrator on 2015/11/09/0009.
 */
var CastleUpgradeUI=cc.Node.extend({
    _ui:null,
    _id:0,
    _blockId:null,
    _info:null,

    _demandItems:null,
    _resourceItems:null,

    _resItemDict:null,

    remainTime:0,

    ctor:function( id, blockId )
    {
        this._super();
        this._id = id;
        this._blockId = blockId;

        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        if( data )
        {
            list = data.getNetBlock( );
        }

        if( list == null || list[this._blockId] == null )
        {
            cc.error("找不到地块数据");
            return;
        }

        this._info = list[this._blockId];

        this.initUI();

        EventMgr.inst().addEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeCall, this );
        EventMgr.inst().addEventListener( "using_token", this.usingCallback,this );
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
    },

    onExit:function()
    {
        this._super();
        EventMgr.inst().removeEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeCall, this );
        EventMgr.inst().removeEventListener( "using_token", this.usingCallback,this );
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
    },

    initUI:function()
    {
        this._ui = ccs.load("res/images/ui/castleUpgrade/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        //适配
        var Image_26 = this._ui.getChildByName("Image_26");
        posAutoLayout(Image_26,0.5);
        sizeAutoLayout(Image_26,0.5);

        var Image_21 = this._ui.getChildByName("Image_21");
        posAutoLayout(Image_21,0.5);
        sizeAutoLayout(Image_21,0.5);

        var Image_26_0 = this._ui.getChildByName("Image_26_0");
        sizeAutoLayout(Image_26_0,0.5);

        var Image_3_1 = this._ui.getChildByName("Image_3_1");
        sizeAutoLayout(Image_3_1,0.5);
        posAutoLayout(Image_3_1,0.5);

        var Image_3_0_0 = this._ui.getChildByName("Image_3_0_0");
        posAutoLayout(Image_3_0_0,0.5);

        var Image_3 = this._ui.getChildByName("Image_3");
        posAutoLayout(Image_3);
        sizeAutoLayout(Image_3,0.5);

        var Image_3_0 = this._ui.getChildByName("Image_3_0");
        posAutoLayout(Image_3_0);

        var Image_21_0 = this._ui.getChildByName("Image_21_0");
        sizeAutoLayout(Image_21_0,0.5);

        //上面的滚动层
        var control = this._ui.getChildByName("Image_1");
        posAutoLayout(control);

        control = this._ui.getChildByName("Text_23");
        posAutoLayout(control);

        control = this._ui.getChildByName("ScrollView_1");
        sizeAutoLayout(control,0.5);
        posAutoLayout(control,0.5);

        //下面的滚动层
        control = this._ui.getChildByName("Image_1_0");
        posAutoLayout(control,0.5);
        control = this._ui.getChildByName("Text_24");
        posAutoLayout(control,0.5);

        control = this._ui.getChildByName("ScrollView_2");
        sizeAutoLayout(control,0.5);

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        var txt = this._ui.getChildByName("Text_23");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("shengji_1") );

        var scroll = this._ui.getChildByName("ScrollView_1");
        scroll.removeAllChildren();
        scroll.addEventListener(this.scrollOneCall, this );

        scroll = this._ui.getChildByName("ScrollView_2");
        scroll.addEventListener(this.scrollTwoCall, this );

        var item0 = this._ui.getChildByName("Panel_0");
        item0.setVisible( false );

        this._demandItems = [];
        this._resourceItems = [];

        this.updateToUI();
    },


    updateToUI:function()
    {
        this.setDemand();
        this.setResource();
    },

    setDemand:function()
    {
        var next = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",this._info._building_level + 1 ]);
        if(next==null){
            this.setVoidItem();
            return;
        }

        this._resItemDict = {};
        this._demandItems = [];
        this.updateDemandAccelerate();
        this.updateDemandObjectConfig();
        this.updateDemandConfig();
        this.updateDemandScrollItemPos(0);
    },

    setResource:function()
    {
        this._resourceItems = [];
        this.updateResourceConfig();
        this.updateDemandScrollItemPos(1);
    },

    //当建筑升级之后刷新
    updateDemandObjectData:function()
    {
        for( var i in this._demandItems )
        {
            var item = this._demandItems[i];
            if( item.info && item.info.itemType == 1 )
            {
                this.setDemandObjectItem( item );
            }
        }
    },

    updateDemandConfigData:function()
    {
        for( var i in this._demandItems )
        {
            var item = this._demandItems[i];
            if( item.info && item.info.itemType == 3 )
            {
                this.setDemandConfigItem( item );
            }
        }
    },



    //设置升级对象
    updateDemandAccelerate:function()
    {
        var data = ModuleMgr.inst().getData("CastleModule");
        if( data == null ) return;
        var list = data.getNetBlockByState( CastleData.STATE_UPGRADE );
        if( list.length <= 0 ) return;
        var len = list.length;
        for( var i=0; i<len; i++ )
        {
            this.addDemandAccelerateItem( list[i], i );
        }
    },

    addDemandAccelerateItem:function( info, i )
    {
        var item0 = this._ui.getChildByName("Panel_0");
        item0.setVisible( false );
        var scroll = this._ui.getChildByName("ScrollView_1");

        var it = item0.clone();
        scroll.addChild( it );
        this._demandItems.splice( i, 0, it );
        it.setVisible(true);

        it.info = {};
        it.info.blockId = info._index;
        it.info.configId = info._building_id;
        it.info.itemType = 0;

        this._resBlockIndex = it.info.blockId;

        var itemUI = it.getChildByName("ico");
        itemUI.ignoreContentAdaptWithSize( true );
        itemUI.loadTexture( "gy_shalou.png" , ccui.Widget.PLIST_TEXTURE );
        itemUI = it.getChildByName("text0");
        itemUI.ignoreContentAdaptWithSize(true);
        itemUI.setTextColor( cc.color(255,0,0) );
        itemUI.setString( ResMgr.inst().getString( info._building_id + "0" ) + ResMgr.inst().getString("xiangqing_18") + " " + StringUtils.formatTimer( info._state_remain ) );
        itemUI = it.getChildByName("zt");
        itemUI = it.getChildByName("Button");
        itemUI.info = it.info;
        itemUI.addTouchEventListener( this.speedCall, this );
        itemUI = it.getChildByName("Button").getChildByName("Text");
        itemUI.ignoreContentAdaptWithSize(true);
        itemUI.enableOutline(cc.color(0,0,0,255));
        itemUI.setString( ResMgr.inst().getString("xiangqing_16") );
    },

    //设置建筑需求Item
    updateDemandObjectConfig:function()
    {
        var data = ModuleMgr.inst().getData("CastleModule");
        if( data == null ) return;
        var list = data.getNetBlockByState( CastleData.STATE_UPGRADE );
        var len = list.length;

        //var configData = ResMgr.inst().getJSON( "City_Tower",this._info._building_level, true );
        var configData = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",this._info._building_level + 1 ])
        if( configData == null ) return;

        var item0 = this._ui.getChildByName("Panel_0");
        item0.setVisible( false );
        var scroll = this._ui.getChildByName("ScrollView_1");

        var it = item0.clone();
        scroll.addChild( it );
        it.setVisible(true);
        this._demandItems.splice( len, 0, it );

        var configObj = {};
        var obj = configData.need;
        if( typeof obj == "string" )
        {
            obj = JSON.parse(obj);
        }
        for( var j in obj )
        {
            configObj.id = j;
            configObj.value = obj[j];
        }

        var list = data.getNetBlockByBuildingId( configObj.id );
        if( list.length <= 0 ) return;

        it.info = {};
        it.info.blockId = list[0]._index;
        it.info.configId = configObj.id;
        it.info.itemType = 1;
        it.info.value = configObj.value;

        var itemUI = it.getChildByName("ico");
        itemUI.ignoreContentAdaptWithSize(true);
        itemUI.loadTexture(ResMgr.inst().getIcoPath( 1104001 ) );
        itemUI = it.getChildByName("text0");
        itemUI.ignoreContentAdaptWithSize(true);
        itemUI.setString( ResMgr.inst().getString( configObj.id + "0") + " " + ResMgr.inst().getString("xiangqing_2") + " " + configObj.value );
        itemUI = it.getChildByName("Button");
        itemUI.info = it.info;
        itemUI.addTouchEventListener( this.gotoCall, this );
        itemUI = it.getChildByName("Button").getChildByName("Text");
        itemUI.ignoreContentAdaptWithSize(true);
        itemUI.enableOutline(cc.color(0,0,0,255));
        itemUI.setString( ResMgr.inst().getString("xiangqing_17") );
        this.setDemandObjectItem( it );

    },

    //跟新需求建筑状态
    setDemandObjectItem:function( it )
    {
        var itemUI = it.getChildByName("zt");
        var arr = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId( it.info.configId );
        var level = 0;
        for( var i in arr )
        {
            var item = arr[i];
            level = Math.max( level, item._building_level );
        }
        itemUI.loadTexture( level >= it.info.value ? "xueyuan_dui.png" : "xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE );
        itemUI = it.getChildByName("text0");
        itemUI.setTextColor( level >= it.info.value ? cc.color(255,255,255) : cc.color(255,0,0) );
        itemUI = it.getChildByName("Button");
        itemUI.setVisible( level >= it.info.value ? false : true );
    },


    //设置资源需求Item
    updateDemandConfig:function()
    {
        //var configData = ResMgr.inst().getJSON( "City_Tower",this._info._building_level, true );
        var configData = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",this._info._building_level + 1 ])
        if( configData == null ) return;

        var item0 = this._ui.getChildByName("Panel_0");
        item0.setVisible( false );
        var scroll = this._ui.getChildByName("ScrollView_1");

        var objList = configData.need_resource;
        if( typeof objList == "string" )
        {
            objList = JSON.parse(objList);
        }
        var dataList = [];
        for( var j in objList )
        {
            var oo = {};
            oo.id = j;
            oo.value = objList[j];
            dataList.push( oo );
        }
        var len = dataList.length
        for( var i = 0; i<len; i++ )
        {
            var it = item0.clone();
            scroll.addChild( it );
            it.setVisible(true);
            this._demandItems.push( it );

            var configObj = dataList[i];
            it.info = {};
            it.info.blockId = 0;
            it.info.configId = configObj.id;
            it.info.itemType = 2;
            it.info.value = configObj.value;
            this.setDemandConfigItem( it );

            this._resItemDict[configObj.id] = it;

            var forbattle = BattleRes.indexOf(configObj.id)==-1?false:true;

            var itemUI = it.getChildByName("ico");
            itemUI.ignoreContentAdaptWithSize( true );
            itemUI.loadTexture(ResMgr.inst().getIcoPath( it.info.configId ) );
            itemUI = it.getChildByName("text0");
            itemUI.setString( it.info.value );
            itemUI = it.getChildByName("Button");
            itemUI.addTouchEventListener( this.demandConfigButCall, this );
            itemUI.setVisible(!forbattle);
            itemUI.info = it.info;
            itemUI = it.getChildByName("Button").getChildByName("Text");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( ResMgr.inst().getString("xiangqing_15") );
            //itemUI.enableOutline(cc.color(0,0,0,255));
            BorderText.replace(itemUI);

            var ico_0_0 = it.getChildByName("ico_0_0");
            ico_0_0.setVisible(!forbattle);
            var ico_1 = it.getChildByName("ico_1");
            ico_1.ignoreContentAdaptWithSize(true);
            ico_1.setVisible(!forbattle);
            ico_1.loadTexture(this.getIconUrl(configObj.id));
            ico_1.setScale(0.2);
            var text0_0 = it.getChildByName("text0_0");
            text0_0.ignoreContentAdaptWithSize(true);
            text0_0.setVisible(!forbattle);
            text0_0.setString(0);
        }
    },

    //跟新资源状态
    setDemandConfigItem:function( it )
    {
        var itemUI = it.getChildByName("zt");
        var num = ModuleMgr.inst().getData("CastleModule").getNetResource( null, it.info.configId );
        itemUI.loadTexture( num >= it.info.value ? "xueyuan_dui.png" : "xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE );
        itemUI = it.getChildByName("text0");
        itemUI.setTextColor( num >= it.info.value ? cc.color(255,255,255) : cc.color(255,0,0) );
        //itemUI = it.getChildByName("Button");
        //itemUI.setVisible( /*num >= it.info.value ? false : true*/false );
    },

    //跟新资源需求
    updateResourceConfig:function()
    {
        //var current = ResMgr.inst().getJSON( "City_Tower",this._info._building_level, true );
        //var next =  ResMgr.inst().getJSON( "City_Tower",this._info._building_level + 1, true );
        var current = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",this._info._building_level ])
        var next = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",this._info._building_level + 1 ]);
        if( current == null ) return;

        var currentList = [];
        var itemData = {};
        itemData.id = 0;
        itemData.value = current.territory_number;
        itemData.max = next == null ? "-" : (next.territory_number);
        currentList.push( itemData );

        var txt = this._ui.getChildByName("Text_24");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( (next == null ? "Max" :ResMgr.inst().getString("shengji_2") + " " + (this._info._building_level + 1)) );

        var len = currentList.length;
        var item0 = this._ui.getChildByName("Panel_1");
        item0.setVisible(false);
        var scroll = this._ui.getChildByName("ScrollView_2");
        scroll.removeAllChildren();

        for( var i = 0; i<len; i++ )
        {
            var it = item0.clone();
            scroll.addChild( it );
            it.setVisible(true);
            this._resourceItems.push( it );

            var d = currentList[i];
            var itemUI = it.getChildByName("ico");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.loadTexture( "res/images/ui/castleUpgrade/jt_lingdi.png" );
            itemUI = it.getChildByName("text0");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( d.value + "" );
            itemUI = it.getChildByName("Text");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( d.max+ ""  );
        }
    },


    //更新滚动层里的item坐标
    updateDemandScrollItemPos:function( n )
    {
        var item0 = null;
        var scroll = null;
        var list = null;
        if( n == 0 )
        {
            list = this._demandItems;
            item0 = this._ui.getChildByName("Panel_0");
            scroll = this._ui.getChildByName("ScrollView_1");
        }
        else
        {
            list = this._resourceItems;
            item0 = this._ui.getChildByName("Panel_1");
            scroll = this._ui.getChildByName("ScrollView_2");
        }

        var gap = 3;
        var len  = list.length;
        var itemH = item0.getContentSize().height;
        var h = len * itemH+(len+1)*gap;
        var size = scroll.getContentSize();
        size.height = h > size.height ? h : size.height;
        for( var i =0; i<len; i++ )
        {
            var it = list[i];
            it.setPosition( 0, (size.height - itemH-gap) - i*(itemH+gap) );
        }
        scroll.setInnerContainerSize( size );
        scroll.jumpToTop();
    },

    //更新滚动层的上下箭头
    updateScroll:function( n )
    {
        var scroll = null;
        var up = null;
        var down = null;

        if( n == 0 )
        {
            scroll = this._ui.getChildByName("ScrollView_1");
            up = this._ui.getChildByName("up0");
            down = this._ui.getChildByName("down0");
        }
        else
        {
            scroll = this._ui.getChildByName("ScrollView_2");
            up = this._ui.getChildByName("up1");
            down = this._ui.getChildByName("down1");
        }

        var scrollSize = scroll.getContentSize();
        var size = scroll.getInnerContainerSize();

        var inner = scroll.getInnerContainer();
        var pos = inner.getPosition();

        up.setVisible(false);
        down.setVisible( false );

        if( size.height <= scrollSize.height )
        {
            up.setVisible( false );
            down.setVisible( false );
        }
        else
        {
            if( pos.y >= 0 && size.height <= scrollSize.height )
            {
                up.setVisible( false );
            }
            else
            {
                up.setVisible( pos.y >= 0 ? false : true );
            }

            var endY = scrollSize.height - size.height;

            down.setVisible( pos.y <= endY ? false : true );
        }

    },

    scrollOneCall:function( node, type )
    {
        if( type ==  ccui.ScrollView.EVENT_SCROLLING )
        {
            //this.updateScroll(0);
        }
    },

    scrollTwoCall:function( node, type )
    {
        if( type ==  ccui.ScrollView.EVENT_SCROLLING )
        {
            //this.updateScroll(1);
        }
    },


    //加速
    speedCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().openModule("AccelerateModule", { id:node.info.configId, blockId:node.info.blockId, type:3 ,time:this.remainTime} );
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    //跳转
    gotoCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            //.inst().openModule( "UpgradeModule" , { id:node.info.configId ,blockId:node.info.blockId } );
            ModuleMgr.inst().closeModule( "UpgradeModule" );
            EventMgr.inst().dispatchEvent( CastleEvent.MOVETO_BUILDING, node.info.configId );
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    //需求
    demandConfigButCall:function( node ,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().openModule("TokenModule",{"resid":node.info.configId,"resnum":node.info.value});
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    upgradeCall:function( event, id )
    {
        for( var i=0; i<this._demandItems.length; i++ )
        {
            var item = this._demandItems[i];
            if( item.info && item.info.itemType == 0 && item.info.blockId == id )
            {
                item.removeFromParent();
                this._demandItems.splice(i,1);
            }
        }
        this.updateDemandScrollItemPos(0);

        if( id == this._blockId )
        {
            this.setResource();
        }

        this.updateDemandObjectData();
    },

    setVoidItem: function () {
        var gap = 3;
        var len  = 4;
        var item0 = this._ui.getChildByName("Panel_0");
        var itemH = item0.getContentSize().height;
        var h = len * itemH+(len+1)*gap;
        var scroll = this._ui.getChildByName("ScrollView_1");
        var size = scroll.getContentSize();
        size.height = h > size.height ? h : size.height;
        for( var i =0; i<len; i++ )
        {
            var it = item0.clone();
            it.setVisible(true);
            scroll.addChild(it);
            it.setPosition( 0, (size.height - itemH-gap) - i*(itemH+gap) );

            var ico_0 = it.getChildByName('ico_0');
            ico_0.setVisible(false);
            var ico = it.getChildByName('ico');
            ico.setVisible(false);
            var text0 = it.getChildByName('text0');
            text0.setVisible(false);
            var zt = it.getChildByName('zt');
            zt.setVisible(false);
            var Button = it.getChildByName('Button');
            Button.setVisible(false);
        }
        scroll.setInnerContainerSize( size );
        scroll.jumpToTop();
    },

    usingCallback: function (event, id, counts,exinfo) {
        if(exinfo<0) exinfo = 0;
        var resnum = this._resItemDict[id].getChildByName("text0");
        resnum.setString(exinfo);

        var tokennum = this._resItemDict[id].getChildByName("text0_0");
        tokennum.setString(counts);

        var rescheck = this._resItemDict[id].getChildByName("zt");
        //刷新状态
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
        if(parseInt(exinfo) > parseInt(resData[id])){
            resnum.setTextColor(cc.color(212,87,87,255));
            rescheck.loadTexture("xueyuan_cuo.png",ccui.Widget.PLIST_TEXTURE);
        }
        else{
            resnum.setTextColor(cc.color(255,255,255,255));
            rescheck.loadTexture("xueyuan_dui.png",ccui.Widget.PLIST_TEXTURE);
        }
    },

    getIconUrl: function (resid) {
        var url = ResMgr.inst()._icoPath;
        switch (parseInt(resid)){
            case 1101001:
                url += "11012010.png";
                break;
            case 1101002:
                url += "11012020.png";
                break;
            case 1101003:
                url += "11012030.png";
                break;
        }
        return url;
    },

    netUpdateTime: function (event,data) {
        if(data._index==this._resBlockIndex){
            var remain = data._state_remain;
            this.remainTime = remain;
        }
    }

});