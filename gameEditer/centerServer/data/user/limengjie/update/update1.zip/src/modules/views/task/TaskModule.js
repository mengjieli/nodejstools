/**
 * Created by admin on 2016/2/4.
 */
var TaskModule = ModuleBase.extend({
    _ui: null,

    _size:null,               //size
    _mainTitle: null,          //主线任务标题
    _mainIcon: null,          //主线任务图标
    _mainBg: null,          //主线任务点击背景
    _mainPercent:null,         //主线任务进度
    _mainPercentInfo:null,         //主线任务描述
    _mainTfOver:null,         //主线任务结束文字
    _mainSelect:null,         //主线任务选中图

    _rewardPanel:null,       //奖励面板
    _rewardBt:null,       //奖励领取按钮
    _ruleBt:null,           //日常规则  ModuleMgr.inst().openModule("AlertCostModule",{"text":str,"func": this.buyItem});

    _msgScroll: null,      //滚动条

    _arrTaskReward:null,//奖励列表
    _arrTaskNode: null,//每日任务列表
    _taskData: null,//聊天数据

    _isTest: false,//测试用true
    _testLayer: null,//测试按钮层

    ctor: function () {
        this._super();
    },
    initUI: function () {
        EventMgr.inst().addEventListener(TaskEvent.TASK_UPDATE_TASK, this.updateTask, this);
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.getReward, this);

        //适配
        var sc = 1 / GameMgr.inst().scaleX;
        var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down = down * sc;
        cc.log(down + "#################down  sc$$$$$$$$$$$ " + sc);

        this._taskData = ModuleMgr.inst().getData("TaskModule");

        this._arrTaskNode = [];
        this._arrTaskReward = [];
        this._ui = ccs.load("res/images/ui/task/Layer.json", "res/images/ui/").node;
        this.addChild(this._ui);
        this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("item").setVisible(false);//
        //主线任务
        this._mainTitle=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("tf_title");

        this._mainIcon=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("list_icon");//.getChildByName("img_icon");
        this._mainBg=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("up_bg");
        this._mainBg.addTouchEventListener(this.selectMain, this);
        this._mainPercent=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("percent");
        this._mainPercentInfo=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("tf_task_name");
        this._mainTfOver=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("tf_task_over");
        this._mainSelect=this._ui.getChildByName("Panel_2").getChildByName("Panel_1").getChildByName("img_main").getChildByName("bg_unselected");

        this._ruleBt=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("bt_wenhao");
        this._ruleBt.addTouchEventListener(this.onRule, this);

        this._rewardPanel=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info");
        this._rewardPanel.getChildByName("list_icon_0").setVisible(false);//
        this._rewardBt=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("bt_get");
        this._rewardBt.addTouchEventListener(this.onReward, this);

        this._msgScroll=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("scroll_1");
        //初始化状态等

        //this.showMainTask();
        //this.showDailyTask();
        //适配调整
        var control=this._ui.getChildByName("Panel_2")
        control.height+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_3");
        control.height+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_3").getChildByName("Image_4");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_1");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5");
        control.height+=down;
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list");
        control.height+=down;
        control.y-=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("bottom_di");
        control.height+=down;
        //control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("up_di");
        control.y+=down;
        this._ruleBt.y+=down;
        //var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("bt_wenhao");
        //control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("tf_title");
        control.y+=down;
        this._msgScroll.height+=down;
        this._msgScroll.y-=down;

        //var scrollsize = this._msgScroll.getContentSize();
        //scrollsize.height += down;
        //this._msgScroll.setContentSize(scrollsize);

        //control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info");
        control.height+=down;
        control.y-=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("bg_taskinfo");
        control.height+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("up_di");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("tf_taskname");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("tf_taskinfo");
        control.y+=down;
        //var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("img_infobg");
        //control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("tf_taskinfo_0");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("tf_taskreward");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("img_rewardbg");
        control.y+=down;
        var control=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("img_rewardrect");
        control.y+=down;
        this._rewardBt.y+=down;
        if(this._rewardBt.y<10) {
            this._rewardBt.y=10;
            this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("img_rewardbg").y=this._rewardBt.y+80;
            this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("img_rewardrect").y=this._rewardBt.y+79;
            this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_info").getChildByName("tf_taskreward").y=this._rewardBt.y+240;
        }

        this._size = cc.director.getVisibleSize();
        this._ui.setContentSize(this._size);
        ccui.helper.doLayout(this._ui);
    },
    show:function( data )
    {
        cc.log(" 打开UI  发送请求");
        this._mainTitle.setString(ResMgr.inst().getString("task_2"));
        this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("Image_list").getChildByName("tf_title").setString(ResMgr.inst().getString("task_3"));
        this._rewardPanel.getChildByName("tf_taskname").setString("");
        this._rewardPanel.getChildByName("tf_taskinfo").setString(ResMgr.inst().getString("task_4"));
        this._rewardPanel.getChildByName("tf_taskreward").setString(ResMgr.inst().getString("task_5"));
        this._rewardPanel.getChildByName("tf_taskinfo_0").setString("");
        this._mainTfOver.setString(ResMgr.inst().getString("task_6"));
        this._rewardBt.setTouchEnabled(false);
        this._rewardBt.setBright(false);

        var msg = new SocketBytes();
        msg.writeUint(TaskNetEvent.SEND_TASK);
        NetMgr.inst().send(msg);
    },
    updateTask:function(type,taskType){
        if(taskType==1) {
            this.showMainTask();
            if(!this._rewardBt.taskId||this._rewardBt.taskType==1)  {
                this._mainSelect.setVisible(false);
                this.showAward(1,this._mainBg.taskId,this._mainBg.rewardList,this._mainBg.percent);
            }
        }
        else  this.showDailyTask(this._rewardBt.taskId,this._rewardBt.taskType);
    },

    //任务内容显示
    showMainTask:function(){
        cc.log(mainData.taskDataList.length+"显示更新 主线任务");

        var mainTask=mainData.taskDataList.getItem("taskType",1);
        var taskList = modelMgr.call("Table","getTableList",["task"]);
        var mainTXT;
        for(var i in taskList) {
            if(taskList[i].task_id==mainTask.taskId){
                mainTXT=taskList[i];
                break;
            }
        }
        if(!mainTXT) {
            cc.error("主线任务找不到"+mainTask.taskId);
            return;
        }
        cc.log(mainTask.taskInfoList.length+"mainTask.taskInfoList.length"+mainTask.taskId);
        cc.log("mainTXT.task_need"+mainTXT.task_need);
        cc.log("mainTXT.task_reward"+mainTXT.task_reward);
        //for(var needKey in mainTXT.task_need){
        //    cc.log(mainTXT.task_need[needKey]+"needKey"+needKey);
        //}
        //进度
        var progressList=[];
        var temp = mainTXT.task_need;
        var tempjson = eval("(" + temp + ")");
        var obtain_item = {};
        for (var i in tempjson) {
            obtain_item.taskId = i;
            obtain_item.counts = tempjson[i];
            //cc.log(obtain_item.taskId+"id count"+obtain_item.counts);
            //cc.log(i+"iiii"+obtain_item.counts[1]);
            progressList.push(obtain_item);
        }
        //奖励
        var rewardList=[];
        var temp1 = mainTXT.task_reward;
        var tempjson1 = eval("(" + temp1 + ")");
        var obtain_item1 = {};
        for (var i in tempjson1) {
            obtain_item1.itemId = i;
            obtain_item1.counts = tempjson1[i];
            //cc.log(obtain_item.taskId+"id count"+obtain_item.counts);
            rewardList.push(obtain_item1);
        }

        this._mainPercent.getChildByName("tf_percent").setString( (mainTask.taskInfoList.length==0?"0":mainTask.taskInfoList[0].num)+"/"+parseInt(mainTXT.task_type==1?obtain_item.counts[1]:obtain_item.counts[0]));//task_type 1  数组有两位特殊处理  其它数组就一位
        var percent=parseInt(mainTask.taskInfoList.length==0?0:mainTask.taskInfoList[0].num)/parseInt(mainTXT.task_type==1?obtain_item.counts[1]:obtain_item.counts[0]);
        if(percent>1) percent=1;

        this._mainBg.taskId=mainTask.taskId;//记录点击id
        this._mainBg.rewardList=rewardList;//记录rewardList
        this._mainBg.progressList=progressList;//记录进度
        this._mainBg.percent=percent;//记录是否完成

        this._mainPercent.getChildByName("ico1_0").setVisible(percent!=0);
        this._mainPercent.getChildByName("ico1_0").width=this._mainPercent.getChildByName("ico1_1").width*percent;//0.5
        cc.log(this._mainPercent.getChildByName("ico1_0").width+"percent"+percent);
        //this._mainPercentInfo.setString("啊啊啊啊啊啊啊啊啊啊啊啊");
        this._mainPercentInfo.setString(ResMgr.inst().getString(String(mainTask.taskId+"0")));//mainTask.taskId+"0"
        var isEnd=false;
        this._mainTfOver.setVisible(isEnd);
        this._mainPercent.setVisible(!isEnd);
        this._mainPercentInfo.setVisible(!isEnd);
        this._mainIcon.setVisible(!isEnd);
        this._mainIcon.ignoreContentAdaptWithSize(true);
        this._mainIcon.getChildByName("img_icon").loadTexture(ResMgr.inst()._icoPath+"renwu_"+mainTXT.task_type+".png");

    },
    showDailyTask:function(lastTaskId,lastTaskType){
        cc.log(lastTaskId+"id  type"+lastTaskType+"显示更新 每日任务"+mainData.taskDataList.length);
        this.clearDailyTask();
        this.judgeMainTaskOver();
        if(mainData.taskDataList.length<2) return;
        var apartDaily=10;
        var newTaskList=[];
        for(var i=0;i<mainData.taskDataList.length;i++){
            if(mainData.taskDataList.getItemAt(i).taskType==2)  newTaskList.push(mainData.taskDataList.getItemAt(i));
        }

        if(newTaskList&&newTaskList.length){
            for(var i=0;i<newTaskList.length;i++){
                var data=newTaskList[i];
                var taskList = modelMgr.call("Table","getTableList",["task_everyday"]);
                var dailyTXT;
                for(var k in taskList) {
                    cc.log(taskList[k].task_id+"示更新 id "+data.taskId);
                    if (taskList[k].task_id == data.taskId) {
                        dailyTXT = taskList[k];
                        break;
                    }
                }
                //进度
                var progressList=[];
                var temp = dailyTXT.task_need;
                var tempjson = eval("(" + temp + ")");
                var obtain_item = {};
                for (var j in tempjson) {
                    obtain_item.taskId = j;
                    obtain_item.counts = tempjson[j];
                    //cc.log(obtain_item.taskId+"id count"+obtain_item.counts);
                    //cc.log(i+"iiii"+obtain_item.counts[1]);
                    progressList.push(obtain_item);
                }
                //奖励
                var rewardList=[];
                var temp1 = dailyTXT.task_reward;
                var tempjson1 = eval("(" + temp1 + ")");
                var obtain_item1 = {};
                for (var m in tempjson1) {
                    obtain_item1.itemId = m;
                    obtain_item1.counts = tempjson1[m];
                    //cc.log(obtain_item.taskId+"id count"+obtain_item.counts);
                    rewardList.push(obtain_item1);
                }

                var item=this._ui.getChildByName("Panel_2").getChildByName("Panel_5").getChildByName("item").clone();
                cc.log(this._msgScroll.height+"daily***************************"+item.height+"y"+(this._msgScroll.height-(i+1)*item.height) );
                cc.log(progressList[0].taskId+"id counts"+progressList[0].counts);
                item.taskId=data.taskId;//记录id
                item.rewardList=rewardList;//记录奖励列表
                item.progressList=progressList;//进度进度
                item.setVisible(true);
                item.setPosition(cc.p(0,(newTaskList.length-1-i)*item.height+(newTaskList.length-1-i)*apartDaily ));
                this.showDailyInfo(item,i,data,dailyTXT,progressList);//初始化 item 内容  this._taskData._dailyTaskList.length-1-i
                item.addTouchEventListener(this.selectDaily, this);
                this._arrTaskNode.push(item);
                this._msgScroll.addChild(item);
                if(lastTaskId!=undefined&&lastTaskId!=null&&data.taskId==lastTaskId&&data.taskType==lastTaskType) {//设置选中 上次
                    cc.log(lastTaskId+"lastTaskId"+data.taskId+"data.taskId"+lastTaskType+"lastTaskType"+"");
                    this.showSelect(lastTaskId);
                    this.showAward(2,data.taskId,rewardList,item.percent);
                }
            }
        }
        cc.log("设置滚动内部 高 "+newTaskList.length*(item.height+apartDaily)-apartDaily);
        this._msgScroll.setInnerContainerSize(cc.size(this._msgScroll.getContentSize().width, newTaskList.length*(item.height+apartDaily)-apartDaily ));

    },
    //显示每日任务具体内容
    showDailyInfo:function(item,index,data,dailyTXT,progressList){
        item.getChildByName("list_icon").getChildByName("img_icon").ignoreContentAdaptWithSize(true);
        item.getChildByName("list_icon").getChildByName("img_icon").loadTexture(ResMgr.inst()._icoPath+"renwu_"+dailyTXT.task_type+".png");
        item._index=index;
        item.getChildByName("img_complete").setVisible(data.reward==1);

        //item.getChildByName("percent").getChildByName("tf_percent").setString(data.taskInfoList[0].num+"/"+parseInt(progressList[0].counts[1]));
        item.getChildByName("percent").getChildByName("tf_percent").setString((data.taskInfoList.length==0?"0":data.taskInfoList[0].num)+"/"+parseInt(dailyTXT.task_type==1?progressList[0].counts[1]:progressList[0].counts[0]));//task_type 1特殊处理 数组两位 其它1位
        //var percent=parseInt(data.taskInfoList.length==0?0:data.taskInfoList[0].num)/parseInt(progressList[0].counts[1]);
        var percent=parseInt(data.taskInfoList.length==0?"0":data.taskInfoList[0].num)/parseInt(dailyTXT.task_type==1?progressList[0].counts[1]:progressList[0].counts[0]);
        item.percent=percent;//记录是否完成
        item.getChildByName("percent").getChildByName("ico1_0").setVisible(percent!=0);
        item.getChildByName("percent").getChildByName("ico1_0").width= item.getChildByName("percent").getChildByName("ico1_1").width*percent;//0.5
        //this._mainPercentInfo.setString("啊啊啊啊啊啊啊啊啊啊啊啊");
        item.getChildByName("tf_name").setString(ResMgr.inst().getString(String(data.taskId+"0")));//mainTask.taskId+"0"
    },
    //判断主线是否完结
    judgeMainTaskOver:function(){
        var isEnd=false;
        this._mainTfOver.setVisible(isEnd);
        this._mainPercent.setVisible(!isEnd);
        this._mainPercentInfo.setVisible(!isEnd);
        this._mainIcon.setVisible(!isEnd);
    },
    //清除每日任务列表
    clearDailyTask: function () {
        if (this._arrTaskNode) {
            for (var i = 0; i < this._arrTaskNode.length; i++) {
                this._arrTaskNode[i].removeFromParent();
                this._arrTaskNode[i] = null;
            }
            this._arrTaskNode = [];
        }
    },
    //清除奖励列表
    clearRewardList: function () {
        if (this._arrTaskReward) {
            for (var i = 0; i < this._arrTaskReward.length; i++) {
                this._arrTaskReward[i].removeFromParent();
                this._arrTaskReward[i] = null;
            }
            this._arrTaskReward = [];
        }
    },
    //选中主线任务
    selectMain:function(target, type){

        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log("selectMain>>>select"+target.taskId);
                if(this._arrTaskNode&&this._arrTaskNode.length>0){
                    for(var i=0;i<this._arrTaskNode.length;i++){
                        var item=this._arrTaskNode[i];
                        item.getChildByName("bg_unselected").setVisible(true);
                    }
                }
                this._mainSelect.setVisible(false);
                this.showAward(1,target.taskId,target.rewardList,target.percent);
                break;
        }
    },
    //选中每日任务
    selectDaily:function(target, type){

        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log(target.taskId+">>>>selectdaily"+target._index);
                this.showSelect(target.taskId);
                this.showAward(2,target.taskId,target.rewardList,target.percent);
                break;
        }

    },
    showSelect:function(taskId){
        if(this._arrTaskNode&&this._arrTaskNode.length>0){
            this._mainSelect.setVisible(true);
            for(var i=0;i<this._arrTaskNode.length;i++){
                var item=this._arrTaskNode[i];
                cc.log("showSelect&&&&&&&&&&&&&&"+item.taskId);
                if(item.taskId==taskId) {
                    cc.log("showSelect&&&&&&&&&&&&&&"+taskId);
                    item.getChildByName("bg_unselected").setVisible(false);
                }
                else item.getChildByName("bg_unselected").setVisible(true);
            }
        }
    },
    //奖励显示
    showAward:function(type,taskId,rewardList,percent){//type 1  主线
        cc.log(taskId+"显示 奖励 任务列表长"+mainData.taskDataList.length+"rewardList长度"+rewardList.length+"类型"+type);
        //if(this._rewardBt.taskId==taskId) {
        //    cc.log("重复点击");
        //    return;
        //}

        this.clearRewardList();
        var taskData;
        if(type==1){
            taskData=mainData.taskDataList.getItem("taskType",1);
            //this._rewardPanel.getChildByName("tf_taskinfo_0").setString(ResMgr.inst().getString("chat_4"));//taskData.taskId+"1"

        }else{
            for(var i=0;i<mainData.taskDataList.length;i++){
                var data=mainData.taskDataList.getItemAt(i);
                //cc.log(data.taskId+"data.task_id"+taskId);
                if(data.taskId==taskId){
                    taskData=data;
                    //cc.log(type+"typetypetypetype每日奖励显示"+taskData);
                    break;
                }
            }
            //this._rewardPanel.getChildByName("tf_taskinfo_0").setString(ResMgr.inst().getString("chat_5"));//taskData.taskId+"1"
        }
        //this._rewardBt.setTouchEnabled(false);
        //this._rewardBt.setBright(false);
        this._rewardPanel.getChildByName("tf_taskname").setString(ResMgr.inst().getString(type==1?"task_2":"task_3"));
        if(rewardList&&rewardList.length>0){
            cc.log("showAward  rewardList.length>>>>>>>>"+rewardList.length);
            for(var i=0;i<rewardList.length;i++){
                var rewardData=rewardList[i];
                var item=this._rewardPanel.getChildByName("list_icon_0").clone();
                //cc.log(this._msgScroll.height+"daily***************************"+item.height+"y"+(this._msgScroll.height-(i+1)*item.height) );
                item.itemId=rewardData.itemId;
                //item.getChildByName("img_icon").ignoreContentAdaptWithSize(true);
                item.getChildByName("img_icon").loadTexture(ResMgr.inst()._icoPath+item.itemId+"0.png");
                item.getChildByName("tf_num").setString(String(rewardData.counts));
                item.setVisible(true);
                item.setPosition(cc.p(55+i*95,72));
                //item.addTouchEventListener(this.selectDaily, this);
                this._arrTaskReward.push(item);
                this._rewardPanel.getChildByName("img_rewardbg").addChild(item);//

            }

        }

        this._rewardPanel.getChildByName("tf_taskinfo_0").setString(ResMgr.inst().getString(String(taskId+"1")));//taskData.taskId+"1"
        this._rewardBt.setTouchEnabled(taskData.reward!=1);
        this._rewardBt.setBright(taskData.reward!=1);
        this._rewardBt.getChildByName("tf").setString(taskData.reward!=1?ResMgr.inst().getString("sign_9"):ResMgr.inst().getString("sign_10"));
        cc.log(taskData.reward+"percent"+percent);
        if(taskData.reward!=1){//设置是否可领取
            this._rewardBt.setTouchEnabled(percent==1);
            this._rewardBt.setBright(percent==1);
            this._rewardBt.getChildByName("tf").setString(percent==1?ResMgr.inst().getString("sign_9"):ResMgr.inst().getString("task_1"));
        }
        this._rewardBt.taskId=taskId;
        this._rewardBt.taskType=type;
    },
    //显示日常规则
    onRule:function(target, type){
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log("日常规则");
                ModuleMgr.inst().openModule("AlertCostModule",{"text":ResMgr.inst().getString("task_7"),"title":ResMgr.inst().getString("task_3"),"oneBt":true});//,"func": this.buyItem

                break;
        }
    },
    //领取奖励
    onReward:function(target, type){
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log("领取奖励"+target.taskId);

                EventMgr.inst().dispatchEvent(TaskEvent.TASK_TASK_REWARD,target.taskId);
                break;
        }
    },
    getReward: function (event, data) {
        if (data == TaskNetEvent.SEND_TASK_REWARD ) {//获取任务奖励
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(8));
            ModuleMgr.inst().openModule("AlertGainModule",{"id":this._rewardBt.taskId,"num":this._rewardBt.taskType,"type":4});
        }
    },
    //清除方法
    destroy: function () {
        //cc.log("清除 方法 模块***************任务");
        //EventMgr.inst().removeEventListener(ChatEvent.ADD_CHAT, this.netAddChat, this);
        EventMgr.inst().removeEventListener(TaskEvent.TASK_UPDATE_TASK, this.updateTask, this);
        this._rewardBt.taskId=null;
        this._rewardBt.taskType=null;
        this.clearDailyTask();
        this.clearRewardList();
    },

})
//静态属性
//ChatModule.NODE_GAP = 5;//聊天块距