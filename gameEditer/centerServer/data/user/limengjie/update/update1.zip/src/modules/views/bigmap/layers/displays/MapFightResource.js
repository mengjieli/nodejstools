var MapFightResource = MapDisplayBase.extend({
    data: null,
    animation:null,
    countTxt:null,
    ctor: function (data) {
        this._super(MapDisplayType.FightResource);
        this.data = data;
        trace("添加战略资源", this.data.coordX, this.data.coordY, this.data.type);
        this.show = new cc.Sprite("#" + this.data.type + ".png");
        this.addChild(this.show);
        this.setCoord(this.data.coordX, this.data.coordY);

        this.count = this.data.count;
        this.data.addListener("count", this.updateResourceCount, this);
    },
    updateResourceCount: function () {
        if (this.data.count == 0) {
            var a = new Animation(MapResource.cfg);
            this.shaderLayer.addChild(a);
            a.setPosition(this.px, this.py);
            a.play(1);
        } else {
            if (this.count > this.data.count) {
                if(this.animation && this.animation.disposeFlag == false) {
                    this.animation.play(4);
                    this.countTxt.setString(this.data.count);
                } else {
                    var a = new Animation(MapFightResource.resource[this.data.type]);
                    var sp = new cc.Sprite("res/fight/ui/resourceBg.png");
                    a.bg.addChild(sp);
                    this.addChild(a);
                    a.setPosition(0, 50);
                    a.play(4);
                    this.animation = a;

                    var countSp = new cc.Sprite("res/fight/ui/resourceCountBg.png");
                    var txt = new ccui.Text();
                    txt.setString(this.data.count);
                    txt.setPosition(42+13,18);
                    txt.setFontSize(16);
                    txt.setColor({r:253,g:253,b:134,a:255});
                    this.countTxt = txt;
                    countSp.addChild(txt);
                    a.addChild(countSp);
                    countSp.setPosition(0,40);

                }
            }
            this.count = this.data.count;
        }
    },
    dispose: function () {
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
        this.data.removeListener("count", this.updateResourceCount, this);
    }
});


MapFightResource.resource = {
    1102002: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 1,
        end: 8,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1102004: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 1,
        end: 8,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1102001: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 20,
        end: 27,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1102003: {
        plist: "res/fight/effect/resource/resource.plist",
        name: "resourceing_00",
        format: "png",
        start: 20,
        end: 27,
        frameRate: 12,
        x: 0,
        y: 0
    }
};




