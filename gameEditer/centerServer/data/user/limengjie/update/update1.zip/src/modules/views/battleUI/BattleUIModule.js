/**
 * Created by cgMu on 2015/11/30.
 */

var BattleUIModule = ModuleBase.extend({
    root:null,
    armyData:null,
    armyItemArray:null,

    ctor:function() {
        this._super();
        this.armyItemArray = [];

        EventMgr.inst().addEventListener("castle_exchange",this.exchangeCallback,this);

        mainData.mapData.armyList.addListener("add", this.reset, this);
        mainData.mapData.armyList.addListener("del", this.reset, this);
    },

    initUI:function() {
        var _ui = ccs.load("res/images/ui/BattleUIModule/Layer.json","res/images/ui/").node;
        this.addChild( _ui );

        var size = cc.director.getVisibleSize();
        _ui.setContentSize(size);
        ccui.helper.doLayout(_ui);

        var root = _ui.getChildByName("Panel_1");
        root.setTouchEnabled(false);
        ModuleMgr.inst().getData("BattleUIModule").setBattleBottomBar(root);//UI动画切换
        this.root = root;

        var btn = root.getChildByName("Image_111");
        btn.setVisible(false);

        btn = _ui.getChildByName("Button_1");
        btn.addTouchEventListener(this.logCallback,this);
        btn.setVisible(false);
        ModuleMgr.inst().getData("BattleUIModule").setBattleLogBtn(btn);
        //posAutoLayout(btn);


        console.log("创建BattleUIModule");
    },

    destroy:function() {
        EventMgr.inst().removeEventListener("castle_exchange",this.exchangeCallback,this);

        mainData.mapData.armyList.removeListener("add", this.reset, this);
        mainData.mapData.armyList.removeListener("del", this.reset, this);
    },

    show:function( data ) {
        this.reset();
        console.log("显示BattleUIModule");
    },

    reset: function () {
        this.armyData = mainData.mapData.armyList.getItems("castleId",mainData.uiData.currentCastleId);//获取部队数据

        for(var i in this.armyItemArray) {
            if(this.armyItemArray[i]){
                this.armyItemArray[i].removeFromParent(true);
            }
        }
        this.armyItemArray = [];

        var pos = ModuleMgr.inst().getData("BattleUIModule").armyItemPos;
        for(var i = 0; i < this.armyData.length; i++) {
            var item = new ArmyItem(this.armyData[i]);
            item.setPosition(pos[i]);
            item.touchIcon.setTag(i);
            item.touchIcon.setUserData(this.armyData[i]);
            item.touchIcon.addTouchEventListener(this.touchCallback,this);
            this.root.addChild(item);
            this.armyItemArray.push(item);
        }
    },

    close:function() {
        console.log("关闭BattleUIModule");
    },

    touchCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        var tag = sender.getTag();
        for(var i in this.armyItemArray){
            if(tag==i) {
                this.armyItemArray[i].setSelectingState(true);
            }
            else {
                this.armyItemArray[i].setSelectingState(false);
            }
        }

        var data = sender.getUserData();
        cc.log("@touch army type",data.type,"id",data.id);

        var pos = MapUtils.transPointToPosition(data.coordX,data.coordY);
        modelMgr.call("BigMap", "cameraLookAt", [pos.x,pos.y]);

        mainData.mapData.myArmyList.setItemsAttribute("selected",true,"selected",false);
        data.selected = true;
        //ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("castle_1"),color:null,time:null,pos:null});
    },

    exchangeCallback : function (event, data) {
        this.reset();
    },

    logCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        ModuleMgr.inst().openModule("BattleLogModule");
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    }
});