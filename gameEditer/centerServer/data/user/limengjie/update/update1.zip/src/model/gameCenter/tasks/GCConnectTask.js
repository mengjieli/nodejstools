var GCConnectTask = (function (_super) {
    __extends(GCConnectTask, _super);

    function GCConnectTask(socket, cmd, taskId, msg) {
        _super.call(this, socket, cmd, taskId, msg);
    }

    var d = __define, c = GCConnectTask;
    p = c.prototype;

    /**
     * 执行任务
     * @param cmd 协议号
     * @param msg 从服务器接收的任务消息
     * @param bytes 返回给服务器的消息
     */
    p.doTask = function (cmd, msg, bytes) {
        var name = msg.readUTFV();
        //data.txt 提示内容	type 1(默认 确定 取消) 2确定 data.owner传this data.okFun点击Yes回调 data.noFun点击No回调	data.params回调参数
        ModuleMgr.inst().openModule("AlertPanel", {
            txt: "是否接收来自 " + name + " 的链接请求？",
            owner: this,
            okFun: this.receive,
            noFun: this.reject,
            params:name
        });
    }

    p.receive = function (name) {
        this.bytes.writeBoolean(true);
        this.completeTask();
        GameCenterConfig.saveConfig(GameCenterConfig.LINK_CLIENT, name);
    }

    p.reject = function () {
        this.bytes.writeBoolean(false);
        this.completeTask();
    }

    return GCConnectTask;
})(GCTaskBase);