/**
 * Created by cgMu on 2015/11/11.
 */

var GameOverModule = ModuleBase.extend({
    ctor:function() {
        this._super();

    },

    initUI:function() {

    },

    show:function( data ) {
        GameMgr.inst().gameOver();
        var auto = true;
        GameMgr.inst().startGame(auto);
    },

    close:function() {

    },

    destroy:function() {

    },

});