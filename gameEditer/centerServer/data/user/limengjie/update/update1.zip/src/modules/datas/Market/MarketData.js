/**
 * Created by Administrator on 2015/12/28 0028.
 */

var MarketData = DataBase.extend({

    _data:null,

    ctor: function () {
        this._data = {};

    },

    init: function () {
        return true;
    },

    destroy: function () {

    },


});