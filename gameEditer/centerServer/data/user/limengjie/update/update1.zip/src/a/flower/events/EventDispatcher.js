var flower;
(function (flower) {
    var EventDispatcher = (function () {
        function EventDispatcher() {
            this._events = {};
        }
        EventDispatcher.prototype.once = function (type, listener, thisObject) {
            this._addListener(type, listener, thisObject, true);
        };
        EventDispatcher.prototype.addListener = function (type, listener, thisObject) {
            this._addListener(type, listener, thisObject, false);
        };
        EventDispatcher.prototype._addListener = function (type, listener, thisObject, once) {
            if (!this._events[type]) {
                this._events[type] = [];
            }
            var list = this._events[type];
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    return;
                }
            }
            list.push({ "listener": listener, "thisObject": thisObject, "once": once, "del": false });
        };
        EventDispatcher.prototype.removeListener = function (type, listener, thisObject) {
            var list = this._events[type];
            if (!list) {
                return;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].listener == listener && list[i].thisObject == thisObject && list[i].del == false) {
                    list[i].listener = null;
                    list[i].thisObject = null;
                    list[i].del = true;
                    break;
                }
            }
        };
        EventDispatcher.prototype.removeAllListener = function () {
            this._events = {};
        };
        EventDispatcher.prototype.hasListener = function (type) {
            var list = this._events[type];
            if (!list) {
                return false;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].del == false) {
                    return true;
                }
            }
            return false;
        };
        EventDispatcher.prototype.dispatch = function (event) {
            var list = this._events[event.type];
            if (!list) {
                return;
            }
            for (var i = 0, len = list.length; i < len; i++) {
                if (list[i].del == false) {
                    var listener = list[i].listener;
                    var thisObj = list[i].thisObject;
                    if (event.$target == null) {
                        event.$target = this;
                    }
                    event.$currentTarget = this;
                    if (list[i].once) {
                        list[i].listener = null;
                        list[i].thisObject = null;
                        list[i].del = true;
                    }
                    listener.call(thisObj, event);
                }
            }
            for (i = 0; i < list.length; i++) {
                if (list[i].del == true) {
                    list.splice(i, 1);
                    i--;
                }
            }
        };
        EventDispatcher.prototype.dispatchWidth = function (type, data) {
            if (data === void 0) { data = null; }
            var e = flower.Event.create(type, data);
            this.dispatch(e);
        };
        EventDispatcher.prototype.dispose = function () {
            this._events = null;
        };
        return EventDispatcher;
    })();
    flower.EventDispatcher = EventDispatcher;
})(flower || (flower = {}));
//# sourceMappingURL=EventDispatcher.js.map