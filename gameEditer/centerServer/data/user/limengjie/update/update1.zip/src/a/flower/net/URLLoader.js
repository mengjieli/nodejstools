var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var URLLoader = (function (_super) {
        __extends(URLLoader, _super);
        function URLLoader(res) {
            _super.call(this);
            this._isLoading = false;
            this._res = res;
        }
        Object.defineProperty(URLLoader.prototype, "url", {
            get: function () {
                return this._res.url;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(URLLoader.prototype, "type", {
            get: function () {
                return this._res.type;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(URLLoader.prototype, "data", {
            get: function () {
                return this._data;
            },
            enumerable: true,
            configurable: true
        });
        URLLoader.prototype.load = function () {
            if (this._isLoading) {
                return;
            }
            this._isLoading = true;
            var func;
            var sync;
            if (this.type == flower.ResType.TEXTURE) {
                func = System.URLLoader.loadTexture.func;
                sync = System.URLLoader.loadTexture.sync;
            }
            else {
                func = System.URLLoader.loadText.func;
                sync = System.URLLoader.loadText.sync;
            }
            var _this = this;
            func(this._res.loadURL, function (d, width, height) {
                if (_this.type == flower.ResType.JSON) {
                    d = flower.JSON.parser.apply(flower.JSON, [d]);
                }
                else if (_this.type == flower.ResType.TEXTURE) {
                    d = flower.TextureManager.getInstance().createTexture(d, _this.url, _this._res.loadURL, width, height);
                }
                _this._data = d;
                new flower.CallLater(_this.dispatchWidth, _this, [flower.Event.COMPLETE, d]);
            }, function () {
                new flower.CallLater(_this.dispatch, _this, [new flower.IOErrorEvent(flower.IOErrorEvent.ERROR)]);
            });
        };
        return URLLoader;
    })(flower.EventDispatcher);
    flower.URLLoader = URLLoader;
})(flower || (flower = {}));
//# sourceMappingURL=URLLoader.js.map