function LoadConfig() {
    var url = "res/configs/table/";
    //加载配置列表
    var loader = new flower.URLLoader();
    loader.addEventListener(flower.Event.COMPLETE, this.loadConfigListComplete, this);
    loader.load(url + "TableList.json");
}

LoadConfig.prototype.loadConfigListComplete = function (event) {
    event.currentTarget.removeEventListener(flower.Event.COMPLETE, this.loadConfigListComplete, this);
    var data = event.currentTarget.data;
    console.log(typeof data);
}