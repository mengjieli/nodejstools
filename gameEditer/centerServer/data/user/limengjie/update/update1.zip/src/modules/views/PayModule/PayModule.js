/**
 * Created by cgMu on 2015/11/9.
 */

var PayModule = ModuleBase.extend({
    scrolItemArray:null,
    tabItemArray:null,
    tabItemFontArray:null,

    scrol:null,
    selectingTag:1,//第一个充值隐藏

    _counts: 0,
    _index: 0,

    //icon_counts:null,
    label_counts:null,
    label_counts_gold:null,
    buy_id:null,

    panel1:null,
    panel2:null,

    activityPanel:null,

    ctor:function() {
        this._super();

        this.scrolItemArray = [];
        this.tabItemArray = [];
        this.tabItemFontArray = [];

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.updateItem,this);
        EventMgr.inst().addEventListener(ITEM_EVENT.ITEM_UPDATE,this.updateItemCounts,this);
    },

    initUI:function() {
        var root = ccs.load("res/images/ui/PayModule/PayLayer.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var panel_root = root.getChildByName("Panel_1");
        posAutoLayout(panel_root,0.5);
        sizeAutoLayout(panel_root);

        var rootpanel = panel_root.getChildByName("Panel_2");
        sizeAutoLayout(rootpanel);

        var Image_82 = rootpanel.getChildByName("Image_82");
        posAutoLayout(Image_82);
        var Image_83 = rootpanel.getChildByName("Image_83");
        posAutoLayout(Image_83);
        Image_83.setLocalZOrder(101);
        var Image_89 = rootpanel.getChildByName("Image_89");
        posAutoLayout(Image_89);
        var Text_32 = rootpanel.getChildByName("Text_32");
        posAutoLayout(Text_32);
        Text_32.ignoreContentAdaptWithSize(true);
        Text_32.setString(ResMgr.inst().getString("pay_8"));

        var cz_baoshikuang_di_2 = rootpanel.getChildByName("cz_baoshikuang_di_2");
        posAutoLayout(cz_baoshikuang_di_2);
        this.panel1 = cz_baoshikuang_di_2;

        var Image_4 = rootpanel.getChildByName("Image_4");
        var cz_baoshi_3_0 = Image_4.getChildByName("cz_baoshi_3_0");
        cz_baoshi_3_0.setTexture(ResMgr.inst()._icoPath+"11030040.png");
        var Text_5_0 = Image_4.getChildByName("Text_5_0");
        Text_5_0.ignoreContentAdaptWithSize(true);
        Text_5_0.setString(ModuleMgr.inst().getData("ItemModule").getCountsByItemId(1103004));
        this.label_counts_gold = Text_5_0;
        posAutoLayout(Image_4);
        Image_4.setTouchEnabled(true);
        Image_4.addTouchEventListener(this.touchCallback,this);
        Image_4.setVisible(false);
        this.panel2 = Image_4;

        var icon_counts = cz_baoshikuang_di_2.getChildByName("cz_baoshi_3");
        this.label_counts = cz_baoshikuang_di_2.getChildByName("Text_5");
        this.label_counts.ignoreContentAdaptWithSize(true);
        this.label_counts.setString(ModuleMgr.inst().getData("ItemModule").getCountsByItemId(1103003));

        var scrollview = rootpanel.getChildByName("ScrollView_1");
        this.scrol = scrollview;
        this.scrol.addEventListener(this.scrollCall, this );
        sizeAutoLayout(scrollview);

        var tab1 = rootpanel.getChildByName("Image_84");
        tab1.ignoreContentAdaptWithSize(true);
        tab1.setTag(0);
        tab1.setTouchEnabled(true);
        tab1.addTouchEventListener(this.refreshTabState,this);
        posAutoLayout(tab1);
        this.tabItemArray.push(tab1);
        var title1 = tab1.getChildByName("Text_27");
        title1.ignoreContentAdaptWithSize(true);
        title1.setString(ResMgr.inst().getString("pay_1"));
        title1 = BorderText.replace(title1);
        this.tabItemFontArray.push(title1);

        var tab2 = rootpanel.getChildByName("Image_84_0");
        tab2.ignoreContentAdaptWithSize(true);
        tab2.setTag(1);
        tab2.setTouchEnabled(true);
        tab2.addTouchEventListener(this.refreshTabState,this);
        posAutoLayout(tab2);
        this.tabItemArray.push(tab2);
        var title2 = tab2.getChildByName("Text_27");
        title2.ignoreContentAdaptWithSize(true);
        title2.setString(ResMgr.inst().getString("pay_2"));
        title2 = BorderText.replace(title2);
        this.tabItemFontArray.push(title2);

        var tab3 = rootpanel.getChildByName("Image_84_1");
        tab3.ignoreContentAdaptWithSize(true);
        tab3.setTag(2);
        tab3.setTouchEnabled(true);
        tab3.addTouchEventListener(this.refreshTabState,this);
        posAutoLayout(tab3);
        this.tabItemArray.push(tab3);
        var title3 = tab3.getChildByName("Text_27");
        title3.ignoreContentAdaptWithSize(true);
        title3.setString(ResMgr.inst().getString("pay_13"));
        title3 = BorderText.replace(title3);
        this.tabItemFontArray.push(title3);

        var tab4 = rootpanel.getChildByName("Image_84_2");
        tab4.ignoreContentAdaptWithSize(true);
        tab4.setTag(3);
        tab4.setTouchEnabled(true);
        tab4.addTouchEventListener(this.refreshTabState,this);
        posAutoLayout(tab4);
        this.tabItemArray.push(tab4);
        var title4 = tab4.getChildByName("Text_27");
        title4.ignoreContentAdaptWithSize(true);
        title4.setString(ResMgr.inst().getString("pay_3"));
        title4 = BorderText.replace(title4);
        this.tabItemFontArray.push(title4);

        var goldTab = mainData.playerDataList.getItem("account", mainData.playerData.account).goldTab;
        cc.log("gold tab*********------>"+goldTab);
        tab4.setVisible(goldTab == "1");

        var tab5 = rootpanel.getChildByName("Image_84_3");
        tab5.ignoreContentAdaptWithSize(true);
        tab5.setTag(4);
        tab5.setTouchEnabled(true);
        tab5.addTouchEventListener(this.refreshTabState,this);
        posAutoLayout(tab5);
        this.tabItemArray.push(tab5);
        var title5 = tab5.getChildByName("Text_27");
        title5.ignoreContentAdaptWithSize(true);
        title5.setString(ResMgr.inst().getString("pay_14"));
        title5 = BorderText.replace(title5);
        this.tabItemFontArray.push(title5);
        tab5.setVisible(goldTab == "1");

        //middle
        var Image_90 = rootpanel.getChildByName("Image_90");
        posAutoLayout(Image_90);
        this.activityPanel = Image_90;

        var Image_93 = rootpanel.getChildByName("Image_93");
        sizeAutoLayout(Image_93);
        posAutoLayout(Image_93,0.5);
        var Image_95 = Image_93.getChildByName("Image_95");
        Image_95.addTouchEventListener(this.leftCallback,this);
        posAutoLayout(Image_95,0.5);
        var Image_93_0 = rootpanel.getChildByName("Image_93_0");
        sizeAutoLayout(Image_93_0);
        posAutoLayout(Image_93_0,0.5);
        var Image_95_0 = Image_93_0.getChildByName("Image_95_0");
        Image_95_0.addTouchEventListener(this.rightCallback,this);
        posAutoLayout(Image_95_0,0.5);

        //特惠购买按钮文字
        var textbtn = this.activityPanel.getChildByName("Panel_12").getChildByName("Button_3").getChildByName("Text_36");
        textbtn.ignoreContentAdaptWithSize(true);
        textbtn.setString(ResMgr.inst().getString("pay_12"));
        textbtn = BorderText.replace(textbtn);

        this.refreshContent_ex(this.selectingTag);
    },

    show:function( value ) {

    },

    touchCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            if(this.selectingTag == 3 || this.selectingTag == 4){
                cc.log("@touchCallback",this.selectingTag);
                ModuleMgr.inst().openModule("TaxRecordModule");

            }
        }
    },

    scrollCall:function( node, type )
    {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                this.setIndex();
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_LEFT:
                this._index = 4;
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_RIGHT:
                this._index = this._counts;
                break;
            default :
                break;
        }
    },

    leftCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;
        cc.log("@leftCallback",this._counts,this._index);
        this._index--;
        if(this._index<4){
            this._index=4;
        }
        this.getPercent();
    },

    rightCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;
        cc.log("@rightCallback",this._counts,this._index);
        this._index++;
        if(this._index>this._counts){
            this._index=this._counts;
        }
        this.getPercent();
    },

    close:function() {

    },

    destroy:function() {
        //NetMgr.inst().removeEventListener(599, this.netUpdateItem, this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.updateItem,this);
        EventMgr.inst().removeEventListener(ITEM_EVENT.ITEM_UPDATE,this.updateItemCounts,this);
    },

    setActivityPanel: function (data) {
        if(!this.activityPanel) return;

        var node = this.activityPanel.getChildByName("Panel_12");
        if(data==0){
            node.setVisible(false);
            return;
        }
        node.setVisible(true);

        var icon = node.getChildByName("Image_91");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(this.getActivityIconUrl(data.price_id),ccui.Widget.PLIST_TEXTURE);
        if(data.price_id==3||data.price_id==5){
            icon.setTouchEnabled(true);
            icon.addTouchEventListener(this.iconcallback,this);
            icon.setUserData(data);
        }

        var buybtn = node.getChildByName("Button_3");
        buybtn.setTag(data.recharge_id);
        buybtn.setUserData(data);
        buybtn.addTouchEventListener(this.itemTouchCallback,this);

        var name = node.getChildByName("Text_33");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(data.icon+"0"));

        var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data.trading_id ]);
        var temp = itemdata.obtain_item;

        var tempjson = eval("(" + temp + ")");
        var obtain_item = {};
        for (var i in tempjson) {
            obtain_item.itemid = i;
            obtain_item.counts = tempjson[i];
        }
        tempjson = eval("(" + itemdata.consumption_item + ")");
        var consumption_item = {};
        for (var i in tempjson) {
            consumption_item.itemid = i;
            consumption_item.counts = tempjson[i];
        }

        var counts = node.getChildByName("Text_34");
        counts.ignoreContentAdaptWithSize(true);
        if(data.price_type==2){
            counts.setString(obtain_item.counts);
        }
        else{
            counts.setString(obtain_item.counts/100);
        }

        var Text_35 = node.getChildByName("Text_35");
        Text_35.setVisible(false);

        var left = node.getChildByName("Panel_9_0");

        var cost_left = left.getChildByName("Text_49");
        cost_left.ignoreContentAdaptWithSize(true);
        cost_left.setString(data.price_id==1?"￥"+data.value:data.value);
        var icon_left = left.getChildByName("Image_3");
        icon_left.ignoreContentAdaptWithSize(true);

        var right = node.getChildByName("Panel_9_1");

        var cost_right = right.getChildByName("Text_49_0");
        cost_right.ignoreContentAdaptWithSize(true);
        var icon_right = right.getChildByName("Image_3");
        icon_right.ignoreContentAdaptWithSize(true);

        if(data.price_id == 1){
            icon_left.setVisible(false);
            icon_right.setVisible(false);
            cost_right.setString("￥6");
        }
        else{
            icon_left.setVisible(true);
            icon_right.setVisible(true);
            icon_left.loadTexture(ResMgr.inst()._icoPath+consumption_item.itemid+"0.png");
            icon_right.loadTexture(ResMgr.inst()._icoPath+consumption_item.itemid+"0.png");
            cost_right.setString(consumption_item.counts/100);
        }

        //重新布局
        if(data.price_id==1){
            cost_left.setPositionX(0);
            left.setContentSize(cc.size(cost_left.getContentSize().width,10));
            cost_right.setPositionX(0);
            right.setContentSize(cc.size(cost_right.getContentSize().width,10));
        }
        else{
            var costiconwidth = icon_left.getContentSize().width;
            cost_left.setPositionX(costiconwidth);
            var totalwidth = costiconwidth+cost_left.getContentSize().width;
            left.setContentSize(cc.size(totalwidth,10));

            costiconwidth = icon_right.getContentSize().width;
            cost_right.setPositionX(costiconwidth);
            totalwidth = costiconwidth+cost_right.getContentSize().width;
            right.setContentSize(cc.size(totalwidth,10));
        }

    },

    getActivityIconUrl: function (type) {
        var url = "";
        switch (type) {
            case 1:
                url = "PayModule/cz_baoshi.png";
                break;
            case 2:
                url = "PayModule/cz_jinbi.png";
                break;
            case 3:
                url = "PayModule/cz_jinbi.png";
                break;
            case 4:
                url = "PayModule/cz_baoxiang.png";
                break;
            case 5:
                url = "PayModule/cz_baoxiang.png";
                break;
            default :
                url = "PayModule/cz_baoshi.png";
                break;
        }
        return url;
    },

    //tab:标签tag
    refreshContent_ex: function (tab) {
        var data_ex = ModuleMgr.inst().getData("PayModule")._data[tab+1];
        //筛选数据 活动特惠
        var data = [];
        var activityData = [];
        for(var i in data_ex){
            if(data_ex[i].type == 6){
                activityData.push(data_ex[i]);
            }
            else{
                data.push(data_ex[i]);
            }
        }

        if(activityData.length>0){
            this.setActivityPanel(activityData[0]);
        }
        else{
            this.setActivityPanel(0);
        }

        for (var i in this.scrolItemArray) {
            if (this.scrolItemArray[i]) {
                this.scrolItemArray[i].removeFromParent(true)
            }
        }
        this.scrolItemArray = [];

        //----------------
        this._counts = data.length;
        this._index = 4;//一次显示4个

        var gap = 36;
        var item_width = 165;
        //var item_height = this.getCustomHeight();
        var size = this.scrol.getContentSize();
        var counts = data.length;
        var totalWidth = (item_width+gap)*counts;
        totalWidth = totalWidth<size.width ? size.width:totalWidth;

        var item0 = this.scrol.getChildByName("Panel_1_0");
        item0.setVisible(false);

        for (var i = 0; i < counts; i++) {
            var item = item0.clone();
            item.setVisible(true);
            this.scrol.addChild(item);
            this.scrolItemArray.push(item);
            item.setPosition(cc.p(i*(gap+item_width)+gap*0.5,4));

            this.setItemContent(item,data[i]);
        }

        this.scrol.setInnerContainerSize( cc.size(totalWidth,size.height) );
        this.scrol.jumpToLeft();
    },

    //getCustomHeight: function () {
    //    var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
    //    down = down * (1 / GameMgr.inst().scaleX);
    //    return 297+down;
    //},

    itemTouchCallback: function (sender, type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                var tag = sender.getTag();
                var userdata = sender.getUserData();
                cc.log("***",tag);
                this.buy_id = null;
                if (userdata.price_id!=1) { //过滤掉人民币充值
                    this.buy(tag,1,userdata);
                    this.buy_id = tag;
                }
                else {
                    ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("college_18"),color:null,time:null,pos:null});
                }
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
        }
    },

    refreshTabState: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        var tag = sender.getTag();
        if (this.selectingTag == tag) {cc.error("touch again"); return;}

        this.selectingTag = tag;
        cc.log("ccui.Widget.TOUCH_ENDED",tag,this.tabItemArray.length);

        if(this.selectingTag == 0 || this.selectingTag == 1 || this.selectingTag == 2){
            //this.icon_counts.setTexture(ResMgr.inst()._icoPath+"11030030.png");
            this.panel1.setVisible(true);
            this.panel2.setVisible(false);
            this.label_counts.setString(ModuleMgr.inst().getData("ItemModule").getCountsByItemId(1103003));
        }
        else if(this.selectingTag == 3 || this.selectingTag == 4){
            this.panel1.setVisible(false);
            this.panel2.setVisible(true);
            //this.icon_counts.setTexture(ResMgr.inst()._icoPath+"11030040.png");
            this.label_counts_gold.setString(ModuleMgr.inst().getData("ItemModule").getCountsByItemId(1103004));
        }

        for (var i in this.tabItemArray) {
            //cc.log(i);
            if (tag == i) {
                this.tabItemArray[i].loadTexture("ty_shangbiaoqianxuanzhong1.png",ccui.Widget.PLIST_TEXTURE);
                var title = this.tabItemFontArray[i];//this.tabItemArray[i].getChildByName("Text_27");
                title.setColor(cc.color(252,250,155,255));
                title.setFontSize(24);
                this.resetTabTitlePos(this.tabItemArray[i],title);
                this.tabItemArray[i].setLocalZOrder(10);
            }
            else {
                this.tabItemArray[i].loadTexture("ty_shangbiaoweiqianxuanzhong.png",ccui.Widget.PLIST_TEXTURE);
                var title = this.tabItemFontArray[i];//this.tabItemArray[i].getChildByName("Text_27");
                title.setColor(cc.color(175,151,86,255));
                title.setFontSize(20);
                this.resetTabTitlePos(this.tabItemArray[i],title);
                this.tabItemArray[i].setLocalZOrder(0);
            }
        }
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        this.refreshContent_ex(this.selectingTag);
    },

    //切换标签时，调整文字坐标，居中
    resetTabTitlePos: function (parent, title) {
        var size = parent.getContentSize();
        title.setPosition(cc.p(size.width*0.5,24.03));
    },
    //设置item样式
    setItemContent: function (item,data) {
        var Image_192 = item.getChildByName("Image_192");
        sizeAutoLayout(Image_192);

        var title_bg = item.getChildByName("Image_1");
        title_bg.ignoreContentAdaptWithSize(true);
        posAutoLayout(title_bg);

        var title = item.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        //title = BorderText.replace(title);
        posAutoLayout(title);

        var name = item.getChildByName("Text_2");
        name.ignoreContentAdaptWithSize(true);
        name = BorderText.replace(name);
        posAutoLayout(name);

        var counts_label = item.getChildByName("Text_3");
        counts_label.ignoreContentAdaptWithSize(true);
        counts_label = BorderText.replace(counts_label);
        posAutoLayout(counts_label);

        var icon = item.getChildByName("Image_2");
        icon.ignoreContentAdaptWithSize(true);
        posAutoLayout(icon,0.5);
        if(data.price_id==3||data.price_id==5){
            icon.setTouchEnabled(true);
            icon.addTouchEventListener(this.iconcallback,this);
            icon.setUserData(data);
        }

        var Button_7 = item.getChildByName("Button_7");
        Button_7.setTag(data.recharge_id);
        Button_7.setUserData(data);
        Button_7.addTouchEventListener(this.itemTouchCallback,this);

        var bg_pan = Button_7.getChildByName("Panel_9");

        var cost = bg_pan.getChildByName("Text_4");
        cost.ignoreContentAdaptWithSize(true);
        //cost = BorderText.replace(cost);
        var cost_icon = bg_pan.getChildByName("Image_3");
        cost_icon.ignoreContentAdaptWithSize(true);

        var obtain_item = {};
        var consumption_item = {};

        if(data.trading_id == 2810001){
            var value = modelMgr.call("Table", "getTableItemByValue", ["Public",100027]).numerical;
            //配置
            obtain_item.itemid = 2100033;
            obtain_item.counts = 1;

            consumption_item.itemid = 1103003;
            consumption_item.counts = value;
        }
        else if(data.trading_id == 2811001){
            var value = modelMgr.call("Table", "getTableItemByValue", ["Public",100027]).numerical;
            //配置
            obtain_item.itemid = 2100033;
            obtain_item.counts = 1;

            consumption_item.itemid = 1103004;
            consumption_item.counts = value;
        }
        else {
            var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data.trading_id ]);
            var temp = itemdata.obtain_item;

            var tempjson = eval("(" + temp + ")");
            for (var i in tempjson) {
                obtain_item.itemid = i;
                obtain_item.counts = tempjson[i];
            }

            tempjson = eval("(" + itemdata.consumption_item + ")");
            for (var i in tempjson) {
                consumption_item.itemid = i;
                consumption_item.counts = tempjson[i];
            }
        }

        if(data.type==4){
            title.setVisible(false);
            title_bg.setVisible(false);
        }
        else {
            title.setString(this.getTitleByType(data.type));
        }

        name.setString(ResMgr.inst().getString(data.icon+"0"));
        if(data.price_type==2){
            counts_label.setString(obtain_item.counts);
        }
        else{
            counts_label.setString(obtain_item.counts/100);
        }

        icon.loadTexture(ResMgr.inst()._icoPath+data.icon+"4.png");
        //根据item类型，相应处理
        if(data.price_id==1) {//人民币支付
            cost_icon.setVisible(false);
            cost.setString("￥"+6);
        }
        else {
            cost_icon.loadTexture(ResMgr.inst()._icoPath+consumption_item.itemid+"0.png");
            cost.setString(consumption_item.counts/100);
        }

        //重新布局
        if(data.price_id==1){
            cost.setPositionX(0);
            bg_pan.setContentSize(cc.size(cost.getContentSize().width,10));
        }
        else{
            var costiconwidth = cost_icon.getContentSize().width;
            cost.setPositionX(costiconwidth);
            var totalwidth = costiconwidth+cost.getContentSize().width;
            bg_pan.setContentSize(cc.size(totalwidth,10));
        }

        cost = BorderText.replace(cost);

    },

    //1:首次翻倍 2:每日限购 3:热卖 4:无标签 5:仅限一次 6:活动特惠
    getTitleByType: function (type) {
        var string = null;
        switch (parseInt(type)) {
            case 1:
                string = ResMgr.inst().getString("pay_6");
                break;
            case 2:
                string = ResMgr.inst().getString("pay_5");
                break;
            case 3:
                string = ResMgr.inst().getString("pay_4");
                break;
            case 6:
                string = ResMgr.inst().getString("pay_8");
                break;
            case 5:
                string = ResMgr.inst().getString("pay_7");
                break;
            default :
                string = ResMgr.inst().getString("pay_9");
                break
        }
        return string;
    },

    buy: function (rechargeid, repeatcount,userdata) {
        //cc.log("@buy trading_id",userdata.trading_id);
        if(userdata.trading_id==2810001){
            var msg = new SocketBytes();
            msg.writeUint(504);//钻石购买效率卡
            msg.writeUint(0);//
            msg.writeUint(repeatcount);
            NetMgr.inst().send(msg);
        }
        else if(userdata.trading_id==2811001){
            var msg = new SocketBytes();
            msg.writeUint(504);//黄金购买效率卡
            msg.writeUint(1);//
            msg.writeUint(repeatcount);
            NetMgr.inst().send(msg);
        }
        else{
            var msg = new SocketBytes();
            msg.writeUint(501);//充值页面购买
            msg.writeUint(rechargeid);//
            msg.writeUint(repeatcount);
            NetMgr.inst().send(msg);
        }
    },

    //更新钻石数量
    updateLabel: function (value) {
        var label = null;
        if(this.panel1.isVisible()){
            label = this.label_counts;
        }
        else if(this.panel2.isVisible()){
            label = this.label_counts_gold;
        }
        if (label) {
            //冒字提示
            var old = parseInt(label.getString());
            var cor = cc.color(255,0,0);
            var delt = value-old;
            if(delt>0){
                delt="+"+delt;
                cor = cc.color(0,204,0);
            }
            var txt = new ccui.Text();
            txt.setFontSize(25);
            txt.setString(delt);
            txt.setPosition(label.getPosition());
            txt.setTextColor( cor );
            var ac = cc.sequence( cc.moveBy( 0.5, cc.p(0,20) ), cc.callFunc( this.txtCall,this) );
            txt.runAction( ac );
            label.getParent().addChild( txt );

            label.setString(value);
        }
    },

    updateItemCounts: function (event, itemid, counts) {
        if(this.selectingTag<=2){
            if(itemid == 1103003) {
                this.updateLabel(counts);
            }
        }
        else{
            if(itemid == 1103004) {
                this.updateLabel(counts);
            }
        }
    },

    updateItem: function (type,data) {
        if (data == 501 || data == 504) {
            if (this.buy_id || this.buy_id==0) {
                //var string = ResMgr.inst().getString("pay_10");
                //if(this.buy_id==0){
                //    string = string+ResMgr.inst().getString("21000330");
                //}
                //else{
                //    var d = modelMgr.call("Table", "getTableItemByValue", ["Pay",this.buy_id]);
                //    string = string+ResMgr.inst().getString(d.icon+"0");
                //}
                //ModuleMgr.inst().openModule("AlertString",{str:string,color:null,time:null,pos:null});

                //播放获得礼包特效
                //var size = cc.director.getVisibleSize();
                //var csv = ResMgr.inst().getCSV("animationConfig","bag_getItems");
                //var effect =new AnimationSprite();
                //effect.setPosition(cc.p(size.width*0.5,size.height*0.5));
                //effect.setName("bag_getItems");
                //effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
                //this.addChild(effect);
                //var itemid = this.buy_id;
                //if(itemid==0){
                //    itemid = 2100033;
                //}
                ModuleMgr.inst().openModule("AlertGainModule",{"id":this.buy_id,"num":100,"type":1});
            }
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(8));
        }
    },

    getPercent: function () {
        var percent = 0;
        var size = this.scrol.getContentSize();
        var h = this.scrol.getInnerContainerSize().width;
        cc.log("@getPercent $",size.width,h,this._index);

        if(this._index>4){
            if(this._index==this._counts){
                percent = 100;
            }
            else{
                var delt = this._index - 4;
                var width = (165+36)*delt;
                percent = width / (h- size.width) * 100;
            }
        }

        //return percent;
        cc.log("@getPercent",percent);
        this.scrol.jumpToPercentHorizontal(percent);
    },

    setIndex: function () {
        var pos = this.scrol.getInnerContainer().getPosition();
        var index = -pos.x / (165+36);
        this._index = parseInt(index)+4;
    },

    txtCall:function( node )
    {
        node.removeFromParent();
    },

    iconcallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            ModuleMgr.inst().openModule("ShowBagModule",sender.getUserData());
        }
    }
});