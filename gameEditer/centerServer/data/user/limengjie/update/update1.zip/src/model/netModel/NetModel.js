var NetModel = (function (_super) {
    __extends(NetModel, _super);

    function NetModel() {
        _super.call(this, "Net");
        this.hasConnect = true;
        this.netWait = [];
        jc.EnterFrame.add(this.update, this);
    }

    var d = __define, c = NetModel;
    p = c.prototype;

    p.onSend = function (cmd) {
        this.netWait.push({"cmd": cmd, "time": (new Date()).getTime()});
    }

    p.onReceive = function (cmd) {
        if(!modelMgr) {
            return;
        }
        this.netWait = [];
        modelMgr.call("NetWiating", "closeView", []);
    }

    p.update = function () {
        if(!modelMgr) {
            return;
        }
        var timeOut = modelMgr.call("Table", "getTableItemByValue", ["Public", 100057]).numerical || 5000;
        var now = (new Date()).getTime();
        for (var i = 0; i < this.netWait.length; i++) {
            if (now - this.netWait[i].time > timeOut) {
                modelMgr.call("NetWiating", "openView", []);
                return;
            }
        }
    }

    return NetModel;
})(ModelBase);