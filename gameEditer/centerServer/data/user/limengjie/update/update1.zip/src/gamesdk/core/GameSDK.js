var GameSDK = function () {

}

var global = global || {};

GameSDK.debug = true;