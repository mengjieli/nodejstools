function Ease() { this.ctor.apply(this,arguments); };

Ease.prototype = 
{
};
Ease.LINE = 1;
Ease.EASE_OUT = 2;
Ease.EASE_IN = 3;
Ease.extend = extendClass;
