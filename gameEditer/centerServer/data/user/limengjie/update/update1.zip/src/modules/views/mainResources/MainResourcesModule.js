/**
 * Created by Administrator on 2015/10/23.
 */

var MainResourcesModule = ModuleBase.extend({

    _text:null,
    _resPanel:null,
    _msgPanel:null,

    _head:null,
    _back:null,
    _bt_refresh:null,//更换资源按钮主界面
    _bt_refresh_0:null,//更换资源按钮 UI界面

    _firstPanel:null,
    _secondPanel:null,
    //主界面UI
    _filters:null,  //过滤列表
    _heads:null,    //头像列表
    _arrTf1:null,//基础资源文本列表
    _arrImg1:null,//基础资源图标列表
    _arrImg2:null,//战略源图标列表
    _arrTf2:null,//战略资源文本列表
    _type:null,//类型
    _lock:null,//锁定点击切换
    //其他UI
    _arrTf01:null,//基础资源文本列表
    _arrImg01:null,//基础资源图标列表
    _arrImg02:null,//战略源图标列表
    _arrTf02:null,//战略资源文本列表
    _type0:null,//类型
    _lock0:null,//锁定点击切换

    _modules:null,

    _listenData:null,
    _listenFightingData:null,

    _level:0,

    ctor: function () {
        this._super();
    },

    initUI: function () {

        trace("MainResource 1");
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.updateMessage,this);
        EventMgr.inst().addEventListener(AnnouncementEvent.SEND_ANNOUNCEMENT_MSG, this.msgCall, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_RESOURCE, this.resUpdata, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_RESOURCE, this.resourceCall, this);
        EventMgr.inst().addEventListener(ModuleEvent.SEND_OPEN_MODULE, this.openCall, this);
        EventMgr.inst().addEventListener(ModuleEvent.SEND_CLOSE_MODULE, this.closeCall, this);
        //修改头像成功事件监听
        EventMgr.inst().addEventListener(HEADEVENT.CHANGE_HEAD_SUCCESS,this.updateHeadIcon,this);
        //道具更新，用于金币数量更新
        EventMgr.inst().addEventListener(ITEM_EVENT.ITEM_UPDATE,this.refreshGoldCounts,this);
        //切换分城
        mainData.uiData.addListener("currentCastleId",this.exchangeCallback,this);

        EventMgr.inst().addEventListener("wareHouse_event",this.updateColor,this);


        trace("MainResource 2");
        this._ui = ccs.load("res/images/ui/mainResourcesModule/Layer.json", "res/images/ui/").node;
        this.addChild(this._ui);

        var panel = this._ui.getChildByName("Panel");
        panel.setVisible(true);
        this._firstPanel = panel;
        ModuleMgr.inst().getData("BattleUIModule").setTopBar(panel);//UI动画切换

        trace("MainResource 3");
        this._resPanel = panel.getChildByName("res_Panel");
        this._msgPanel = panel.getChildByName("msg_panel");

        var head = panel.getChildByName("res_Panel").getChildByName("head_layer").getChildByName("head");
        var headname = mainData.playerData.headid;
        if(headname == undefined || headname == "") {
            headname = ResMgr.inst().getCSV("head",1).head_id;//默认配置第一个
        }
        trace("MainResource 4");
        head.loadTexture(ResMgr.inst().getIcoPath(headname));
        head.ignoreContentAdaptWithSize(true);
        //head.setSize(70, 70);
        head.setScale(0.55);
        head.setTouchEnabled(true);
        head.addTouchEventListener( this.headCall, this );

        trace("MainResource 5");
        this._head = panel.getChildByName("res_Panel").getChildByName("head_layer");

        var castleData = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId);
        this._listenData = castleData;
        this._listenData.addListener("attributes",this.attCallback,this);
        this._listenData.addListener("force",this.updateFighting,this);

        //trace("城堡属性!!",castleData.attributes.length);
        //for (var m =0; m < castleData.attributes.length; m++) {
        //    trace(castleData.attributes.getItemAt(m).type,castleData.attributes.getItemAt(m).value);
        //}
        var data_2 = 0;
        if(castleData.attributes.getItem("type",2500001)){
            data_2 = castleData.attributes.getItem("type",2500001).value;
        }

        trace("data_2",data_2);
        var fighting = panel.getChildByName("res_Panel").getChildByName("Image_1");
        var tx = fighting.getChildByName("Text_6");
        tx.ignoreContentAdaptWithSize(true);
        trace("data_2 -2",tx);
        tx.setString(data_2);

        trace("armyfighting",armyfighting);
        var armyfighting = castleData.force;
        cc.log("@force----------->",castleData.force,armyfighting);
        var label2 = panel.getChildByName("res_Panel").getChildByName("Image_1_0").getChildByName("Text_6");
        label2.ignoreContentAdaptWithSize(true);
        label2.setString(armyfighting);

        this._bt_refresh = panel.getChildByName("res_Panel").getChildByName("bt_refresh");
        if(this._bt_refresh)    this._bt_refresh.addTouchEventListener( this.onRefreshAll, this );//onFresh

        var qian_layer = this._resPanel.getChildByName("qian_layer");
        qian_layer.addTouchEventListener(this.goldCall,this);
        this.play(qian_layer);
        if(!this._arrImg1) this._arrImg1=[panel.getChildByName("res_Panel").getChildByName("img0"),panel.getChildByName("res_Panel").getChildByName("img1"),panel.getChildByName("res_Panel").getChildByName("img2"),panel.getChildByName("res_Panel").getChildByName("img3")];
        if(!this._arrTf1) this._arrTf1=[panel.getChildByName("res_Panel").getChildByName("txt0"),panel.getChildByName("res_Panel").getChildByName("txt1"),panel.getChildByName("res_Panel").getChildByName("txt2"),panel.getChildByName("res_Panel").getChildByName("txt3")];
        if(!this._arrTf2) this._arrTf2=[panel.getChildByName("res_Panel").getChildByName("txt10"),panel.getChildByName("res_Panel").getChildByName("txt11"),panel.getChildByName("res_Panel").getChildByName("txt12"),panel.getChildByName("res_Panel").getChildByName("txt13")];
        if(!this._arrImg2) this._arrImg2=[panel.getChildByName("res_Panel").getChildByName("img10"),panel.getChildByName("res_Panel").getChildByName("img11"),panel.getChildByName("res_Panel").getChildByName("img12"),panel.getChildByName("res_Panel").getChildByName("img13")];
        var img = panel.getChildByName("res_Panel").getChildByName("img0");
        img.loadTexture("res/images/ico/11010010.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = panel.getChildByName("res_Panel").getChildByName("img1");
        img.loadTexture("res/images/ico/11010020.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = panel.getChildByName("res_Panel").getChildByName("img2");
        img.loadTexture("res/images/ico/11010030.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = panel.getChildByName("res_Panel").getChildByName("img3");
        img.loadTexture("res/images/ico/11010040.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setScale(0.8);
        var img = panel.getChildByName("res_Panel").getChildByName("img10");
        img.loadTexture("res/images/ico/11020010.png");
        img.ignoreContentAdaptWithSize(true);
        var img = panel.getChildByName("res_Panel").getChildByName("img11");
        img.loadTexture("res/images/ico/11020020.png");
        img.ignoreContentAdaptWithSize(true);
        var img = panel.getChildByName("res_Panel").getChildByName("img12");
        img.loadTexture("res/images/ico/11020030.png");
        img.ignoreContentAdaptWithSize(true);
        var img = panel.getChildByName("res_Panel").getChildByName("img13");
        img.loadTexture("res/images/ico/11020040.png");
        img.ignoreContentAdaptWithSize(true);

        //其他UI资源条
        this._text = new ccui.Text();
        this._text.setAnchorPoint(0,0);
        this._text.ignoreContentAdaptWithSize( true );
        this._text.setFontSize(18);
        this._text.setPosition(0,5);
        this._text.setString("");
        this._text.setColor(cc.color(239,235,198));
        this._msgPanel.addChild( this._text );
        this._msgPanel.setVisible(false);//默认不显示
        //second
        var Panel_0 = this._ui.getChildByName("Panel_0");
        Panel_0.setVisible(false);
        this._secondPanel = Panel_0;
        ModuleMgr.inst().getData("BattleUIModule").setTopBarS(Panel_0);//UI动画切换

        this._back = Panel_0.getChildByName("res_Panel").getChildByName("Button");
        this._back.addTouchEventListener( this.backCall, this );


        var img = Panel_0.getChildByName("res_Panel").getChildByName("img0");
        img.loadTexture("res/images/ico/11010010.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img1");
        img.loadTexture("res/images/ico/11010020.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img2");
        img.loadTexture("res/images/ico/11010030.png");
        img.ignoreContentAdaptWithSize(true);
        //img.setSize(45, 45);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img3");
        img.loadTexture("res/images/ico/11010040.png");
        img.ignoreContentAdaptWithSize(true);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img10_0");
        img.loadTexture("res/images/ico/11020010.png");
        img.ignoreContentAdaptWithSize(true);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img11_0");
        img.loadTexture("res/images/ico/11020020.png");
        img.ignoreContentAdaptWithSize(true);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img12_0");
        img.loadTexture("res/images/ico/11020030.png");
        img.ignoreContentAdaptWithSize(true);
        var img = Panel_0.getChildByName("res_Panel").getChildByName("img13_0");
        img.loadTexture("res/images/ico/11020040.png");
        img.ignoreContentAdaptWithSize(true);

        var qian_layer = Panel_0.getChildByName("res_Panel").getChildByName("qian_layer");
        qian_layer.addTouchEventListener(this.goldCall,this);
        this.play(qian_layer);
        this._bt_refresh_0 = Panel_0.getChildByName("res_Panel").getChildByName("bt_refresh_0");
        if(this._bt_refresh_0)    this._bt_refresh_0.addTouchEventListener( this.onRefreshAll, this );

        if(!this._arrImg01) this._arrImg01=[Panel_0.getChildByName("res_Panel").getChildByName("img0"),Panel_0.getChildByName("res_Panel").getChildByName("img1"),Panel_0.getChildByName("res_Panel").getChildByName("img2"),Panel_0.getChildByName("res_Panel").getChildByName("img3")];
        if(!this._arrTf01) this._arrTf01=[Panel_0.getChildByName("res_Panel").getChildByName("txt0"),Panel_0.getChildByName("res_Panel").getChildByName("txt1"),Panel_0.getChildByName("res_Panel").getChildByName("txt2"),Panel_0.getChildByName("res_Panel").getChildByName("txt3")];
        if(!this._arrTf02) this._arrTf02=[Panel_0.getChildByName("res_Panel").getChildByName("txt10_0"),Panel_0.getChildByName("res_Panel").getChildByName("txt11_0"),Panel_0.getChildByName("res_Panel").getChildByName("txt12_0"),Panel_0.getChildByName("res_Panel").getChildByName("txt13_0")];
        if(!this._arrImg02) this._arrImg02=[Panel_0.getChildByName("res_Panel").getChildByName("img10_0"),Panel_0.getChildByName("res_Panel").getChildByName("img11_0"),Panel_0.getChildByName("res_Panel").getChildByName("img12_0"),Panel_0.getChildByName("res_Panel").getChildByName("img13_0")];

        //适配
        var size = cc.director.getVisibleSize();
        this._ui.setContentSize(size);
        ccui.helper.doLayout(this._ui);

        //当前打开的模块需要返回的模块列表
        this._modules = [];

        //过滤列表
        this._filters =
        {
            "MainResourcesModule":1,
            "TileMenuModule":1,
            "BuildingUIModule":1,
            "CreateBuildingUIModule":1,
            "AccelerateModule":1,
            "AlertString":1,
            "AlertPanel":1,
            "MainMenuModule":1,
            "SignModule":1,
            "AddCollectModule":1,
            "BlockInfoModule":1,
            "BlockLevelupModule":1,
            "BattleUIModule":1,
            "ChatModule":1,
            "PlayerInfoModule":1,
            "GuideModule":1,
            "TextboxModule":1,
            "AlertCostModule":1,
            "AlertGainModule":1,
            "MapChangeModule":1
        };

        //显示头像列表
        this._heads =
        {
            "CastleModule":1,
            "BigMapModule":1
        };

        this.resUpdata();
        ModuleMgr.inst().openModule("ChatModule");

        ModuleMgr.inst().getData("ItemModule").initSignModule();
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
        this.doGuide();
        //任务请求
        cc.log("任务请求 1200"+TaskNetEvent.SEND_TASK);
        var msg = new SocketBytes();
        msg.writeUint(TaskNetEvent.SEND_TASK);
        NetMgr.inst().send(msg);
    },

    acBack:function( node )
    {
        var obj = {castleId:1,resourceId:1101001,differ:50,current:10};
        this.resourceCall( null, obj );
    },

    destroy: function ()
    {
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.updateMessage,this);
        EventMgr.inst().removeEventListener(AnnouncementEvent.SEND_ANNOUNCEMENT_MSG, this.msgCall, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_RESOURCE, this.resourceCall, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_RESOURCE, this.resUpdata, this);
        EventMgr.inst().removeEventListener(ModuleEvent.SEND_OPEN_MODULE, this.openCall, this);
        EventMgr.inst().removeEventListener(ModuleEvent.SEND_CLOSE_MODULE, this.closeCall, this);
        EventMgr.inst().removeEventListener(HEADEVENT.CHANGE_HEAD_SUCCESS,this.updateHeadIcon,this);

        EventMgr.inst().removeEventListener(ITEM_EVENT.ITEM_UPDATE,this.refreshGoldCounts,this);
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        mainData.uiData.removeListener("currentCastleId",this.exchangeCallback,this);

        //var castleData = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId);

        if(this._listenData){
            this._listenData.removeListener("attributes",this.attCallback,this);
            this._listenData.removeListener("force",this.updateFighting,this);
            this._listenData = null;
        }
    },

    show: function (data)
    {
        this.showMsg();

        if( data == null ) return;
        var b = data.isShowBack;
        if( this._head/* && this._back*/ )
        {
            this._head.setVisible( !b );
            //this._back.setVisible( b );
        }
    },

    close: function ()
    {

    },

    resUpdata:function()
    {
        //主界面资源条
        var ui0 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt0");
        var ui1 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt1");
        var ui2 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt2");
        var ui3 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt3");
        ui0.ignoreContentAdaptWithSize(true);
        ui1.ignoreContentAdaptWithSize(true);
        ui2.ignoreContentAdaptWithSize(true);
        ui3.ignoreContentAdaptWithSize(true);
        var ui110 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt10");
        var ui111 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt11");
        var ui112 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt12");
        var ui113 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt13");
        ui110.ignoreContentAdaptWithSize(true);
        ui111.ignoreContentAdaptWithSize(true);
        ui112.ignoreContentAdaptWithSize(true);
        ui113.ignoreContentAdaptWithSize(true);
        ui110.setString( this.getRes(1102001) );
        ui111.setString( this.getRes(1102002) );
        ui112.setString( this.getRes(1102003) );
        ui113.setString( this.getRes(1102004) );
        ui0.setString( this.getRes(1101001) );
        ui1.setString( this.getRes(1101002) );
        ui2.setString( this.getRes(1101003) );
        ui3.setString( this.getRes(1101004) );
        this.setTxt(ui0,1101001);
        this.setTxt(ui1,1101002);
        this.setTxt(ui2,1101003);
        //其他UI界面资源条
        var ui10 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt0");
        var ui11 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt1");
        var ui12 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt2");
        var ui3 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt3");
        ui10.ignoreContentAdaptWithSize(true);
        ui11.ignoreContentAdaptWithSize(true);
        ui12.ignoreContentAdaptWithSize(true);
        ui3.ignoreContentAdaptWithSize(true);

        var ui110_0 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt10_0");
        var ui111_0 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt11_0");
        var ui112_0 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt12_0");
        var ui113_0 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("txt13_0");
        ui110_0.ignoreContentAdaptWithSize(true);
        ui111_0.ignoreContentAdaptWithSize(true);
        ui112_0.ignoreContentAdaptWithSize(true);
        ui113_0.ignoreContentAdaptWithSize(true);
        ui110_0.setString( this.getRes(1102001) );
        ui111_0.setString( this.getRes(1102002) );
        ui112_0.setString( this.getRes(1102003) );
        ui113_0.setString( this.getRes(1102004) );

        //ui0.setString( this.getRes(1101001) );
        //ui1.setString( this.getRes(1101002) );
        //ui2.setString( this.getRes(1101003) );
        ui3.setString( this.getRes(1101004) );
        this.setTxt(ui10,1101001);
        this.setTxt(ui11,1101002);
        this.setTxt(ui12,1101003);

        var coinItem = mainData.bagDataList.getItem("itemid",1103001);
        var coin = coinItem==null?0:coinItem.counts;
        var ui4 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("qian_layer").getChildByName("qian");
        ui4.ignoreContentAdaptWithSize(true);
        ui4.setString( coin );//StringUtils.getUnitNumber( coin )
        //second
        ui4 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("qian_layer").getChildByName("qian");
        ui4.ignoreContentAdaptWithSize(true);
        ui4.setString( coin );
    },

    setTxt: function (ui, id) {

        var config = modelMgr.call("Table","getTableList",["City_Storage"]);
        var data = config[this._level-1];
        if(data == undefined || data == null)
        {
            return;
        }
        var resourceObj = data.resource_max;
        //cc.log("$$$$$$$$$$$$$$$ resobj->"+resourceObj);
        if( typeof resourceObj == "string" )
        {
            resourceObj = JSON.parse( resourceObj );
        }
        var max = resourceObj[id]==undefined?0:resourceObj[id];
        //cc.log("仓库等级----->"+this._level+" 资源上限 ->"+max);

        var data = ModuleMgr.inst().getData("CastleModule");
        if( data == null )return 0;
        var dic = data.getNetResource();
        if( dic == undefined ) return 0;
        var n = dic[id];
        if( n == undefined ) return 0;

        ui.setString(StringUtils.getUnitNumberToFixed(n));
        if(n>=max)
        {
            ui.setColor(cc.color("#d45757"));
        }
        else
        {
            ui.setColor(cc.color("#EFEBC6"));
        }
    },

    updateColor: function () {
        var blockData = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(1906001);
        this._level = blockData[0]._building_level;
        this.resUpdata();
    },

    getRes:function( id )
    {
        var data = ModuleMgr.inst().getData("CastleModule");
        if( data == null )return 0;
        var dic = data.getNetResource();
        if( dic == undefined ) return 0;
        var n = dic[id];
        if( n == undefined ) return 0;
        if( n > 0 )
        {
            //cc.log("getRes"+ n );
            var str = StringUtils.getUnitNumberToFixed( n );
            return str;
        }
        return 0;
    },

    _count:0,
    _run:true,
    showMsg:function()
    {
        if( this._count > 0  || this._run == false ) {
            if(AnnouncementData.TEST_LOG)   cc.log(this._count+"***showMsg   return")
            return;
        }

        var gg = ModuleMgr.inst().getData("announcement");
        var data = gg.getAnnouncement();
        if( data == null ) {
            if(AnnouncementData.TEST_LOG)   cc.log("getAnnouncement 空的  ***showMsg   return")
            //gg.resetAnnouncement();
            //this.showMsg();
            this._msgPanel.setVisible(false);
            return;
        }
        this._msgPanel.setVisible(true);
        this._count = data.num;
        //this._text.setString( data._message );
        var strMessage=String(data.getParseMessage());
        this._text.setString(strMessage);
        this._text.setPosition( 960,5 );
        if(AnnouncementData.TEST_LOG)   cc.log(data+"showMsg%%%%%%%%%%");
        this.run();
    },

    run:function()
    {
        var gg = ModuleMgr.inst().getData("announcement");
        gg._runing=true;
        this._text.setPosition( 960,5 );
        var size = this._text.getSize();
        var endPos = cc.p( -size.width, 5 );

        var ac = cc.sequence( cc.moveTo( 15, endPos ), cc.callFunc( this.actionEnd, this ) );//cc.Sequence(cc.DelayTime(2)),
        this._text.runAction( ac );
    },

    actionEnd:function()
    {
        this._count --;
        if( this._count <= 0  )
        {
            this.showMsg();
            var gg = ModuleMgr.inst().getData("announcement");
            if(gg._announcements.length==0) {
                gg._runing=false;
                //this._msgPanel.setVisible(false);
            }
            return;
        }
        this.run();
    },

    headCall:function( node, type )
    {
        if( type != ccui.Widget.TOUCH_ENDED ) return;
        if(mainData.uiData.mapChangeModule == true) {
            return;
        }
        ModuleMgr.inst().openModule("HeadModule");
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    goldCall: function (node, type) {
        if( type != ccui.Widget.TOUCH_ENDED ) return;
        ModuleMgr.inst().openModule("PayModule");
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    backCall:function( node, type )
    {
        if( type != ccui.Widget.TOUCH_ENDED ) return;
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        if( this._modules != null && this._modules.length > 0 )
        {
            var len = this._modules.length;
            var moduleName = this._modules[len-1];//this._modules.pop();
            cc.log("@backCall",this._modules.length );
            ModuleMgr.inst().closeModule(moduleName);
        }
    },
    //同时刷新主界面和UI资源
    onRefreshAll:function(node, type){
        if( type != ccui.Widget.TOUCH_ENDED ) return;
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        this.onFresh(null,null);
        this.onFresh0(null,null);
    },
    //刷新主界面资源显示
    onFresh:function(node, type){
        //if( type != ccui.Widget.TOUCH_ENDED ) return;
        //SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        //cc.log("资源更换显示动画");
        //cc.log(this._arrImg1.length+"1"+this._arrImg2.length+"1"+this._arrTf1.length+"1"+this._arrTf2.length);
        if(this._lock) {
            //cc.error("lock")
            return;
        }
        this._lock=true;
        this._type=1;
        if(this._arrImg1&&this._arrImg1[0].y>MainResourcesModule.DOWNPOSY)  {
            this._type=2;
        }
        this.moveOne(null,0);
    },
    moveOne:function(node,index){
        //cc.log(node+"node"+index+"type"+this._type);
        if(index==4) {
            return;
        }
        var arrImgDown=this._arrImg1;
        var arrImgUp=this._arrImg2;
        if(this._type==2){
            arrImgDown=this._arrImg2;
            arrImgUp=this._arrImg1;
        }
        var moveUp = cc.moveTo(0.1,cc.p(arrImgDown[index].x,MainResourcesModule.UPPOSY) );
        var seq = cc.sequence( moveUp, cc.callFunc( this.moveOne,this, index+1 ));
        arrImgDown[index].runAction(seq);
        var moveDown = cc.moveTo(0.3,cc.p(arrImgUp[index].x,MainResourcesModule.DOWNPOSY-4) );
        var seq2 = cc.sequence( moveDown, cc.callFunc( this.moveBack,this, index ));
        arrImgUp[index].runAction(seq2);

        var arrTfDown=this._arrTf1;
        var arrTfUp=this._arrTf2;
        if(this._type==2){
            arrTfDown=this._arrTf2;
            arrTfUp=this._arrTf1;
        }
        var moveUp2 = cc.moveTo(0.1,cc.p(arrTfDown[index].x,MainResourcesModule.UPPOSY) );
        //var seq = cc.sequence( moveUp, cc.callFunc( this.moveOne,this, index+1 ));
        arrTfDown[index].runAction(moveUp2);
        var moveDown2 = cc.moveTo(0.3,cc.p(arrTfUp[index].x,MainResourcesModule.DOWNPOSY-4) );
        var seq22 = cc.sequence( moveDown2, cc.callFunc( this.moveBack,this, index ));
        arrTfUp[index].runAction(seq22);
    },
    moveBack:function(node,index){
        //cc.log(this._type+"this._type   moveBack"+index);
        var moveBack = cc.moveTo(0.1,cc.p(node.x,MainResourcesModule.DOWNPOSY) );
        var seq = cc.sequence( moveBack,
            cc.callFunc(this.showState,this,index
        ));
        node.runAction(seq);
    },
    showState:function(node,index){
        //cc.error(node+"node"+index);
        if(index==3&&this._lock){
            if(this._type==1)   this._type=2;
            else this._type=1;
            this._lock=false;
        }
    },
    //刷新其他UI界面资源显示
    onFresh0:function(node, type){
        //if( type != ccui.Widget.TOUCH_ENDED ) return;
        //SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        //cc.log("资源更换显示动画");
        //cc.log(this._arrImg1.length+"1"+this._arrImg2.length+"1"+this._arrTf1.length+"1"+this._arrTf2.length);
        if(this._lock0) {
            //cc.error("lock")
            return;
        }
        this._lock0=true;
        this._type0=1;
        if(this._arrImg01&&this._arrImg01[0].y>MainResourcesModule.DOWNPOSY)  {
            this._type0=2;
        }
        this.moveOne0(null,0);
    },
    moveOne0:function(node,index){
        //cc.log(node+"node"+index+"type"+this._type);
        if(index==4) {
            return;
        }
        var arrImgDown=this._arrImg01;
        var arrImgUp=this._arrImg02;
        if(this._type0==2){
            arrImgDown=this._arrImg02;
            arrImgUp=this._arrImg01;
        }
        var moveUp = cc.moveTo(0.1,cc.p(arrImgDown[index].x,MainResourcesModule.UPPOSY) );
        var seq = cc.sequence( moveUp, cc.callFunc( this.moveOne0,this, index+1 ));
        arrImgDown[index].runAction(seq);
        var moveDown = cc.moveTo(0.3,cc.p(arrImgUp[index].x,MainResourcesModule.DOWNPOSY-4) );
        var seq2 = cc.sequence( moveDown, cc.callFunc( this.moveBack0,this, index ));
        arrImgUp[index].runAction(seq2);

        var arrTfDown=this._arrTf01;
        var arrTfUp=this._arrTf02;
        if(this._type0==2){
            arrTfDown=this._arrTf02;
            arrTfUp=this._arrTf01;
        }
        var moveUp2 = cc.moveTo(0.1,cc.p(arrTfDown[index].x,MainResourcesModule.UPPOSY) );
        //var seq = cc.sequence( moveUp, cc.callFunc( this.moveOne,this, index+1 ));
        arrTfDown[index].runAction(moveUp2);
        var moveDown2 = cc.moveTo(0.3,cc.p(arrTfUp[index].x,MainResourcesModule.DOWNPOSY-4) );
        var seq22 = cc.sequence( moveDown2, cc.callFunc( this.moveBack0,this, index ));
        arrTfUp[index].runAction(seq22);
    },
    moveBack0:function(node,index){
        //cc.log(this._type+"this._type   moveBack"+index);
        var moveBack = cc.moveTo(0.1,cc.p(node.x,MainResourcesModule.DOWNPOSY) );
        var seq = cc.sequence( moveBack,
            cc.callFunc(this.showState0,this,index
            ));
        node.runAction(seq);
    },
    showState0:function(node,index){
        //cc.error(node+"node"+index);
        if(index==3&&this._lock0){
            if(this._type0==1)   this._type0=2;
            else this._type0=1;
            this._lock0=false;
        }
    },
    //收取部队成功播放特效
    updateMessage: function (event,data) {
        if (data == CastleNetEvent.SEND_GETBUILD_ARMY) {
            //this.showGetArmyEffect();
            //return;
            //播放特效
            var castleData=ModuleMgr.inst().getData("CastleModule");

            var size = cc.director.getVisibleSize();
            var endP=cc.p(330,size.height-80);
            var radian=Math.atan2(castleData._clickPos.x-endP.x,castleData._clickPos.y-endP.y);
            var angle=MathUtils.radianToAngle(radian);
            //cc.error(angle);
            //cc.error(castleData._clickPos.x+"xy"+castleData._clickPos.y);
            var patrolMove1=new AnimationMove();
            patrolMove1._callBack=this.showGetArmyEffect;
            patrolMove1._owner=this;
            patrolMove1.setAdd(true);
            //patrolMove1._parameter=null;
            patrolMove1.initMoveOnce("castle_armytrain_star",[cc.p(castleData._clickPos.x,castleData._clickPos.y),endP],700,false,false,this.showGetArmyEffect,this);
            patrolMove1.rotation=-(180-angle);//计算角度 旋转

            this.addChild(patrolMove1);
        }
    },
    //星星飞完处理
    showGetArmyEffect:function(){
        cc.error("播放亮一下 特效");
        var size = cc.director.getVisibleSize();
        var csvEffect = ResMgr.inst().getCSV("animationConfig","castle_armytrain_getOneLight");
        var animate=new AnimationSprite();
        animate._removeSelf=true;
        animate.setPosition(cc.p(300,size.height-60));
        animate.setAnimationByCount(csvEffect,1);
        this.addChild(animate);
    },

    msgCall: function ()
    {
        //cc.log("AnnouncementData.SEND_ANNOUNCEMENT_MSG   msgCall")
        this.showMsg();
    },

    _moduleName:null,
    openCall:function( event, moduleName )
    {
        //过滤列表
        if( this._filters&&this._filters[moduleName] != null ) return;

        //根据模块来显示对应东西

        var b = false;

        //是否显示头像
        if( this._heads[moduleName] == true )
        {
            b = true;
        }

        //this._head.setVisible( b );
        //this._back.setVisible( !b );
        this._firstPanel.setVisible(b);
        this._secondPanel.setVisible(!b);

        //this._moduleName = moduleName;
        var exist = false;
        for(var i in this._modules){
            var name = this._modules[i];
            if(name == moduleName) exist = true;
            break
        }
        if( !b && !exist ) {
            var guideData=ModuleMgr.inst().getData("GuideModule");
            if(guideData._guideBean&&(guideData._guideBean._idStep=="2_1"||guideData._guideBean._idStep=="3_1")){
                //cc.log(moduleName+"MaiResouce moudule^%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+guideData._guideBean._idStep)
                EventMgr.inst().dispatchEvent("remove_guide" );//特殊处理 移除上次引导效果
            }
            this._modules.push(moduleName);
        }
        cc.log(this._modules.length+"mainresource打开模块事件处理"+exist+"$$exit b$$"+b);
        EventMgr.inst().dispatchEvent(ChatEvent.SHOW_CHAT,this._modules.length);
    },

    closeCall:function( event, moduleName )
    {
        //当前需要返回的模块不为空
        if(this._modules==null) return;
        //cc.log("@closeCall", this._modules.length );
        //if( this._modules.length > 0 ) return;

        //过滤列表
        if( this._filters[moduleName] != null ) return;

        var b = true;

        //是否显示头像
        if( this._heads[moduleName] == true )
        {
            b = false;
        }

        //this._head.setVisible( b );
        //this._back.setVisible( !b );
        if(this._modules.length==1){
            this._firstPanel.setVisible(b);
            this._secondPanel.setVisible(!b);
        }
        //this._firstPanel.setVisible(b);
        //this._secondPanel.setVisible(!b);

        if(b) this._modules.pop();
        cc.log("@closeCall", this._modules.length );
        EventMgr.inst().dispatchEvent(ChatEvent.SHOW_CHAT,this._modules.length);
    },

    //更新头像icon
    updateHeadIcon: function (event) {
        var head = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("head_layer").getChildByName("head");
        head.loadTexture(ResMgr.inst().getIcoPath(mainData.playerData.headid));
    },

    refreshGoldCounts: function (event,itemid,counts) {
        if(itemid == 1103001) {
            cc.log("金币数量更新~",counts);
            var ui4 = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("qian_layer").getChildByName("qian");
            ui4.ignoreContentAdaptWithSize(true);
            ui4.setString( counts );//StringUtils.getUnitNumber( counts )
            //second
            ui4 = this._ui.getChildByName("Panel_0").getChildByName("res_Panel").getChildByName("qian_layer").getChildByName("qian");
            ui4.ignoreContentAdaptWithSize(true);
            ui4.setString( counts );
        }
    },

    resourceCall:function( event, obj )
    {
        if( obj == null ) return;
        var ui0         = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt0");
        var ui1         = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt1");
        var ui2         = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt2");
        var ui3         = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("txt3");
        var dic         = {"1101001":ui0,"1101002":ui1,"1101003":ui2,"1101004":ui3};
        var resId       = obj.resourceId;
        var v           = obj.differ;
        if( isNaN(v) )v = 0;
        if( v == 0 ) return;

        if(obj.resourceId==1101004 && v>0) return;

        var cor         = cc.color(0,204,0);
        if( v < 0 ) cor = cc.color(255,0,0);
        var ui          = dic[resId];
        if(ui==undefined) return;
        var pos         = ui.getParent().convertToWorldSpace(ui.getPosition());
        var txt         = new ccui.Text();
        txt.setFontSize(25);
        var str         = v;
        if( v < 0 ) str =  v;
        else str        =  "+" + v;
        txt.setString(str);
        txt.setPosition(pos);
        txt.setTextColor( cor );
        var ac = cc.sequence( cc.moveBy( 0.5, cc.p(0,20) ), cc.callFunc( this.txtCall,this) );
        txt.runAction( ac );
        this.addChild( txt );
    },

    txtCall:function( node )
    {
        node.removeFromParent();
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("MainResource引导触发操作doGuide"+guideId);

        this._back.setTouchEnabled(true);
        this._firstPanel.getChildByName("res_Panel").getChildByName("head_layer").getChildByName("head").setTouchEnabled(true);
        this._resPanel.getChildByName("qian_layer").setTouchEnabled(true);
        this._secondPanel.getChildByName("res_Panel").getChildByName("qian_layer").setTouchEnabled(true);
        if(guideId=="2_3"||guideId=="2_9"||guideId=="2_15"||guideId=="4_5"||guideId=="4_7"){
            this._back.setTouchEnabled(false);
            this._firstPanel.getChildByName("res_Panel").getChildByName("head_layer").getChildByName("head").setTouchEnabled(false);
            this._resPanel.getChildByName("qian_layer").setTouchEnabled(false);
            this._secondPanel.getChildByName("res_Panel").getChildByName("qian_layer").setTouchEnabled(false);
        }

    },

    playEffect: function (node) {
        var csv = ResMgr.inst().getCSV("animationConfig","pay_icon");
        var effect =new AnimationSprite();
        effect.setPosition(cc.p(79,22));
        effect.setName("pay_icon");
        effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
        node.addChild(effect);
    },

    effectCallback: function (sender) {
        sender.removeFromParent(true);
    },

    //每隔3秒播放一次
    play: function (node) {
        this.runAction(cc.RepeatForever(cc.Sequence(cc.CallFunc(function(sender){
            sender.playEffect(node);
        }),cc.DelayTime(3))));
    },

    exchangeCallback: function (event, data) {
        if(this._listenData){
            this._listenData.removeListener("attributes",this.attCallback,this);
            this._listenData.addListener("force",this.updateFighting,this);
            this._listenData = null;
        }
        var castleData = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId);
        this._listenData = castleData;
        this._listenData.addListener("attributes",this.attCallback,this);
        this._listenData.addListener("force",this.updateFighting,this);

        this.setProsperity();
        this.setFighting();
    },

    attCallback: function () {
        cc.log("@attCallback------->");
        this.setProsperity();
    },
    updateFighting: function () {
        cc.log("@updateFighting------->");
        this.setFighting();
    },

    //设置繁荣度
    setProsperity: function () {
        var castleData = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId);
        var data_2 = castleData.attributes.getItem("type",2500001).value;
        var fighting = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("Image_1");
        var tx = fighting.getChildByName("Text_6");
        tx.ignoreContentAdaptWithSize(true);
        tx.setString(data_2);
    },

    //设置士兵战斗力
    setFighting: function () {
        var castleData = mainData.mapData.myCastleList.getItem("id",mainData.uiData.currentCastleId);
        var data_2 = castleData.force;
        var fighting = this._ui.getChildByName("Panel").getChildByName("res_Panel").getChildByName("Image_1_0");
        var tx = fighting.getChildByName("Text_6");
        tx.ignoreContentAdaptWithSize(true);
        tx.setString(data_2);
        cc.log("@setFighting------- force ----------->",data_2,castleData.force);
    }
});
MainResourcesModule.DOWNPOSY=77;
MainResourcesModule.UPPOSY=117;