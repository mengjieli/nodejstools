var MapEarth = MapDisplayBase.extend({
    data: null,
    showbg: null,
    show: null,
    farmer: null,
    txt: null,
    level: null,
    ctor: function (data) {
        this._super(MapDisplayType.Earth);
        this.data = data;


        if (data.resourceAmount / data.capacity < (modelMgr.call("Table", "getTableItemByValue", ["Public", 100051]).numerical|| 0.01)) {
            this.showbg = new cc.Sprite("res/fight/ui/" + this.data.config[MapEarth.typeToName[data.productionResourceId]] + "5.png");
        } else {
            this.showbg = new cc.Sprite("res/fight/ui/" + this.data.config[MapEarth.typeToName[data.productionResourceId]] + "6.png");
        }
        this.onRelationChange(this.data.relation);
        this.addChild(this.showbg);

        this.setCoord(this.data.coordX, this.data.coordY);

        this.data.addListener("earthCard", this.updateData, this);
        this.data.addListener("level", this.updateLevel, this);
        this.data.addListener("relation", this.onRelationChange, this);
        this.data.addListener("resourceAmount", this.updateCount, this);
    },
    onRelationChange: function (relation) {
        var show = this.showbg;
        if (this.data.relation == "enemy") {
            show.shaderProgram = (Shader.getRolerColor("R"));
        } else if (this.data.relation == "other") {
            show.shaderProgram = (Shader.getRolerColor("Y"));
        }
    },
    updateLevel: function (value, old) {
        if(this.showbg) {
            this.showbg.getParent().removeChild(this.showbg);
            this.showbg = null;
        }
        var config = ModelManager.getInstance().call("Table","getTableItemByValue",["Territory_levelup",this.data.earthCard]);
        if (this.data.resourceAmount / this.data.capacity < modelMgr.call("Table", "getTableItemByValue", ["Public", 100051]).numerical|| 0.01) {
            this.showbg = new cc.Sprite("res/fight/ui/" + config[MapEarth.typeToName[this.data.productionResourceId]] + "5.png");
        } else {
            this.showbg = new cc.Sprite("res/fight/ui/" + config[MapEarth.typeToName[this.data.productionResourceId]] + "6.png");
        }
        this.addChild(this.showbg);
        this.onRelationChange(this.data.relation);
    },
    updateCount: function (value, old) {
        if ((value / this.data.capacity - (modelMgr.call("Table", "getTableItemByValue", ["Public", 100051]).numerical || 0.01)) *
            (old / this.data.capacity - (modelMgr.call("Table", "getTableItemByValue", ["Public", 100051]).numerical || 0.01)) < 0) {
            if(this.showbg) {
                this.showbg.getParent().removeChild(this.showbg);
                this.showbg = null;
            }
            if (this.data.resourceAmount / this.data.capacity < modelMgr.call("Table", "getTableItemByValue", ["Public", 100051]).numerical|| 0.01) {
                this.showbg = new cc.Sprite("res/fight/ui/" + config[MapEarth.typeToName[this.data.productionResourceId]] + "5.png");
            } else {
                this.showbg = new cc.Sprite("res/fight/ui/" + config[MapEarth.typeToName[this.data.productionResourceId]] + "6.png");
            }
            this.addChild(this.showbg);
            this.onRelationChange(this.data.relation);
        }
    },
    updateData: function () {
        var testTable = modelMgr.call("Table", "getTableItemByValue", ["item", this.data.earthCard]);
        var level = parseInt(testTable.type);
        if (level > this.level) {
            var a = new Animation(MapEarth.levelUpConfig);
            this.addChild(a);
            a.play(1);
        }
        this.level = level;
    },
    getUserAccount: function () {
        return this.data.user;
    },
    isMine: function () {
        return this.data.user == mainData.playerData.account ? true : false;
    },
    getUseAccelerationCard: function () {
        return this.data.useAccelerationCard;
    },
    getProductId: function () {
        return this.data.productionResourceId;
    },
    getEarthCard: function () {
        return this.data.earthCard;
    },
    dispose: function () {
        trace("删除土地");
        this.data.removeListener("earthCard", this.updateData, this);
        this.data.removeListener("level", this.updateLevel, this);
        this.data.removeListener("relation", this.onRelationChange, this);
        this.data.removeListener("resourceAmount", this.updateCount, this);
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
    }
});

MapEarth.farmerConfig = {
    1101001: {
        plist: "res/fight/rolers/farmer.plist",
        name: "11010019_00",
        format: "png",
        start: 0,
        end: 11,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1101002: {
        plist: "res/fight/rolers/farmer.plist",
        name: "11010029_00",
        format: "png",
        start: 0,
        end: 11,
        frameRate: 12,
        x: 0,
        y: 0
    },
    1101003: {
        plist: "res/fight/rolers/farmer.plist",
        name: "11010039_00",
        format: "png",
        start: 0,
        end: 11,
        frameRate: 12,
        x: 0,
        y: 0
    }
};

MapEarth.levelUpConfig = {
    plist: "res/fight/effect/earth/earthLevelUp.plist",
    name: "earthLevelUp_00",
    format: "png",
    start: 0,
    end: 5,
    frameRate: 6,
    x: 0,
    y: 0,
    scaleX: 2,
    scaleY: 2,
    blendMode: "add"
}

MapEarth.typeToName = {
    1101001:"display_farm",
    1101002:"display_lumbering",
    1101003:"display_mine"
}
