/**
 * Created by cgMu on 2015/10/14.
 */

var TileMenuModule = ModuleBase.extend({
    hide:false,

    label1:null,
    label2:null,

    ctor:function() {
        this._super();
    },

    initUI:function() {
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
    },

    touchEvent:function (sender) {
        var tag = sender.getTag();
        var menuData =  ModuleMgr.inst().getData("TileMenuModule");
        var callbackdata = menuData.callback;
        if(callbackdata[tag]) {
            callbackdata[tag].back(tag);
        }
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    destroy:function() {
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
    },

    show:function( data ) {
        var menuData = ModuleMgr.inst().getData("TileMenuModule");

        //null,关闭弹框
        if (data == null) {
            if (menuData.moduleInit) {
                var time = 0.2;
                var index = menuData.tileItemArray.length;
                for(var i = 0; i < menuData.tileItemArray.length; i++) {
                    index--;
                    menuData.tileItemArray[index].runAction( cc.ScaleTo(time,0) );
                }

                if(index==0){
                    if(menuData.closeBack) menuData.closeBack();
                    ModuleMgr.inst().closeModule("TileMenuModule");

                }else{
                    menuData.tileMenuBg.runAction(cc.Sequence(cc.FadeOut(time),cc.CallFunc(function(){
                        if(menuData.closeBack) menuData.closeBack();
                        ModuleMgr.inst().closeModule("TileMenuModule");
                    })));
                }

            }
            menuData.destroy();
            return;
        }

        menuData.setNewTileData(data);

        if (menuData.tileUI.length == 0&&!data.hide) {
            cc.log("没有弹出UI，直接跳转界面");
            return;
        }

        if (!menuData.moduleInit) {
            //加载UI
            var json = ccs.load("res/images/ui/TileMenuModule/MenuLayer.json","res/images/ui/");
            var root = json.node;
            this.addChild(root);
            this.root=root;
            menuData.buildingUI=root;

            this.bgPanel = ccui.helper.seekWidgetByName(root, "menuPanel");
            this.bgPanel.setTouchEnabled(false);
            this.bgPanel.addTouchEventListener(this.touchcallback,this);

            var bgpanel = ccui.helper.seekWidgetByName(root,"Panel_1");
            bgpanel.setTouchEnabled(true);
            bgpanel.addTouchEventListener(this.touchcallback,this);

            var scaleBg = this.bgPanel.getChildByName("Image_2");
            scaleBg.setTouchEnabled(true);
            scaleBg.addTouchEventListener(this.touchcallback,this);

            //名称
            var name = this.bgPanel.getChildByName("Image_1");
            name.setVisible(false);

            if(data.title){
                var title = this.bgPanel.getChildByName("Text_4");
                title.setVisible(true);
                title.ignoreContentAdaptWithSize(true);
                title.setString(data.title);
                title = BorderText.replace(title);
            }
            if(data.player){
                var player = this.bgPanel.getChildByName("Text_2_0");
                player.setVisible(true);
                player.ignoreContentAdaptWithSize(true);
                player.setString(data.player);
                player = BorderText.replace(player);
            }
            if(data.consortia){
                var consortia = this.bgPanel.getChildByName("Text_2_1");
                consortia.setVisible(true);
                consortia.ignoreContentAdaptWithSize(true);
                consortia.setString(data.consortia);
                consortia = BorderText.replace(consortia);
            }
            if(data.name){
                var name = this.bgPanel.getChildByName("Text_2");
                name.setVisible(true);
                name.ignoreContentAdaptWithSize(true);
                name.setString(data.name);
                //name = BorderText.replace(name);
                this.label2 = name;
            }
            if(data.px!=undefined && data.py!=undefined){//地块坐标显示
                var poslabel = this.bgPanel.getChildByName("Text_3");
                poslabel.setVisible(true);
                poslabel.ignoreContentAdaptWithSize(true);
                poslabel.setString("X:"+data.px+" Y:"+data.py);
                //poslabel = BorderText.replace(poslabel);
                this.label1 = poslabel;
            }
            if(data.res){//战略资源剩余产量显示
                var node = this.bgPanel.getChildByName("Text_2_1_0");
                node.setVisible(true);
                node.ignoreContentAdaptWithSize(true);
                node.setString(data.res.num);
                node = BorderText.replace(node);
                var ico = this.bgPanel.getChildByName("Image_3");
                ico.setVisible(true);
                ico.ignoreContentAdaptWithSize(true);
                ico.loadTexture(ResMgr.inst().getIcoPath(data.res.id));
                ico.setPositionX(node.getPositionX()-node.getContentSize().width*0.5-ico.getContentSize().width*0.5);
            }
            if(data.hide){
                this.hide = true;
                var bg = this.bgPanel.getChildByName("Image_2");
                bg.setVisible(false);
                var txt = this.bgPanel.getChildByName("Text_2");
                txt.setPositionY(txt.getPositionY()+70);
                txt = this.bgPanel.getChildByName("Text_3");
                txt.setPositionY(txt.getPositionY()+70);
            }


            //描边
            if(this.label1){
                BorderText.replace(this.label1);
            }
            if(this.label2){
                BorderText.replace(this.label2);
            }
        }

        var scaleBg = this.bgPanel.getChildByName("Image_2");
        scaleBg.ignoreContentAdaptWithSize(true);
        menuData.tileMenuBg=scaleBg;

        var pos = menuData.tilePosition;
        menuData.moduleInit = true;
        this.root.setPosition(cc.p(pos.x-151.5,pos.y-151.5));
        //更新按钮
        if(!this.hide){
            this.refreshMenuItem();
        }

    },

    close:function( ) {

    },

    //背景圆圈触摸响应
    touchcallback: function (sender, type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                mainData.uiData.closeTileMenu++;
                //ModuleMgr.inst().openModule("TileMenuModule");//关闭UI弹框
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    refreshMenuItem: function () {
        var menuData =  ModuleMgr.inst().getData("TileMenuModule");
        var length = menuData.tileItemArray.length;

        for (var i = 0; i < length; i++) {
            if (menuData.tileItemArray[i]) {
                menuData.tileItemArray[i].removeFromParent(true);
                menuData.tileItemArray[i] = null;
            }
        }

        menuData.tileItemArray=[];

        var counts = menuData.tileUI.length;
        if(counts<4){
            menuData.tileMenuBg.loadTexture("zjm_tubiaodi23.png",ccui.Widget.PLIST_TEXTURE);
        }
        var posArray = menuData.tilePositionArray[counts-1];

        for (var i = 0;i < counts;i++) {
            var titleName = ResMgr.inst().getString(menuData.tileUI[i]+"0");

            var cell = new CustomMenuItem(menuData.tileUI[i]+"3",
                menuData.tileUI[i]+"1",
                titleName,this.touchEvent,null,true);
            cell.setPosition(cc.p((303-63)*0.5,(303-73)*0.5));
            cell.setVisible(false);
            this.bgPanel.addChild(cell);

            //打开动画
            var time = 0.5;
            var move = new cc.MoveTo(time, posArray[i]);
            var action = new cc.EaseExponentialOut(move);
            cell.runAction(cc.Spawn(cc.Show(),action));

            menuData.tileItemArray.push(cell);
        }
    },

    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("TileMenuModule引导触发操作doGuide"+guideId);
        if(guideId=="2_5"||guideId=="2_11"||guideId=="2_17"){
            //1501014
            var menuData =  ModuleMgr.inst().getData("TileMenuModule");
            var callbackdata = menuData.callback;
            if(callbackdata[1501014]) {
                callbackdata[1501014].back(1501014);
            }
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
        else if(guideId=="4_9"){
            //1503003 驻城
            var menuData =  ModuleMgr.inst().getData("TileMenuModule");
            var callbackdata = menuData.callback;
            if(callbackdata[1503003]) {
                callbackdata[1503003].back(1503003);
            }
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },
});