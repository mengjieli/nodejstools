var jc;
(function (jc) {
    var XMLAttribute = (function () {
        function XMLAttribute() {
            this.name = "";
            this.value = "";
        }

        var d = __define, c = XMLAttribute;
        p = c.prototype;
        return XMLAttribute;
    })();
    jc.XMLAttribute = XMLAttribute;
})(jc || (jc = {}));
