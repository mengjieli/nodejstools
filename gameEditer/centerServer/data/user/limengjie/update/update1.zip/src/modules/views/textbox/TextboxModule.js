/**
 * Created by admin on 2016/1/6.
 */
var TextboxModule = ModuleBase.extend({
    _ui: null,//ui
    _tf:null,//输入文本
    _close:null,//关闭×

    _cnW:null,//中文字宽
    _enW:null,//英文字宽
    _cnH:null,//中文字高
    ctor: function ()
    {
        this._super();
    },
    initUI: function ()
    {
        var en= cc.LabelTTF.create( "A","微软雅黑" ,TextboxModule.WORDS_SIZE ).getContentSize();
        var cn = cc.LabelTTF.create( "中","微软雅黑" ,TextboxModule.WORDS_SIZE ).getContentSize();
        this._cnW=cn.width;
        this._cnH=cn.height;
        this._enW=en.width;

        this._ui = ccs.load("res/images/ui/textbox/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );
        this._tf=this._ui.getChildByName("Panel_2").getChildByName("tf");
        this._close=this._ui.getChildByName("Panel_2").getChildByName("close");
        this._ui.getChildByName("Panel_1").addTouchEventListener(this.onClose, this);
        this._close.setVisible(false);

        this._size = cc.director.getVisibleSize();
        this._ui.setContentSize(this._size);
        ccui.helper.doLayout(this._ui);

        EventMgr.inst().addEventListener("show_text", this.showString, this);
    },
    //
    show:function( data )
    {
        cc.log(" 文本框  show------------");
        if(data&&data.str){
            //this._tf.setString(data.str);
            this.showString(null,data.str);
        }

    },
    //调整文本换行
    showString:function(type,str){

        var newStr=this.setWordsHeight(str);
        if(this._tf)    this._tf.setString(newStr);
    },
    setWordsHeight:function(str){
        var index=str.indexOf("\n");
        //cc.log(str+"设置文本文字行数等"+index+"index"+str.length+"length<"+(str=="\n"));
        //if(index>0){
        //    var newStr=str.slice(index);
        //    cc.log(newStr+"newStr");
        //    this._lineNum+=1;
        //    this.setWordsHeight(newStr);
        //    return str;
        //}
        var strW=0;//字符宽
        var arrIndex=[];
        for( var i=0; i<str.length; i++ ) {
            var enAscii = str.charCodeAt(i);
            var oneW=null;
            if( enAscii >= 32 && enAscii <= 126 )
            {
                oneW= this._enW;
            }
            else{
                oneW= this._cnW;
            }
            strW+=oneW;
            if(strW>=this._tf.width){
                //this._lineNum+=1;
                strW=(strW>this._tf.width)?oneW:0;
                arrIndex.push(i);
            }
        }
        //自动换行数字有BUG   手动换行
        if(arrIndex.length>0){
            for(var i=arrIndex.length-1;i>-1;i--){
                str=str.substr(0,arrIndex[i])+"\n"+str.substr(arrIndex[i]);
            }
        }
        //cc.log(this._lineNum+"行数"+this._tfWords.getContentSize().height+50);
        return str;
    },
    //清除方法
    destroy:function() {
        cc.log(" 文本框destroy");
        EventMgr.inst().removeEventListener("show_text", this.showString, this);
    },
    onClose:function(node,type)
    {
        if( type == ccui.Widget.TOUCH_ENDED ){
            ModuleMgr.inst().closeModule("TextboxModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },
})
//静态属性
TextboxModule.WORDS_SIZE = 22;//文本字号