var BattleModeCommand = (function (_super) {
    __extends(BattleModeCommand, _super);

    function BattleModeCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
    }

    var d = __define, c = BattleModeCommand;
    p = c.prototype;

    /**
     * 初始化
     * @param params Object
     */
    p.init = function (params) {
        mainData.uiData.map.addListener("inFight",this.fightChange,this);
    }

    p.fightChange = function(val) {
        if(val) {
            SoundPlay.playEffect("res/sounds/battle_alert.mp3");
        }
    }

    return BattleModeCommand;
})(CycleCommand);