var TestCase = (function () {
    function TestCase() {
        this.name = "123sasss";
        this.testEventDispatcher();
    }
    TestCase.prototype.testEventDispatcher = function () {
        trace("[Test Case] EventDispatcher ---------------------");
        var e = new flower.Event("a");
        e.data = 123;
        var ed = new flower.EventDispatcher();
        var func = function (event) {
            if (event.type != "a") {
                trace("  type --", false);
            }
            if (event.data != 123) {
                trace("  data --", false);
            }
        };
        ed.addListener("a", func, null);
        ed.dispatch(e);
        if (ed.hasListener("a") == false) {
            trace("  addListener --", false);
        }
        ed.removeListener("a", func, null);
        if (ed.hasListener("a") == true) {
            trace("  removeListener --", false);
        }
        e = new flower.Event("b");
        e.data = this.name;
        ed.once("b", this.eventBack, this);
        ed.dispatch(e);
        if (ed.hasListener("b")) {
            trace("  once --", false);
        }
        trace("-------------------------------------------------\n");
    };
    TestCase.prototype.eventBack = function (event) {
        if (event.data != this.name) {
            trace("  data --", false);
        }
    };
    return TestCase;
})();
//# sourceMappingURL=TestCase.js.map