/**
 * Created by Administrator on 2015/12/14.
 */

var LoginUI = cc.Node.extend({

    _ui:null,

    _loginBtn:null,
    _userNameInput:null,
    _passwordInput:null,
    _errorName:null,
    _errorPassword:null,

    _loginCtlTimer:null,

    ctor:function( )
    {
        this._super();
        this._loginCtlTimer = -1;

    },

    onEnter: function()
    {
        this._super();
        this._ui = ccs.load("res/images/ui/login/login.json","res/images/ui/").node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName("ui_mianban");
        uiPanel.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(false) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //登录按钮
        var but = this._ui.getChildByName("ui_mianban" ).getChildByName("denglu");
        but.addTouchEventListener( this.loginCall, this );
        this._loginBtn = but;

        //用户名，密码输入文本框
        this._userNameInput = this._ui.getChildByName("ui_mianban" ).getChildByName("TextField_1");
        this._userNameInput.setTag(1);
        this._userNameInput.addEventListener(this.inputCallback,this);
        this._userNameInput.setMaxLength(50);
        this._passwordInput = this._ui.getChildByName("ui_mianban" ).getChildByName("TextField_2");
        this._passwordInput.setTag(2);
        this._passwordInput.addEventListener(this.inputCallback,this);

        this._userNameInput.addEventListener(this.onTfInput, this);
        this._passwordInput.addEventListener(this.onTfInput, this);

        this._errorName = uiPanel.getChildByName("error_1");
        this._errorName.ignoreContentAdaptWithSize(true);
        this._errorName.setString(ResMgr.inst().getString("login_25"));
        this._errorName.setVisible(false);
        this._errorPassword = uiPanel.getChildByName("error_2");
        this._errorPassword.ignoreContentAdaptWithSize(true);
        this._errorPassword.setString(ResMgr.inst().getString("login_26"));
        this._errorPassword.setVisible(false);

        //用户协议
        var verify = this._ui.getChildByName("ui_mianban" ).getChildByName("xieyi");
        verify.addTouchEventListener( this.verifyCall, this );

        //用户注册
        var reg = this._ui.getChildByName("ui_mianban" ).getChildByName("yongh_zhuce");
        reg.addTouchEventListener( this.regCall, this );
        var reg_x = reg.getChildByName("Panel_3");
        //找回密码
        var pass = this._ui.getChildByName("ui_mianban" ).getChildByName("mima");
        pass.addTouchEventListener( this.passwordCall, this );
        var pass_x = pass.getChildByName("Panel_3_0");

        var verify_one = this._ui.getChildByName("ui_mianban" ).getChildByName("xieyi_shuoming");
        var verify_two = this._ui.getChildByName("ui_mianban" ).getChildByName("xieyi");
        verify_one.ignoreContentAdaptWithSize(true);
        verify_two.ignoreContentAdaptWithSize(true);
        verify_one.setString( ResMgr.inst().getString("login_3") );
        verify_two.setString( ResMgr.inst().getString("login_4") );
        var w_x = verify_one.getContentSize().width + verify_two.getContentSize().width + 5;
        w_x = -(w_x >> 1)
        verify_one.setPositionX( w_x );
        var onePos = verify_one.getPositionX();
        verify_two.setPositionX( onePos + verify_one.getContentSize().width + 5 );
        //设置文本
        but.setTitleText( ResMgr.inst().getString("login_2"));
        //this._userNameInput.ignoreContentAdaptWithSize(true);
        this._userNameInput.setPlaceHolder( ResMgr.inst().getString("login_0") );
        //this._passwordInput.ignoreContentAdaptWithSize(true);
        this._passwordInput.setPlaceHolder( ResMgr.inst().getString("login_1") );
        reg.ignoreContentAdaptWithSize(true);
        reg.setString( ResMgr.inst().getString("login_5") );
        pass.ignoreContentAdaptWithSize(true);
        pass.setString( ResMgr.inst().getString("login_6") );

        var s = reg.getContentSize();
        s.height = 2;
        reg_x.setContentSize( s );
        var s = pass.getContentSize();
        s.height = 2;
        pass_x.setContentSize( s );

        if(startGameData.autoLogin==1){
            this.autoLoginAuthenticate();//自动登录
        }

        NetMgr.inst().addEventListener(0, this.netGetError, this);
    },

    onExit:function()
    {
        this._super();
        if(-1 != this._loginCtlTimer)
        {
            clearTimeout(this._loginCtlTimer);
            this._loginCtlTimer = null;
        }
        NetMgr.inst().removeEventListener(0, this.netGetError, this);
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /*******************************
     * 控件回调
     */

    inputCallback: function (node, type) {
        var tag = node.getTag();
        if(tag==1){
            switch (type){
                case ccui.TextField.EVENT_ATTACH_WITH_IME:
                    this._errorName.setVisible(false);
                    break;
                case ccui.TextField.EVENT_DETACH_WITH_IME:
                    break;
                case ccui.TextField.EVENT_INSERT_TEXT:
                    //var arr = text.split(" ");
                    //cc.log("EVENT_INSERT_TEXT",text);
                    //cc.log("@EVENT_INSERT_TEXT",arr[0]);

                    var text = node.getString();
                    var arr = text.split("\r");
                    node.setString(arr[0]);
                    break;
            }
        }
        else if (tag==2){
            switch (type){
                case ccui.TextField.EVENT_ATTACH_WITH_IME:
                    //cc.log("@EVENT_ATTACH_WITH_IME 2");
                    break;
                case  ccui.TextField.EVENT_DETACH_WITH_IME:
                    //cc.log("@EVENT_DETACH_WITH_IME 2");
                    break;
                case ccui.TextField.EVENT_INSERT_TEXT:
                    var text = node.getString();
                    var arr = text.split("\r");
                    node.setString(arr[0]);
                    break;
            }
        }
    },

    /**
     * 登录按钮回调
     * @param node
     * @param type
     */
    loginCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            //登录
            this.loginCallback();
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    /**
     * 用户协议
     * @param node
     * @param type
     */
    verifyCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"treaty","ip":null});
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    //获取本地账号信息
    fetchUserInfo : function()
    {
        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var fileExist = jsb.fileUtils.isFileExist(storagePath + "cache");
        cc.log("文件存在标识:" + storagePath);

        if(fileExist)
        {
            var string = jsb.fileUtils.getValueMapFromFile(storagePath + "cache");
            cc.log("cache:" + JSON.stringify(string["lastLoginName"]) + "_" + (string["lastLoginPassword"]) + "_" + (string["lastLoginToken"]));
            return {"username":string["lastLoginName"], "password":string["lastLoginPassword"], "token":string["lastLoginToken"]};
        }
        return null;
    },

    /**
     * 用户注册
     * @param node
     * @param type
     */
    regCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            //登录
            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"register","ip":null});
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    /**
     * 用户找回密码
     * @param node
     * @param type
     */
    passwordCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            //登录
            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"mobile","ip":null});
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    //验证账号是否存在
    //checkAccount: function () {
    //    var account = this._userNameInput.getString();
    //    if(0 == account.length || !CD.isPhoneNum(account))
    //    {
    //        this._errorName.setVisible(true);
    //        return;
    //    }
    //
    //    var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "check";
    //    var url = head;
    //    url += "?accountName=" + account;
    //
    //    NetMgr.inst().sendHttp(url, null, false, function(data, param){
    //            cc.log("checkAccount data:" + data);
    //            var ret = JSON.parse(data);
    //            if(ret)
    //            {
    //                if(0 == ret.errCode)
    //                {
    //                    //用户名不存在
    //                    param.owner._errorName.setVisible(true);
    //                }
    //                else
    //                {
    //                    param.owner._errorName.setVisible(false);
    //                }
    //            }
    //        }, null, {"objs":null, "onAccountStatus":null, "owner":this}
    //    );
    //},

    //token失效时，再次登录
    autoLogin: function () {
        var cache = this.fetchUserInfo();
        if(cache){
            this._loginBtn.setTouchEnabled(false);

            var accountId = cache.username;
            var password = cache.password;
            //var oldToken = cache.token;
            var token = CD.genRandToken();

            var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "check_login";
            var url = head;
            url += "?loginName=" + encodeString(accountId);
            url += "&password=" + encodeString(password);
            url += "&token=" + encodeString(token);

            NetMgr.inst().sendHttp(url, null, false, function(data, param){
                cc.log("autoLogin 接收:" + data);
                param.owner._loginBtn.setTouchEnabled(true);
                var ret = JSON.parse(data);
                if(ret)
                {
                    switch(ret.err_code)
                    {
                        case 0:
                            cc.error("用户登录验证成功，登录ing");
                            var hasBeenActivated = ret.hasBeenActivated;
                            if(hasBeenActivated){
                                ModuleMgr.inst().getData("GameLoginModule").recordUserInfo([accountId, password, token]);
                                param.request.apply(param.owner,[accountId, password, token]);
                            }
                            else{
                                cc.log("@打开激活界面，",accountId,token);
                                ModuleMgr.inst().openModule("GameLoginModule",{"ui":"key","ip":accountId,"tk":token});
                                modelMgr.call("NetWiating", "closeView", []);
                            }
                            break;
                        default:
                            var value = ResMgr.inst().getString(ret.err_code);
                            ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                            modelMgr.call("NetWiating", "closeView", []);
                            break;
                    }
                }
                else
                {
                    var value = ResMgr.inst().getString("denglu_20");
                    ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                    modelMgr.call("NetWiating", "closeView", []);
                }
            }, null, {"objs":null, "request":this.autoLoginPrepare, "owner":this});
        }
    },

    //登录
    loginCallback: function () {
        var account = this._userNameInput.getString();
        if(0 == account.length)//!CD.isPhoneNum(account)
        {
            this._errorName.setVisible(true);
            return;
        }


        var password = this._passwordInput.getString();
        var token = null;
        var cache = this.fetchUserInfo();
        if(null != cache && undefined != cache && cache.token)
        {
            token = cache.token;
        }
        else
        {
            token = CD.genRandToken();
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "check_login";
        var url = head;

        //var encodestring = ModuleMgr.inst().getData("GameLoginModule").encodeString()

        url += "?loginName=" + encodeString(account);
        url += "&password=" + encodeString(password);
        url += "&token=" + encodeString(token);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
            cc.log("loginCallback 接收:" + data);
            var ret = JSON.parse(data);
            if(ret)
            {
                switch(ret.err_code)
                {
                    case 80102://密码不正确
                        param.owner._errorPassword.setVisible(true);
                        break;
                    case 80105:
                        var value = ResMgr.inst().getString("denglu_19");
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        break;
                    case 71203://账号被封
                        var value = ResMgr.inst().getString("denglu_19");
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        break;
                    case 71205:
                        //var value = ResMgr.inst().getString("71205");
                        //ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        param.owner.autoLogin();
                        break;
                    case 0:
                        cc.error("用户登录验证成功，登录ing");
                        var hasBeenActivated = ret.hasBeenActivated;
                        if(hasBeenActivated){
                            ModuleMgr.inst().getData("GameLoginModule").recordUserInfo([account, password, token]);
                            param.request.apply(param.owner,[account, password, token]);
                        }
                        else{
                            cc.log("@打开激活界面，",account,token);
                            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"key","ip":account,"tk":token});
                        }
                        break;
                    default:
                        var value = ResMgr.inst().getString(ret.err_code);
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        break;
                }
            }
            else
            {
                var value = ResMgr.inst().getString("denglu_20");
                ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
            }
        }, null, {"objs":null, "request":this.loginRequest, "owner":this});
    },

    //历史登陆存在
    autoLoginAuthenticate : function()
    {
        var cache = this.fetchUserInfo();
        if(cache)
        {
            var accountId = cache.username;
            var password = cache.password;
            var oldToken = cache.token;

            if(accountId&&oldToken==undefined){
                this._userNameInput.setString(accountId);
                return;
            }

            //this._loginBtn.setTouchEnabled(false);
            modelMgr.call("NetWiating", "openView", []);


            var token = CD.genRandToken();
            var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "renewal_token";
            var url = head;
            url += "?loginName=" + encodeString(accountId);
            url += "&oldToken=" + encodeString(oldToken);
            url += "&token=" + encodeString(token);

            NetMgr.inst().sendHttp(url, null, false, function(data, param){
                    cc.log("收到:" + data);
                    //param.owner._loginBtn.setTouchEnabled(true);

                    var ret = JSON.parse(data);
                    if(ret)
                    {
                        switch(ret.err_code)
                        {
                            case 0:
                                cc.log("身份刷新成功，登陆ing");
                                ModuleMgr.inst().getData("GameLoginModule").recordUserInfo([accountId, password, token]);
                                param.changeMode.apply(param.owner, [accountId, password, token]);
                                break;
                            case 71205:
                                //var value = ResMgr.inst().getString("71205");
                                //ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                                param.owner.autoLogin();
                                break;
                            default:
                                var value = ResMgr.inst().getString(ret.err_code);
                                ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                                modelMgr.call("NetWiating", "closeView", []);
                                break;
                        }
                    }
                    else
                    {
                        //ModuleMgr.inst().closeModule("NetworkWaitModule");
                        var value = ResMgr.inst().getString("denglu_24");
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        modelMgr.call("NetWiating", "closeView", []);
                    }

                    //modelMgr.call("NetWiating", "closeView", []);
                },
                function(url, response)
                {
                    if("" == response)
                    {
                        cc.error("服务器连接失败");
                        //modelMgr.call("NetWiating", "closeView", []);

                        var value = ResMgr.inst().getString("denglu_16");
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2, "okFun":function(){cc.director.end()}});
                    }
                },
                {"objs":null, "changeMode":this.autoLoginPrepare, "owner":this});
        }
    },

    autoLoginPrepare : function(v1, v2, v3)
    {
        cc.log("ac:" + v1);
        cc.log("pw:" + v2);
        cc.log("tok:" + v3);
        this._userNameInput.setString(v1);
        this._passwordInput.setString(v2);

        this.loginRequest(v1, v2, v3);
    },

    loginRequest : function (v1, v2, v3) {
        ReconnectionMgr.getInstance();
        NetMgr.inst().connectWebSocket(GameConfig.serverAddress);
        NetMgr.inst().addEventListener(NetEvent.socket.SOCKET_CONNECT, function () {
            var account = v1;
            var password = v2;
            var token = v3;
            cc.error("token:" + token);
            cc.error("account:" + account);
            cc.error("password:" + password);

            var msg = new SocketBytes();
            msg.writeUint(200);//账号登录
            msg.writeUint(GameConfig.PLATFORM_DEFAULT_ID);
            msg.writeString(account);
            msg.writeString(token);
            NetMgr.inst().send(msg);
        },this);
    },

    netGetError : function (cmd,data) {
        if(cmd == 0){
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            cc.log("2@netGetError",data0,data1,data2);
            if(data0 == 200 && data1 == 0){
                ModuleMgr.inst().openModule("GameLoginModule",{"ui":"loading","login":true});
                startGameData.step = 6;
                modelMgr.call("NetWiating", "closeView", []);
            }
            else if(data1 == 71240){
                this._passwordInput.setString("");
                var value = ResMgr.inst().getString(71240);
                ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                modelMgr.call("NetWiating", "closeView", []);
            }
        }
    },

    //文本响应事件
    onTfInput: function (node, type) {
        //cc.log(cc.sys.platform+"sys"+cc.sys.os+(cc.sys.os=="Windows"));
        if(cc.sys.os=="Windows") return;//电脑调试return
        if (type == ccui.TextField.EVENT_ATTACH_WITH_IME) {
            cc.log("焦点定位到文本 可输入文本"+node.getString());
            ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
        }
        else if (type == ccui.TextField.EVENT_DETACH_WITH_IME) {
            //cc.log("焦点delete@@@@@@@@@@@@@@@@@@@@@%%%%%%%%%%%%%%");
            ModuleMgr.inst().closeModule("TextboxModule");
        }
        else if (type == ccui.TextField.EVENT_INSERT_TEXT) {
            //cc.log("文本事件：EVENT_INSERT_TEXT");
            //ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
            EventMgr.inst().dispatchEvent("show_text",node.getString());
        }
        else if (type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            //cc.log("文本事件：EVENT_DELETE_BACKWARD");
            //ModuleMgr.inst().openModule("TextboxModule",{str:node.getString()});
            EventMgr.inst().dispatchEvent("show_text",node.getString());
        }

    },



});