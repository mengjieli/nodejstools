var flower;
(function (flower) {
    var Scanner = (function () {
        function Scanner() {
            this.start = flower.ScannerTable.start;
            this.moves = flower.ScannerTable.moves;
            this.endInfos = flower.ScannerTable.endInfos;
            this.befores = flower.ScannerTable.befores;
            this.inputs = flower.ScannerTable.inputs;
            this.tokenPos = 0;
            this.tokenContent = null;
            this.tokenContentLength = 0;
            this.commonInfo = null;
            this.lastToken = null;
        }
        Scanner.prototype.setCommonInfo = function (info) {
            this.commonInfo = info;
        };
        Scanner.prototype.setTokenContent = function (content) {
            content += "\r\n";
            this.tokenContent = content;
            this.tokenPos = 0;
            this.tokenContentLength = content.length;
            this.lastToken = null;
        };
        Scanner.prototype.getNextToken = function () {
            if (this.tokenContentLength == 0) {
                return null;
            }
            var recordPos = this.tokenPos;
            var ch;
            var findStart = this.tokenPos;
            var state = this.start;
            var receiveStack = [];
            var lastEndPos = -1;
            var lastEndState = -1;
            while (this.tokenPos < this.tokenContentLength) {
                ch = this.tokenContent.charCodeAt(this.tokenPos);
                if (ch == 92 && this.tokenPos < this.tokenContent.length) {
                    this.tokenPos++;
                }
                if (this.inputs[ch] == undefined) {
                    ch = 20013;
                }
                if (this.moves[state] == undefined || this.moves[state][ch] == undefined)
                    break;
                state = this.moves[state][ch];
                if (this.endInfos[state] != undefined) {
                    lastEndPos = this.tokenPos;
                    lastEndState = state;
                    receiveStack.push([this.tokenPos, state]);
                    if (this.endInfos[state] == true)
                        break;
                }
                this.tokenPos++;
            }
            var last;
            if (receiveStack.length) {
                while (receiveStack.length) {
                    last = receiveStack.pop();
                    lastEndPos = last[0];
                    lastEndState = last[1];
                    if (this.lastToken == null || this.befores[lastEndState] == undefined || (this.befores[lastEndState] != undefined && this.befores[lastEndState][this.lastToken] != undefined)) {
                        this.tokenPos = lastEndPos + 1;
                        var str = this.tokenContent.slice(findStart, this.tokenPos);
                        var result = this.getTokenComplete(lastEndState, str);
                        if (result == null)
                            return this.getNextToken();
                        this.commonInfo.tokenPos = findStart;
                        if (flower.TokenType.TokenTrans[result] != undefined)
                            this.lastToken = this.commonInfo.tokenValue;
                        else
                            this.lastToken = result;
                        return result;
                    }
                }
            }
            if (this.tokenPos < this.tokenContent.length) {
            }
            else {
                this.commonInfo.tokenValue = null;
                return flower.TokenType.Type.endSign;
            }
            return null;
        };
        Scanner.prototype.getFilePosInfo = function (content, pos) {
            var line = 1;
            var charPos = 1;
            for (var i = 0; i < content.length && pos > 0; i++) {
                charPos++;
                if (content.charCodeAt(i) == 13) {
                    if (content.charCodeAt(i + 1) == 10) {
                        i++;
                        pos--;
                    }
                    charPos = 1;
                    line++;
                }
                else if (content.charCodeAt(i + 1) == 10) {
                    if (content.charCodeAt(i) == 13) {
                        i++;
                        pos--;
                    }
                    charPos = 1;
                    line++;
                }
                pos--;
            }
            return "第" + line + "行，第" + charPos + "个字符(后面10个):" + content.slice(charPos, charPos + 10);
        };
        Scanner.prototype.installId = function (commonInfo, content) {
            if (commonInfo.ids[content]) {
                return commonInfo.ids[content];
            }
            var id = { "name": content };
            commonInfo.ids[content] = id;
            return id;
        };
        Scanner.prototype.getTokenComplete = function (token, content) {
            this.commonInfo.tokenValue = null;
            switch (token) {
                case 1:
                    return null;
                case 35:
                    return flower.TokenType.Type["null"];
                case 24:
                    return flower.TokenType.Type["as"];
                case 25:
                    return flower.TokenType.Type["is"];
                case 36:
                    return flower.TokenType.Type["true"];
                case 37:
                    return flower.TokenType.Type["false"];
                case 3:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 4:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 5:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 6:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 7:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 8:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 9:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 10:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 11:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 12:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 13:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 28:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 29:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 16:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 14:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 15:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 17:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 27:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 26:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 34:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 33:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 18:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 19:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 20:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 21:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 22:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["op"];
                case 23:
                case 40:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["valueInt"];
                case 31:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["valueOxInt"];
                case 30:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["valueNumber"];
                case 32:
                    this.commonInfo.tokenValue = content;
                    return flower.TokenType.Type["valueString"];
                case 2:
                case 39:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 49:
                case 50:
                case 51:
                case 52:
                case 53:
                    this.commonInfo.tokenValue = this.installId(this.commonInfo, content);
                    return flower.TokenType.Type["id"];
            }
            return null;
        };
        return Scanner;
    })();
    flower.Scanner = Scanner;
})(flower || (flower = {}));
//# sourceMappingURL=Scanner.js.map