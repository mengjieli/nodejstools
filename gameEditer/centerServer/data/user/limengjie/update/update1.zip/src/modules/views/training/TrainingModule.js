/**
 * Created by cgMu on 2016/1/19.
 */

var TrainingModule = ModuleBase.extend({
    //_root:null,
    _resIcon:null,
    _resCounts:null,

    _tabRoot:null,
    _tabBtnList:null,
    _tabBtnTitleList:null,

    _itemRoot:null,
    _pageview:null,
    _scrollview:null,
    //_leftScrollView:null,
    //leftStartPos:null,
    resScrollView:null,
    resroot:null,
    resItemVector:null,
    _array:null,

    itemIndex:0,
    itemCounts:0,
    itemIdList:null,

    _timeIcon:null,
    _timeLabel:null,
    _btn:null,
    _btnTitle:null,
    _describeLabel:null,
    _numberLabel:null,
    _slider:null,

    configName:null,
    blockId:null,//地块索引ID
    campId:null,//建筑ID 马厩 兵营 器械 靶场
    campLv:null,
    tabIndex:null,//当前显示的标签索引
    //selectingArmId:null,//当前显示的士兵ID  this.itemIdList[this.itemIndex]
    unlocked:false,//标识当前显示的士兵是否解锁
    unlimited:false,//标识是否满足条件
    armsMax:0,//造兵上限
    arms:0,//当前造兵数量

    _rightPanel_top:null,
    _rightPanel_top_0:null,
    _rightPanel_bottom:null,
    _rightPanel_bottom_0:null,

    _leftBtn:null,
    _rightBtn:null,
    _gotLabel:null,

    needRes:null,
    _resNumLabelList:null,
    armTime:null,//单兵建造时间
    dissolveBtn:null,

    ctor:function() {
        this._super();

        this._tabBtnList = [];
        this._tabBtnTitleList = [];

        this.tabIndex = 0;
        this.resItemVector = [];


        this._array = [];

        //EventMgr.inst().addEventListener(TrainingEvent.UNLOCK_SUCCESS,this.unlockCallback,this);
        //EventMgr.inst().addEventListener(CastleEvent.UPDATE_RESOURCE, this.setRes, this);
        EventMgr.inst().addEventListener("dissolve_callback",this.dissolve,this);
        EventMgr.inst().addEventListener( "using_token", this.usingCallback,this );
    },

    initUI:function() {
        var json = ccs.load("res/images/ui/training/trainingLayer2.json","res/images/ui/");
        var root_ = json.node;
        this.addChild(root_);

        //适配
        var size = cc.director.getVisibleSize();
        root_.setContentSize(size);
        ccui.helper.doLayout(root_);

        var root = root_.getChildByName("Panel_1");
        sizeAutoLayout(root);
        //this._root = root;

        var Image_7 = root.getChildByName("Image_7");
        //Image_7.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(false) );
        sizeAutoLayout(Image_7);
        posAutoLayout(Image_7,0.5);

        var Image_8 = root.getChildByName("Image_8");
        sizeAutoLayout(Image_8);

        var Panel_55  = root.getChildByName("Panel_55");
        sizeAutoLayout(Panel_55);

        var Image_151  = root.getChildByName("Image_151");
        posAutoLayout(Image_151);

        //var Image_152 = root.getChildByName("Image_152");
        //posAutoLayout(Image_152);

        //arm button tab root
        var Button_7 = root.getChildByName("Button_7");
        Button_7.addTouchEventListener(this.itemCallback,this);
        Button_7.setVisible(false);
        posAutoLayout(Button_7);
        this._tabRoot = Button_7;

        var Button_5 = root.getChildByName("Button_5");
        posAutoLayout(Button_5);
        var tit = Button_5.getChildByName("Text_44");
        tit.ignoreContentAdaptWithSize(true);
        tit.setString(ResMgr.inst().getString("message_2"));

        var Image_10 = root.getChildByName("Image_10");
        posAutoLayout(Image_10);

        var Image_154 = root.getChildByName("Image_154");
        sizeAutoLayout(Image_154);
        posAutoLayout(Image_154,0.5);

        //var Image_182 = root.getChildByName("Image_182");
        //sizeAutoLayout(Image_182);
        //var Image_182_0 = root.getChildByName("Image_182_0");
        //sizeAutoLayout(Image_182_0);

        var Button_14_0 = root.getChildByName("Button_14_0");
        Button_14_0.addTouchEventListener(this.leftCallback,this);
        posAutoLayout(Button_14_0,0.5);
        var Button_14 = root.getChildByName("Button_14");
        Button_14.addTouchEventListener(this.rightCallback,this);
        posAutoLayout(Button_14,0.5);

        this._leftBtn = Button_14_0;
        this._rightBtn = Button_14;
        //this.setButtonEnabled(this._leftBtn,false);

        var Image_251 = root.getChildByName("Image_251");
        Image_251.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(false) );
        Image_251.setVisible(false);
        this._itemRoot = Image_251;

        var PageView_1 = root.getChildByName("PageView_1");
        PageView_1.addEventListener(this.pageViewEvent,this);
        sizeAutoLayout(PageView_1);
        this._pageview = PageView_1;
        //PageView_1.setVisible(false);


        //var ScrollView_2 = root.getChildByName("ScrollView_2");
        //ScrollView_2.setVisible(true);
        //ScrollView_2.addTouchEventListener(this.leftScrollViewCallback,this);
        //sizeAutoLayout(ScrollView_2);
        //this._leftScrollView = ScrollView_2;

        var ScrollView_1 = root.getChildByName("ScrollView_1");
        this.resScrollView = ScrollView_1;
        posAutoLayout(ScrollView_1,0.5);
        sizeAutoLayout(ScrollView_1,0.5);


        var resRoot = root.getChildByName("Panel_1");
        resRoot.setVisible(false);
        this.resroot = resRoot;

        var Image_232  = root.getChildByName("Panel_10");
        var Text_63 = Image_232.getChildByName("Text_63");
        Text_63.ignoreContentAdaptWithSize(true);
        this._describeLabel = Text_63;

        //var Image_234_0  = root.getChildByName("Image_234_0");
        //posAutoLayout(Image_234_0,0.5);
        //sizeAutoLayout(Image_234_0);

        //var Image_234 = root.getChildByName("Image_234");
        //posAutoLayout(Image_234,0.5);
        //sizeAutoLayout(Image_234,0.5);

        //scrollview
        //var ScrollView_1 = root.getChildByName("ScrollView_1");
        //sizeAutoLayout(ScrollView_1);
        //this._scrollview = ScrollView_1;

        var Text_66 = root.getChildByName("Image_237").getChildByName("Text_66");
        Text_66.ignoreContentAdaptWithSize(true);
        this._gotLabel = Text_66;
        this.setGotLabel(0);

        //var rightPanel_top = ScrollView_1.getChildByName("rightPanel_top");
        //var rightPanel_bottom = root.getChildByName("rightPanel_bottom");
        //var rightPanel_top_0 = ScrollView_1.getChildByName("rightPanel_top_0");
        //var rightPanel_bottom_0 = root.getChildByName("rightPanel_bottom_0");

        //this._rightPanel_top = rightPanel_top;
        //this._rightPanel_top_0 = rightPanel_top_0;
        //this._rightPanel_bottom = rightPanel_bottom;
        //this._rightPanel_bottom_0 = rightPanel_bottom_0;
        //this.initRightPanelTopEx(rightPanel_top);
        this.initRightPanelBottomEx(root);

        //解散
        var Image_236 = root.getChildByName("Image_236");
        var Text_65 = Image_236.getChildByName("Text_65");
        Text_65.ignoreContentAdaptWithSize(true);
        Text_65.setString(ResMgr.inst().getString("train_8"));
        //Image_236.setVisible(false);
        Image_236.setTouchEnabled(true);
        Image_236.addTouchEventListener(this.dissolveCall,this);
        this.dissolveBtn = Image_236;

        //训练
        var Button_10 = root.getChildByName("Button_10");
        Button_10.addTouchEventListener(this.btncallback,this);
        var Text_50 = Button_10.getChildByName("Text_50");
        Text_50.ignoreContentAdaptWithSize(true);
        Text_50 = BorderText.replace(Text_50);
        this._btn = Button_10;
        this._btnTitle = Text_50;

        //资源
        //var Image_152 = root.getChildByName("Image_152");
        //var Image_153 = Image_152.getChildByName("Image_153");
        //Image_153.ignoreContentAdaptWithSize(true);
        //this._resIcon = Image_153;
        //var Text_26 = Image_152.getChildByName("Text_26");
        //Text_26.ignoreContentAdaptWithSize(true);
        //this._resCounts = Text_26;

        //训练时间
        var Image_231 = root.getChildByName("Image_231");
        this._timeIcon = Image_231;
        var Text_62 = root.getChildByName("Text_62");
        Text_62.ignoreContentAdaptWithSize(true);
        this._timeLabel = Text_62;

    },

    initResScrollView: function (armConfig) {
        this.resScrollView.removeAllChildren();
        this.resItemVector = [];

        var resdata = eval("(" + armConfig.recruit_resource + ")");
        var reslist = [];
        for(var i in resdata){
            var item={};
            item.itemid = i;
            item.counts = resdata[i];
            reslist.push(item);
        }
        this.needRes = reslist;

        var counts = this.needRes.length;
        var size = this.resroot.getContentSize();
        var gap  = 5 ;
        var totalHeight = (size.height+gap)*counts+gap;
        totalHeight = Math.max(totalHeight,size.height);

        cc.log("@------>",counts);

        for(var i = 0; i < counts; i++){
            var it = this.resroot.clone();
            it.setVisible(true);
            it.setPositionX(0);
            it.setPositionY(totalHeight-(size.height+gap)*(i+1));
            it.setUserData(this.needRes[i]);
            this.resScrollView.addChild(it);
            this.setResItem(it,this.needRes[i],i);
            this.resItemVector.push(it);
        }


        this.resScrollView.setInnerContainerSize(cc.size(size.width,totalHeight));
        this.resScrollView.jumpToTop();

        this.setNeedResNumber2();

        this._numberLabel.setString(this.arms+"/"+this.armsMax);
        this._slider.setPercent(this.arms/this.armsMax*100);
    },

    setResItem: function (node,data,index) {
        var Image_2 = node.getChildByName("Image_2");
        Image_2.ignoreContentAdaptWithSize(true);
        Image_2.loadTexture(ResMgr.inst()._icoPath+data.itemid+"0.png");

        var Text_3 = node.getChildByName("Text_3");
        Text_3.ignoreContentAdaptWithSize(true);
        Text_3.setString(data.counts);//StringUtils.getUnitNumber(data.counts)

        var forbattle = BattleRes.indexOf(data.itemid)==-1?false:true;
        if(data.itemid==1101004){
            forbattle= true;
        }
        var Button_1 = node.getChildByName("Button_1");
        Button_1.addTouchEventListener(this.resCallback,this);
        Button_1.setTag(index);
        Button_1.setUserData(data);
        var btnTitle = Button_1.getChildByName("Text_2");
        btnTitle.setString(ResMgr.inst().getString("xiangqing_15"));
        btnTitle = BorderText.replace(btnTitle);

        Button_1.setVisible(!forbattle);

        var Image_2_1_0 = node.getChildByName("Image_2_1_0");
        Image_2_1_0.setVisible(!forbattle);
        var Image_2_2 = node.getChildByName("Image_2_2");
        Image_2_2.setVisible(!forbattle);
        Image_2_2.setScale(0.8);
        Image_2_2.loadTexture(this.getIconUrl(data.itemid));
        var Text_6 = node.getChildByName("Text_6");
        Text_6.ignoreContentAdaptWithSize(true);
        Text_6.setVisible(!forbattle);
        Text_6.setString(0);
    },

    getIconUrl: function (resid) {
        var url = ResMgr.inst()._icoPath;
        switch (parseInt(resid)){
            case 1101001:
                url += "11012010.png";
                break;
            case 1101002:
                url += "11012020.png";
                break;
            case 1101003:
                url += "11012030.png";
                break;
        }
        return url;
    },

    resCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var tag = sender.getTag();
            var userdata = sender.getUserData();
            cc.log("获取更多",tag, "id ",userdata.itemid,"value",userdata.counts);
            ModuleMgr.inst().openModule("TokenModule",{"resid":userdata.itemid,"resnum":userdata.counts*this.arms});
        }
    },

    dissolveCall: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var armid = this.itemIdList[this.itemIndex];
            //var counts = ModuleMgr.inst().getData("CastleModule").getNetArmy(null,armid);
            //cc.log("@dissolveCall",armid,counts);
            var layer = new TrainingDissolveLayer(armid);
            ModuleMgr.inst().addNodeTOLayer(layer,ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    destroy:function() {
        ModuleMgr.inst().getData("TrainingModule").destroy();
        //EventMgr.inst().removeEventListener(TrainingEvent.UNLOCK_SUCCESS,this.unlockCallback,this);
        //EventMgr.inst().removeEventListener(CastleEvent.UPDATE_RESOURCE, this.setRes, this);
        EventMgr.inst().removeEventListener("dissolve_callback",this.dissolve,this);
        EventMgr.inst().removeEventListener( "using_token", this.usingCallback,this );
    },

    show:function( data ) {
        this.blockId = data.blockid;
        this.campId = data.id;
        var moduledata = ModuleMgr.inst().getData("TrainingModule");
        moduledata.campId = this.campId;
        moduledata.initData();

        var campLv = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(this.campId)[0]._building_level;
        this.campLv = campLv;

        this.configName = this.getConfigName(this.campId);
        cc.log("@getConfigName",this.configName);
        var campConfig = modelMgr.call("Table", "getTableItemByValue", [this.configName,campLv]);
        this.armsMax = campConfig.perlevy_max;
        this.arms = this.armsMax;
        //cc.log("@camp",this.campId," level",campLv,"max",this.armsMax);

        //this.setRes();
        this.setArmTab();
        this.setSelectingTab(0);//默认选中第一个标签
        this.setLeftPageView();
        this.setDescribeLabel();
    },

    close:function( ) {

    },

    pageViewEvent: function (pageView,type) {
        switch (type){
            case ccui.PageView.EVENT_TURNING:
                this.itemIndex = pageView.getCurPageIndex();
                this.resetBtnState();
                this.showArmInfo();
                break;
            default:
                break;
        }
    },

    showArmInfo: function () {
        var armid = this.itemIdList[this.itemIndex];
        var armConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",armid]);

        this.unlimited = true;
        var unlockLv = 0;
        var reqdata = eval("(" + armConfig.arm_need + ")");
        for(var i in reqdata){
            unlockLv = reqdata[i];
            var campLv = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(i)[0]._building_level;
            if(campLv<reqdata[i]){
                this.unlimited = false;
                break;
            }
        }

        var armyData = ModuleMgr.inst().getData("CastleModule").getNetArmy(null,armid);
        if(armyData!=null && armyData>=0) {
            this.unlocked = true;
        }
        else{
            if(armConfig.levelup_resource=="{}"){
                this.unlocked = true;
            }
            else{
                this.unlocked = false;
            }
        }

        //this.setRightPanelTop(this._rightPanel_top,this._rightPanel_top_0,armConfig);
        //this.setRightPanelBottom(this._rightPanel_bottom,this._rightPanel_bottom_0,armConfig,unlockLv);
        this.initResScrollView(armConfig);


        this.arms = this.armsMax;//显示另一个士兵信息，默认造兵最大值
        this.armTime = armConfig.levy_time*60;
        this.setTimeState(this.armTime * this.arms * 1000);

        this.setGotLabel(this.unlocked&&armyData?armyData:0);
    },

    setLeftPageView: function () {
        this._pageview.removeAllPages();

        var data = ModuleMgr.inst().getData("TrainingModule").armList[this.tabIndex];
        this.itemIdList = data;

        var showIndex = 0;
        if(this.itemIdList[0]){
            var type = modelMgr.call("Table", "getTableItemByValue", ["Arm",this.itemIdList[0]]).arm_type;
            var lv = this.getMaxArmy(type);
            showIndex = lv -1;
        }

        var counts = data.length;
        var size = this._pageview.getContentSize();
        for(var i = 0; i < counts; i++) {
            var layout = new ccui.Layout();
            layout.setContentSize(size);

            var item = this._itemRoot.clone();
            item.setPosition(cc.p(size.width*0.5,size.height*0.5+15));
            item.setVisible(true);
            item.setTag(101);
            //item._ex = i;
            layout.addChild(item);
            this.setArmInfo(item,this.itemIdList[i]);

            this._pageview.addPage(layout);
        }

        this.runAction(cc.Sequence(cc.DelayTime(0.1),cc.CallFunc(function (sender) {
            sender._pageview.scrollToPage(showIndex);
        })));

        //this.itemIndex = 0;
        this.itemCounts = counts-1;
        if(this.itemIndex>this.itemCounts){
            this.itemIndex = this.itemCounts;
        }

        //this._pageview.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function (sender) {
        //    sender.scrollToPage(0);
        //})));
        this.resetBtnState();
        this.showArmInfo();//显示当前士兵信息
    },

    //index:0,1,2
    setScrollViewPages: function (index) {
        if(this._leftScrollView){
            var viewSize = this._leftScrollView.getContentSize();
            var containerSize = this._leftScrollView.getInnerContainerSize();

            var percent = viewSize.width*index / containerSize.width * 100;
            this._leftScrollView.jumpToPercentHorizontal(percent);
        }
    },

    setArmInfo: function (node,armid) {
        var name = node.getChildByName("Text_1");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(armid+"0"));

        var lv = node.getChildByName("Text_2");
        lv.ignoreContentAdaptWithSize(true);
        lv.setString(this.getArmLvById(armid));

        var icon = node.getChildByName("Image_9");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst()._icoPath+armid+"4.png");

        var visible = this.checkUnlock(armid);
        var lockIcon = node.getChildByName("Image_11");
        lockIcon.setVisible(!visible);
        var lockbg = node.getChildByName('Image_11_0');
        lockbg.setVisible(!visible);
    },

    checkUnlock: function (armid) {
        var back = false;
        var armConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",armid]);
        var armyData = ModuleMgr.inst().getData("CastleModule").getNetArmy(null,armid);
        if(armyData!=null && armyData>=0) {
            back = true;
        }
        else{
            if(armConfig.levelup_resource=="{}"){
                back = true;
            }
            else{
                back = false;
            }
        }
        return back;
    },

    leftCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            this.itemIndex--;
            if(this.itemIndex<0){
                this.itemIndex=0;
            }
            this._pageview.scrollToPage(this.itemIndex);
        }
    },

    rightCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            this.itemIndex++;
            if(this.itemIndex>this.itemCounts){
                this.itemIndex=this.itemCounts;
            }
            this._pageview.scrollToPage(this.itemIndex);
        }
    },

    resetBtnState: function () {
        if(this.itemIndex==0){
            this.setButtonEnabled(this._leftBtn,false);
        }
        else{
            this.setButtonEnabled(this._leftBtn,true);
        }
        if(this.itemIndex==this.itemCounts){
            this.setButtonEnabled(this._rightBtn,false);
        }
        else{
            this.setButtonEnabled(this._rightBtn,true);
        }
    },

    getTechEffect: function (techid) {
        var info = 0;
        var data = ModuleMgr.inst().getData("CastleModule").getNetTech();
        //cc.log("@getTechEffect-------->",techid);
        if(techid && data[techid] && data[techid]._tech_level > 0){
            var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+techid+","+data[techid]._tech_level+"]" ]);
            var jsondata = eval("(" + tech_data.tech_effect + ")");
            for(var k in jsondata) {
                info = jsondata[k];
            }
        }
        return info;
    },

    getTechId: function (type) {
        var arr = [];
        var attr = modelMgr.call("Table", "getTableList", ["attribute"]);
        for(var i =0;i<attr.length;i++){
            var it = attr[i];
            if(type == it.arm_id){
                arr.push(it.tech_id);
            }
        }
        return arr;
    },

    setRightPanelTop: function (node1,node2,data) {
        if(this.unlocked){
            this._rightPanel_top.setVisible(true);
            this._rightPanel_top_0.setVisible(false);
            this.setRightPanelTopEx(node1,data);
        }
        else{
            this._rightPanel_top.setVisible(false);
            this._rightPanel_top_0.setVisible(true);
            this.setRightPanelTopExUnlock(node2,data);
        }
    },

    initRightPanelTopEx: function (node) {
        //兵力上限
        var Text_67  = node.getChildByName("Text_67");
        Text_67.ignoreContentAdaptWithSize(true);
        Text_67.setString(ResMgr.inst().getString("train_1"));
        //移动速度
        var Text_67_0  = node.getChildByName("Text_67_0");
        Text_67_0.ignoreContentAdaptWithSize(true);
        Text_67_0.setString(ResMgr.inst().getString("train_2"));
        //攻击力
        var Text_67_1  = node.getChildByName("Text_67_1");
        Text_67_1.ignoreContentAdaptWithSize(true);
        Text_67_1.setString(ResMgr.inst().getString("train_3"));
        //攻击距离
        var Text_67_2  = node.getChildByName("Text_67_2");
        Text_67_2.ignoreContentAdaptWithSize(true);
        Text_67_2.setString(ResMgr.inst().getString("train_4"));
        //防御力
        var Text_67_3  = node.getChildByName("Text_67_3");
        Text_67_3.ignoreContentAdaptWithSize(true);
        Text_67_3.setString(ResMgr.inst().getString("train_5"));
        //战斗力
        var Text_67_4  = node.getChildByName("Text_67_4");
        Text_67_4.ignoreContentAdaptWithSize(true);
        Text_67_4.setString(ResMgr.inst().getString("train_6"));
        //单支部队建造时间
        var Text_67_5  = node.getChildByName("Text_67_5");
        Text_67_5.ignoreContentAdaptWithSize(true);
        Text_67_5.setString(ResMgr.inst().getString("train_7"));

        var Text_67_5_0 = node.getChildByName("Text_67_5_0");
        Text_67_5_0.ignoreContentAdaptWithSize(true);
        Text_67_5_0.setString(ResMgr.inst().getString("train_30"));
    },

    setRightPanelTopEx: function (node,armConfig) {

        //var attr = modelMgr.call("Table", "getTableItemByValue", ["attribute",armConfig.arm_type]);
        //if(attr){
        var techlist = this.getTechId(armConfig.arm_type);
        //var value = this.getTechEffect(techid);
        //}

        //兵力上限
        var Text_74 = node.getChildByName("Text_74");
        Text_74.ignoreContentAdaptWithSize(true);
        Text_74.setString(armConfig.force_mnax);

        //移动速度
        var Text_74_0 = node.getChildByName("Text_74_0");
        Text_74_0.ignoreContentAdaptWithSize(true);
        Text_74_0.setString(armConfig.speed);

        //攻击力
        var Text_74_1 = node.getChildByName("Text_74_1");
        Text_74_1.ignoreContentAdaptWithSize(true);
        Text_74_1.setString(armConfig.attack);

        var value = this.getTechEffect(techlist[0]);
        //加成
        var Text_74_1_0 = node.getChildByName("Text_74_1_0");
        Text_74_1_0.ignoreContentAdaptWithSize(true);
        //Text_74_1_0.setString(value);
        Text_74_1_0.setPositionX(Text_74_1.getPositionX()+Text_74_1.getContentSize().width+5);
        //Text_74_1_0.setVisible(false);
        if(value==0){
            Text_74_1_0.setVisible(false);
        }
        else{
            Text_74_1_0.setString("+"+value*100+"%");
        }

        //攻击距离
        var Text_74_2 = node.getChildByName("Text_74_2");
        Text_74_2.ignoreContentAdaptWithSize(true);
        Text_74_2.setString(armConfig.shoot_range);

        //防御力
        var Text_74_3 = node.getChildByName("Text_74_3");
        Text_74_3.ignoreContentAdaptWithSize(true);
        Text_74_3.setString(armConfig.defence);

        value = this.getTechEffect(techlist[1]);

        //加成Text_74_1_0_0
        var Text_74_1_0_0 = node.getChildByName("Text_74_1_0_0");
        Text_74_1_0_0.ignoreContentAdaptWithSize(true);
        //Text_74_1_0_0.setString(this.getTechEffect(techlist[1]));
        //Text_74_1_0_0.setVisible(false);
        Text_74_1_0_0.setPositionX(Text_74_3.getPositionX()+Text_74_3.getContentSize().width+5);
        if(value==0){
            Text_74_1_0_0.setVisible(false);
        }
        else{
            Text_74_1_0_0.setString("+"+value*100+"%");
        }

        //战斗力
        var Text_74_4 = node.getChildByName("Text_74_4");
        Text_74_4.ignoreContentAdaptWithSize(true);
        Text_74_4.setString(armConfig.warfare);

        //单支部队建造时间
        var Text_74_5 = node.getChildByName("Text_74_5");
        Text_74_5.ignoreContentAdaptWithSize(true);
        Text_74_5.setString(armConfig.levy_time*60);

        var Text_74_5_0 = node.getChildByName("Text_74_5_0");
        Text_74_5_0.ignoreContentAdaptWithSize(true);
        Text_74_5_0.setString(armConfig.arm_load);

    },

    setRightPanelTopExUnlock: function (node,armConfig) {
        var data = ModuleMgr.inst().getData("TrainingModule");
        var Text_67 = node.getChildByName("Text_67");
        Text_67.setString(data.lockInfo[armConfig.city_camp]);
    },

    setRightPanelBottom: function (node1,node2,data,unlocklv) {
        if(this.unlocked){
            this._rightPanel_bottom.setVisible(true);
            this._rightPanel_bottom_0.setVisible(false);
            this.setRightPanelBottomEx(node1,data);
        }
        else{
            this._rightPanel_bottom.setVisible(false);
            this._rightPanel_bottom_0.setVisible(true);
            this.setRightPanelBottomExUnlock(node2,unlocklv);
        }
    },

    initRightPanelBottomEx: function (node) {
        var Slider_1 = node.getChildByName("Slider_1");
        Slider_1.addEventListener(this.sliderCallback, this);
        Slider_1.setPercent(100);
        this._slider = Slider_1;
        posAutoLayout(Slider_1,0.5);

        var add = node.getChildByName("Image_243_0");
        add.setTouchEnabled(true);
        add.addTouchEventListener(this.addCallback,this);
        posAutoLayout(add,0.5);
        var sub = node.getChildByName("Panel_2");
        sub.addTouchEventListener(this.subCallback,this);
        posAutoLayout(sub,0.5);
        var Image_243 = node.getChildByName("Image_243");
        posAutoLayout(Image_243,0.5);

        var Text_64 = node.getChildByName("Text_64");
        Text_64.ignoreContentAdaptWithSize(true);
        this._numberLabel = Text_64;
        posAutoLayout(Text_64,0.5);
    },

    setRightPanelBottomEx: function (node,armConfig) {
        var resdata = eval("(" + armConfig.recruit_resource + ")");
        var reslist = [];
        for(var i in resdata){
            var item={};
            item.itemid = i;
            item.counts = resdata[i];
            reslist.push(item);
        }
        this.needRes = reslist;

        var icolist = [];
        //0
        var Image_239 = node.getChildByName("Image_239");
        Image_239.ignoreContentAdaptWithSize(true);
        Image_239.setVisible(false);
        icolist.push(Image_239);
        //1
        var Image_239_0 = node.getChildByName("Image_239_0");
        Image_239_0.ignoreContentAdaptWithSize(true);
        Image_239_0.setVisible(false);
        icolist.push(Image_239_0);
        //2
        var Image_239_0_0 = node.getChildByName("Image_239_0_0");
        Image_239_0_0.ignoreContentAdaptWithSize(true);
        Image_239_0_0.setVisible(false);
        icolist.push(Image_239_0_0);
        //3
        var Image_239_1 = node.getChildByName("Image_239_1");
        Image_239_1.ignoreContentAdaptWithSize(true);
        Image_239_1.setVisible(false);
        icolist.push(Image_239_1);
        //4
        var Image_239_2 = node.getChildByName("Image_239_2");
        Image_239_2.ignoreContentAdaptWithSize(true);
        Image_239_2.setVisible(false);
        icolist.push(Image_239_2);
        //5
        var Image_239_1_0_2 = node.getChildByName("Image_239_1_0_2");
        Image_239_1_0_2.ignoreContentAdaptWithSize(true);
        Image_239_1_0_2.setVisible(false);
        icolist.push(Image_239_1_0_2);
        //6
        var Image_239_1_0 = node.getChildByName("Image_239_1_0");
        Image_239_1_0.ignoreContentAdaptWithSize(true);
        Image_239_1_0.setVisible(false);
        icolist.push(Image_239_1_0);
        //7
        var Image_239_1_0_0 = node.getChildByName("Image_239_1_0_0");
        Image_239_1_0_0.ignoreContentAdaptWithSize(true);
        Image_239_1_0_0.setVisible(false);
        icolist.push(Image_239_1_0_0);
        //8
        var Image_239_1_0_1 = node.getChildByName("Image_239_1_0_1");
        Image_239_1_0_1.ignoreContentAdaptWithSize(true);
        Image_239_1_0_1.setVisible(false);
        icolist.push(Image_239_1_0_1);

        var numlist = [];
        var Text_81 = node.getChildByName("Text_81");
        Text_81.ignoreContentAdaptWithSize(true);
        Text_81.setVisible(false);
        numlist.push(Text_81);
        var Text_81_0 = node.getChildByName("Text_81_0");
        Text_81_0.ignoreContentAdaptWithSize(true);
        Text_81_0.setVisible(false);
        numlist.push(Text_81_0);
        var Text_81_0_0 = node.getChildByName("Text_81_0_0");
        Text_81_0_0.ignoreContentAdaptWithSize(true);
        Text_81_0_0.setVisible(false);
        numlist.push(Text_81_0_0);
        var Text_81_1 = node.getChildByName("Text_81_1");
        Text_81_1.ignoreContentAdaptWithSize(true);
        Text_81_1.setVisible(false);
        numlist.push(Text_81_1);
        var Text_81_2 = node.getChildByName("Text_81_2");
        Text_81_2.ignoreContentAdaptWithSize(true);
        Text_81_2.setVisible(false);
        numlist.push(Text_81_2);
        var Text_81_1_0_2 = node.getChildByName("Text_81_1_0_2");
        Text_81_1_0_2.ignoreContentAdaptWithSize(true);
        Text_81_1_0_2.setVisible(false);
        numlist.push(Text_81_1_0_2);
        var Text_81_1_0 = node.getChildByName("Text_81_1_0");
        Text_81_1_0.ignoreContentAdaptWithSize(true);
        Text_81_1_0.setVisible(false);
        numlist.push(Text_81_1_0);
        var Text_81_1_0_0 = node.getChildByName("Text_81_1_0_0");
        Text_81_1_0_0.ignoreContentAdaptWithSize(true);
        Text_81_1_0_0.setVisible(false);
        numlist.push(Text_81_1_0_0);
        var Text_81_1_0_1 = node.getChildByName("Text_81_1_0_1");
        Text_81_1_0_1.ignoreContentAdaptWithSize(true);
        Text_81_1_0_1.setVisible(false);
        numlist.push(Text_81_1_0_1);

        this._resNumLabelList = numlist;

        for(var i in reslist){
            if(icolist[i] && numlist[i]){
                icolist[i].setVisible(true);
                icolist[i].loadTexture(ResMgr.inst().getIcoPath(reslist[i].itemid));
                numlist[i].setVisible(true);
                numlist[i].setString(StringUtils.getUnitNumber(reslist[i].counts*this.arms));
            }
        }
        this.setNeedResNumber();

        this._numberLabel.setString(this.arms+"/"+this.armsMax);
        this._slider.setPercent(this.arms/this.armsMax*100);
    },

    setNeedResNumber: function () {
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();

        for(var i in this.needRes){
            if(this._resNumLabelList[i]){
                this._resNumLabelList[i].setVisible(true);

                var counts = this.needRes[i].counts*this.arms;
                var res_counts = resData[this.needRes[i].itemid];//this.getRes(this.needRes[i].itemid);
                if(res_counts==undefined) res_counts = 0;

                //cc.log("@res test", this.needRes[i].itemid,res_counts,counts);
                if(res_counts<counts){
                    this._resNumLabelList[i].setColor(cc.color(212,87,87));
                }
                else{
                    this._resNumLabelList[i].setColor(cc.color(239,235,198));
                }
                this._resNumLabelList[i].setString(StringUtils.getUnitNumber(counts));
            }
        }
    },

    setNeedResNumber2: function () {
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
        for(var i in this.needRes){
            if(this.resItemVector[i]){
                var Text_3 = this.resItemVector[i].getChildByName("Text_3");
                var itemCheck = this.resItemVector[i].getChildByName("Image_2_0");
                itemCheck.ignoreContentAdaptWithSize(true);

                var counts = this.needRes[i].counts*this.arms;
                var res_counts = resData[this.needRes[i].itemid];//this.getRes(this.needRes[i].itemid);
                if(res_counts==undefined) res_counts = 0;

                //cc.log("@res test", this.needRes[i].itemid,res_counts,counts);
                if(res_counts<counts){
                    Text_3.setColor(cc.color(212,87,87));

                    itemCheck.loadTexture("xueyuan_cuo.png",ccui.Widget.PLIST_TEXTURE);
                }
                else{
                    Text_3.setColor(cc.color(239,235,198));

                    itemCheck.loadTexture("xueyuan_dui.png",ccui.Widget.PLIST_TEXTURE);
                }
                Text_3.setString(counts);//StringUtils.getUnitNumber(counts)
            }
        }
    },

    usingCallback: function (event, id, counts,exinfo) {
        for(var i in this.resItemVector){
            var it = this.resItemVector[i];
            if(it){
                var userdata = it.getUserData();
                if(userdata.itemid==id){
                    var tokenlabel = it.getChildByName("Text_6");
                    tokenlabel.setString(counts);

                    var reslabel = it.getChildByName("Text_3");
                    reslabel.setString(exinfo);
                    var rescheck = it.getChildByName("Image_2_0");

                    //刷新状态
                    var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
                    if (parseInt(exinfo) > parseInt(resData[id])) {
                        //不满足
                        reslabel.setColor(cc.color(212,87,87,255));
                        rescheck.loadTexture("xueyuan_cuo.png",ccui.Widget.PLIST_TEXTURE);
                        //this.playEffect(this.itemDict[id],true);
                    }
                    else {
                        //满足
                        reslabel.setColor(cc.color(255,255,255,255));
                        rescheck.loadTexture("xueyuan_dui.png",ccui.Widget.PLIST_TEXTURE);
                        //this.playEffect(this.itemDict[id],false);
                    }
                    //-----------------
                    var itemId = null;
                    switch (parseInt(id)){
                        case 1101001:
                            itemId = 1101201;
                            break;
                        case 1101002:
                            itemId = 1101202;
                            break;
                        case 1101003:
                            itemId = 1101203;
                            break;
                    }
                    var count = counts;

                    var exist = false;
                    for(var i in this._array){
                        if(this._array[i].itemId==itemId){
                            this._array[i].counts = count;
                            exist = true;
                        }
                    }

                    if(!exist){
                        this._array.push({"itemId":itemId,"counts":count});
                    }
                    break;
                }
            }
        }
    },

    setRightPanelBottomExUnlock: function (node,unlocklv) {
        var string = ResMgr.inst().getString(this.campId+"0")+ unlocklv +ResMgr.inst().getString("train_16");
        var Text_81 = node.getChildByName("Text_81");
        Text_81.ignoreContentAdaptWithSize(true);
        Text_81.setString(string);

        string = ResMgr.inst().getString(this.campId+"0")+ResMgr.inst().getString("train_17");
        var Text_81_0 = node.getChildByName("Text_81_0");
        Text_81_0.ignoreContentAdaptWithSize(true);
        Text_81_0.setString(string);

        var Text_81_1 = node.getChildByName("Text_81_1");
        Text_81_1.ignoreContentAdaptWithSize(true);
        Text_81_1.setString(this.campLv+ResMgr.inst().getString("train_18"));
        if(unlocklv<=this.campLv){
            Text_81_1.setColor(cc.color(65,150,57));
        }
        else{
            Text_81_1.setColor(cc.color(212,87,87));
        }
    },

    //setRes: function () {
    //    var itemid = ModuleMgr.inst().getData("TrainingModule").getResIconUrl(this.campId);
    //    this._resIcon.loadTexture(ResMgr.inst().getIcoPath(itemid));
    //    this._resCounts.setString(this.getRes(itemid));
    //},

    //坐标适配
    setArmTab: function () {
        var node = this._tabRoot;
        node.setVisible(true);
        var pos = node.getPosition();
        var size = node.getContentSize();
        var parent = node.getParent();

        var data = ModuleMgr.inst().getData("TrainingModule");

        var counts = data.armList.length;
        for(var i = 0; i <counts; i++) {
            var item = node.clone();
            item.setPosition(cc.p(pos.x+i*size.width,pos.y));
            item.setTag(i);
            parent.addChild(item);
            this._tabBtnList.push(item);

            var title = item.getChildByName("Text_25");
            title.ignoreContentAdaptWithSize(true);
            title.setString(data.newArmList[i]);
            title = BorderText.replace(title);
            this._tabBtnTitleList.push(title);
        }
    },

    setSelectingTab: function (index) {
        for(var i in this._tabBtnList){
            if(i==index){
                this.setButtonTitleColor(this._tabBtnList[i],this._tabBtnTitleList[i],true);
            }
            else{
                this.setButtonTitleColor(this._tabBtnList[i],this._tabBtnTitleList[i],false);
            }
        }
    },

    itemCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var index = sender.getTag();
            if(this.tabIndex==index) return;

            this.tabIndex = index;
            this.setSelectingTab(this.tabIndex);
            this.setLeftPageView();
        }
    },

    //训练时间 按钮 状态
    setTimeState: function (time) {
        if(this.unlocked){
            this._timeIcon.setVisible(true);
            this._timeLabel.setVisible(true);
            this.setTime(time);

            this._btnTitle.setString(ResMgr.inst().getString("train_9"));
            this.setButtonEnabled(this._btn,true);
        }
        else{
            this._timeIcon.setVisible(false);
            this._timeLabel.setVisible(false);

            this._btnTitle.setString(ResMgr.inst().getString("train_10"));
            if(!this.unlimited){
                this.setButtonEnabled(this._btn,false);
            }
            else{
                this.setButtonEnabled(this._btn,true);
            }
        }
    },

    //设置训练时间 StringUtils.formatTimer(time*60*1000)
    setTime: function (time) {
        this._timeLabel.setString(StringUtils.formatTimer(time));
    },

    setGotLabel: function (string) {
        if(this._gotLabel){
            this._gotLabel.setString(ResMgr.inst().getString("train_12")+string);
        }
        if(this.dissolveBtn){
            if(string==0){
                this.dissolveBtn.setVisible(false);
            }
            else{
                this.dissolveBtn.setVisible(true);
            }
        }
    },

    setDescribeLabel: function () {
        this._describeLabel.setString(ResMgr.inst().getString(this.campId+"1"));
    },

    //三态：1.已解锁 2.满足条件，未解锁 3.条件不足
    btncallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){

            if(this.unlocked){
                cc.log("@训练士兵 id ", this.itemIdList[this.itemIndex],this.arms,"兵营地块 ID",this.blockId);
                EventMgr.inst().dispatchEvent( CastleEvent.BUILD_ARMY,this.blockId,this.itemIdList[this.itemIndex], this.arms,this._array);
                ModuleMgr.inst().closeModule("TrainingModule");
            }
            else{
                if(this.unlimited){
                    var layer = new UnlockingLayer(this.itemIdList[this.itemIndex]);
                    ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOPUI);
                }
            }

        }
    },

    setButtonEnabled: function (node,enabled) {
        if(node){
            node.setBright(enabled);
            node.setTouchEnabled(enabled);
        }
    },

    //设置按钮状态颜色
    setButtonTitleColor: function (btn,title,enabled) {
        if(btn){
            var color = cc.color(0,0,0,255);
            if(enabled){
                btn.loadTextureNormal("training/zy_youshangbiaoqian.png",ccui.Widget.PLIST_TEXTURE);
                color = cc.color(252,250,155,255);
            }
            else{
                btn.loadTextureNormal("training/zy_youshangbiaoqian2.png",ccui.Widget.PLIST_TEXTURE);
                color = cc.color(175,151,86,255);
            }
            title.setColor(color);
        }
    },

    addCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            this.arms++;
            if(this.arms>this.armsMax){
                this.arms = this.armsMax;
            }
            this._numberLabel.setString(this.arms + "/" + this.armsMax);
            this._slider.setPercent(this.arms/this.armsMax*100);
            //this.setNeedResNumber();
            this.setNeedResNumber2();
            this.setTime(this.armTime * this.arms * 1000);
        }
    },

    subCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            this.arms--;
            if(this.arms<0){
                this.arms=0;
            }
            this._numberLabel.setString(this.arms + "/" + this.armsMax);
            this._slider.setPercent(this.arms/this.armsMax*100);
            //this.setNeedResNumber();
            this.setNeedResNumber2();
            this.setTime(this.armTime * this.arms * 1000);
        }
    },

    sliderCallback: function (sender,type) {
        if (type == ccui.Slider.EVENT_PERCENT_CHANGED) {
            var num = sender.getPercent();
            var use_counts = num * this.armsMax / 100;
            this.arms = parseInt(use_counts);
            this._numberLabel.setString(this.arms + "/" + this.armsMax);
            //this.setNeedResNumber();
            this.setNeedResNumber2();
            this.setTime(this.armTime * this.arms * 1000);
        }
    },

    getArmLvById: function (armid) {
        var str = ResMgr.inst().getString("train_19");
        var lv = armid % 100;
        return str += lv;
    },

    getRes:function( id )
    {
        var data = ModuleMgr.inst().getData("CastleModule");
        if( data == null )return 0;
        var dic = data.getNetResource();
        if( dic == undefined ) return 0;
        var n = dic[id];
        if( n == undefined ) return 0;
        if( n > 0 )
        {
            var str = StringUtils.getUnitNumber( n );
            return str;
        }
        return 0;
    },

    getItemByPageviewIndex: function (index) {
        if(this._pageview){
            var layout = this._pageview.getPage(index);
            if(layout==null) return null;

            var item = layout.getChildByTag(101);
            //cc.log("@getItemByPageviewIndex",item._ex);
            return item;
        }
        return null;
    },

    unlockCallback: function (event, data) {
        this.showArmInfo();

        this.playEffect()
    },

    playEffect: function () {
        cc.log("@playEffect",this.itemIndex);
        var item = this.getItemByPageviewIndex(this.itemIndex);
        var lockIcon = item.getChildByName("Image_11");
        lockIcon.setVisible(false);
        var lockbg = item.getChildByName('Image_11_0');
        lockbg.setVisible(false);

        var csv = ResMgr.inst().getCSV("animationConfig","train_lock1");
        var effect =new AnimationSprite();
        effect.setPosition(cc.p(103,197));
        effect.setName("train_lock1");
        effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
        item.addChild(effect);

        csv = ResMgr.inst().getCSV("animationConfig","train_lock2");
        effect =new AnimationSprite();
        effect.setPosition(cc.p(103,197));
        effect.setName("train_lock2");
        effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
        item.addChild(effect);
    },

    effectCallback: function (sender) {
        sender.removeFromParent(true);
    },

    getConfigName: function (buildid) {
        var str = "";
        switch (parseInt(buildid)){
            case 1902001:
                str += "City_Camp_horse";
                break;
            case 1902002:
                str += "City_Camp_Barracks";
                break;
            case 1902003:
                str += "City_Camp_target";
                break;
            case 1902004:
                str += "City_Camp_instrument";
                break;
            default :
                str += "City_Camp";
                break;
        }
        return str;
    },

    dissolve: function (event, armyid, counts) {
        var armyData = ModuleMgr.inst().getData("CastleModule").getNetArmy(null,armyid);
        this.setGotLabel(armyData);
        cc.log("@dissolve",armyid,counts,armyData);
    },
    
    getMaxArmy: function (type) {
        var arr = [];
        var list = mainData.castleData.armyList.getItems("castleId",mainData.uiData.currentCastleId);
        for(var i = 0; i < list.length; i++){
            var it = list[i];
            var armytype = modelMgr.call("Table", "getTableItemByValue", ["Arm",it.armyId]).arm_type;
            if(armytype==type){
                arr.push(it);
            }
        }

        var temp = 1;
        for(var i in arr){
            var id = arr[i].armyId;
            var lv = id % 100;
            //cc.log("@_____________",id,"_________",lv);
            if(lv > temp) {
                temp = lv;
            }
        }
        //
        //cc.log("@getMaxArmy ----------- >>>",arr.length,type,temp);

        return temp;
    }
});