var MapBuild = MapDisplayBase.extend({
    shaderLayer: null,
    data: null,
    shader: null,
    powerShader: null,
    showRangeFlag:false,
    ctor: function (shaderLayer, data) {
        this._super(MapDisplayType.Build);
        this.shaderLayer = shaderLayer;
        this.data = data;
        this.show = new cc.Sprite("res/fight/build/" +  modelMgr.call("Table", "getTableItemByValue", ["City_Castel", this.data.level]).display_map + ".png");
        this.addChild(this.show);
        this.show.setPosition(MapUtils.width / 2 - 50 + 48, 50 - 67 + 24);
        //this.show.setScaleX(1.3);
        //this.show.setScaleY(1.3);
        this.onRelationChange(this.data.relation);
        this.setCoord(this.data.coordX, this.data.coordY);
        if (this.isMyCastle()) {
            this.showRange(true);
            if((new Date()).getTime() - this.data.createTime < 500) {
                this.showEffect();
            }
        }
        this.data.addListener("relation", this.onRelationChange, this);
    },
    onRelationChange: function (relation) {
        trace("城堡颜色",relation,this.data.coordX,this.data.coordY);
        var show = this.show;
        if (this.data.relation == "enemy") {
            show.shaderProgram = (Shader.getRolerColor("R"));
        } else if (this.data.relation == "other") {
            show.shaderProgram = (Shader.getRolerColor("Y"));
        }
    },
    onShowCastleRange: function(castleId){
        trace("比较？？？？",this.data.id,castleId,this.showRangeFlag);
        if(castleId == this.data.id && this.showRangeFlag == false) {
            this.showRange(true);
        } else if(this.showRangeFlag == true) {
            trace("关闭显示？？？？");
            this.showRange(false);
        }
    },
    isTouch: function (x, y) {
        if (x == this.coordX && y == this.coordY ||
            x == this.coordX - 1 && y == this.coordY ||
            x == this.coordX + 1 && y == this.coordY ||
            x == this.coordX + 2 && y == this.coordY ||
            (this.coordY % 2 == 0 && (
            x == this.coordX - 1 && y == this.coordY - 1 ||
            x == this.coordX && y == this.coordY - 1 ||
            x == this.coordX + 1 && y == this.coordY - 1 ||
            x == this.coordX - 1 && y == this.coordY + 1 ||
            x == this.coordX && y == this.coordY + 1 ||
            x == this.coordX + 1 && y == this.coordY + 1)) ||
            (this.coordY % 2 != 0 && (
            x == this.coordX && y == this.coordY - 1 ||
            x == this.coordX + 1 && y == this.coordY - 1 ||
            x == this.coordX + 2 && y == this.coordY - 1 ||
            x == this.coordX && y == this.coordY + 1 ||
            x == this.coordX + 1 && y == this.coordY + 1 ||
            x == this.coordX + 2 && y == this.coordY + 1))) {
            return true;
        }
        return false;
    },
    /**
     * 是否在势力范围内
     * @param x
     * @param y
     * @returns {boolean}
     */
    isMyCastlePowerRange: function (x, y) {
        trace("是否在领地势力范围？", x, y, this.coordX, this.coordY, this.data.user);
        if (this.data.userAccount != mainData.playerData.account) {
            return false;
        }
        var dis = MapUtils.getDistance(this.coordX, this.coordY, x, y);
        var lv = this.data.attributes.getItem("type", 2500007).value;
        /*if(mainData.castleData.blockList.getItem("buildId", 1901001) != null) {
         var lv = mainData.castleData.blockList.getItem("buildId", 1901001).buildLevel;
         } else {
         var lv = 1;
         }*/
        var testTable = modelMgr.call("Table", "getTableItemByValue", ["City_Castel", lv]);
        trace("是否在领地势力范围？2", dis, testTable.range);
        if (dis <= testTable.range) {
            return true;
        }
        return false;
    },
    getUserAccount: function () {
        return this.data.userAccount;
    },
    isMyCastle: function () {
        trace("判断是否为自己的城堡?", this.data.coordX, this.data.coordY, this.data.userAccount, mainData.playerData.account);
        return this.data.userAccount == mainData.playerData.account ? true : false;
    },
    getCastleId: function () {
        return this.data.id;
    },
    //显示主城范围和势力范围
    showRange: function (val) {
        this.showRangeFlag = val;
        if (val) {
            if (!this.shader && !MapBuild.showCastleRange[this.data.id]) {
                MapBuild.showCastleRange[this.data.id] = true;
                //主城范围
                this.shader = new cc.Sprite("res/fight/ui/cityRange" + IdChange.changeToResource(IdType.CASTLE, this.data.id) + ".png");
                this.shaderLayer.addChild(this.shader);
                this.shader.setPosition(this.px + MapUtils.width / 2, this.py);

                this.powerShader = new cc.Sprite();
                this.shaderLayer.addChild(this.powerShader);
                this.powerShader.setPosition(this.px, this.py);
                trace("城堡属性",this.data.attributes.length);
                for (var m =0; m < this.data.attributes.length; m++) {
                    trace(this.data.attributes.getItemAt(m).type,this.data.attributes.getItemAt(m).value);
                }
                var lv = this.data.attributes.getItem("type", 2500007).value;
                //if(mainData.castleData.blockList.getItem("buildId", 1901001) != null) {
                //    var lv = mainData.castleData.blockList.getItem("buildId", 1901001).buildLevel;
                //} else {
                //    var lv = 1;
                //}
                var testTable = modelMgr.call("Table", "getTableItemByValue", ["City_Castel", lv]);
                var range = testTable.range;
                var pts = [
                    {
                        x: -range * MapUtils.width,
                        y: 0,
                        images: [
                            {
                                name: "2",
                                anchorX: 0,
                                anchorY:
                                    5,
                                offx: -MapUtils.width / 2,
                                offy: 0
                            },
                            {
                                name: "3",
                                anchorX: 1,
                                anchorY: 0,
                                offx: 0,
                                offy: -MapUtils.height / 2
                            }
                        ],
                        disx: MapUtils.width / 2,
                        disy: -MapUtils.height * 0.75
                    },
                    {
                        x: -range * MapUtils.width / 2,
                        y: -range * MapUtils.height * 0.75,
                        images: [
                            {
                                name: "3",
                                anchorX: 1,
                                anchorY: 0,
                                offx: 0,
                                offy: -MapUtils.height / 2
                            },
                            {
                                name: "1",
                                anchorX: 0,
                                anchorY: 0,
                                offx: 0,
                                offy: -MapUtils.height / 2
                            }
                        ],
                        disx: MapUtils.width,
                        disy: 0
                    },
                    {
                        x: range * MapUtils.width / 2,
                        y: -range * MapUtils.height * 0.75,
                        images: [
                            {
                                name: "1",
                                anchorX: 0,
                                anchorY: 0,
                                offx: 0,
                                offy: -MapUtils.height / 2
                            },
                            {
                                name: "2",
                                anchorX: 0,
                                anchorY: 0.5,
                                offx: MapUtils.width / 2,
                                offy: 0
                            }
                        ],
                        disx: MapUtils.width / 2,
                        disy: MapUtils.height * 0.75
                    },
                    {
                        x: range * MapUtils.width,
                        y: 0,
                        images: [
                            {
                                name: "2",
                                anchorX: 0,
                                anchorY: 0.5,
                                offx: MapUtils.width / 2,
                                offy: 0
                            },
                            {
                                name: "3",
                                anchorX: 0,
                                anchorY: 1,
                                offx: 0,
                                offy: MapUtils.height / 2
                            }
                        ],
                        disx: -MapUtils.width / 2,
                        disy: MapUtils.height * 0.75
                    },
                    {
                        x: range * MapUtils.width / 2,
                        y: range * MapUtils.height * 0.75,
                        images: [

                            {
                                name: "3",
                                anchorX: 0,
                                anchorY: 1,
                                offx: 0,
                                offy: MapUtils.height / 2
                            },
                            {
                                name: "1",
                                anchorX: 1,
                                anchorY: 1,
                                offx: 0,
                                offy: MapUtils.height / 2
                            }
                        ],
                        disx: -MapUtils.width,
                        disy: 0
                    },
                    {
                        x: -range * MapUtils.width / 2,
                        y: range * MapUtils.height * 0.75,
                        images: [
                            {
                                name: "1",
                                anchorX: 1,
                                anchorY: 1,
                                offx: 0,
                                offy: MapUtils.height / 2
                            },
                            {
                                name: "2",
                                anchorX: 0,
                                anchorY: 0.5,
                                offx: -MapUtils.width / 2,
                                offy: 0
                            }
                        ],
                        disx: -MapUtils.width / 2,
                        disy: -MapUtils.height * 0.75
                    }
                ];
                var sp;
                for (var i = 0; i < pts.length; i++) {
                    for (var m = 0; m < pts[i].images.length; m++) {
                        for (var r = 0; r <= range; r++) {
                            if (r == range && m != 0) continue;
                            sp = new cc.Sprite("res/fight/ui/power" + IdChange.changeToResource(IdType.CASTLE, this.data.id) + pts[i].images[m].name + ".png");
                            trace(pts[i].images[m].anchorX, pts[i].images[m].anchorY);
                            sp.setAnchorPoint(pts[i].images[m].anchorX, pts[i].images[m].anchorY);
                            trace(pts[i].x + pts[i].images[m].offx + r * pts[i].disx, pts[i].y + pts[i].images[m].offy + r * pts[i].disy);
                            sp.setPosition(pts[i].x + pts[i].images[m].offx + r * pts[i].disx, pts[i].y + pts[i].images[m].offy + r * pts[i].disy);
                            this.powerShader.addChild(sp);
                        }
                    }
                }
            }
        } else {
            delete MapBuild.showCastleRange[this.data.id];
            if (this.shader) {
                this.shader.getParent().removeChild(this.shader);
                this.shader = null;
                this.powerShader.getParent().removeChild(this.powerShader);
                this.powerShader = null;
            }
        }
    },
    //建城特效
    showEffect:function() {
        var effect = new Animation(MapBuild.buildCastle);
        this.addChild(effect,-1);
        effect.play(1);
        effect.setPosition(MapUtils.width / 2 - 23, 50);
        jc.EnterFrame.add(this.showEffectUpdate, this);
        this.showEffectTime = 0;
        this.show.setOpacity(0);
        SoundPlay.playEffect("res/sounds/effects_build2.mp3");
    },
    showEffectTime:0,
    showEffectUpdate:function(dt){
        this.showEffectTime += dt;
        if(this.showEffectTime < 50) {
            this.show.setOpacity(this.showEffectTime*255/50);
        } else {
            this.show.setOpacity(255);
        }
        if(this.showEffectTime < 200) {
            this.show.setPositionY(50 - 67 + 24 + (1-this.showEffectTime/200)*70);
        } else if(this.showEffectTime < 250) {
            this.show.setPositionY(50- 67 + 24 + (this.showEffectTime-200)*6/50);
        }  else if(this.showEffectTime < 300) {
            this.show.setPositionY(50- 67 + 24 + (1-(this.showEffectTime-250)/50)*6);
        }  else {
            jc.EnterFrame.del(this.showEffectUpdate, this);
            //setTimeout(this.showEffect.bind(this),2000);
        }
    },
    dispose: function () {
        this.data.removeListener("relation", this.onRelationChange, this);
        this._super();
    }
});

MapBuild.buildCastle = {
    plist: "res/fight/effect/build/buildCastle.plist",
    name: "buildCastle_00",
    format: "png",
    start: 0,
    end: 12,
    frameRate: 18,
    x: 0,
    y: 0,
    scaleX:1.3,
    scaleY:1.3
};

MapBuild.showCastleRange = {};