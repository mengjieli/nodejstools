/**
 * Created by Administrator on 2015/10/23.
 */

AnnouncementEvent = {};
AnnouncementEvent.SEND_ANNOUNCEMENT_MSG = "send_announcement_msg";
AnnouncementEvent.SHOW_ANNOUNCEMENT_BG = "show_announcement_bg";
//通讯部分
AnnouncementNetEvent = {};
AnnouncementNetEvent.GET_ANNOUNCEMENT=999;//收到公告信息

var AnnouncementData = DataBase.extend({


    _announcements:null,//当前播放列表
    _announcements_next:null,//周期播放列表
    _interval:null,//计时器
    _runing:null,//是否播放中

    ctor:function()
    {
        this._super();

        this._announcements = [];
        this._announcements_next = [];
        this._runing=false;
        //this.resetAnnouncement();
        return;
        this._announcements = [];
        var obj = {};
        obj.msg = ResMgr.inst().getString("announcement_1");
        obj.num = 2;
        obj.isInit=true;
        cc.log(ResMgr.inst().getString("announcement_2")+"公告文本"+ResMgr.inst().getString("announcement_1"))
        this._announcements.push(obj);
        //this._announcements.push(obj);
        //this._announcements.push(obj);
    },

    init:function()
    {
        //NetMgr.inst().addEventListener( ProtoclId.DZSLogin , this.transactionHandler, this);
        EventMgr.inst().addEventListener("get_announcenment_msg", this.setAnnouncement, this);
        NetMgr.inst().addEventListener(AnnouncementNetEvent.GET_ANNOUNCEMENT, this.netGetAnnouncement, this);
        return;
        var msg = new SocketBytes();
        msg.writeUint(900);
        msg.writeUint(1);
        NetMgr.inst().send(msg);
        return;//测试数组排序工具
        var arr=[2,5,4,3,6];
        var newArr=[];
        for(var i=0;i<5;i++){
            var obj={};
            obj.endt=arr[i];
            newArr.push(obj);
        }
        Tools.sortArray(newArr,"endt");
        cc.log("arr   公告 init））））））））"+newArr[0].endt+newArr[1].endt+newArr[2].endt+newArr[3].endt+newArr[4].endt);

    },

    getAnnouncement:function()
    {
        var data = null;
        if( this._announcements && this._announcements.length > 0 )
        {
            data = this._announcements.shift();
            if(data._period!=0){//有周期的 塞入周期列表
                data._showTime=new Date().getTime()+AnnouncementData.MOVE_TIME*1000+data._period;
                if(data._showTime<data._endTime)   {
                    if(AnnouncementData.TEST_LOG)   cc.log(this._announcements.length+"有周期的 未过期公告 塞入周期列表"+this._announcements_next.length);
                    var bool=false;//判断下次播放列表中是否存在
                    for(var i=0;i<this._announcements_next.length;i++){
                        var nextBean=this._announcements_next[i];
                        if(nextBean._id==data._id) {
                            nextBean._showTime=nextBean._showTime;
                            bool=true;
                            break;
                        }
                    }
                    if(!bool)   this._announcements_next.push(data);
                    if(this._announcements_next.length>0) Tools.sortArray(this._announcements_next,"_showTime");
                }
            }
        }
        return data;
    },
    resetAnnouncement:function(){

        //cc.log("resetAnnouncement"+this._announcements.length);
        //cc.log("time date$$$$$$$$"+new Date().getTime())
        var obj = {};
        obj.msg = ResMgr.inst().getString("announcement_1");
        obj.num = 2;
        obj.isInit=true;
        //cc.log(ResMgr.inst().getString("announcement_2")+"公告文本"+ResMgr.inst().getString("announcement_1"))
        this._announcements.push(obj);
    },
    setAnnouncement:function(type,period)
    {
        cc.log(period+"setAnnouncement"+this._announcements);

        var arr=["","testtest  testtest1111","52526236322222","ljkgasdjgklag33333","try44444"];
        var ran=parseInt(Math.random()*2)+1;//4
        var arrData=[String(ran)+"id####"+Math.random(),1,123,500000,period>0?ran*60*1000:0,[  [0,arr[ran]] ],1 ];
        this.addNetAnnouncement(arrData);
        if(AnnouncementData.TEST_LOG)   cc.log(period+"周期分钟 随机数"+ran);
        return;

        if(this._announcements){
            for(var i=this._announcements.length-1; i>-1;i--){
                if(this._announcements[i].isInit){
                    this._announcements.splice(i);
                }
            }
        }else this._announcements=[];

        var arr=["","testtest  testtest1111","52526236322222","ljkgasdjgklag33333","try44444"];
        var obj = {};
        var ran=parseInt(Math.random()*4)+1;
        obj.msg = arr[ran];
        obj.num = 1;
        obj.isInit=false;
        cc.log(ran+"ran   this._announcements>"+this._announcements.length);
        this._announcements.push(obj);
        cc.log(ran+"ran   this._announcements>>"+this._announcements.length);
        if(this._announcements.length==1)   EventMgr.inst().dispatchEvent(AnnouncementEvent.SEND_ANNOUNCEMENT_MSG);
    },
    //收到服务端传得公告信息
    netGetAnnouncement:function(cmd,data){
        if(AnnouncementData.TEST_LOG)   cc.log(cmd+"收到公告信息");
        if (AnnouncementNetEvent.GET_ANNOUNCEMENT == cmd) {
            data.resetCMDData();
            var id=data.readString();
            var languageId=data.readUint();
            var createdTime=data.readUint();
            var leftTime=data.readUint();
            var period=data.readUint();
            var len = data.readUint();
            var message=[];
            for (var i = 0; i < len; i++) {
                var slot = data.readUint();
                var value = data.readString();
                message.push([slot,value]);
                //cc.log(slot+"slot value"+value);
            }
            var messageType=data.readUint();
            var newString=this.parseMessage(message,messageType);
            //var arrData=[data.readString(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint(),data.readUint()];
            var arrData=[id,languageId,createdTime,leftTime,period,message,messageType];
            if(AnnouncementData.TEST_LOG)   cc.log("收到公告信息"+id+"id"+leftTime+"leftTime"+period+"period"+messageType+"messageType >>>>message数组长度"+message.length);
            this.addNetAnnouncement(arrData);

            //判断是否当前播放列表空 直接公告
        }
    },
    //解析组合文字
    parseMessage:function(arr,type){
        if(type==2){

        }
        //for(var )
    },
    //收到服务端公告后处理
    addNetAnnouncement:function(arr){

        var bean=new AnnouncementBeanNet(arr);
        //bean.
        bean._endTime=new Date().getTime()+bean._leftTime;
        bean.num=1;
        this._announcements.push(bean);
        if(bean._period!=0){
            bean._showTime=new Date().getTime();
            this._announcements_next.push(bean);
        }
        if( this._announcements.length==1&&!this._runing )   EventMgr.inst().dispatchEvent(AnnouncementEvent.SEND_ANNOUNCEMENT_MSG);
        if(this._interval==null)    this._interval=setInterval(this.doInterval, 1000,this);
    },
    //计时器
    doInterval:function(owner){
        //if(owner._announcements.length>0||owner._runing) EventMgr.inst().dispatchEvent(AnnouncementEvent.SHOW_ANNOUNCEMENT_BG,true);//显示 隐藏 走马灯背景条
        //else EventMgr.inst().dispatchEvent(AnnouncementEvent.SHOW_ANNOUNCEMENT_BG,false);//显示 隐藏 走马灯背景条
        if(owner._announcements.length==0&&owner._announcements_next.length==0) {
            if(AnnouncementData.TEST_LOG)   cc.log("没有播放公告  清除计时器");
            clearInterval(owner._interval);
            owner._interval=null;
            return;
        }
        if(owner._announcements.length==0){
            //cc.log(owner._announcements_next[0]._showTime+"showTime"+new Date().getTime());
            if(owner._announcements_next.length>0&&owner._announcements_next[0]._showTime<=new Date().getTime()){
                if(AnnouncementData.TEST_LOG)   cc.log(owner._announcements_next.length+"当前播放列表长度0   周期列表到时间了 要插入当前播放");
                owner._announcements.push(owner._announcements_next.shift());//周期列表第一个插入 当前列表
                if(AnnouncementData.TEST_LOG)   cc.log(owner._announcements_next.length+"当前播放列表长度0   周期列表到时间了 要插入当前播放"+owner._announcements.length);
                EventMgr.inst().dispatchEvent(AnnouncementEvent.SEND_ANNOUNCEMENT_MSG);
            }
        }
    },


});
//静态属性
AnnouncementData.MOVE_TIME=15;//文字滚动时间
AnnouncementData.TEST_LOG=false;//测试Log信息true