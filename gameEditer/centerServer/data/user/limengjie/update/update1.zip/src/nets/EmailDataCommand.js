/**
 * Created by Administrator on 2015/12/3.
 */
EmailDataCommandCMD = {};
EmailDataCommandCMD.load = 699;
EmailDataCommandCMD.info = 698;
MailSTATE = {};
MailSTATE.system = 0x01;
MailSTATE.reade = 0x10;
MailSTATE.receive = 0x20;

var EmailDataCommand = function () {

    var init = function () {
        NetMgr.inst().addEventListener(EmailDataCommandCMD.load, loadCall, this);
        NetMgr.inst().addEventListener(EmailDataCommandCMD.info, infoCall, this);
        NetMgr.inst().addEventListener(0, onServerReturn, this);

    }

    var loadCall = function (cmd, msg) {
        msg.resetCMDData();
        var mailId = msg.readString();
        var surplusTime = msg.readUint();
        var flags = msg.readUint();
        var obj = mainData.emailData.getItem("id", mailId);
        msg.resetCMDData();

        //判断邮件是否新的
        if (obj == null) {
            obj = DataManager.getInstance().getNewData("EmailData");
            obj.isLoadInfo = false;
        }
        obj.id = mailId;
        obj.surplusTime = surplusTime;
        obj.flags = flags;
        obj.isRead = !!( flags & MailSTATE.reade );
        obj.isReceive = !!( flags & MailSTATE.receive );
        cc.log("------------------ 邮件列表数据 ->" + mailId + "surplusTime------>" + obj.surplusTime);
        if (obj.isLoadInfo == false && obj.surplusTime != 0) {
            mainData.emailData.push(obj);
            //新的就加载内容
            //var msg = new SocketBytes();
            //msg.writeUint( 601 );
            //msg.writeString( mailId );
            //msg.writeUint( 1 );             // 语言类型  先写死
            //NetMgr.inst().send( msg );
            ModuleMgr.inst().getData("MailModule").push2List(mailId);
        }

        if(obj.surplusTime == 0)
        {
            cc.log("delete mail succ id--->" + obj.id);
            ModuleMgr.inst().getData("MailModule").deleteMailData(obj.id);
            EventMgr.inst().dispatchEvent(MailEvent.SEND_DELETE_MAIL, obj.id);
        }
        else
        {
            ModuleMgr.inst().getData("MailModule").updateMailData(obj.id);
            EventMgr.inst().dispatchEvent(MailEvent.SEND_UPDATE_MAIL, obj.id);
        }
    }

    var infoCall = function (cmd, msg) {
        cc.log("---------------------------- 收到新邮件数据 ---------------------------------");
        msg.resetCMDData();
        var mailId = msg.readString();
        var languageId = msg.readUint();
        var time = msg.readUint();
        var type = msg.readUint();
        var role = msg.readString(); // 发送人
        var title = msg.readString(); // 主题

        var body = "";
        var len = msg.readUint();

        cc.log("邮件类型11111 --------------->" + type);
        if (type == 1) {
            for (var i = 0; i < len; i++) {
                var slot = msg.readUint();
                body += msg.readString();
            }
        }
        else {
            body = "";
            var titleText = ResMgr.inst().getString("mail" + type + "0");
            if (titleText) {
                title = titleText;
                body = ResMgr.inst().getString("mail" + type + "1");
            }
            var itemId = null;
            for (var i = 0; i < len; i++) {
                var slot = msg.readUint();
                var value = msg.readString();
                if(slot == 86201) {
                    value = mainData.playerDataList.getItem("account",value).nick;
                }
                if(slot == 86202) {
                    value = (parseInt(value)/100) + "";
                }
                if (slot == 86301) {
                    body += "\n" + ResMgr.inst().getString(value + "0");
                    itemId = parseInt(value);
                }
                else if (slot == 86302) {
                    if(itemId) {
                        var itemConfig = modelMgr.call("Table", "getTableItemByValue", ["item", itemId]);
                        if(itemConfig && itemConfig.class == 8) {
                            value = value/100;
                        }
                    }
                    body += " x " + value;
                    itemId = null;
                } else if(slot == 86303) {
                    body += "\n" + ResMgr.inst().getString(value + "0");
                    itemId = parseInt(value);
                } else if(slot == 86304) {
                    body += " x " + value;
                    itemId = null;
                }
                else {
                    body = body.replace("{" + slot + "}", value);
                }
            }
        }
        var items = [];
        len = msg.readUint();
        for (var i = 0; i < len; i++) {
            var it = DataManager.getInstance().getNewData("MailItemData");
            it.id = msg.readUint();
            var num = msg.readUint();
            var itemConfig = modelMgr.call("Table", "getTableItemByValue", ["item", it.id]);
            if(itemConfig && itemConfig.class == 8) {
                num = num/100;
            }
            it.num = num;
            items.push(it);
        }

        msg.resetCMDData();

        var mail = mainData.emailData.getItem("id", mailId);
        if (mail)
            mail.languageId = languageId;
        mail.time = time;
        mail.type = type;
        mail.roleId = role;
        mail.roleName = "";
        mail.title = title;
        mail.msg = body;
        for (var i = 0; i < len; i++) {
            mail.items.push(items[i]);
        }

        mail.isLoadInfo = true;
        ModuleMgr.inst().getData("MailModule").updateMailData(mailId);
        EventMgr.inst().dispatchEvent(MailEvent.SEND_ADD_MAIL, mailId);

    }

    onServerReturn = function (cmd, data) {
        data.resetCMDData();
        var c = data.readUint();
        var code = data.readInt();
        data.resetCMDData();
        //cc.log("on proto->"+c+" return: error code->"+code);
        switch (c) {
            case 604:   // 收取附件
                if (code == 0) {

                    var md = ModuleMgr.inst().getData("MailModule");
                    var id = md.pop();
                    var mail = mainData.emailData.getItem("id", id);
                    cc.log("receive succ id ->" + id + " cache items->" + mail.items.length);
                    mail.items = [];
                    mail.isReceive = true;

                }
                break;

            case MailCMD.NC_MAIL_READE:
                if (code == 0) {
                    var md = ModuleMgr.inst().getData("MailModule");
                    var id = md.pop();
                    var mail = mainData.emailData.getItem("id", id);
                    mail.isRead = true;
                }
                break;

            case MailCMD.NC_MAIL_DELETE:
                if (code == 0) {
                    //var md = ModuleMgr.inst().getData("MailModule");
                    //var id = md.pop();
                    //var mail = mainData.emailData.getItem("id", id);
                    //ModuleMgr.inst().getData("MailModule").deleteMailData(id);
                    //EventMgr.inst().dispatchEvent(MailEvent.SEND_DELETE_MAIL, id);

                }
                break;
        }

    }

    init();
}