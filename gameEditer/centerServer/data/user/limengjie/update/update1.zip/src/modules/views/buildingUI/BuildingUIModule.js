/**
 * Created by cgMu on 2015/10/24.
 */

var BuildingUIModule = ModuleBase.extend({

    ctor:function() {
        this._super();
    },

    initUI:function() {
        EventMgr.inst().addEventListener(CastleEvent.UPGRADE_COMPLETE, this.onUpdateUI, this);
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
    },

    show:function( data ) {
        var buildingData = ModuleMgr.inst().getData("BuildingUIModule");

        if (data.objectid == null) {
            if (buildingData.moduleInit) {
                this.unscheduleUpdate();
                //var movePos = cc.p((303-63)*0.5,(303-73)*0.5);
                //var delayTime = 0.05;
                var time = 0.2;
                //var move = new cc.MoveTo(time, movePos);
                //var action = new cc.EaseElasticOut(move);
                //var action = new cc.EaseExponentialOut(move);
                //var action = new cc.ScaleTo(time,0);

                var index = buildingData.buildingItemArray.length;
                for(var i = 0; i < buildingData.buildingItemArray.length; i++) {
                    index--;
                    //buildingData.buildingItemArray[index].runAction(cc.Sequence(cc.DelayTime(i*delayTime), action,cc.Hide()));
                    cc.log("@index",index);
                    buildingData.buildingItemArray[index].runAction( cc.ScaleTo(time,0) );
                }

                //buildingData.buildingMenuBg.runAction(cc.Sequence(cc.DelayTime(buildingData.buildingItemArray.length*delayTime),cc.ScaleTo(0.1,0),cc.CallFunc(function(){
                //    ModuleMgr.inst().closeModule("BuildingUIModule");
                //})));

                buildingData.buildingMenuBg.runAction(cc.Sequence(cc.FadeOut(time),cc.CallFunc(function(){
                    ModuleMgr.inst().closeModule("BuildingUIModule");
                })));
            }
            buildingData.destroy();
            return;
        }

        buildingData.initBuildingData(data.objectid,data.objectpos,null,data.objectindex);

        if (buildingData.menuUI.length == 0) {
            cc.log("没有弹出UI，直接跳转界面",buildingData.buildingObjectId);
            this.openModule(buildingData.buildingObjectId);
            ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});
            return;
        }

        if (!buildingData.moduleInit) {
            var json = ccs.load("res/images/ui/TileMenuModule/MenuLayer.json","res/images/ui/");
            var root = json.node;
            this.addChild(root);

            buildingData.buildingUI=root;

            this.bgPanel = ccui.helper.seekWidgetByName(root, "menuPanel");
            //var size = this.bgPanel.getContentSize();
            this.bgPanel.setTouchEnabled(true);
            this.bgPanel.addTouchEventListener(this.touchcallback,this);

            var scaleBg = this.bgPanel.getChildByName("Image_2");
            scaleBg.setTouchEnabled(true);
            scaleBg.addTouchEventListener(this.touchcallback,this);
            var counts = buildingData.menuUI.length;
            //if(counts<4){
            //    scaleBg.y -= 20;
            //}

            //名称
            var name = this.bgPanel.getChildByName("Image_1").getChildByName("Text_1");
            name.ignoreContentAdaptWithSize(true);
            name = BorderText.replace(name);
            buildingData.buildingNameLabel = name;

            this.scheduleUpdate();
        }

        cc.log("BuildingUIModule id ",buildingData.buildingObjectId, "地块索引 ",buildingData.buildingBlockId);

        var scaleBg = this.bgPanel.getChildByName("Image_2");
        scaleBg.ignoreContentAdaptWithSize(true);
        buildingData.buildingMenuBg=scaleBg;

        var pos = buildingData.buildingPosition;
        buildingData.moduleInit = true;

        buildingData.buildingNameLabel.setString(ResMgr.inst().getString(buildingData.buildingObjectId+"0"));

        //cc.log("pospos ",pos.x,pos.y);
        var visiblesize = cc.director.getVisibleSize();
        if(pos.x<100 || pos.y<120 || visiblesize.width-pos.x<100 || visiblesize.height-pos.y < 120){
            //EventMgr.inst().dispatchEvent( CastleEvent.MOVETO_BUILDING,data.objectid );
        }
        else{
            this.refreshMenuPosition(pos);
        }


        this.refreshMenuItem();
    },

    //背景圆圈触摸响应
    touchcallback: function (sender, type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                cc.log("TOUCH_BEGAN");
                break;
            case ccui.Widget.TOUCH_MOVED:
                //cc.log("TOUCH_MOVED");
                break;
            case ccui.Widget.TOUCH_ENDED:
                cc.log("TOUCH_ENDED");
                ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});//关闭UI弹框
                break;
            case ccui.Widget.TOUCH_CANCELED:
                //cc.log("TOUCH_CANCELED");
                break;
            default:
                //cc.log("default");
                break;
        }
    },

    close:function() {

    },

    destroy:function() {
        EventMgr.inst().removeEventListener(CastleEvent.UPGRADE_COMPLETE, this.onUpdateUI, this);
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
    },

    onUpdateUI: function (type,index) {
        var buildingData = ModuleMgr.inst().getData("BuildingUIModule");
        ModuleMgr.inst().openModule("BuildingUIModule",{objectid:buildingData.buildingObjectId,
            objectpos:buildingData.buildingPosition,objectstate:null,
            objectindex:buildingData.buildingBlockId});
    },

    refreshMenuItem: function () {
        var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
        var length = buildingData.buildingItemArray.length;
        for (var i = 0; i < length; i++) {
            if (buildingData.buildingItemArray[i]) {
                buildingData.buildingItemArray[i].removeFromParent(true);
                buildingData.buildingItemArray[i] = null;
            }
        }
        buildingData.buildingItemArray=[];

        var counts = buildingData.menuUI.length;
        if(counts<4){
            buildingData.buildingMenuBg.loadTexture("zjm_tubiaodi23.png",ccui.Widget.PLIST_TEXTURE);
        }

        var posArray = buildingData.buildingPositionArray[counts-1];

        for (var i = 0;i < counts;i++) {
            var titleName = ResMgr.inst().getString(buildingData.menuUI[i]+"0");
            var cell = new CustomMenuItem(buildingData.menuUI[i]+"3",
                buildingData.menuUI+"1",
                titleName,this.touchEvent,buildingData.buildingBlockId,true);
            cell.setPosition(cc.p((buildingData._menuWidth-buildingData._itemWidth)*0.5,(buildingData._menuHeight-buildingData._itemHeight)*0.5));
            cell.setVisible(false);
            this.bgPanel.addChild(cell);

            //var delayTime = 0.1;
            var time = 0.5;
            var move = new cc.MoveTo(time, posArray[i]);
            //var action = new cc.EaseElasticOut(move,0.4);
            var action = new cc.EaseExponentialOut(move);
            //cell.runAction(cc.sequence(cc.DelayTime(i*delayTime), cc.Spawn(cc.Show(),action)));
            cell.runAction(cc.Spawn(cc.Show(),action));

            buildingData.buildingItemArray.push(cell);
        }
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("引导触发操作doGuide"+guideId);
        if(guideId=="1_3"){
            var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("UpgradeModule",{"id":buildingData.buildingObjectId,"blockId":buildingData.buildingBlockId});
            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});//关闭UI弹框
        }
        else if(guideId=="3_4"){
            var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("CitadelResourceModule");
            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});//关闭UI弹框
        }
        else if(guideId=="3_10"){
            var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("CollegeModule",{"id":buildingData.buildingObjectId,"blockId":buildingData.buildingBlockId});
            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});//关闭UI弹框
        }
    },
    touchEvent:function (sender) {
        var tag = sender.getTag(); //tag = buildingData.menuUI[i]
        //tag = parseInt(tag/10);
        var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
        //var scene = cc.Director.getInstance().getRunningScene();
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        cc.log("sender.getTag" ,tag,"objectId:",buildingData.buildingObjectId,buildingData.buildingBlockId);
        switch (tag) {
            case 1501001://升级
                cc.log("升级");
                ModuleMgr.inst().openModule("UpgradeModule",{"id":buildingData.buildingObjectId,"blockId":buildingData.buildingBlockId});//buildingData.buildingObjectId);
                break;
            case 1501002://详情
                cc.log("详情");
                ModuleMgr.inst().openModule("ParticularsModule",{"id":buildingData.buildingObjectId,"blockId":buildingData.buildingBlockId});
                break;
            case 1501003://进攻
                cc.log("进攻");
                break;
            case 1501004://购买
                cc.log("购买");
                break;
            case 1501005://出售
                cc.log("出售");
                break;
            case 1501006://撤单
                cc.log("撤单");
                break;
            case 1501007://放弃领地
                cc.log("放弃领地");
                break;
            case 1501008://训练
                cc.log("训练");
                ModuleMgr.inst().openModule("TrainingModule",{"id":buildingData.buildingObjectId,"blockid":buildingData.buildingBlockId});
                break;
            case 1503001://城市收益
                cc.log("城市收益");
                ModuleMgr.inst().openModule("CityGainModule");
                break;
            case 1503002://城堡资源
                cc.log("城堡资源");
                ModuleMgr.inst().openModule("CitadelResourceModule");
                break;
            case 1504001://城墙维修
                cc.log("城墙维修");
                //ModuleMgr.inst().openModule("TheWallModule");
                break;
            case 1505001://学院研究
                cc.log("学院研究");
                ModuleMgr.inst().openModule("CollegeModule",{"id":buildingData.buildingObjectId,"blockId":buildingData.buildingBlockId});
                break;
            case 1501012://升级加速
                ModuleMgr.inst().openModule("AccelerateModule", { id:buildingData.buildingObjectId, blockId:buildingData.buildingBlockId, collegeId:null,type:3 ,time:sender.exinfo} );
                break;
            case 1501013://金币加速升级
                EventMgr.inst().dispatchEvent( CastleEvent.SPEED_SUCCESS,buildingData.buildingBlockId);
                break;
            case 1501011://取消升级
                EventMgr.inst().dispatchEvent( CastleEvent.CANCEL_SUCCESS,buildingData.buildingBlockId);
                break;
            case 1501020:
                ModuleMgr.inst().openModule("SignModule");
                break;
            case 1501017://我的部队
                ModuleMgr.inst().openModule("CorpsAssembledModule");
                break;
            case 1501021://取消训练
                EventMgr.inst().dispatchEvent( CastleEvent.CANCEL_ARMY,buildingData.buildingBlockId);
                break;
            case 1501022://训练加速
                ModuleMgr.inst().openModule("AccelerateModule", { id:buildingData.buildingObjectId, blockId:buildingData.buildingBlockId, collegeId:null,type:2 ,time:sender.exinfo} );
                break;
            case 1501023://金币加速训练
                EventMgr.inst().dispatchEvent( CastleEvent.SPEED_ARMY,buildingData.buildingBlockId);
                break;

            default :
                break;
        }

        ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});//关闭UI弹框
    },

    refreshMenuPosition: function (pos) {
        if(pos==null) return;
        var buildingData =  ModuleMgr.inst().getData("BuildingUIModule");
        if (buildingData.buildingUI) {
            var pos = cc.p(pos.x-buildingData._menuWidth*0.5,pos.y-buildingData._menuHeight*0.5)
            //cc.log("pospos ",pos.x,pos.y);
            buildingData.buildingUI.setPosition(pos);
        }
    },

    update: function (dt) {
        var pos = ModuleMgr.inst().getData("CastleModule")._movePos;
        this.refreshMenuPosition(pos);
    },
    
    openModule: function (moduleid) {
        switch (moduleid) {
            case 1909001://军团集结
                cc.log("军团集结");
                ModuleMgr.inst().openModule("CorpsAssembledModule");
                break;
            case 1910001://交易市场
                cc.log("交易市场");
                if(mainData.playerData.attributes.getItem("type",304)) {
                    ModuleMgr.inst().openModule("AlertPanel", {
                        txt: "交易已开启",
                        type: 2
                    });
                }
                //ModuleMgr.inst().openModule("MarketModule");

                break;
            default :
                cc.error("error",moduleid);
                break
        }
    }
});