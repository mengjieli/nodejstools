/**
 * Created by Administrator on 2016/2/3 0003.
 */

Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

var TaxRecordModule = ModuleBase.extend({

    _root:null,

    _listView:null,
    _item:null,

    _lastIdx:-1,
    _isLoading:false,

    _curPage:0,
    _pageLabel:null,

    ctor: function () {
        this._super();
    },

    initUI: function () {
        var root = ccs.load("res/images/ui/taxRecord/Layer.json","res/images/ui/").node;
        this._root = root;
        this.addChild(root);

        var pnl = root.getChildByName("Panel_2");
        this._listView = pnl.getChildByName(("ListView_1"));
        this._listView.addCCSEventListener(this.onListViewEvent);
        var item = root.getChildByName("Item");
        this._item = item.clone();
        this._item.retain();
        item.setVisible(false);

        var helpBtn = pnl.getChildByName("Button_help");
        helpBtn.addTouchEventListener(this.onHelpBtnClick,this);

        this._pageLabel = pnl.getChildByName("Text_page");

        var closeBtn = pnl.getChildByName("guanbi");
        closeBtn.addTouchEventListener(this.onCloseBtnClick,this);

        EventMgr.inst().addEventListener("Receive_Tax_Record", this.onRecordReturnEvent, this);

        var data = ModuleMgr.inst().getData("TaxRecordModule");
        data.requestTaxRecord();
    },

    destroy: function () {
        this._item.release();
        EventMgr.inst().removeEventListener("Receive_Tax_Record", this.onRecordReturnEvent, this);

    },

    onHelpBtnClick: function (node,type) {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().openModule("AlertPanel", {"txt":ResMgr.inst().getString("taxTip"),"type":2 , "owner":this});

        }
    },

    onCloseBtnClick: function (node,type) {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().closeModule("TaxRecordModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            var data = ModuleMgr.inst().getData("TaxRecordModule");
            data.destroy();
        }
    },

    onListViewEvent: function (target,type) {
        //cc.log("event type------------->"+type);
        var self = target.getParent().getParent().getParent();
        if(type == ccui.ScrollView.EVENT_BOUNCE_BOTTOM)
        {
            var data = ModuleMgr.inst().getData("TaxRecordModule");
            cc.log("$$$$$$$$$ on list view events ---------------------->"+self._lastIdx+"--->"+data.getMaxPageIdx());

            if(self._lastIdx == data._beginIndex-1  )
            {
                if(!self._isLoading)
                {
                    cc.log("request next page----------1111111111111");
                    data.requestTaxRecord();
                    self.showLoading(true);
                }
            }
            else
            {
                if(self._curPage+1<=data.getMaxPageIdx())
                {
                    self._curPage++;
                    self.showPage(self._curPage);

                }
            }
        }
        else if(type == ccui.ScrollView.EVENT_BOUNCE_TOP)
        {
            if(self._curPage-1>=0)
            {
                self._curPage--;
                self.showPage(self._curPage);
            }
        }
    },

    onRecordReturnEvent: function (event,beginIdx,len) {
        //cc.log("#$#$###################################");
        this.showLoading(false);
        if(this.isCurPageFull())
        {
            this._curPage++;
            this.showPage(this._curPage);
        }
        else
        {
            this.showPage(this._curPage);
        }
    },

    showLoading: function (val) {
        this._isLoading = val;
    },

    isCurPageFull: function () {
        var items = this._listView.getItems();
        return items.length == TaxRecordData.RecordPerPage;
    },

    showPage: function (page) {
        var data = ModuleMgr.inst().getData("TaxRecordModule");

        if(page<0) return;
        if(page>data.getMaxPageIdx()) return;
        this.updatePageLabel();
        this._listView.removeAllItems();

        var beginIdx = page * TaxRecordData.RecordPerPage;
        cc.log("#$#$################################### show page begin idx-->"+beginIdx+" total record ->"+data._records.length);

        for(var i=0;i<TaxRecordData.RecordPerPage;i++)
        {
            var idx = beginIdx+i;
            var record = data._records[idx];
            cc.log("rrrrrrrrrrrrrrrrrrrrrr record data->"+record+"---->"+i+" beginidx ->"+beginIdx);

            if(record!=null && record!=undefined)
            {
                var item = this.record2Item(record);
                this._listView.pushBackCustomItem(item);
                //if(this._lastIdx < idx)
                {
                    this._lastIdx = idx;
                }
            }
            else
            {
                break;
            }

        }
    },

    record2Item: function (info) {
        var item = this._item.clone();

        var time = item.getChildByName("Text_time");
        var cd = new Date(info.timestamp);
        var s = cd.Format("yyyy-MM-dd hh:mm:ss")
        time.setString(s);

        var name = item.getChildByName("Text_name");
        var pd = mainData.playerDataList.getItem("account",info.fromAccountUuid);
        if(pd)
            s = pd.nick;
        else
            s = "未知玩家";
        name.setString(s);

        //for(var i = 0; i < mainData.playerDataList.list.length; i++) {
        //    var playerData = mainData.playerDataList.list[i];
        //    cc.log("player data->"+playerData.account+"-->"+playerData.nick);
        //}

        var amount = item.getChildByName("Text_amount");
        var old = item.getChildByName("Text_settlement1");
        var now = item.getChildByName("Text_settlement2");

        old.setString(info.oldAmount/100);
        now.setString(info.newAmount/100);
        amount.setString(Math.floor(info.newAmount-info.oldAmount)/100);

        return item;
    },

    updatePageLabel: function () {
        var data = ModuleMgr.inst().getData("TaxRecordModule");
        var max = data.getMaxPageIdx()+1;
        var s = (this._curPage+1) + "/" + max;
        this._pageLabel.setString(s);
    },



});