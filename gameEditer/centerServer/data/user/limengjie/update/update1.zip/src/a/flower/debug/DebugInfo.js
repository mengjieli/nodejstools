var flower;
(function (flower) {
    var DebugInfo = (function () {
        function DebugInfo() {
        }
        DebugInfo.debug = function (str, type) {
            if (type === void 0) { type = 0; }
            if (type == 1 && flower.Setting.warnInfo == false)
                return;
            if (type == 2 && flower.Setting.errorInfo == false)
                return;
            if (type == 3 && flower.Setting.tipInfo == false)
                return;
            if (type == 1)
                str = "[警告]  " + str;
            if (type == 2)
                str = "[错误] " + str;
            if (type == 3)
                str = "[提示] " + str;
            System.log(str);
        };
        DebugInfo.debug2 = function (type) {
            var args = [];
            for (var i = 0; i < arguments.length; i++) {
                if (i < 1)
                    continue;
                args.push(arguments[i]);
            }
            var str = "";
            for (var i = 0; i < args.length; i++) {
                var args = [];
                for (var i = 0; i < arguments.length; i++) {
                    if (i < 1)
                        continue;
                    args.push(arguments[i]);
                }
                str += args[i] + "\t";
            }
            flower.DebugInfo.debug(str, type);
        };
        return DebugInfo;
    })();
    flower.DebugInfo = DebugInfo;
})(flower || (flower = {}));
flower.DebugInfo.NONE = 0;
flower.DebugInfo.WARN = 1;
flower.DebugInfo.ERROR = 2;
flower.DebugInfo.TIP = 3;
//# sourceMappingURL=DebugInfo.js.map