var flower;
(function (flower) {
    var Blend = (function () {
        function Blend() {
        }

        var d = __define, c = Blend;
        p = c.prototype;

        Blend.NORMAL = 1;
        Blend.ADD = 2;

        return Blend;
    })();
    flower.Blend = Blend;
})(flower || (flower = {}));
