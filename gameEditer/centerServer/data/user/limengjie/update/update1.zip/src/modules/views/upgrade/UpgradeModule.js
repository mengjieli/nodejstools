/**
 * Created by Administrator on 2015/10/24.
 */

//升级

BattleRes = ["1102001","1102002","1102003","1102004"];

var UpgradeModule = ModuleBase.extend({

    _back: null,

    _id: null,
    _blockId: 0,

    _button:null,
    _buttonText:null,

    //代币数据
    //_itemId:null,
    //_counts:null,
    _array:null,
    ctor: function () {
        this._super();

        this._array = [];
    },

    initUI: function () {

        this._back = ccs.load("res/images/ui/publicBackdrop/Layer.json", "res/images/ui/").node;
        this.addChild(this._back);

        var PanelBg = this._back.getChildByName("Panel");
        sizeAutoLayout(PanelBg);

        var Panel_1 = PanelBg.getChildByName("Panel_1");
        sizeAutoLayout(Panel_1);

        var Image_bg = PanelBg.getChildByName("Image_4");
        sizeAutoLayout(Image_bg);

        var Image_top = PanelBg.getChildByName("Image_5");
        posAutoLayout(Image_top);

        var left = PanelBg.getChildByName("left");
        sizeAutoLayout(left);

        var Image_1_0_0 = left.getChildByName("Image_1_0_0");
        sizeAutoLayout(Image_1_0_0);
        posAutoLayout(Image_1_0_0,0.5);

        var leftbg = left.getChildByName("Image_1");
        sizeAutoLayout(leftbg);

        var name = left.getChildByName("name");
        posAutoLayout(name);

        var Image_1_0 = left.getChildByName("Image_1_0");
        posAutoLayout(Image_1_0,0.5);

        var ico = left.getChildByName("ico");
        posAutoLayout(ico,0.5);

        var Image_1_1 = left.getChildByName("Image_1_1");
        posAutoLayout(Image_1_1);

        var btn = this._back.getChildByName("Panel").getChildByName("left").getChildByName("Button");
        btn.addTouchEventListener(this.UpgradeCall, this);
        this._button = btn;

        var size = cc.director.getVisibleSize();
        this._back.setContentSize(size);
        ccui.helper.doLayout(this._back);


        EventMgr.inst().addEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeLevelCall, this );
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().addEventListener("using_token", this.usingCallback, this);

    },

    destroy: function ()
    {
        EventMgr.inst().removeEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeLevelCall, this );
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        if (this._son)
        {
            if( this._son.destroy && (typeof this._son.destroy == "function") )
            {
                this._son.destroy();
            }
            this._son.removeFromParent();
        }
        EventMgr.inst().removeEventListener("using_token", this.usingCallback, this);
        //this._itemId=null;
        //this._counts=null;
        this._array = [];
    },

    show: function (data)
    {
        if (data == null) return;

        this._id = data.id;//建筑ID
        this._blockId = data.blockId;//地块索引

        this.showUI();
        var guideData=ModuleMgr.inst().getData("GuideModule");
        if(guideData&&guideData._guideBean&&guideData._guideBean._idStep=="1_3"){//(!guideData&&mainData.playerData.guide=="2_1")||
            var size = cc.director.getVisibleSize();
            EventMgr.inst().dispatchEvent("guide_arrowP","up",cc.p(size.width-40-450,size.height-25));//发送引导点击位置事件
        }
    },

    close: function () {

    },

    showUI: function () {

        this.updateLeft();
        this.updateRight();
        this.upgradeLevelCall();
    },

    updateLeft: function () {
        var img = this._back.getChildByName("Panel").getChildByName("left").getChildByName("ico");
        img.ignoreContentAdaptWithSize(true);
        img.loadTexture(ResMgr.inst()._icoPath + this._id + "4.png");

        var name = this._back.getChildByName("Panel").getChildByName("left").getChildByName("name");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(this._id + "0"));
        var msg = this._back.getChildByName("Panel").getChildByName("left").getChildByName("msg");
        var str = this._id + "1";
        msg.setString(ResMgr.inst().getString(str));

        var buttonText = this._back.getChildByName("Panel").getChildByName("left").getChildByName("Button").getChildByName("Text");
        buttonText.ignoreContentAdaptWithSize(true);
        buttonText.setString(ResMgr.inst().getString("shengji_0"));
        buttonText = BorderText.replace(buttonText);
        this._buttonText = buttonText;
    },

    _son: null,
    updateRight: function () {
        if (this._son)
        {
            if( this._son.destroy && (typeof this._son.destroy == "function") )
            {
                this._son.destroy();
            }
            this._son.removeFromParent();
        }
        var ui = null;
        if (this._id == 1901001)//主城堡
        {
            ui = new CastleUpgradeUI(this._id, this._blockId);
            this.addChild(ui);
        }
        if (this._id == 1906001)//仓库
        {
            ui = new WarehouseUpgradeUI(this._id, this._blockId);
            this.addChild(ui);
        }
        else if (this._id == 1913001 || this._id == 1913002) //箭塔
        {
            ui = new TowerUpgradeUI(this._id, this._blockId);
            this.addChild(ui);
        }
        else if (this._id == 1903001)//学院
        {
            ui = new CollegeUpgradeUI(this._id, this._blockId );
            this.addChild(ui);
        }
        else if (this._id == 1907001)//城墙
        {
            ui = new TheWallUpgradeUI(this._id, this._blockId);
            this.addChild(ui);
        }
        else if(this._id == 1902001 || this._id == 1902002 || this._id == 1902003 || this._id == 1902004) //马厩 兵营 弓手 器械
        {
            ui = new StableUpgradeUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1904001) //民房
        {
            ui = new HouseUpgradeUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1909001) //校场
        {
            ui = new DrillGroundUpgradeUI( this._id,this._blockId );
            this.addChild( ui );
        }

        this._son = ui;
    },

    UpgradeCall: function (node, type) {
        if (type != ccui.Widget.TOUCH_ENDED)return;
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        EventMgr.inst().dispatchEvent(CastleEvent.UPGRADE_SUCCESS, this._blockId,this._array);
        ModuleMgr.inst().closeModule("UpgradeModule");
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("UpgradeModule引导触发操作doGuide"+guideId);
        if(guideId=="1_5"){
            this.UpgradeCall(null,ccui.Widget.TOUCH_ENDED);
        }
        else if(guideId=="1_4"){
            EventMgr.inst().dispatchEvent("guide_handP",this._button.getPosition());//发送引导点击位置事件
        }
    },

    upgradeLevelCall:function()
    {
        var level = this._back.getChildByName("Panel").getChildByName("left").getChildByName("level");
        level.ignoreContentAdaptWithSize(true);

        var level_ = 0;
        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        var info = null;
        if( data )
        {
            list = data.getNetBlock( );
        }

        if( list != null && list[this._blockId] != null )
        {
            info = list[this._blockId];
            if( info )
            {
                level_ = info._building_level;
            }
        }
        level.setString(ResMgr.inst().getString("xiangqing_1") + " " + level_);

        //检测是否满级
        var data = null;
        switch (this._id){
            case 1901001:
                data = modelMgr.call("Table","getTableList",["City_Castel"]);
                break;
            case 1906001:
                data = modelMgr.call("Table","getTableList",["City_Storage"]);
                break;
            case 1913001:
            case 1913002:
                data = modelMgr.call("Table","getTableList",["City_Tower"]);
                break;
            case 1903001:
                data = modelMgr.call("Table","getTableList",["City_College"]);
                break;
            case 1907001:
                data = modelMgr.call("Table","getTableList",["City_Wall"]);
                break;
            case 1902001:
                data = modelMgr.call("Table","getTableList",["City_Camp_horse"]);
                break;
            case 1902002:
                data = modelMgr.call("Table","getTableList",["City_Camp_Barracks"]);
                break;
            case 1902003:
                data = modelMgr.call("Table","getTableList",["City_Camp_target"]);
                break;
            case 1902004:
                data = modelMgr.call("Table","getTableList",["City_Camp_instrument"]);
                break;
            case 1904001:
                data = modelMgr.call("Table","getTableList",["City_House"]);
                break;
            case 1909001:
                data = modelMgr.call("Table","getTableList",["City_Flied"]);
                break;
        }
        if(data){
            if(data.length==level_){
                this._buttonText.setString(ResMgr.inst().getString("wall_1"));
                this._button.setBright(false);
            }
        }
    },

    //id:资源ID，counts:使用的代币数量，exinfo:剩余的资源数量
    usingCallback: function (event, id, counts, exinfo) {
        var itemId = null;
        switch (parseInt(id)){
            case 1101001:
                itemId = 1101201;
                break;
            case 1101002:
                itemId = 1101202;
                break;
            case 1101003:
                itemId = 1101203;
                break;
        }
        var count = counts;

        var exist = false;
        for(var i in this._array){
            if(this._array[i].itemId==itemId){
                this._array[i].counts = count;
                exist = true;
            }
        }

        if(!exist){
            this._array.push({"itemId":itemId,"counts":count});
        }
    }

});