//auto:标识取消自动登录,默认null（false），用于注销游戏gameover模块 111


var Game = function (auto) {
    var _me = this;
    var _timer;

    var _vector = [];

    function init() {

        //TODO 换成新的注册登录流程之后删掉下面2个步骤
        //初始化数据和网络监听
        //new InitClientData();
        //new InitCommand();

        EnterFrame.init();

        //原始本地
        loadResources();

        //刷新视野
        var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
        var start = {x:castle.coordX - 30,y:castle.coordY - 30};
        var end = {x:castle.coordX + 30,y:castle.coordY + 30};
        var msg = new SocketBytes();
        msg.writeUint(301);
        msg.writeInt(start.x);
        msg.writeInt(start.y);
        msg.writeUint(end.x - start.x);
        msg.writeUint(end.y - start.y);
        NetMgr.inst().send(msg);
    }


    /*
     * 加载公共资源
     */
    function loadResources() {
        var resList = ResMgr.inst().getModuleResources("public");
        if (resList && resList.length > 0) {
            ResMgr.inst().loadList("公共资源", resList,
                function (event, loadName) {
                    if (event == LoadEvent.LOAD_COMPLETE) {
                        runGame();
                    }
                }, this);
        }
        else {
            console.log("load source complete2");
            runGame();
        }
    }

    /*
     * 启动游戏
     */
    function runGame() {
        cc.log("开始游戏" + mainData.playerData.guide);
        if (mainData.playerData.guide == "2_2" || mainData.playerData.guide == "2_8" || mainData.playerData.guide == "2_14" ||
            mainData.playerData.guide == "3_1" || mainData.playerData.guide == "4_4") {
            var msg = new SocketBytes();
            msg.writeUint(CastleNetEvent.SEND_CASTLE);
            msg.writeString(mainData.uiData.currentCastleId);
            NetMgr.inst().send(msg);
            //mainData.uiData.showCastleFinish = true;
            mainData.uiData.showMap = "map";
        }//引导特殊处理锁定大地图
        //2015-10-15 by shenwei 原始模块调整到加载-登陆模块后等通知

        ModuleMgr.inst().closeModule("GameLoginModule");

        //初始化Data
        ModuleMgr.inst().getData("CollectModule");
        ModuleMgr.inst().getData("ServerTimeData");
        //createYuyan();

        ModuleMgr.inst().openModule("MainResourcesModule");
        if (mainData.uiData.showMap == "castle") {
            ModuleMgr.inst().openModule("CastleModule");
            ModuleMgr.inst().openModule("MainMenuModule");
        } else if (mainData.uiData.showMap == "map") {
            ModuleMgr.inst().openModule("BigMapModule");
            ModuleMgr.inst().openModule("BattleUIModule");//战斗UI
            ModuleMgr.inst().openModule("MainMenuModule");
        }

        SoundPlay.playMusic(ResMgr.inst().getSoundPath(1));
    }


    /*
     * 注册所有的模块
     * 注册模块分3块，（模块，数据，资源），注册的时候必须有一个不能为NULL
     */
    function registerLoadingAndLoginingModule() {
        //预加载公共
        registerModuleAndData("AlertPanel", {
            className: "AlertPanelModule",
            layer: ModuleLayer.LAYER_TYPE_TOP
        }, null, []);
        registerModuleAndData("AlertString", {
            className: "AlertStringModule",
            layer: ModuleLayer.LAYER_TYPE_TOP
        }, null, []);

        cc.log("注册游戏加载-登陆模块...");
        //加载-登陆-注册-找回(取代Login模块)
        registerModuleAndData("Loading", {
            className: "LoadingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, {className: "LoadingData", isInit: false}, ["res/loadingAndLogining/loadingUI.json"]);
        registerModuleAndData("Registering", {
            className: "RegisteringModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/registeringUI.json"]);
        registerModuleAndData("UserAnnouncing", {
            className: "UserAnnouncingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/AnnouncingUI.json"]);
        registerModuleAndData("Presetting", {
            className: "PresettingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/presettingUI.json"]);
        registerModuleAndData("Retrieving", {
            className: "RetrievingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/pwRetrievingUI.json"]);
        registerModuleAndData("MSGActivating", {
            className: "MSGActivatingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/pwActivatingUI.json"]);
        registerModuleAndData("ImgNavigating", {
            className: "ImgNavigatingModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        }, null, ["res/loadingAndLogining/imgNavigatingUI.json"]);


        ModuleMgr.inst().initData();

        cc.eventManager.addCustomListener(cc.game.EVENT_HIDE, function (event) {
            if (NetMgr.inst().isConnection() == true) {
                NetMgr.inst().closeWebScoket();
            }
            //_timer.stop();
        });

        cc.eventManager.addCustomListener(cc.game.EVENT_SHOW, function (event) {
            if (NetMgr.inst().isConnection() == false) {
                //_timer.start();
            }
        });
    }

    function setTxtColor(tag) {
        for (var i in _vector) {
            if (tag == i) {
                _vector[i].setTextColor(cc.color(0, 255, 0));
            }
            else {
                _vector[i].setTextColor(cc.color(255, 255, 255));
            }
        }
    }

    function createYuyan() {
        //四个语言版本
        var txt = ccui.Text();
        txt.setFontSize(25);
        txt.setAnchorPoint(0, 0);
        txt.setString("韩文");
        txt.setPosition(10, 130);
        txt.setTouchEnabled(true);
        txt.setTag(0);
        txt.addTouchEventListener(function (node, type) {
            if (type != ccui.Widget.TOUCH_ENDED) return;
            cc.log("韩文");
            ResMgr.inst().setLanguage("KR");
            setTxtColor(node.getTag());
        }, this);
        ModuleMgr.inst().addNodeTOLayer(txt, ModuleLayer.LAYER_TYPE_TOP);
        _vector.push(txt);

        txt = ccui.Text();
        txt.setFontSize(25);
        txt.setAnchorPoint(0, 0);
        txt.setString("英文");
        txt.setPosition(10, 90);
        txt.setTouchEnabled(true);
        txt.setTag(1);
        txt.addTouchEventListener(function (node, type) {

            if (type != ccui.Widget.TOUCH_ENDED) return;
            cc.log("英文");
            ResMgr.inst().setLanguage("EN");
            setTxtColor(node.getTag());
        }, this);
        ModuleMgr.inst().addNodeTOLayer(txt, ModuleLayer.LAYER_TYPE_TOP);
        _vector.push(txt);

        txt = ccui.Text();
        txt.setFontSize(25);
        txt.setAnchorPoint(0, 0);
        txt.setString("中文");
        txt.setPosition(10, 50);
        txt.setTouchEnabled(true);
        txt.setTag(2);
        txt.addTouchEventListener(function (node, type) {

            if (type != ccui.Widget.TOUCH_ENDED) return;
            cc.log("中文");
            ResMgr.inst().setLanguage("CN");
            setTxtColor(node.getTag());
        }, this);
        ModuleMgr.inst().addNodeTOLayer(txt, ModuleLayer.LAYER_TYPE_TOP);
        _vector.push(txt);

        txt = ccui.Text();
        txt.setFontSize(25);
        txt.setAnchorPoint(0, 0);
        txt.setString("繁体");
        txt.setPosition(10, 10);
        txt.setTouchEnabled(true);
        txt.setTag(3);
        txt.addTouchEventListener(function (node, type) {

            if (type != ccui.Widget.TOUCH_ENDED) return;
            cc.log("繁体");
            ResMgr.inst().setLanguage("ZH");
            setTxtColor(node.getTag());
        }, this);
        ModuleMgr.inst().addNodeTOLayer(txt, ModuleLayer.LAYER_TYPE_TOP);
        _vector.push(txt);
        setTxtColor(2);
    }


    init();
}

/*
 * 注册模块
 * moduleName ：模块名称　
 * moduleConfig =
 * {
 *  moduleName:模块名称，如果没有就默认上面模块名
 *  className:模块类，工厂类会根据该名字创建类对像
 *  isCache:是否缓存
 * }
 * dataConfig =
 * {
 *  dataName:模块名称，如果没有就默认上面模块名
 *  className:模块类，工厂类会根据该名字创建类对像
 *  isInit:是否游戏开始就初始化
 *  cmdList:[] //初始化CMD表，目前没用。以后在增加，这个list会初始化到NetMgr里
 * }
 * resources:资源列表，模块初始化的时候会加载该资源，模块卸载的时候会移除该资源
 *
 */
function registerModuleAndData(moduleName, moduleConfig, dataConfig, resources) {
    var name = moduleName;
    if (moduleConfig) {
        moduleConfig.moduleName != undefined ? moduleName = moduleConfig.moduleName : moduleName = name;
        ModuleMgr.inst().registerModuleClass(moduleName, moduleConfig.className, moduleConfig.layer, moduleConfig.isCache == undefined ? false : moduleConfig.isCache);
    }
    if (dataConfig) {
        dataConfig.dataName != undefined ? moduleName = dataConfig.dataName : moduleName = name;
        ModuleMgr.inst().registerDataClass(moduleName, dataConfig.className, dataConfig.isInit == undefined ? false : dataConfig.isInit);
    }

    if (resources) {
        ResMgr.inst().registerModuleResources(moduleName, resources);
    }
}

//适配
//大小适配
function sizeAutoLayout(node, scale) {
    scale = scale ? scale : 1;
    var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
    down = down * (1 / GameMgr.inst().scaleX);
    var size = node.getContentSize();
    size.height += down * scale;
    node.setContentSize(size);
}

//坐标适配
function posAutoLayout(node, scale) {
    scale = scale ? scale : 1;
    var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
    down = down * (1 / GameMgr.inst().scaleX);
    var posY = node.getPositionY();
    posY += down * scale;
    node.setPositionY(posY);
}

function encodeString (data) {
    return encodeURI(data);
}
