function NetCompiler() {
}

NetCompiler.initData = function (data) {
    NetCompiler.data = data;
}

NetCompiler.data = null;

NetCompiler.decode = function (cmd, data) {
    data.resetCMDData();
    var define = NetCompiler.data[cmd];
    //trace("自动解析协议:",cmd);
    var res = {};
    if(!define) {
        trace("饿呢消息都没了???",cmd);
    }
    for (var i = 0; i < define.length; i++) {
        NetCompiler.decodeSingle(res,define[i],data);
    }
    return res;
}

NetCompiler.decodeSingle = function(res,define,data) {
    var changeName = {
        "string": "String",
        "uint": "Uint",
        "int": "Int",
        "bool":"Boolean"
    }
    if (define.type == "Array") {
        res[define.name] = NetCompiler.decodeArray(define.typeValue, data);
    } else {
        var value = data["read" + changeName[define.type]]();
        res[define.name] = value;
    }
}

NetCompiler.decodeArray = function (define, data) {
    var list = new ArrayData();
    var len = data.readUint();
    for(var i = 0; i < len; i++) {
        var item = {};
        for(var t = 0; t < define.length; t++) {
            NetCompiler.decodeSingle(item,define[t],data);
        }
        list.push(item);
    }
    return list;
}