var MapRoler = MapDisplayBase.extend({
    shaderLayer: null,
    data: null,
    id: null,
    cache: null,
    shows: null,
    action: null,
    dir: null,
    path: null,
    nextPoint: null,
    moveTime: null,
    moveVX: null,
    moveVY: null,
    moveV: 0.5,
    selectedShow: null,
    blood: null,
    effectTexts:null,
    bag:null,
    bgContainer:null,
    rolerContainer:null,
    //frontContainer:null,
    bag:null,
    ctor: function (shaderLayer, data) {
        this.data = data;
        this._super(MapDisplayType.Player);
        this.addChild(this.bgContainer = new cc.Sprite());
        this.addChild(this.rolerContainer = new cc.Sprite());
        this.addChild(this.bag = new cc.Sprite("res/fight/ui/bag.png"));
        //this.addChild(this.frontContainer = new cc.Sprite());
        this.data.display = this;
        this.shaderLayer = shaderLayer;
        this.path = [];
        this.effectTexts = [];
        this.id = data.id;
        this.cache = {};
        this.shows = [];
        var blood = this.data.attributes.getItem("type", 2500011).value;
        var fullBlood = this.data.attributes.getItem("type", 2500077).value;
        trace("this.data.config.arm_type", this.data.config.arm_type);
        this.showArray = JSON.parse(ModelManager.getInstance().call("Table", "getTableItemByValue", ["arm_interval", this.data.config.arm_type]).arm_display);
        this.showArray = this.showArray.slice(0, Math.ceil(this.showArray.length * blood / fullBlood));
        this.moveV = 1 / this.data.config.speed;
        this.setCoord(data.coordX, data.coordY);
        this.playAction(Action.Stand, Dir.RightDown);
        this.data.addListener("selected", this.setSelected, this);
        this.data.addListener("positionChange", this.onServerMove, this);
        this.data.addListener("attributes", this.changeBlood, this);
        this.data.addListener("relation", this.onRelationChange, this);
        this.data.addListener("resource", this.onResourceChange, this);
        mainData.mapData.addListener("attack", this.receiveAttackData, this);
        this.bag.setVisible(this.data.resource);
        //mainData.mapData.addListener("");
        if (this.data.selected == true) {
            this.setSelected(true);
        }
        this.blood = new RolerBlood(this.data);
        this.addChild(this.blood);
        this.blood.setPosition(0, 50);
    },
    onResourceChange: function(value) {
        this.bag.setVisible(this.data.resource);
    },
    changeBlood: function (attributes) {
        var blood = this.data.attributes.getItem("type", 2500011).value;
        var fullBlood = this.data.attributes.getItem("type", 2500077).value;
        var showArray = JSON.parse(ModelManager.getInstance().call("Table", "getTableItemByValue", ["arm_interval", this.data.config.arm_type]).arm_display);
        var showArray = this.showArray.slice(0, Math.ceil(this.showArray.length * blood / fullBlood));
        if (showArray.length != this.showArray.length) {
            while (this.showArray.length > showArray.length) {
                this.showArray.pop();
                var index = this.showArray.length;
                if (this.shows.length > index) {
                    var show = this.shows.pop();
                    if (index == 0) {
                        show.dispatcher.removeEventListener(flower.Event.DISPOSE, this.onDisposeShow, this);
                    }
                    if (show.disposeFlag == false) {
                        show.dispose();
                    }
                }
            }
        }
    },
    playAction: function (action, dir, time) {
        time = time || 10000000;
        if (dir == null) {
            dir = this.dir;
        }
        if (action == this.action && dir == this.dir) {
            return;
        }
        if (this.shows.length) {
            //this.show.retain();
            //this.cache[this.action + "_" + this.dir] = this.show;
            for (var i = 0; i < this.shows.length; i++) {
                var show = this.shows[i];
                if (i == 0) {
                    show.dispatcher.removeEventListener(flower.Event.DISPOSE, this.onDisposeShow, this);
                }
                if (show.disposeFlag == false) {
                    show.dispose();
                }
                this.shows[i] = null;
            }
            this.shows = [];
        }
        this.action = action;
        this.dir = dir;
        /*if (false && this.cache[action + "_" + dir]) {
         this.show = this.cache[action + "_" + dir];
         //this.show.release();
         this.cache[action + "_" + dir] = null;
         } else {
         var look = this.data.config.arm_type;
         trace("外观", look);
         this.show = RolerAnimationData.getRolerAnimation(look, action, dir);
         }*/
        var look = this.data.config.arm_image;
        trace("外观", look);
        var poses = this.showArray.slice(0, this.showArray.length);
        poses.sort(function (a, b) {
            return a[1] == b[1] ? 0 : (a[1] < b[1] ? 1 : -1);
        });
        for (var i = 0; i < poses.length; i++) {
            var show = RolerAnimationData.getRolerAnimation(look, action, dir);
            if (this.data.relation == "enemy") {
                show.setShader(Shader.getRolerColor("R"));
            } else if (this.data.relation == "other") {
                show.setShader(Shader.getRolerColor("Y"));
            } else if (this.data.relation == "monster" && ModelManager.getInstance().call("Table", "getTbaleItem", ["Arm", "arm_image", look])) {
                show.setShader(Shader.getRolerColor("Black"));
            }
            show.setPosition(poses[i][0], poses[i][1]);
            this.shows.push(show);
            if (i == 0) {
                //如果是多个 show 只监听第一个 show
                show.dispatcher.addEventListener(flower.Event.DISPOSE, this.onDisposeShow, this);
            }
            show.play(time);
            this.rolerContainer.addChild(show);
        }
        var _this = this;
    },
    /**
     * 关系改变，只有从 other->enemy 或者 enemy->other
     * @param relation
     */
    onRelationChange: function (relation) {
        for(var i = 0; i < this.shows.length; i++) {
            var show = this.shows[i];
            if (this.data.relation == "enemy") {
                show.setShader(Shader.getRolerColor("R"));
            } else if (this.data.relation == "other") {
                show.setShader(Shader.getRolerColor("Y"));
            }
        }
    },
    onDisposeShow: function (event) {
        this.playAction(Action.Stand);
    },
    onServerMove: function () {
        //trace("服务器消息移动", this.data.coordX, this.coordY);
        this.goDownTheRoad([{x: this.data.coordX, y: this.data.coordY}]);
    },
    goDownTheRoad: function (path) {
        if (path == null) return;
        if (path.length == 0) return;
        for (var i = 0; i < path.length; i++) {
            this.path.push(path[i]);
        }
        if (this.action == Action.Stand) {
            this.scheduleUpdate();
            this.moveToNextPoin();
        }
    },
    moveToNextPoin: function () {
        if(ModelManager.getInstance().call("Table","getTableItemByValue",["sounds",this.data.config.arm_type + "_move.mp3"])) {
            SoundPlay.playEffect("res/sounds/" + this.data.config.arm_type + "_move.mp3");
        }
        this.nextPoint = this.path.shift();
        //计算方向
        var dir = "";
        if (this.nextPoint.y == this.coordY) {
            if (this.nextPoint.x == this.coordX + 1) {
                dir = Dir.Right;
            } else if (this.nextPoint.x == this.coordX - 1) {
                dir = Dir.Left;
            }
        } else {
            if (this.coordY % 2 == 0) {
                if (this.nextPoint.x == this.coordX) {
                    if (this.nextPoint.y == this.coordY + 1) {
                        dir = Dir.RightUp;
                    } else if (this.nextPoint.y == this.coordY - 1) {
                        dir = Dir.RightDown
                    }
                } else {
                    if (this.nextPoint.y == this.coordY + 1) {
                        dir = Dir.LeftUp;
                    } else if (this.nextPoint.y == this.coordY - 1) {
                        dir = Dir.LeftDown
                    }
                }
            } else {
                if (this.nextPoint.x == this.coordX) {
                    if (this.nextPoint.y == this.coordY + 1) {
                        dir = Dir.LeftUp;
                    } else if (this.nextPoint.y == this.coordY - 1) {
                        dir = Dir.LeftDown
                    }
                } else {
                    if (this.nextPoint.y == this.coordY + 1) {
                        dir = Dir.RightUp;
                    } else if (this.nextPoint.y == this.coordY - 1) {
                        dir = Dir.RightDown
                    }
                }
            }
        }
        if (dir == "") {
            this.setCoord(this.nextPoint.x, this.nextPoint.y);
            this.nextPoint = null;
            if (this.path.length) {
                this.moveToNextPoin();
            } else {
                this.playAction(Action.Stand);
                this.unscheduleUpdate();
            }
            return;
        }
        this.playAction(Action.Run, dir);
        //计算速度
        if (dir == Dir.Left || dir == Dir.Right) {
            this.moveTime = this.moveV;
            this.moveVX = (dir == Dir.Right ? 1 : -1) * MapUtils.width / this.moveTime;
            this.moveVY = 0;
        } else {
            this.moveTime = this.moveV;
            this.moveVX = MapUtils.obliqueCos * MapUtils.obliqueDis / this.moveTime;
            this.moveVY = MapUtils.obliqueSin * MapUtils.obliqueDis / this.moveTime;
            if (dir == Dir.RightDown || dir == Dir.LeftDown) {
                this.moveVY = -this.moveVY;
            }
            if (dir == Dir.LeftUp || dir == Dir.LeftDown) {
                this.moveVX = -this.moveVX;
            }
        }
    },
    update2Flag:false,
    update2: function(dt) {
        for(var i = 0; i < this.effectTexts.length; i++) {
            var eft = this.effectTexts[i];
            eft.time = (jc.EnterFrame.curTime - eft.start)/1000;
            eft.txt.setPositionY(eft.y+eft.time*30);
            if(eft.time < 0.25) {
                eft.txt.setOpacity(255*4*eft.time);
                eft.txt.setScale((1+eft.time*3));
            } else if(eft.time < 0.5) {
                eft.txt.setOpacity(255*4*(1-eft.time));
                eft.txt.setScale((1+(0.5-eft.time)*3));
            } else {
                this.removeChild(eft.txt);
                this.effectTexts.splice(i,1);
                i--;
            }
        }
        if(this.effectTexts.length == 0) {
            jc.EnterFrame.del(this.update2,this);
            this.update2Flag = false;
        }
    },
    update: function (dt) {
        ////trace("移动", dt, this.path, this.nextPoint);
        this.setPos(this.px + dt * this.moveVX, this.py + dt * this.moveVY);
        //this.data.moveTo(this.coordX, this.coordY, this.px, this.py);
        this.moveTime -= dt;
        if (this.moveTime < 0) {
            this.setCoord(this.nextPoint.x, this.nextPoint.y);
            //trace("我的点", this.coordX, this.coordY, this.nextPoint.x, this.nextPoint.y);
            this.nextPoint = null;
            if (this.path.length) {
                this.moveToNextPoin();
            } else {
                this.playAction(Action.Stand);
                this.unscheduleUpdate();
            }
        }
    },
    isMy: function () {
        return this.data.userAccount == mainData.playerData.account ? true : false;
    },
    setSelected: function () {
        //if(this.getParent() == null) {
        //    return;
        //}
        var flag = this.data.selected;
        if (flag == true) {
            if (!this.selectedShow) {
                this.selectedShow = new Animation(MapRoler.cfg);
                this.bgContainer.addChild(this.selectedShow, -1);
            }
            this.selectedShow.play();
            this.selectedShow.setVisible(true);
        } else {
            if (this.selectedShow) {
                this.selectedShow.setVisible(false);
                this.selectedShow.stop();
            }
        }
    },
    moveTo: function (x, y, action) {
        action = action == null ? 0 : action;
        if (this.data.coordX < mainData.mapData.cameraData.viewPort.x ||
            this.data.coordX >= mainData.mapData.cameraData.viewPort.x + mainData.mapData.cameraData.viewPort.width ||
            this.data.coordY < mainData.mapData.cameraData.viewPort.y ||
            this.data.coordY >= mainData.mapData.cameraData.viewPort.y + mainData.mapData.cameraData.viewPort.height) {
            ModuleMgr.inst().openModule("AlertString", {
                str: ResMgr.inst().getString("moveOutRange"),
                color: null,
                time: null,
                pos: null
            });
            return;
        }

        var pos = MapUtils.transPositionToPoint(x, y);
        var rolerServer = ServerMapConfig.getInstance().getServerCoord(this.data.coordX, this.data.coordY);
        var touchServer = ServerMapConfig.getInstance().getServerCoord(pos.x, pos.y);
        if (rolerServer.x != touchServer.x || rolerServer.y != touchServer.y) {
            var dir = -1;
            if (rolerServer.y == touchServer.y && Math.abs(rolerServer.x - touchServer.x) == 1) {
                if (rolerServer.x < touchServer.x && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).x == ServerMapConfig.getInstance().serverCoordWidth - 3) {
                    dir = 0;
                } else if (rolerServer.x > touchServer.x && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).x == 2) {
                    dir = 2;
                }
            } else if (rolerServer.x == touchServer.x && Math.abs(rolerServer.y - touchServer.y) == 1) {
                if (rolerServer.y < touchServer.y && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).y == ServerMapConfig.getInstance().serverCoordHeight - 3) {
                    dir = 1;
                } else if (rolerServer.y > touchServer.y && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).y == 2) {
                    dir = 3;
                }
            }
            //string      mapObjectUuid       // 部队 uuid
            //uint        direction           // 0, 1, 2, 3 对应 向右，向上，向左，向下。注意不同方向的跳跃对部队当前的坐标有限定。
            if (dir >= 0) {
                var msg = new SocketBytes();
                msg.writeUint(309);
                msg.writeString(this.id);
                msg.writeUint(dir);
                NetMgr.inst().send(msg);
                console.log("跨越服务器:" + dir);
            } else {
            }
            return;
        }
        ////trace("触摸点", x, y, pos.x, pos.y);
        var start = this.checkPathOutCastle(pos.x, pos.y);
        //周围所有的路都被堵死了
        if (!start) {
            return null;
        }
        var path;
        //trace("是否在城内?",start.endInRange);
        if (start.endInRange) {
            path = start.path;
        } else {
            path = ServerMapConfig.getInstance().astar.findPath(start.x, start.y, pos.x, pos.y);
            if (!path || !path.length) {
                return;
            }
            if (start.path) {
                path = start.path.concat(path);
            }
        }
        //this.goDownTheRoad(path);
        var msg = new SocketBytes();
        msg.writeUint(303);
        msg.writeString(this.id);
        var str = "寻路结果: ";
        for (var i = 0; i < path.length; i++) {
            str += "(" + path[i].x + "," + path[i].y + ")" + (i < path.length - 1 ? "->" : "");
        }
        //trace(str);
        msg.writeUint(path.length);
        var lastPath = {x: this.data.coordX, y: this.data.coordY};
        for (var p = 0; p < path.length; p++) {
            msg.writeInt(path[p].x - lastPath.x);
            msg.writeInt(path[p].y - lastPath.y);
            console.log((path[p].x - lastPath.x) + "," + (path[p].y - lastPath.y));
            lastPath = path[p];
        }
        msg.writeUint(action);
        msg.writeString("");
        NetMgr.inst().send(msg);
    },
    receiveAttackData: function (attackData) {
        if(attackData.roler.id == this.data.id) {
            if(attackData.type == 2) {
                this.showTextEffect("暴击",{r:0xffce0b>>16,g:0xffce0b>>8&0xFF,b:0xffce0b&0xFF,a:255});
            }
        }
        if(attackData.aim && attackData.aim.id == this.data.id) {
            if(attackData.type == 1) {
                this.showTextEffect("闪避",{r:0xdcdcdc>>16,g:0xdcdcdc>>8&0xFF,b:0xdcdcdc&0xFF,a:255});
            }
            if(ModelManager.getInstance().call("Table","getTableItemByValue",["sounds",this.data.config.arm_type + "_attacked.mp3"])) {
                SoundPlay.playEffect("res/sounds/" + this.data.config.arm_type + "_attacked.mp3");
            }
        }
        if (attackData.roler.id != this.data.id) {
            return;
        }
        var dir = this.getAttackDir(attackData.aimX, attackData.aimY, this.data.coordX, this.data.coordY);
        this.playAction(Action.Attack, dir, 1);
        var attackInfo = ModelManager.getInstance().call("Table", "getTableItemByValue", ["arm_interval", this.data.config.arm_type]);
        if (attackInfo.weapon != "") {
            var poses = this.showArray;
            for (var i = 0; i < poses.length; i++) {
                var weapon = DataManager.getInstance().getNewData("WeaponData");
                weapon.name = attackInfo.weapon;
                weapon.coordX = this.data.coordX;
                weapon.coordY = this.data.coordY;
                weapon.aimX = attackData.aimX;
                weapon.aimY = attackData.aimY;
                trace("武器", weapon.coordX, weapon.coordY, weapon.aimX, weapon.aimY);
                weapon.offX = 0 + poses[i][0];
                weapon.offY = 20 + poses[i][1];
                mainData.mapData.weapon = weapon;
            }
        }
        if(ModelManager.getInstance().call("Table","getTableItemByValue",["sounds",this.data.config.arm_type + "_attack.mp3"])) {
            SoundPlay.playEffect("res/sounds/" + this.data.config.arm_type + "_attack.mp3");
        }
    },
    getAttackDir: function (startX, startY, endX, endY) {
        var start = MapUtils.transPointToPosition(startX, startY);
        var end = MapUtils.transPointToPosition(endX, endY);
        var rot = Math.atan2(end.y - start.y, end.x - start.x);
        rot = -rot * 180 / Math.PI + 180;
        rot = rot % 360;
        var dirs = [Dir.Right, Dir.RightDown, Dir.LeftDown, Dir.Left, Dir.LeftUp, Dir.RightUp];
        rot += 30;
        rot = rot % 360;
        var index = Math.floor(rot / 60);
        index = index >= dirs.length ? dirs.length - 1 : index;
        return dirs[index];
        //trace("角度",rot);
    },
    showTextEffect: function(text,color) {
        if(this.data.display==null) {
            return;
        }
        var txt = ccui.Text();
        txt.setFontSize(18);
        txt.setTextColor(color);
        txt.setString(text);
        txt.setOpacity(0);
        txt.setPositionY(50);
        this.addChild(txt);
        this.effectTexts.push({"txt":txt,time:0,start:jc.EnterFrame.curTime,y:txt.getPositionY()});
        if(this.update2Flag == false) {
            jc.EnterFrame.addWithTimeStamp(this.update2,this);
            this.update2Flag = true;
        }
    },
    dispose: function () {
        if(this.update2Flag) {
            jc.EnterFrame.del(this.update2,this);
        }
        this.blood.dispose();
        this.data.display = null;
        this.data.removeListener("selected", this.setSelected, this);
        this.data.removeListener("positionChange", this.onServerMove, this);
        this.data.removeListener("relation", this.onRelationChange, this);
        this.data.removeListener("resource", this.onResourceChange, this);
        mainData.mapData.removeListener("attack", this.receiveAttackData, this);
        if (this.selectedShow) {
            this.selectedShow.dispose();
        }
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
    }
});

MapRoler.cfg = {
    plist: "res/fight/effect/army/selectRoler.plist",
    name: "selectRoler_00",
    format: "png",
    start: 0,
    end: 7,
    frameRate: 6,
    x: 0,
    y: 0,
    scaleX: 2,
    scaleY: 2
};