/**
 * Created by Administrator on 2015/11/24/0024.
 */
var PlayerInfoModule = ModuleBase.extend({
    _ui: null,//ui
    _id:null,//玩家id
    _tfName:null,//名字
    _imgHead:null,//头像
    _btPrivateChat:null,//私聊按钮
    _btAddFriend:null,//加好友按钮
    _btClose:null,//关闭按钮

    _playerInfo:null,//玩家信息
    ctor: function ()
    {
        this._super();
    },
    initUI: function ()
    {
        this._ui = ccs.load("res/images/ui/playerInfo/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        this._tfName = this._ui.getChildByName("Panel_2").getChildByName("name");
        this._imgHead = this._ui.getChildByName("Panel_2").getChildByName("head");
        this._btPrivateChat = this._ui.getChildByName("Panel_2").getChildByName("private_chat");
        this._btPrivateChat.getChildByName("Text_4").setString( ResMgr.inst().getString("chat_7"));
        this._btPrivateChat.addTouchEventListener( this.onPrivateChat, this );
        this._btAddFriend = this._ui.getChildByName("Panel_2").getChildByName("add_friend");
        this._btAddFriend.getChildByName("Text_4").setString( ResMgr.inst().getString("chat_8"));
        this._btAddFriend.addTouchEventListener( this.onAddFriend, this );
        this._btClose = this._ui.getChildByName("Panel_2").getChildByName("close");
        this._btClose.addTouchEventListener( this.onClose, this );
        this._ui.getChildByName("Panel_2").getChildByName("biaoti").setString( ResMgr.inst().getString("chat_6"));

        this._ui.getChildByName("Panel_2").getChildByName("family").setVisible(false);
        this._ui.getChildByName("Panel_2").getChildByName("level").setVisible(false);
        this._size = cc.director.getVisibleSize();
        this._ui.setContentSize(this._size);
        ccui.helper.doLayout(this._ui);
    },
    //
    show:function( data )
    {
        cc.log(" 玩家信息  show------------"+mainData.playerData.account);
        if(data!=undefined) {
            cc.log(mainData.playerData.account+"data.id"+data.id);
            this._id=data.id;
            if(mainData.playerData.account==data.id) {
                this._playerInfo=mainData.playerData;
                this._btAddFriend.setVisible(false);
                this._btPrivateChat.setVisible(false);
            }
            else {
                this._playerInfo=mainData.playerDataList.getItem("account",data.id);
                this._btAddFriend.setVisible(true);
                this._btPrivateChat.setVisible(true);
            }//根据id取玩家数据
        }
        //暂时屏蔽私聊加好友按钮
        this._btAddFriend.setVisible(false);
        this._btPrivateChat.setVisible(false);
        //var url=ResMgr.inst().getCSV("head",1).head_id;
        //this._imgHead.loadTexture(ResMgr.inst().getIcoPath(url));
        //cc.log(this._playerInfo.headid+"#########null")
        this._imgHead.loadTexture(ResMgr.inst().getIcoPath((this._playerInfo.headid==""||this._playerInfo.headid==undefined)?ResMgr.inst().getCSV("head",1).head_id:this._playerInfo.headid));
        //this._imgHead.scale=0.9;
        this._tfName.setString(this._playerInfo.nick);
    },
    //清除方法
    destroy:function() {
        cc.log("玩家信息destroy");
    },
    //==========================事件
    onPrivateChat:function(node,type){
        if( type == ccui.Widget.TOUCH_ENDED ){
            cc.log("打开私聊模块"+this._id);
            return;//
            ModuleMgr.inst().openModule("PrivateChatModule",{id:this._id});
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
    },
    onAddFriend:function(node,type){
        if( type == ccui.Widget.TOUCH_ENDED ){
            cc.log("申请加好友");
            //FriendEvent.ACCEPT_APPLY
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
    },
    onClose:function(node,type)
    {
        if( type == ccui.Widget.TOUCH_ENDED ){
            ModuleMgr.inst().closeModule("PlayerInfoModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
    },

})