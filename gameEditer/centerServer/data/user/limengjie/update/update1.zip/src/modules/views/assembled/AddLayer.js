/**
 * Created by cgMu on 2015/11/25.
 */

var AddLayer = cc.Node.extend({
    scrol: null,
    item_root: null,
    itemList: null,

    item_selecting: null,
    selecting_tag: 0,
    selecting_max: 0,
    selecting_got: 0,
    selecting_limite: 0,

    slider: null,
    percent: null,

    canUse: true,//标识主城内是否有部队

    _data:null,

    ctor: function (data) {
        this._super();

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);

        this.itemList = [];
        this.item_selecting = [];

        this._data = data;

        //this.checkCanUsing();

        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255 * 0.8));
        this.addChild(colorbg);

        var _root = ccs.load("res/images/ui/CorpsAssembled/addLayer.json", "res/images/ui/").node;
        this.addChild(_root);

        var size = cc.director.getVisibleSize();
        _root.setContentSize(size);
        ccui.helper.doLayout(_root);

        var root = _root.getChildByName("Panel_1");
        sizeAutoLayout(root);
        posAutoLayout(root, 0.5);

        var title = root.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("assembled_11"));

        var closebtn = root.getChildByName("Button_1");
        closebtn.addTouchEventListener(this.closecallback, this);

        var Text_3 = root.getChildByName("Text_3");
        Text_3.setColor(cc.color(77, 77, 77));
        Text_3.ignoreContentAdaptWithSize(true);
        Text_3.setString(ResMgr.inst().getString("assembled_21"));

        var name = root.getChildByName("Text_8");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(data.armyId + "0"));

        //数量
        var counts = root.getChildByName("Text_10");
        counts.ignoreContentAdaptWithSize(true);
        //counts.setString("");
        this.percent = counts;

        counts = root.getChildByName("Text_7");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString(data.num);

        var label1 = root.getChildByName("Text_9");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("bag_1"));

        var Text_9_0 = root.getChildByName("Text_9_0");
        Text_9_0.ignoreContentAdaptWithSize(true);
        Text_9_0.setString(ResMgr.inst().getString("assembled_20"));

        var button = root.getChildByName("Button_2");
        button.addTouchEventListener(this.btncallback, this);
        var btn_title = button.getChildByName("Text_2");
        btn_title.ignoreContentAdaptWithSize(true);
        btn_title.setString(ResMgr.inst().getString("assembled_13"));

        var slider = root.getChildByName("Slider_1");
        slider.addEventListener(this.sliderCall, this);
        this.slider = slider;

        var sub = root.getChildByName("Panel_2");
        sub.addTouchEventListener(this.subcallback, this);
        var subEx = root.getChildByName("Image_5");
        var add = root.getChildByName("Image_5_0");
        add.setTouchEnabled(true);
        add.addTouchEventListener(this.addcallback, this);

        //var scrollview = root.getChildByName("ScrollView_1");
        //this.scrol = scrollview;
        var urlid = modelMgr.call("Table", "getTableItemByValue", ["Arm", data.armyId]).arm_type;

        var icon = root.getChildByName("Image_11").getChildByName("Image_11_0");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(urlid));
        //item_root.setVisible(false);
        //this.item_root = item_root;

        //cc.log("@checkCanUsing",this.canUse);
        this.setContent(data);

        if (this.canUse) {
            Text_3.setVisible(false);
            //this.setScrollview();
        }
        //else {
        //    Text_3.setVisible(true);
        //    scrollview.setVisible(false);
        //    slider.setVisible(false);
        //    sub.setVisible(false);
        //    add.setVisible(false);
        //    counts.setVisible(false);
        //    label1.setVisible(false);
        //    subEx.setVisible(false);
        //}

    },

    onExit: function () {
        this._super();
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    setScrollview: function () {
        for (var i in this.itemList) {
            this.itemList[i].removeFromParent(true);
        }
        this.itemList = [];

        var data = this.gotData();
        var size = this.scrol.getContentSize();
        var item_width = 90;
        var gap = 10;
        var counts = data.length;
        var total_width = (gap + item_width) * counts + gap;
        if (total_width < size.width) {
            total_width = size.width;
        }
        this.scrol.setInnerContainerSize(cc.size(total_width, size.height));

        for (var i = 0; i < counts; i++) {
            var item = this.item_root.clone();
            item.setVisible(true);
            this.scrol.addChild(item);
            item.setPosition(cc.p(gap + item_width * 0.5 + (gap + item_width) * i, 62));
            item.setTouchEnabled(true);
            item.setTag(i);
            item.setUserData(data[i]);
            item.addTouchEventListener(this.itemcallback, this);
            this.itemList.push(item);

            this.setItem(item, data[i]);

            var selecting = item.getChildByName("Image_11_0_0");
            selecting.setVisible(false);
            this.item_selecting.push(selecting);
        }

        //初始化
        //this.selecting_max = 100;
        //this.selecting_got = this.selecting_max;

        this.resetSelectingItem(this.selecting_tag);
    },

    resetSelectingItem: function (tag) {
        for (var i in this.item_selecting) {
            if (tag == i) {
                this.item_selecting[i].setVisible(true);
            }
            else {
                this.item_selecting[i].setVisible(false);
            }
        }

        var data = this.itemList[tag].getUserData();
        this.setContent(data);
    },

    btncallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        if (this.canUse) {
            var armyid = this._data.armyId;
            cc.log("添加部队数量：", armyid, this.selecting_got);
            EventMgr.inst().dispatchEvent(CastleEvent.CREATE_ARMY, armyid, this.selecting_got)
        }
        else {
            //没有可用部队
            this.removeFromParent(true);
        }
    },

    sliderCall: function (sender, type) {
        if (type == ccui.Slider.EVENT_PERCENT_CHANGED) {
            var num = sender.getPercent();
            var counts = parseInt(this.selecting_limite * num / 100);
            this.selecting_got = counts;
            if (this.selecting_got > this.selecting_max) this.selecting_got = this.selecting_max;
            //if(this.percent){
            //    this.percent.setString(this.selecting_got+"/"+this.selecting_limite);
            //}
            this.updateSlider();
        }
    },

    closecallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        this.removeFromParent(true);
    },

    itemcallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        var tag = sender.getTag();
        if (tag == this.selecting_tag) return;
        this.selecting_tag = tag;
        //this.selecting_max = 1000;
        //this.selecting_got = this.selecting_max;
        this.resetSelectingItem(this.selecting_tag);
    },

    updateSlider: function () {
        if (this.slider && this.percent) {
            this.slider.setPercent(this.selecting_got / this.selecting_limite * 100);
            this.percent.setString(this.selecting_got + "/" + this.selecting_limite);
        }
    },

    subcallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        this.selecting_got--;
        if (this.selecting_got < 0) this.selecting_got = 0;

        this.updateSlider();
    },

    addcallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        this.selecting_got++;
        if (this.selecting_got > this.selecting_max) this.selecting_got = this.selecting_max;

        this.updateSlider();
    },

    checkCanUsing: function () {
        var list = mainData.castleData.armyList;
        for (var i = 0; i < list.length; i++) {
            var it = list.getItemAt(i);
            if (it.castleId==mainData.uiData.currentCastleId && it.num > 0) {
                //cc.log("@----------checkCanUsing----------->",it.num,it.armyId,it.castleId,"now-->>>",mainData.uiData.currentCastleId);
                this.canUse = true;
                break;
            }
        }
    },

    gotData: function () {
        var arr = [];
        var list = mainData.castleData.armyList;
        for (var i = 0; i < list.length; i++) {
            var it = list.getItemAt(i);
            if (it.castleId == mainData.uiData.currentCastleId) {
                if (it.num > 0) {
                    cc.log("@gotData", it.castleId, it.armyId, it.num);
                    arr.push(it);
                }
            }
        }
        return arr;
    },

    setItem: function (item, data) {
        var name = item.getChildByName("Text_8");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(data.armyId + "0"));

        var urlid = modelMgr.call("Table", "getTableItemByValue", ["Arm", data.armyId]).arm_type;
        var icon = item.getChildByName("Image_11_0");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(urlid));

        var counts = item.getChildByName("Text_7");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString(data.num);

        var lv = item.getChildByName("Text_4");
        lv.ignoreContentAdaptWithSize(true);
        lv.setString(this.getArmLvById(data.armyId));
    },

    getArmLvById: function (armid) {
        var lv = armid % 100;
        return lv;
    },

    setContent: function (data) {
        var limite = modelMgr.call("Table", "getTableItemByValue", ["Arm", data.armyId]).force_mnax;
        this.selecting_limite = limite;
        this.selecting_max = data.num;
        this.selecting_max = this.selecting_max > this.selecting_limite ? this.selecting_limite : this.selecting_max;
        this.selecting_got = this.selecting_max;

        this.updateSlider();
    },

    netComplete: function (event, data) {
        if (data == CastleNetEvent.SEND_CREATE_ARMY) {
            EventMgr.inst().dispatchEvent("refresh_content");
            this.removeFromParent(true);
        }
    }
});