//2015-10-16 by shenwei
var SoundConfig = cc.Class.extend({

});
//按钮声音
SoundConfig.BUTTON = "res/sounds/an_01_for_ui_btn.mp3";
//打开面板
SoundConfig.OPEN_PANEL = "res/sounds/an_01_for_ui_btn.mp3";
//关闭面板
SoundConfig.CLOSE_PANEL = "res/sounds/closePanel.mp3";