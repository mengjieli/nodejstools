var flower;
(function (flower) {
    var Compiler = (function () {
        function Compiler() {
            this._scanner = new flower.Scanner();
            this._parser = new flower.Parser();
        }
        Compiler.prototype.parser = function (content, property, checks, result) {
            var scanner = new flower.Scanner();
            var common = { "content": content, "ids": {}, "tokenValue": null, "scanner": this._scanner, "nodeStack": null, bindList: new Array() };
            this._scanner.setCommonInfo(common);
            this._parser.setCommonInfo(common);
            this._parser.parser(content);
            common.result = result;
            common.stmts = common.newNode.expval;
            common.stmts.checkPropertyBinding(checks, common);
            return common.stmts;
        };
        Compiler.prototype.parserExpr = function (content, property, checks, result) {
            var scanner = new flower.Scanner();
            var common = { "content": content, "ids": {}, "tokenValue": null, "scanner": this._scanner, "nodeStack": null, bindList: new Array() };
            this._scanner.setCommonInfo(common);
            this._parser.setCommonInfo(common);
            this._parser.parser(content);
            common.result = result;
            common.expr = common.newNode.expval;
            common.expr.checkPropertyBinding(checks, common);
            return common.expr;
        };
        Compiler.parserExpr = function (content, property, checks, result) {
            if (!flower.Compiler.ist) {
                flower.Compiler.ist = new flower.Compiler();
            }
            return flower.Compiler.ist.parserExpr(content, property, checks, result);
        };
        return Compiler;
    })();
    flower.Compiler = Compiler;
})(flower || (flower = {}));
//# sourceMappingURL=Compiler.js.map