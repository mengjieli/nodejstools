var flower;
(function (flower) {
    var ExprAtr = (function () {
        function ExprAtr() {
            this.type = "attribute";
            this.list = new Array();
        }
        ExprAtr.prototype.addItem = function (item) {
            this.list.push(item);
        };
        ExprAtr.prototype.checkPropertyBinding = function (checks, commonInfo) {
            var atr;
            if (this.list[0].type == "()") {
                this.list[0].val.checkPropertyBinding(checks, commonInfo);
            }
            else if (this.list[0].type == "id") {
                var name = this.list[0].print();
                for (var c = 0; c < checks.length; c++) {
                    try {
                        atr = checks[c][name];
                        this.before = checks[c];
                    }
                    catch (e) {
                        atr = null;
                        this.before = null;
                    }
                    if (atr) {
                        break;
                    }
                }
            }
            for (var i = 1; i < this.list.length; i++) {
                if (this.list[i].type == ".") {
                    if (atr) {
                        var atrName = this.list[i].val;
                        try {
                            atr = atr[atrName];
                        }
                        catch (e) {
                            atr = null;
                        }
                    }
                }
                else if (this.list[i].type == "call") {
                    atr = null;
                    this.list[i].val.checkPropertyBinding(checks, commonInfo);
                }
            }
            if (atr && atr instanceof flower.Value) {
                this.value = atr;
                commonInfo.result.push(atr);
            }
        };
        ExprAtr.prototype.getValue = function () {
            if (this.value) {
                return this.value.value;
            }
            var atr;
            var lastAtr = null;
            if (this.list[0].type == "()") {
                atr = this.list[0].val.getValue();
            }
            else if (this.list[0].type == "id") {
                atr = this.before;
                lastAtr = this.before;
                try {
                    atr = atr[this.list[0].val];
                }
                catch (e) {
                    return null;
                }
            }
            for (var i = 1; i < this.list.length; i++) {
                try {
                    if (this.list[i].type == ".") {
                        atr = atr[this.list[i].val];
                    }
                    else if (this.list[i].type == "call") {
                        atr = atr.apply(lastAtr, this.list[i].val.getValueList());
                    }
                    lastAtr = atr;
                }
                catch (e) {
                    return null;
                }
            }
            return atr;
        };
        ExprAtr.prototype.print = function () {
            var content = "";
            for (var i = 0; i < this.list.length; i++) {
                content += this.list[i].print();
            }
            return content;
        };
        return ExprAtr;
    })();
    flower.ExprAtr = ExprAtr;
})(flower || (flower = {}));
//# sourceMappingURL=ExprAtr.js.map