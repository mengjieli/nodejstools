/**
 * Created by admin on 2016/1/29.
 */
var AnnouncementBeanNet = cc.Class.extend({
    _data:null,//数组 数据
    _id:null,//id
    _language:null,//语言
    _createdTime:null,//发布 时间 时间戳
    _leftTime:null,//剩余时间
    _period:null,//周期
    _message:null,//文字信息
    _type:null,//类型  比如2是移民建城

    _endTime:null,//播放时间
    _showTime:null,//播放时间
    num:null,//次数 暂时全部设成1

    ctor:function(data)
    {
        if(data!=null)    this._data=data;
        if(data[0]!=null) this._id=data[0];
        if(data[1]!=null) this._language=data[1];
        if(data[2]!=null) this._createdTime=data[2];
        if(data[3]!=null) this._leftTime=data[3];
        if(data[4]!=null) this._period=data[4];
        if(data[5]!=null) this._message=data[5];
        if(data[6]!=null) this._type=data[6];

    },
    getParseMessage:function(){
        var str;
        //cc.log(this._message+"this._message"+this._message.length);
        if(this._message.length==1) {
            //cc.log(this._message[0][1]);
            return this._message[0][1];
        }
        //{XXXX玩家名称}在{X：XXX，Y:XXX}点建造了分城
        if(this._type==2){
            var getUid=this.getSlotMessage(86401);
            var pInfo=null;
            //cc.log(mainData.playerData.account+"getUid>>>>>"+getUid+"istrue"+(String(mainData.playerData.account)==getUid));
            if(String(mainData.playerData.account)==getUid) pInfo=mainData.playerData;
            else pInfo=mainData.playerDataList.getItem("account",getUid);//根据id取玩家数据
            //cc.error(pInfo+"pInfo>>"+pInfo.nick+"account"+pInfo.account);
            str=pInfo.nick+"在 X："+this.getSlotMessage(86402)+"，Y:"+this.getSlotMessage(86403)+""+ResMgr.inst().getString("announcement_type"+this._type)//"点建造了分城";

        }
        return str;
    },
    getSlotMessage:function(slot){
        if(this._message&&this._message.length>1){
            for(var i=0;i<this._message.length;i++){
                if(this._message[i][0]==slot) return this._message[i][1];
            }
        }
        cc.log("公告解析slot出错有BUG");
        return null;
    },

});