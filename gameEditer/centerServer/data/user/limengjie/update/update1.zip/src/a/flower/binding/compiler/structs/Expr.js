var flower;
(function (flower) {
    var Expr = (function () {
        function Expr(type, expr1, expr2, expr3) {
            if (expr1 === void 0) { expr1 = null; }
            if (expr2 === void 0) { expr2 = null; }
            if (expr3 === void 0) { expr3 = null; }
            this.type = type;
            this.expr1 = expr1;
            this.expr2 = expr2;
            this.expr3 = expr3;
        }
        Expr.prototype.checkPropertyBinding = function (checks, commonInfo) {
            if (this.type == "Atr") {
                this.expr1.checkPropertyBinding(checks, commonInfo);
            }
            if (this.expr1 && this.expr1 instanceof flower.Expr) {
                this.expr1.checkPropertyBinding(checks, commonInfo);
            }
            if (this.expr2 && this.expr2 instanceof flower.Expr) {
                this.expr2.checkPropertyBinding(checks, commonInfo);
            }
            if (this.expr3 && this.expr3 instanceof flower.Expr) {
                this.expr3.checkPropertyBinding(checks, commonInfo);
            }
        };
        Expr.prototype.getValue = function () {
            if (this.type == "+a") {
                return this.expr1.getValue();
            }
            if (this.type == "-a") {
                return -this.expr1.getValue();
            }
            if (this.type == "!") {
                return !this.expr1.getValue();
            }
            if (this.type == "*") {
                return this.expr1.getValue() * this.expr2.getValue();
            }
            if (this.type == "/") {
                return this.expr1.getValue() / this.expr2.getValue();
            }
            if (this.type == "%") {
                return this.expr1.getValue() % this.expr2.getValue();
            }
            if (this.type == "+") {
                return this.expr1.getValue() + this.expr2.getValue();
            }
            if (this.type == "-") {
                return this.expr1.getValue() - this.expr2.getValue();
            }
            if (this.type == "<<") {
                return this.expr1.getValue() << this.expr2.getValue();
            }
            if (this.type == ">>") {
                return this.expr1.getValue() >> this.expr2.getValue();
            }
            if (this.type == ">>>") {
                return this.expr1.getValue() >>> this.expr2.getValue();
            }
            if (this.type == ">") {
                return this.expr1.getValue() > this.expr2.getValue();
            }
            if (this.type == "<") {
                return this.expr1.getValue() < this.expr2.getValue();
            }
            if (this.type == ">=") {
                return this.expr1.getValue() >= this.expr2.getValue();
            }
            if (this.type == "<=") {
                return this.expr1.getValue() <= this.expr2.getValue();
            }
            if (this.type == "==") {
                return this.expr1.getValue() == this.expr2.getValue();
            }
            if (this.type == "===") {
                return this.expr1.getValue() === this.expr2.getValue();
            }
            if (this.type == "!==") {
                return this.expr1.getValue() !== this.expr2.getValue();
            }
            if (this.type == "!=") {
                return this.expr1.getValue() != this.expr2.getValue();
            }
            if (this.type == "&") {
                return this.expr1.getValue() & this.expr2.getValue();
            }
            if (this.type == "~") {
                return ~this.expr1.getValue();
            }
            if (this.type == "^") {
                return this.expr1.getValue() ^ this.expr2.getValue();
            }
            if (this.type == "|") {
                return this.expr1.getValue() | this.expr2.getValue();
            }
            if (this.type == "&&") {
                return this.expr1.getValue() && this.expr2.getValue();
            }
            if (this.type == "||") {
                return this.expr1.getValue() || this.expr2.getValue();
            }
            if (this.type == "?:") {
                return this.expr1.getValue() ? this.expr2.getValue() : this.expr3.getValue();
            }
            if (this.type == "Atr") {
                return this.expr1.getValue();
            }
            if (this.type == "int") {
                return this.expr1;
            }
            if (this.type == "0xint") {
                return this.expr1;
            }
            if (this.type == "number") {
                return this.expr1;
            }
            if (this.type == "boolean") {
                return this.expr1;
            }
            return null;
        };
        return Expr;
    })();
    flower.Expr = Expr;
})(flower || (flower = {}));
//# sourceMappingURL=Expr.js.map