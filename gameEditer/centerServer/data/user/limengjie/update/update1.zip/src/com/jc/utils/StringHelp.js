function StringHelp() { this.ctor.apply(this,arguments); };

StringHelp.prototype = 
{
	ctor : function ()
	{
	}
};
StringHelp.extend = extendClass;
