/**
 * Created by cgMu on 2016/3/10.
 */

var BattleLogModule = ModuleBase.extend({
    _root:null,
    tabVector:null,
    tabindex:0,
    scrollview:null,
    item_root:null,
    itemVector:null,
    tipsPanel:null,

    loadingStep:20,
    loading:false,

    scrolLoadingStep:25,
    scrolLoadingIndex:0,
    scrolList:null,

    ctor: function () {
        this._super();
        this.tabVector = [];
        this.itemVector = [];
        this.scrolList = [];

        mainData.logData.logList.addListener("add", this.add, this);
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netCall, this);
    },

    initUI: function () {
        var root = ccs.load("res/images/ui/BattleUIModule/BattleLogLayer.json","res/images/ui/").node;
        this.addChild(root);
        this._root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var panel = root.getChildByName("Panel_1");
        var close = panel.getChildByName("Button_1");
        close.addTouchEventListener( this.closeCall, this );

        var Text_1 = panel.getChildByName("Text_1");
        Text_1.ignoreContentAdaptWithSize(true);
        Text_1.setString(ResMgr.inst().getString("battlelog_1"));

        var Image_189 = panel.getChildByName("Image_189");
        Image_189.setTouchEnabled(true);
        Image_189.addTouchEventListener(this.tipsCallback,this);

        var Panel_2_0 = root.getChildByName("Panel_2_0");
        Panel_2_0.addTouchEventListener(this.tipsPanelCallback,this);
        Panel_2_0.setLocalZOrder(10);
        this.tipsPanel = Panel_2_0;
        var max = modelMgr.call("Table", "getTableItemByValue", ["Public", 100047]).numerical;
        var tips = Panel_2_0.getChildByName("Text_41");
        tips.ignoreContentAdaptWithSize(true);
        tips.setString(ResMgr.inst().getString("battlelog_2")+max+ResMgr.inst().getString("battlelog_3"));

        //tab
        var tabroot = panel.getChildByName("Image_175");
        tabroot.setTouchEnabled(true);
        tabroot.addTouchEventListener(this.tabCallback,this);
        tabroot.setTag(0);
        var title = tabroot.getChildByName("Text_33");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("battlelog_tab_0"));
        this.tabVector.push(tabroot);

        var x = tabroot.getPositionX();
        var width = tabroot.getContentSize().width;

        for(var i = 1; i <= 3; i++) {
            var tab = tabroot.clone();
            tab.setTag(i);
            title = tab.getChildByName("Text_33");
            title.ignoreContentAdaptWithSize(true);
            title.setString(ResMgr.inst().getString("battlelog_tab_"+i));
            tab.setPositionX(x+width*i);
            panel.addChild(tab);

            this.tabVector.push(tab);
        }

        var ScrollView_2 = panel.getChildByName("ScrollView_2");
        ScrollView_2.addEventListener(this.scrollCall, this);
        this.scrollview = ScrollView_2;

        var scrolroot = ScrollView_2.getChildByName("Panel_10");
        scrolroot.setVisible(false);
        this.item_root = scrolroot;

        this.setTabState();
    },

    show: function (data) {
        //每次打开都要重新请求
        //this.sendMsg();
        var msg = new SocketBytes();
        msg.writeUint(1300);
        msg.writeUint(0);
        msg.writeUint(this.loadingStep);
        NetMgr.inst().send(msg);

        this.loading = true;
    },

    destroy: function () {
        mainData.logData.logList.removeListener("add", this.add, this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netCall, this);
    },

    scrollCall: function (sender, type) {
        if(type==ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM){

            cc.log("@-->",mainData.logData.begin,this.scrolLoadingIndex);

            //if(mainData.logData.begin<=this.scrolLoadingIndex){

                cc.log("@本地数据加载完成----------->");
                this.sendMsg();

            //}
            //else{
            //    //加载本地数据
            //    cc.log("@加载本地数据----------->");
            //    //var list = this.scrolList;
            //    this.localLoading();
            //}

        }
    },

    localLoading: function () {
        var total = this.scrolList.length;
        var delt = total - this.scrolLoadingIndex;
        if(delt<=0) return;

        var counts = Math.min(delt,this.scrolLoadingStep);
        for(var i=this.scrolLoadingIndex; i < counts; i++) {
            var it = this.scrolList[i];
            this.createItem(it);
        }
        cc.log("@加载本地数据----------->",counts);

        this.scrolLoadingIndex += this.scrolLoadingStep;

        this.resetPosition();

    },

    sendMsg: function () {
        if(this.tabindex>0) return;
        if(this.loading) return;
        if(mainData.logData.begin!=0 && mainData.logData.totalCount<=mainData.logData.begin){
            cc.log("@战斗日志数据加载完成*****************");
            return;
        }

        var msg = new SocketBytes();
        msg.writeUint(1300);
        msg.writeUint(mainData.logData.begin);
        msg.writeUint(this.loadingStep);
        NetMgr.inst().send(msg);

        this.loading = true;
    },

    closeCall:function( node,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED ) {
            ModuleMgr.inst().closeModule("BattleLogModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    tabCallback: function (sender, type) {
        if(type == ccui.Widget.TOUCH_ENDED) {
            var tag = sender.getTag();
            if(tag==this.tabindex) return;

            this.tabindex = tag;
            this.setTabContent();
        }
    },

    add: function (log) {
        this.createItem(log);
    },

    setTabContent: function () {
        this.setTabState();

        for(var i in this.itemVector){
            this.itemVector[i].removeFromParent(true);
        }
        this.itemVector= [];

        var list = this.getDataList(this.tabindex);
        var num = list.length;
        this.scrolList = list;

        //if(num>this.scrolLoadingStep) {
        //    num = this.scrolLoadingStep;
        //}
        //this.scrolLoadingIndex = num;
        cc.log("@list counts--------->",num);

        var size = this.scrollview.getContentSize();
        var height = this.item_root.getContentSize().height;
        var totalheight = height*num;
        totalheight = Math.max(totalheight,size.height);

        for(var i = 0; i < num; i++) {
            var data = list[i];//mainData.logData.logList.getItemAt(i);
            var item = this.item_root.clone();
            item.setVisible(true);
            item.setPosition(cc.p(0,totalheight-height*(i+1)));
            item.setTag(i);
            this.scrollview.addChild(item);
            this.setItem(item,data);
            this.itemVector.push(item);
        }

        this.scrollview.setInnerContainerSize(cc.size(size.width,totalheight));
        this.scrollview.jumpToTop();
    },

    setTabState: function () {
        for(var i in this.tabVector){
            var tab = this.tabVector[i];
            if(this.tabindex == i) {
                tab.loadTexture("BattleUIModule/zd_rizhiweixuanzhongdianji_icon.png",ccui.Widget.PLIST_TEXTURE);
            }
            else{
                tab.loadTexture("BattleUIModule/zd_rizhiweixuanzhong_icon.png",ccui.Widget.PLIST_TEXTURE);
            }
        }
    },

    tipsCallback: function (sender, type) {
        if(ccui.Widget.TOUCH_ENDED==type){
            if(this.tipsPanel){
                this.tipsPanel.setVisible(true);
            }
        }
    },

    tipsPanelCallback: function (sender, type) {
        if(ccui.Widget.TOUCH_ENDED==type){
            sender.setVisible(false);
        }
    },

    setItem: function (item, data) {
        var time = item.getChildByName("Text_37");
        time.ignoreContentAdaptWithSize(true);
        time.setString(this.getLocalTime(data.timestamp));//time.setString(item.getTag());//

        var label1 = item.getChildByName("Text_37_0");
        label1.ignoreContentAdaptWithSize(true);

        var label2 = item.getChildByName("Text_37_0_0");
        label2.ignoreContentAdaptWithSize(true);

        var label3 = item.getChildByName("Text_37_0_1");
        label3.ignoreContentAdaptWithSize(true);

        var color = cc.color(0,255,0);
        var txt1 = ResMgr.inst().getItemName(data.type)+ResMgr.inst().getString("battlelog_4");//部队（我方）
        var txt3 = ResMgr.inst().getString("battlelog_6");//伤害

        var value = Math.abs(data.resultType);
        if(value==1){

            if(data.remaining==0){
                if(data.resultType>0){
                    txt1+=ResMgr.inst().getString("battlelog_7")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_5");//消灭了 部队（敌方）
                }
                else{
                    txt1+=ResMgr.inst().getString("battlelog_8")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_9");// 被 部队（敌方）消灭了
                    color = cc.color(255,0,0);
                }
                label2.setVisible(false);
                label3.setVisible(false);
            }
            else{
                if(data.resultType>0){
                    txt1+=ResMgr.inst().getString("battlelog_11")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_12");//对  部队（敌方）造成了
                }
                else{
                    txt1+=ResMgr.inst().getString("battlelog_8")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_10");//被 部队（敌方）攻击造成了
                    color = cc.color(255,0,0);
                }

            }

        }
        else if(value==2){
            if(data.resultType>0){
                txt1+=ResMgr.inst().getString("battlelog_13")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_14");//躲过了  部队（敌方）的攻击
            }
            else{
                txt1+=ResMgr.inst().getString("battlelog_16")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_17");//的攻击被  部队（敌方）躲过了
            }
            label2.setVisible(false);
            label3.setVisible(false);
        }
        else if(value==3){
            if(data.resultType>0){
                txt1+=ResMgr.inst().getString("battlelog_11")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_12");//对  部队（敌方）造成了
            }
            else{
                txt1+=ResMgr.inst().getString("battlelog_8")+ResMgr.inst().getItemName(data.accountType)+ResMgr.inst().getString("battlelog_10");//被 部队（敌方）攻击造成了
                color = cc.color(255,0,0);
            }

            txt3 = ResMgr.inst().getString("battlelog_15");//严重伤害
        }

        label1.setString(txt1);

        var x = label1.getPositionX();

        label2.setString(data.damaged);
        label2.setColor(color);
        label2.setPositionX(x+label1.getContentSize().width);

        label3.setString(txt3);
        label3.setPositionX(label2.getPositionX()+label2.getContentSize().width);
    },

    getLocalTime: function (time) {
        var data = new Date(parseInt(time));
        var year=data.getYear()+1900;
        var month=data.getMonth()+1;
        var date=data.getDate();
        var hour=data.getHours();
        var minute=data.getMinutes();
        var second=data.getSeconds();
        return year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second;
    },

    createItem: function (logdata) {
        if(this.item_root){

            var item = this.item_root.clone();
            item.setVisible(true);
            item.setTag(this.itemVector.length);
            this.setItem(item,logdata);
            this.scrollview.addChild(item);
            this.itemVector.push(item);

            //var i = this.itemVector.length;
            //var size = this.scrollview.getContentSize();
            //var height = this.item_root.getContentSize().height;
            //var totalheight = height*i;
            //totalheight = Math.max(totalheight,size.height);

            //item.setPosition(cc.p(0,totalheight-height*i));//------>this.itemVector length set

            //this.setItemPosition(item);
            //this.scrollview.setInnerContainerSize(cc.size(size.width,totalheight));
        }
    },

    //默认放在列表最后
    setItemPosition: function (item) {
        var num = this.itemVector.length;
        var size = this.scrollview.getContentSize();
        var height = this.item_root.getContentSize().height;
        var totalheight = height*num;
        totalheight = Math.max(totalheight,size.height);
        this.scrollview.setInnerContainerSize(cc.size(size.width,totalheight));
        item.setPosition(cc.p(0,totalheight-height*num));
        cc.log("@setItemPosition",num,totalheight,totalheight-height*num);
        this.scrollview.jumpToTop();
    },

    netCall: function (event,data) {
        if(data==1300){
            mainData.logData.begin += this.loadingStep;
            this.loading = false;

            cc.log("@netCall 1300",mainData.logData.begin,"*************",this.scrolLoadingIndex);

            if(this.scrolLoadingIndex==0) this.scrolLoadingIndex = mainData.logData.begin;


            this.resetPosition();
        }
    },

    resetPosition: function (top) {
        var num = this.itemVector.length;
        var size = this.scrollview.getContentSize();
        var height = this.item_root.getContentSize().height;
        var totalheight = height*num;
        totalheight = Math.max(totalheight,size.height);
        this.scrollview.setInnerContainerSize(cc.size(size.width,totalheight));
        for(var i =0;i<num ; i++){
            var it = this.itemVector[i];
            it.setPosition(cc.p(0,totalheight-height*(i+1)));
            //cc.log("@resetPosition",it.getTag());
        }
        if(top){
            this.scrollview.jumpToTop();
        }
    },

    getDataList: function (tabindex) {
        var list = this.getDataByTab(tabindex);
        return list;
    },

    //1 正常伤害  2 闪避  3 暴击，正数表示我方对敌方发起攻击，负数表示敌方对我方发起攻击
    getDataByTab: function (type) {
        var list = mainData.logData.logList;

        var arr = [];

        if(type==0){
            for(var i = 0; i < list.length; i++){
                var log = list.getItemAt(i);
                arr.push(log);
            }
            return arr;
        }

        for(var i = 0; i < list.length; i++){
            var log = list.getItemAt(i);
            //cc.log("@getDataByTab",log.resultType);
            if(Math.abs(log.resultType)==type){
                arr.push(log);
            }
        }
        return arr;
    }
});