var Sprite = (function () {
    function Sprite() {
    }
    return Sprite;
})();
//# sourceMappingURL=Sprite.js.map