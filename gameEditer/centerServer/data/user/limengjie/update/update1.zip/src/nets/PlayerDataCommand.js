//默认协议第一个收取的是玩家数据

var PlayerDataCommand = cc.Class.extend({
    ctor: function () {
        NetMgr.inst().addEventListener(298, this.updatePlayerData, this);//更新账号属性
        NetMgr.inst().addEventListener(295, this.updatePlayerFightState, this);//更新玩家敌对状态
        setInterval(this.checkEnemyState, 1000);
    },

    updatePlayerData: function (cmd, data) {
        if (cmd == 298) {
            data.resetCMDData();
            var account = data.readString();//uid
            var nick = data.readString();
            //nick = modelMgr.call("ValidText","replaceText",[nick]);
            var newplayer = null;
            var list = mainData.playerDataList;
            for (var i = 0; i < list.length; i++) {
                if (list.getItemAt(i).account == account) {
                    newplayer = list.getItemAt(i);
                    if (nick != "") {
                        list.getItemAt(i).nick = nick;
                    }
                    var array = new ArrayData();
                    var len = data.readUint();
                    for (var j = 0; j < len; j++) {
                        var slot = data.readUint();
                        var value = data.readString();
                        array.push({type: slot, value: value});
                        if (slot == 1) {
                            list.getItemAt(i).gender = value;
                        }
                        if (slot == 2) {
                            list.getItemAt(i).headid = value;
                        }
                        if (slot == 199) {
                            list.getItemAt(i).collection = value;
                            if (account == mainData.playerData.account) {
                                ModuleMgr.inst().getData("CollectModule").updateList(value);
                            }
                        }
                        if (slot == 303) {
                            list.getItemAt(i).signday = value;
                        }
                        if (slot == 198) {//引导
                            list.getItemAt(i).guide = value;
                        }
                        if (slot == 304) {//是否已开启交易市场
                            list.getItemAt(i).trade = value;
                        }
                        if (slot == 403) {//开启黄金页面
                            list.getItemAt(i).goldTab = value;
                        }
                    }
                    newplayer.attributes = array;
                    var len2 = data.readUint();
                    for (var i = 0; i < len2; i++) {
                        var slot = data.readUint();
                        var value = data.readUint();
                    }
                    var promotionLevel = data.readUint();
                    newplayer.promotionLevel = promotionLevel;
                    break;
                }
            }
            if (newplayer == null) {
                //cc.log("@updatePlayerData******");
                newplayer = DataManager.getInstance().getNewData("PlayerData");
                newplayer.account = account;
                if (nick != "") {
                    newplayer.nick = nick;
                }
                var len = data.readUint();
                for (var i = 0; i < len; i++) {
                    var slot = data.readUint();
                    var value = data.readString();
                    if (slot == 1) {
                        newplayer.gender = value;
                    }
                    if (slot == 2) {
                        newplayer.headid = value;
                    }
                    if (slot == 199) {
                        newplayer.collection = value;
                    }
                    if (slot == 303) {
                        newplayer.signday = value;
                    }
                    if (slot == 198) {//引导
                        newplayer.guide = value;
                    }
                    if (slot == 304) {//是否已开启交易市场
                        newplayer.trade = value;
                    }
                    if (slot == 403) {//开启黄金页面
                        newplayer.goldTab = value;
                    }
                }
                var len2 = data.readUint();
                for (var i = 0; i < len2; i++) {
                    var slot = data.readUint();
                    var value = data.readUint();
                }
                var promotionLevel = data.readUint();
                newplayer.promotionLevel = promotionLevel;
                //newplayer.showBlood = !!newplayer.
                mainData.playerDataList.push(newplayer);
            }

            if (mainData.playerData.account == "" || mainData.playerData.account == account) {
                mainData.playerData.account = account;
                mainData.playerData = mainData.playerDataList.getItem("account", mainData.playerData.account);
            }
        }
    },
    updatePlayerFightState: function (cmd, data) {
        var info = NetCompiler.decode(cmd, data);
        info.endTime = jc.EnterFrame.curTime + info.time;
        if(info.account == mainData.playerData.account) {
            info.account = "none";
        }
        var enemyData = mainData.enemyList.getItem("account", info.account);
        if (enemyData) {
            enemyData.receive(info);
        } else {
            enemyData = DataManager.getInstance().getNewData("EnemyData");
            enemyData.receive(info);
            mainData.enemyList.push(enemyData);
            mainData.uiData.map.inFight = true;
        }
    },
    //定期检查敌对玩家状态
    checkEnemyState: function () {
        var list = mainData.enemyList;
        for (var i = 0; i < list.length; i++) {
            var enemyData = list.getItemAt(i);
            if (jc.EnterFrame.curTime >= enemyData.endTime) {
                list.delItemAt(i);
                i--;
            } else {
                //trace("剩余显血时间:",(enemyData.endTime-jc.EnterFrame.curTime)/1000);
            }
        }
        if (list.length == 0) {
            mainData.uiData.map.inFight = false;
        }
    }
});
