function InitModel(complete,thisObj) {

    new ModelManager();

    //调试用的中心服务器
    ModelManager.getInstance().registerModel(new GameCenterModel());

    //非法字符处理模块
    ModelManager.getInstance().registerModel(new ValidTextModel());

    //注册配置模块
    ModelManager.getInstance().registerModel(new ConfigModel());

    //注册表格模块
    ModelManager.getInstance().registerModel(new TableModel());

    //注册配置模块
    ModelManager.getInstance().registerModel(new BigMapModel());

    //注册网络模块
    ModelManager.getInstance().registerModel(new NetModel());

    //注册网络等待模块
    ModelManager.getInstance().registerModel(new NetWaitingModel());

    //注册GM命令模块
    ModelManager.getInstance().registerModel(new GMCommandModel());

    //错误处理模块
    ModelManager.getInstance().registerModel(new ErrorModel());

    ModelManager.getInstance().load(complete,thisObj);
}