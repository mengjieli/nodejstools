var GMCommandModel = (function (_super) {
    __extends(GMCommandModel, _super);

    function GMCommandModel() {
        _super.call(this, "GMCommand");
        this.camera = null;
    }

    var d = __define, c = GMCommandModel;
    p = c.prototype;

    p.excute = function (content) {
        if (content.slice(0, "gm ts ".length) == "gm ts ") {
            var str = content.slice("gm ts ".length, content.length);
            var pts = str.split(" ");
            var px = parseInt(pts[0]);
            var py = parseInt(pts[1]);
            var pos;
            if (mainData.uiData.showMap == MapChangeModule.MAP) {
                pos = MapUtils.transPointToPosition(px, py);
                modelMgr.call("BigMap", "cameraLookAt", [pos.x, pos.y]);
            } else {
                pos = MapUtils.transPointToPosition(px, py);
                ModuleMgr.inst().openModule("MapChangeModule", {
                    "type": MapChangeModule.MAP,
                    moduleData: {x: pos.x, y: pos.y}
                });
            }
        }
        trace("聊天内容!!!!",content);
        if (content == "gm build") {
            new BuildLevelUpCommand();
        }
        if(content == "gm showgrid") {
            mainData.uiData.showMapGrid = true;
        }
        //if (content == "gm server 1") {
        //    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        //    var file = jsb.fileUtils.writeToFile({
        //        "ip": 1,
        //    }, storagePath + "server");
        //} else if (content == "gm server 2") {
        //    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        //    var file = jsb.fileUtils.writeToFile({
        //        "ip": 2,
        //    }, storagePath + "server");
        //} else if (content == "gm server 0") {
        //    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        //    var file = jsb.fileUtils.writeToFile({
        //        "ip": 0,
        //    }, storagePath + "server");
        //}
    }

    return GMCommandModel;
})(ModelBase);