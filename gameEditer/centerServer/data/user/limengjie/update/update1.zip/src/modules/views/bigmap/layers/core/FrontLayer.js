var FrontLayer = cc.Sprite.extend({
    data: null,
    list: null,
    ctor: function () {
        this._super();
        this.list = [];
        this.paths = [];
        this.data = mainData.mapData;
        this.data.earthList.addListener("add", this.simpleResourceChange, this);
        this.data.earthList.addListener("del", this.delObject, this);
        this.data.fightResourceList.addListener("add", this.simpleResourceChange, this);
        this.data.fightResourceList.addListener("del", this.delObject, this);
        mainData.favoritesData.addListener("add",this.simpleResourceChange, this);
        mainData.favoritesData.addListener("del",this.delObject, this);

        this.initRolerPath();
    },
    initRolerPath: function () {
        var paths = mainData.mapData.myRolerPathList;
        for (var i = 0; i < paths.length; i++) {
            this.addPath(paths.getItemAt(i));
        }
        this.data.myRolerPathList.addListener("add", this.addPath, this);
        this.data.myRolerPathList.addListener("del", this.delPath, this);
    },
    updateShow: function (camera) {
        this.setPosition(-camera.x, -camera.y);

        //移除范围之外的对象
        for (var i = 0; i < this.list.length; i++) {
            var item = this.list[i];
            if (item.px > camera.x - 200 && item.px < camera.x + camera.width + 200 &&
                item.py > camera.y - 200 && item.py < camera.y + camera.height + 200) {

            } else {
                this.list.splice(i, 1);
                i--;
                item.dispose();
                if (item == this.otherShowRangeCastle) {
                    this.otherShowRangeCastle = null;
                }
            }
        }

        var earthList = this.data.earthList;
        var find;
        for (var i = 0; i < earthList.length; i++) {
            var earthData = earthList.getItemAt(i);
            if (earthData.showX > camera.x - 200 && earthData.showX < camera.x + camera.width + 200 &&
                earthData.showY > camera.y - 200 && earthData.showY < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    //trace("比较",this.list.length,f,this.list[f].data.name,builds[i].name);
                    if (this.list[f].data == earthData) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    var earth = new MapEarth(earthData);
                    this.addChild(earth);
                    this.list.push(earth);
                }
            }
        }

        var fightResourceList = this.data.fightResourceList;
        var find;
        for (var i = 0; i < fightResourceList.length; i++) {
            var fresourceData = fightResourceList.getItemAt(i);
            if (fresourceData.showX > camera.x - 200 && fresourceData.showX < camera.x + camera.width + 200 &&
                fresourceData.showY > camera.y - 200 && fresourceData.showY < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    //trace("比较",this.list.length,f,this.list[f].data.name,builds[i].name);
                    if (this.list[f].data == fresourceData) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    var fresource = new MapFightResource(fresourceData);
                    this.addChild(fresource);
                    this.list.push(fresource);
                }
            }
        }

        var cllectionList = mainData.favoritesData;
        var find;
        for (var i = 0; i < cllectionList.length; i++) {
            var collectionData = cllectionList.getItemAt(i);
            if(collectionData.tag == false) continue;
            var pos = MapUtils.transPointToPosition(collectionData.x, collectionData.y);
            if (pos.x > camera.x - 200 && pos.x < camera.x + camera.width + 200 &&
                pos.y > camera.y - 200 && pos.y < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    if (this.list[f].data == collectionData) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    var collection = new MapCollection(collectionData);
                    this.addChild(collection);
                    this.list.push(collection);
                }
            }
        }
    },
    simpleResourceChange: function(data) {
        var camera = MapCamera.getInstance();
        if (data.showX > camera.x - 200 && data.showX < camera.x + camera.width + 200 &&
            data.showY > camera.y - 200 && data.showY < camera.y + camera.height + 200) {
            this.updateShow(camera);
        }
    },
    delObject: function (data) {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i].data == data) {
                trace("找到删除的资源啦!");
                var resource = this.list.splice(i, 1)[0];
                resource.dispose();
                break;
            }
        }
    },
    getEarth: function (x, y) {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i].type == MapDisplayType.Earth && this.list[i].isTouch(x, y)) {
                return this.list[i];
            }
        }
        return null;
    },
    /**
     * 添加寻路表现
     */
    addPath: function (pathData) {
        var path = new MapRolerPath(pathData);
        this.addChild(path);
        this.paths.push(path);
    },
    delPath: function (pathData) {
        for (var i = 0; i < this.paths.length; i++) {
            if(this.paths[i].data == pathData) {
                var path = this.paths[i];
                this.paths.splice(i,1);
                path.dispose();
                //setTimeout(function(){
                //},800);
                break;
            }
        }
    },
    delEarth: function (pathData) {
        for (var i = 0; i < this.paths.length; i++) {
            var path = this.paths[i];
            if (path.data == pathData) {
                this.paths.splice(i, 1);
                i--;
                path.dispose();
            }
        }
    },
    dispose: function () {
        while (this.list.length) {
            this.list.pop().dispose();
        }
        this.data.earthList.removeListener("add", this.simpleResourceChange, this);
        this.data.earthList.removeListener("del", this.delObject, this);
        this.data.fightResourceList.removeListener("add", this.simpleResourceChange, this);
        this.data.fightResourceList.removeListener("del", this.delObject, this);
        while (this.paths.length) {
            this.paths.pop().dispose();
        }
        this.data.myRolerPathList.removeListener("add", this.addPath, this);
        this.data.myRolerPathList.removeListener("del", this.delPath, this);
        mainData.favoritesData.removeListener("add",this.simpleResourceChange, this);
        mainData.favoritesData.removeListener("del",this.delObject, this);
    }
});