var flower;
(function (flower) {
    var Event = (function () {
        function Event(type, bubbles) {
            if (bubbles === void 0) { bubbles = false; }
            this.$cycle = false;
            this.$target = null;
            this.$currentTarget = null;
            this.$type = type;
            this.$bubbles = bubbles;
        }
        Object.defineProperty(Event.prototype, "type", {
            get: function () {
                return this.$type;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Event.prototype, "bubbles", {
            get: function () {
                return this.$bubbles;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Event.prototype, "target", {
            get: function () {
                return this.$target;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Event.prototype, "currentTarget", {
            get: function () {
                return this.$currentTarget;
            },
            enumerable: true,
            configurable: true
        });
        Event.create = function (type, data) {
            if (data === void 0) { data = null; }
            var e;
            if (!flower.Event._eventPool.length) {
                e = new flower.Event(type);
            }
            else {
                e = flower.Event._eventPool.pop();
                e.$cycle = false;
            }
            e.$type = type;
            e.$bubbles = false;
            e.data = data;
            return e;
        };
        Event.release = function (e) {
            if (e.$cycle) {
                return;
            }
            e.$cycle = true;
            flower.Event._eventPool.push(e);
        };
        return Event;
    })();
    flower.Event = Event;
})(flower || (flower = {}));
flower.Event.COMPLETE = "complete";
flower.Event.ADD = "add";
flower.Event.REMOVE = "remove";
flower.Event._eventPool = new Array();
//# sourceMappingURL=Event.js.map