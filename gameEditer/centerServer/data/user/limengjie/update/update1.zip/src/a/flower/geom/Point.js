var flower;
(function (flower) {
    var Point = (function () {
        function Point(x, y) {
            if (x === void 0) { x = 0; }
            if (y === void 0) { y = 0; }
            this.x = x;
            this.y = y;
        }
        Point.prototype.setTo = function (x, y) {
            if (x === void 0) { x = 0; }
            if (y === void 0) { y = 0; }
            this.x = x;
            this.y = y;
            return this;
        };
        Object.defineProperty(Point.prototype, "length", {
            get: function () {
                return Math.sqrt(this.x * this.x + this.y * this.y);
            },
            enumerable: true,
            configurable: true
        });
        Point.distance = function (p1, p2) {
            return Math.sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
        };
        Point.release = function (point) {
            if (!point) {
                return;
            }
            flower.Point.pointPool.push(point);
        };
        Point.create = function (x, y) {
            var point = flower.Point.pointPool.pop();
            if (!point) {
                point = new flower.Point(x, y);
            }
            else {
                point.x = x;
                point.y = y;
            }
            return point;
        };
        return Point;
    })();
    flower.Point = Point;
})(flower || (flower = {}));
flower.Point.$TempPoint = new flower.Point();
flower.Point.pointPool = new Array();
//# sourceMappingURL=Point.js.map