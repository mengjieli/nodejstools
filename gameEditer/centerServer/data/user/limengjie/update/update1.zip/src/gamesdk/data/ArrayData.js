/**
 * @Event "length" 参数为本身
 * @Event "Array" 数组中的某个元素属性改变，则发出此事件，参数为改变的元素（不是元素的属性）
 * @Event "add" 增加某个元素，参数为增加的元素，此改变在 length 之后
 * @Event "del" 删除某个元素，参数为删除的元素，此改变在 length 之后
 * 模拟数组
 * @constructor
 */

var ArrayData = function (array) {
    if(array != null) {
        this._list = array;
        this._length = array.length;
    } else {
        this.list = [];
        this._length = 0;
    }
}

/**
 * 数组尾部加入元素
 * @param item
 */
ArrayData.prototype.push = function (item) {
    this.list.push(item);
    if (typeof item != "number" && item.setParent) {
        item.setParent(this, "Array");
    }
    this.length = this._length + 1;
    this.call("add", item);
}

/**
 * 指定地反加入元素
 * @param item
 */
ArrayData.prototype.addItemAt = function (item, index) {
    index = index == null ? this.list.length : index;
    this.list.splice(index, 0, item);
    if (typeof item != "number" && item.setParent) {
        item.setParent(this, "Array");
    }
    this.length = this._length + 1;
    this.call("add", item);
}

/**
 * 数组头部加入元素
 */
ArrayData.prototype.shift = function () {
    var item = this.list.shift();
    if (typeof item != "number" && item.setParent) {
        item.setParent(null, null);
    }
    this.length = this._length - 1;
    this.call("del", item);
}

/**
 * 从尾部删除
 */
ArrayData.prototype.pop = function () {
    var item = this.list.pop();
    if (typeof item != "number" && item.setParent) {
        item.setParent(null, null);
    }
    this.length = this._length - 1;
    this.call("del", item);
}

/**
 * 删除所有数据
 */
ArrayData.prototype.removeAll = function() {
    while(this.length) {
        var item = this.list.pop();
        if (typeof item != "number" && item.setParent) {
            item.setParent(null, null);
        }
        this.length = this._length - 1;
        this.call("del", item);
    }
}

/**
 * 删除某个元素
 */
ArrayData.prototype.delItemAt = function (index) {
    var item = this.list.shift(index);
    if (typeof item != "number" && item.setParent) {
        item.setParent(null, null);
    };
    this.length = this._length - 1;
    this.call("del", item)
}

/**
 * 删除某个特定元素
 */
ArrayData.prototype.delItem = function (key, value, key2, value2) {
    var item;
    if (!key2) {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value) {
                item = this.list.splice(i, 1)[0];
                break;
            }
        }
    } else {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value && this.list[i][key2] == value2) {
                item = this.list.splice(i, 1)[0];
                break;
            }
        }
    }
    if(!item) {
        return;
    }
    if (typeof item != "number" && item.setParent) {
        item.setParent(null, null);
    }
    this.length = this._length - 1;
    this.call("del", item);
    return item;
}

/**
 * 排序
 */
ArrayData.prototype.sort = function () {
    this.list.sort.apply(this.list.sort, arguments);
    this.length = this._length;
}

/**
 * 默认的 key
 * @param key
 */
ArrayData.prototype.setKey = function (key) {
    this.key = key;
}

ArrayData.prototype.setRangeMinKey = function(key) {
    this.rangeMinKey = key;
}

ArrayData.prototype.setRangeMaxKey = function(key) {
    this.rangeMaxKey = key;
}

/**
 * 获取第 index 个元素
 * @param index
 * @returns {*}
 */
ArrayData.prototype.getItemAt = function (index) {
    return this.list[index];
}

/**
 * 根据获取值
 * @param value
 * @returns 单个对象
 */
ArrayData.prototype.getItemByValue = function (value) {
    if (this.key == null) {
        console.log("没有设定健值");
        return null;
    }
    for (var i = 0; i < this.list.length; i++) {
        if (this.list[i][this.key] == value) {
            return this.list[i];
        }
    }
    return null;
}

/**
 * 根据获取值
 * @param value
 * @returns 单个对象
 */
ArrayData.prototype.getItemByRange = function (value) {
    if (this.key == null) {
        console.log("没有设定健值");
        return null;
    }
    for (var i = 0; i < this.list.length; i++) {
        var min = this.list[i][this.rangeMinKey];
        var max = this.list[i][this.rangeMaxKey];
        if (value >= min && value <= max) {
            return this.list[i];
        }
    }
    return null;
}

/**
 * 查询列表中 属性 key 等于 value 的对象
 * @param key
 * @param value
 * @return 单个对象
 */
ArrayData.prototype.getItem = function (key, value, key2, value2) {
    if (!key2) {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value) {
                return this.list[i];
            }
        }
    } else {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value && this.list[i][key2] == value2) {
                return this.list[i];
            }
        }
    }
    return null;
}

/**
 * 查询列表中 属性 key 等于 value 的对象
 * @param func 检测函数，函数返回 true 则匹配成功
 * @param thisObj this 指针
 * @param ...args 多余的参数放入前面，返回给检查函数
 * @return 单个对象
 */
ArrayData.prototype.getItemFunction = function (func,thisObj) {
    var args = [];
    if(arguments.length && arguments.length > 2) {
        args = [];
        for(var a = 2; a < arguments.length; a++) {
            args.push(arguments[a]);
        }
    }
    for (var i = 0; i < this.list.length; i++) {
        args.push(this.list[i]);
        var r = func.apply(thisObj,args);
        args.pop();
        if (r == true) {
            return this.list[i];
        }
    }
    return null;
}

/**
 * 查询列表中 属性 key 等于 value 的对象，返回数组
 * @param key
 * @param value
 * @return 数组对象 Array
 */
ArrayData.prototype.getItems = function (key, value, key2, value2) {
    var result = [];
    if (!key2) {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value) {
                result.push(this.list[i]);
            }
        }
    } else {
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i][key] == value && this.list[i][key2] == value2) {
                result.push(this.list[i]);
            }
        }
    }
    return result;
}

/**
 * 查找列表中 属性 findKey findValue value 的对象，并设置其属性
 * @param key
 * @param value
 * @return 数组对象 Array
 */
ArrayData.prototype.setItemsAttribute = function (findKey,findValue,setKey,setValue) {
    for (var i = 0; i < this.list.length; i++) {
        if (this.list[i][findKey] == findValue) {
            this.list[i][setKey] = setValue;
        }
    }
}

/**
 * 查询列表中 属性 key 等于 value 的对象，返回数组
 * @param func 检测函数，函数返回 true 则匹配成功
 * @param thisObj this 指针
 * @param ...args 多余的参数放入前面，返回给检查函数
 * @return 数组对象 Array
 */
ArrayData.prototype.getItemsFunction = function (func,thisObj) {
    var result = [];
    var args = [];
    if(arguments.length && arguments.length > 2) {
        args = [];
        for(var a = 2; a < arguments.length; a++) {
            args.push(arguments[a]);
        }
    }
    for (var i = 0; i < this.list.length; i++) {
        args.push(this.list[i]);
        var r = func.apply(thisObj,args);
        args.pop();
        if (r == true) {
            result.push(this.list[i]);
        }
    }
    return result;
}

/**
 * 设置第 index 个元素
 * @deprecated 这个函数后面需要删掉，功能有问题，以后不要再用了
 * @param index
 * @param item
 */
ArrayData.prototype.setItemAt = function (index, item) {
    if (index >= this._length) {
        GameSDK.Error.show("超出索引范围");
        return;
    }
    if (item == this.list[index]) return;
    if (typeof this.list[index] != "number" && this.list[index].setParent) {
        this.list[index].setParent(null, null);
    }
    this.list[index] = item;
    if (typeof item != "number" && item.setParent) {
        item.setParent(this, "Array");
    }
}

global.ArrayData = ArrayData;
ListenerBase.registerClass(ArrayData);

__define(ArrayData.prototype, "length"
    , function () {
        return this._length;
    }
    , function (val) {
        val = +val | 0;
        this._length = val;
        this.call("length", this);
    }
);

ArrayData.prototype.setParent = function (parent, attributeName) {
    this._parent = parent;
    this._parentAttribute = attributeName;
}

ArrayData.prototype.propertyChange = function (name, value) {
    this.call(name, value);
}

GameSDK.ArrayData = ArrayData;