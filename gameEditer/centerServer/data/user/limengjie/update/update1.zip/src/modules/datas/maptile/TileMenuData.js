/**
 * Created by cgMu on 2015/10/16.
 */

var TileMenuData = DataBase.extend({
    tileUI:null,
    tilePositionArray:[],
    tilePosition:cc.p(0,0),

    tileMenuBg:null,
    tileItemArray:[],
    moduleInit:false,

    callback:null,
    closeBack:null,
    //弹框背景尺寸
    _menuWidth:303,
    _menuHeight:303,
    //菜单按钮尺寸
    _itemWidth:63,
    _itemHeight:73,

    ctor:function() {
        this._menuWidth = 303;
        this._menuHeight = 303;
        this._itemWidth = 63;
        this._itemHeight = 73;

        var t = 34;
        //按钮菜单的坐标，索引表示拥有的按钮个数，从0开始，表示1个，最大值6
        this.tilePositionArray[0] = [cc.p(123+t,40+t)];
        this.tilePositionArray[1] = [cc.p(75+t,40+t),
            cc.p(153+t,40+t)];
        this.tilePositionArray[2] = [cc.p(44+t,47+t),
            cc.p(123+t,40+t),
            cc.p(202+t,47+t)];
        this.tilePositionArray[3] = [cc.p(-4+t,53+t),
            cc.p(75+t,40+t),
            cc.p(154+t,40+t),
            cc.p(230+t,53+t)];
        this.tilePositionArray[4] = [cc.p(-40+t,65+t),
            cc.p(44+t,47+t),
            cc.p(123+t,40+t),
            cc.p(202+t,47+t),
            cc.p(282+t,65+t)];
        this.tilePositionArray[5] = [cc.p(-82+t,80+t),
            cc.p(-4+t,53+t),
            cc.p(75+t,40+t),
            cc.p(154+t,40+t),
            cc.p(230+t,53+t),
            cc.p(310+t,80+t)];
    },

    init:function()
    {
        return true;
    },

    destroy:function()
    {
        this.tileUI = null;
        this.tilePosition = cc.p(0,0);
        this.tileItemArray = [];
        this.moduleInit = false;
        this.closeBack = null;
    },

    //data:{x:100,y:100,list[],title:"最上面的文字",name:"中间的文字","player":"","consortia":"","px":"","py":"","res":{id:,num:},"hide":true}
    //list:[{id:123,back:this.clickBack,thisObj:this}]
    setNewTileData: function (data) {
        var itemArray = [];

        this.callback = {};
        for(var i in data.list) {
            var id = data.list[i].id;
            itemArray.push(id);
            this.callback[id]=data.list[i];
        }

        this.tileUI = itemArray;
        this.tilePosition = cc.p(data.x,data.y);

        if(data.closeBack) this.closeBack = data.closeBack;
    }
});