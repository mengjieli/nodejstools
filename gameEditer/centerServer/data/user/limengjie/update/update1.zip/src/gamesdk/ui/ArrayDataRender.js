var ArrayDataRender = (function (_super) {

    __extends(ArrayDataRender, _super);

    function ArrayDataRender(arrayData, itemRenderClass) {
        _super.call(this);
        this.data = arrayData;
        this.itemRenderClass = itemRenderClass;
        this.items = [];
        this.data.addListener("add", this.addItem, this);
        this.data.addListener("del", this.delItem, this);
    }

    var d = __define, c = ArrayDataRender, p = c.prototype;

    p.addItem = function () {
    }

    return ArrayDataRender;
})(flower.EventDispatcher);