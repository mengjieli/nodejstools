/**
 * 登录成功后，发送网络消息，等待所有消息返回后调用返回函数，才真正的进入游戏界面
 * @param back
 * @constructor
 */
function EnterGameNet(back) {
    console.log("EnterGameNet");

    new ServerMapConfig();

    //加载服务器列表
    var msg = new SocketBytes();
    msg.writeUint(300);
    NetMgr.inst().send(msg);
    //请求城堡列表
    var msg = new SocketBytes();
    msg.writeUint(411);
    NetMgr.inst().send(msg);
    //加载道具列表
    var msg = new SocketBytes();
    msg.writeUint(500);
    NetMgr.inst().send(msg);
    //请求交战列表
    var msg = new SocketBytes();
    msg.writeUint(207);
    NetMgr.inst().send(msg);

    //需要监听返回的协议号
    var cmds = [
        0,
        399
    ];

    var cmd0 = {
        411: false,
        500: false,
        300: false
    };

    GameSDK.DataManager.getInstance().loadingData.model.progress = 0;
    GameSDK.DataManager.getInstance().loadingData.model.max = cmds.length - 1 + Object.keys(cmd0).length;

    var listener = function (cmd, data) {
        if (cmd == 0) {
            data.resetCMDData();
            var backCmd = data.readUint();
            cmd0[backCmd] = true;
            GameSDK.DataManager.getInstance().loadingData.model.progress++;
            var flag = true;
            for (var key in cmd0) {
                if (cmd0[key] == false) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                NetMgr.inst().removeEventListener(cmd, listener);
                loads[cmd] = true;
            }
        } else {
            NetMgr.inst().removeEventListener(cmd, listener);
            loads[cmd] = true;
            GameSDK.DataManager.getInstance().loadingData.model.progress++;
        }
        for (var key in cmd0) {
            if (!cmd0[key]) {
                return;
            }
        }
        for (var c = 0; c < cmds.length; c++) {
            if (!loads[cmds[c]]) {
                return;
            }
        }
        for (var i = 0; i < cmds.length; i++) {
            NetMgr.inst().removeEventListener(cmds[i], listener);
        }
        back();
    };
    var loads = {};
    for (var i = 0; i < cmds.length; i++) {
        NetMgr.inst().addEventListener(cmds[i], listener);
    }
}

/**
 * 连上服务器
 */
EnterGameNet.onConnectGameServer = function () {
}