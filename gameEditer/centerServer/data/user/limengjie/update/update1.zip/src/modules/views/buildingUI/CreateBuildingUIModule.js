/**
 * Created by cgMu on 2015/10/31.
 */

var CreateBuildingUIModule = ModuleBase.extend({
    ctor:function() {
        this._super();
    },

    initUI:function() {
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.updateMessage,this);
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
    },

    show:function( value ) {
        if(value.objectid == 1){
            return;
        }

        var data = ModuleMgr.inst().getData("CreateBuildingUIModule");//获取模块数据

        //传入的对象id（地块索引）为null时，关闭模块 + 动画
        if (value.objectid == null) {
            if (data.moduleInit) {
                this.unscheduleUpdate();
                //var movePos = cc.p((data._menuWidth-data._itemWidth)*0.5,(data._menuHeight-data._itemHeight)*0.5);
                //var delayTime = 0.05;
                var time = 0.2;
                //var move = new cc.MoveTo(time, movePos);
                //var action = new cc.EaseElasticOut(move);
                //var action = new cc.EaseExponentialOut(move);

                var index = data.buildingItemArray.length;
                for(var i = 0; i < data.buildingItemArray.length; i++) {
                    index--;
                    //data.buildingItemArray[index].runAction(cc.Sequence(cc.DelayTime(i*delayTime), action,cc.Hide()));
                    data.buildingItemArray[index].runAction( cc.ScaleTo(time,0) );
                }

                //data.buildingMenuBg.runAction(cc.Sequence(cc.DelayTime(data.buildingItemArray.length*delayTime),cc.ScaleTo(0.1,0),cc.CallFunc(function(){
                //    ModuleMgr.inst().closeModule("CreateBuildingUIModule");
                //})));
                data.buildingMenuBg.runAction(cc.Sequence(cc.FadeOut(time),cc.CallFunc(function(){
                    ModuleMgr.inst().closeModule("CreateBuildingUIModule");
                })));
            }
            data.destroy();
            return;
        }

        data.initData(value.objectid,value.objectpos);//初始化模块数据--地块索引和坐标

        if (data.menuUI == 0) {
            cc.log("当前空地没有建筑可以建造");
            ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null});
            return;
        }

        if (!data.moduleInit) {
            var json = ccs.load("res/images/ui/TileMenuModule/MenuLayer.json","res/images/ui/");
            var root = json.node;
            this.addChild(root);
            data.buildingUI=root;

            this.bgPanel = ccui.helper.seekWidgetByName(root, "menuPanel");

            var scaleBg = this.bgPanel.getChildByName("Image_2");
            var counts = data.menuUI.length;
            //if(counts<4){
            //    scaleBg.y -= 20;
            //}

            //名称
            var name = this.bgPanel.getChildByName("Image_1");
            name.setVisible(false);

            this.scheduleUpdate()
        }

        //data.initData(value.objectid,value.objectpos);
        cc.log("CreateBuildingUIModule", data.buildingObjectId);

        var scaleBg = this.bgPanel.getChildByName("Image_2");
        scaleBg.ignoreContentAdaptWithSize(true);
        data.buildingMenuBg=scaleBg;

        var pos = data.buildingPosition;
        data.moduleInit = true;
        //data.buildingMenuBg.setScale(0);

        this.refreshMenuPosition(pos);
        this.refreshMenuItem();
    },

    close:function() {

    },

    destroy:function() {
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.updateMessage,this);
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
    },

    refreshMenuItem: function () {
        var data = ModuleMgr.inst().getData("CreateBuildingUIModule");
        var length = data.buildingItemArray.length;
        cc.log("refreshMenuItem", length);

        for (var i = 0; i < length; i++) {
            if (data.buildingItemArray[i]) {
                data.buildingItemArray[i].removeFromParent(true);
                data.buildingItemArray[i] = null;
            }
        }
        data.buildingItemArray=[];

        var counts = data.menuUI.length;
        if(counts<4){
            data.buildingMenuBg.loadTexture("zjm_tubiaodi23.png",ccui.Widget.PLIST_TEXTURE);
        }
        //cc.log("buildingData.menuUI.length",buildingData.menuUI.length);
        var posArray = data.buildingPositionArray[counts-1];

        for (var i = 0;i < counts;i++) {
            var titleName = ResMgr.inst().getString(data.menuUI[i]+"0");

            //var cell = new CustomMenuItem(data.menuUI[i]+"2",
            //    data.menuUI+"1",
            //    titleName,this.touchEvent);
            var cell = new BuildingMenuItem(data.menuUI[i],data.menuUI[i]+"3",
                data.menuUI+"1",
                titleName,this.touchEvent);
            cell.setPosition(cc.p((data._menuWidth-data._itemWidth)*0.5,(data._menuHeight-data._itemHeight)*0.5));
            cell.setVisible(false);
            this.bgPanel.addChild(cell);

            //var delayTime = 0;
            var time = 0.5;
            var move = new cc.MoveTo(time, posArray[i]);
            //var action = new cc.EaseElasticOut(move);
            var action = new cc.EaseExponentialOut(move);
            //cell.runAction(cc.sequence(cc.DelayTime(i*delayTime), cc.Spawn(cc.Show(),action)));
            cell.runAction(cc.Spawn(cc.Show(),action));

            data.buildingItemArray.push(cell);
        }

        //data.buildingMenuBg.runAction(cc.EaseElasticOut(cc.scaleTo(1,1)));
    },

    touchEvent:function (sender) {
        var tag = sender.getTag();
        //tag = parseInt(tag/10);
        var data = ModuleMgr.inst().getData("CreateBuildingUIModule");

        cc.log("sender.getTag" ,tag,"index :",data.buildingObjectId);
        EventMgr.inst().dispatchEvent( CastleEvent.BUILD_SUCCESS,data.buildingObjectId,tag);
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    refreshMenuPosition: function (pos) {
        var data = ModuleMgr.inst().getData("CreateBuildingUIModule");
        if (data.buildingUI) {
            data.buildingUI.setPosition(cc.p(pos.x-data._menuWidth*0.5,pos.y-data._menuHeight*0.5));
        }
    },

    update: function (dt) {
        var pos = ModuleMgr.inst().getData("CastleModule")._movePos;
        this.refreshMenuPosition(pos);
    },

    updateMessage: function (event,data) {
        if (data == CastleNetEvent.SEND_BUILD) {
            var data = ModuleMgr.inst().getData("CreateBuildingUIModule");
            EventMgr.inst().dispatchEvent( CastleEvent.UPGRADE_COMPLETE,data.buildingObjectId);
            ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
        }
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("createBuildingUI引导触发操作doGuide"+guideId);
        if(guideId=="2_1"){//造仓库
            var data = ModuleMgr.inst().getData("CreateBuildingUIModule");
            EventMgr.inst().dispatchEvent( CastleEvent.BUILD_SUCCESS,data.buildingObjectId,1906001);
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
        }
        else if(guideId=="3_8"){//造学院
            var data = ModuleMgr.inst().getData("CreateBuildingUIModule");
            EventMgr.inst().dispatchEvent( CastleEvent.BUILD_SUCCESS,data.buildingObjectId,1903001);
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
        }
    },
});