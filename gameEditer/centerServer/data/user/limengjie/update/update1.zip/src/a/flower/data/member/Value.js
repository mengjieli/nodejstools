var flower;
(function (flower) {
    var Value = (function () {
        function Value() {
        }
        return Value;
    })();
    flower.Value = Value;
})(flower || (flower = {}));
//# sourceMappingURL=Value.js.map