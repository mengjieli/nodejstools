var flower;
(function (flower) {
    var Texture2D = (function () {
        function Texture2D(nativeTexture, url, nativeURL, w, h) {
            this._hasDispose = false;
            this._nativeTexture = nativeTexture;
            this._url = url;
            this._nativeURL = nativeURL;
            this.count = 0;
            this._width = w;
            this._height = h;
        }
        Texture2D.prototype.$dispose = function () {
            if (flower.Texture2D.safeLock == true) {
                flower.DebugInfo.debug("|释放纹理| 操作失败，此方法提供内部结构使用，外部禁止使用，请用TextureManager.disposeTexure()代替，url:" + this.url, flower.DebugInfo.ERROR);
                return;
            }
            if (this.count != 0) {
                flower.DebugInfo.debug("|释放纹理| 纹理计数器不为0，此纹理不会被释放，计数为 " + this.count + "，地址为" + this.url, flower.DebugInfo.ERROR);
                return;
            }
            new flower.CallLater(this._realDispose, this);
        };
        Texture2D.prototype._realDispose = function () {
            if (this.count == 0) {
                System.disposeTexture(this._nativeTexture, this._nativeURL);
                this._nativeTexture = null;
                flower.DebugInfo.debug("|释放纹理| " + this.url, flower.DebugInfo.TIP);
                this._hasDispose = true;
            }
        };
        Texture2D.prototype.addCount = function () {
            this.count++;
        };
        Texture2D.prototype.delCount = function () {
            this.count--;
            if (this.count == 0) {
                flower.TextureManager.getInstance().delTexture(this);
            }
        };
        Texture2D.prototype.getCount = function () {
            return this.count;
        };
        Object.defineProperty(Texture2D.prototype, "url", {
            get: function () {
                return this._url;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Texture2D.prototype, "nativeURL", {
            get: function () {
                return this._nativeURL;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Texture2D.prototype, "width", {
            get: function () {
                return this._width;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Texture2D.prototype, "height", {
            get: function () {
                return this._height;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Texture2D.prototype, "hasDispose", {
            get: function () {
                return this._hasDispose;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Texture2D.prototype, "$nativeTexture", {
            get: function () {
                return this._nativeTexture;
            },
            enumerable: true,
            configurable: true
        });
        return Texture2D;
    })();
    flower.Texture2D = Texture2D;
})(flower || (flower = {}));
flower.Texture2D.safeLock = true;
//# sourceMappingURL=Texture2D.js.map