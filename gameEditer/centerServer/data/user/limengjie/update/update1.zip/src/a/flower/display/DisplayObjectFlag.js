var flower;
(function (flower) {
    var DisplayObjectFlag = (function () {
        function DisplayObjectFlag() {
        }
        return DisplayObjectFlag;
    })();
    flower.DisplayObjectFlag = DisplayObjectFlag;
})(flower || (flower = {}));
flower.DisplayObjectFlag.SIZE = 1;
flower.DisplayObjectFlag.NATIVE_TEXT = 2;
flower.DisplayObjectFlag.COMPONENT_POSITION = 10;
//# sourceMappingURL=DisplayObjectFlag.js.map