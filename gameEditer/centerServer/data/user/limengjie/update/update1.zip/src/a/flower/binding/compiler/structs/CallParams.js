var flower;
(function (flower) {
    var CallParams = (function () {
        function CallParams() {
            this.type = "callParams";
            this.list = [];
        }
        CallParams.prototype.addParam = function (expr) {
            this.list.push(expr);
        };
        CallParams.prototype.addParamAt = function (expr, index) {
            this.list.splice(index, 0, expr);
        };
        CallParams.prototype.checkPropertyBinding = function (checks, commonInfo) {
            for (var i = 0; i < this.list.length; i++) {
                this.list[i].checkPropertyBinding(checks, commonInfo);
            }
        };
        CallParams.prototype.getValueList = function () {
            var params = [];
            for (var i = 0; i < this.list.length; i++) {
                params.push(this.list[i].getValue());
            }
            return params;
        };
        return CallParams;
    })();
    flower.CallParams = CallParams;
})(flower || (flower = {}));
//# sourceMappingURL=CallParams.js.map