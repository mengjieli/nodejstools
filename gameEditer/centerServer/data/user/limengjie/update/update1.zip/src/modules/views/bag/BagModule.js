/**
 * Created by cgMu on 2015/11/21.
 */

var BagModule = ModuleBase.extend({
    scrol: null,
    scrollbar: null,
    barTotalHeight: 0,
    barPercent_total: 0,
    scrollPosY: 0,

    row: null,
    isOnePage: null,
    item_root: null,

    panel_up: null,
    panel_down: null,
    countsMax: null,//记录当前道具的使用最大数量

    itemData: null,//数组，道具ID，背包中数量不为0的可查看的道具
    scrolItemArray: null,
    selectingGridIndex: 0,//默认选中第一个

    openItemId : null,//开启礼包id

    ctor: function () {
        this._super();

        this.row = 4;//每行4列
        this.itemData = [];
        this.scrolItemArray = [];

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.updateBag, this);
    },

    initUI: function () {
        var root = ccs.load("res/images/ui/BagModule/Layer.json", "res/images/ui/").node;
        this.addChild(root);

        //适配
        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1 = ccui.helper.seekWidgetByName(root, "Panel_1");
        sizeAutoLayout(Panel_1);

        var Image_30 = Panel_1.getChildByName("Image_30");
        sizeAutoLayout(Image_30);

        var Panel_5 = Panel_1.getChildByName("Panel_5");
        sizeAutoLayout(Panel_5);

        var Image_28 = Panel_1.getChildByName("Image_28");
        posAutoLayout(Image_28);

        var Image_9 = Panel_1.getChildByName("Image_9");
        sizeAutoLayout(Image_9);
        var Image_9_0 = Panel_1.getChildByName("Image_9_0");
        sizeAutoLayout(Image_9_0);

        var Image_26 = Panel_1.getChildByName("Image_26");
        sizeAutoLayout(Image_26);
        posAutoLayout(Image_26, 0.5);

        var Image_24 = Panel_1.getChildByName("Image_24");
        sizeAutoLayout(Image_24);

        var scrollview = Panel_1.getChildByName("ScrollView_1");
        sizeAutoLayout(scrollview);
        scrollview.addEventListener(this.scrollCall, this);
        this.scrol = scrollview;

        var item_root = this.scrol.getChildByName("Image_5");
        item_root.setVisible(false);
        this.item_root = item_root;

        var scrolbar_bg = Panel_1.getChildByName("Image_3");
        sizeAutoLayout(scrolbar_bg);

        var scrolbar = Panel_1.getChildByName("Image_4");
        posAutoLayout(scrolbar);
        this.scrollbar = scrolbar;
        this.scrollPosY = this.scrollbar.getPositionY();
        this.barTotalHeight = scrolbar_bg.getContentSize().height;

        var right_up = ccui.helper.seekWidgetByName(root, "Panel_2");
        posAutoLayout(right_up);
        this.panel_up = right_up;

        var right_down = ccui.helper.seekWidgetByName(root, "Panel_3");
        this.panel_down = right_down;

        var s1 = ccui.helper.seekWidgetByName(root, "Image_16");
        posAutoLayout(s1);
        var s2 = ccui.helper.seekWidgetByName(root, "Image_16_5");
        posAutoLayout(s2, 1 / 7);
        var s3 = ccui.helper.seekWidgetByName(root, "Image_16_4");
        posAutoLayout(s3, 2 / 7);
        var s4 = ccui.helper.seekWidgetByName(root, "Image_16_3");
        posAutoLayout(s4, 3 / 7);
        var s5 = ccui.helper.seekWidgetByName(root, "Image_16_2");
        posAutoLayout(s5, 4 / 7);
        var s6 = ccui.helper.seekWidgetByName(root, "Image_16_1");
        posAutoLayout(s6, 5 / 7);
        var s7 = ccui.helper.seekWidgetByName(root, "Image_16_0");
        posAutoLayout(s7, 6 / 7);

    },

    show: function (value) {
        this.getBagData();
        this.refreshContent();
        this.setSelectingGrid(this.selectingGridIndex);
    },

    close: function () {

    },

    destroy: function () {
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.updateBag, this);
    },

    //数据过滤，道具排序
    getBagData: function () {
        this.itemData = [];
        var data = mainData.bagDataList;
        for (var i = 0; i < data.length; i++) {
            var item = data.getItemAt(i);
            var itemConfig = modelMgr.call("Table", "getTableItemByValue", ["item", item.itemid]);
            if (itemConfig) {
                var cansee = itemConfig.cansee;
                if (parseInt(cansee) > 0 && parseInt(item.counts) > 0) {
                    this.itemData.push(item.itemid);
                }
            }
        }
        this.sortData();
    },

    //获得背包格子数
    getBagGridsCounts: function () {
        var y = this.row;//每行4列

        var size = this.scrol.getContentSize();
        var item_height = 86;
        var gap_height = 5;
        var counts = Math.ceil(size.height/(item_height+gap_height)) * y;

        var add = 0;//记录需要额外添加的空背包格子数量
        var ex = this.itemData.length % y;
        if (ex > 0) {
            add = y - ex;
        }

        if(counts>this.itemData.length + add){
            return counts;
        }

        return this.itemData.length + add;
    },

    refreshContent: function () {
        for (var i in this.scrolItemArray) {
            if (this.scrolItemArray[i]) {
                this.scrolItemArray[i].removeFromParent(true)
            }
        }
        this.scrolItemArray = [];

        var counts = this.getBagGridsCounts();
        var counts_ex = this.itemData.length;

        for (var i = 0; i < counts; i++) {
            var item = this.item_root.clone();
            item.setVisible(true);
            this.scrol.addChild(item);
            this.scrolItemArray.push(item);
            item.setTouchEnabled(true);
            item.addTouchEventListener(this.itemCallback, this);

            item.setTag(i);//格子索引
            if (i >= counts_ex) {
                //该索引的为空格子
                item.setUserData(0);
            }
            else {
                var itemid = this.itemData[i];
                item.setUserData(itemid);//道具ID,空格子置0
            }

            this.setItem(item);
        }

        this.updateItemPosition(counts,true);
    },

    updateItemPosition: function (counts,top) {
        var size = this.scrol.getContentSize();
        var item_width = 86;
        var item_height = 86;
        var gap_width = 4;
        var gap_height = 5;

        var x = parseInt(counts / this.row);
        var total_height = x * (gap_height + item_height) + gap_height;
        if (total_height < size.height) {
            total_height = size.height;
        }

        for (var i in this.scrolItemArray) {
            this.scrolItemArray[i].setPosition(cc.p(gap_width + 4 + item_width * 0.5 + (gap_width + item_width) * (i % this.row), total_height - gap_height - item_height * 0.5 - parseInt(i / this.row) * (gap_height + item_height)));
        }

        this.scrol.setInnerContainerSize(cc.size(size.width, total_height));
        if(top){
            this.scrol.jumpToTop();
        }

        var pos = size.height-total_height;
        this.barPercent_total = Math.abs(pos);

        //重置滑块大小
        var innerContainerSize = this.scrol.getInnerContainerSize();
        if (innerContainerSize.height < size.height) {
            this.isOnePage = true;
        }
        else {
            this.isOnePage = false;
        }
        if (this.isOnePage) {
            this.refreshScrollbarState(100);
        }
        else {
            this.refreshScrollbarState(0);
        }

        //this.updateScrollviewSelecting(this.scrol, x, item_height, parseInt(this.selectingGridIndex / this.row));
    },

    itemCallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;

        var index = sender.getTag();
        var itemid = sender.getUserData();
        if (itemid == 0) return;//空格子不响应触摸
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));

        if (this.selectingGridIndex == index) return;//重复触摸处理
        this.selectingGridIndex = index;
        cc.log("itemCallback", this.selectingGridIndex);
        this.setSelectingGrid(this.selectingGridIndex);
    },

    setItem: function (item) {
        var itemid = item.getUserData();

        var selecting = item.getChildByName("Image_5_0_0");
        selecting.setVisible(false);
        var icon = item.getChildByName("Image_5_0");
        icon.ignoreContentAdaptWithSize(true);
        var counts = item.getChildByName("Text_1");
        counts.ignoreContentAdaptWithSize(true);
        var countsBg = item.getChildByName("Image_6");
        var unit = item.getChildByName("Image_5_0_2");
        unit.ignoreContentAdaptWithSize(true);
        unit.setVisible(false);

        if (itemid == 0) {
            //空格子
            icon.setVisible(false);
            counts.setVisible(false);
            countsBg.setVisible(false);
        }
        else {
            icon.loadTexture(ResMgr.inst().getIcoPath(itemid));
            icon.setScale(0.6);
            counts.setString(ModuleMgr.inst().getData("ItemModule").getCountsByItemId(itemid));
            icon.setVisible(true);
            counts.setVisible(true);
            countsBg.setVisible(true);

            var tokenList = [1101201,1101202,1101203];
            //cc.log("@BagModule", itemid,tokenList.indexOf(itemid));
            if(tokenList.indexOf(itemid)!=-1) {
                unit.setVisible(true);
                unit.loadTexture("BagModule/"+counts.getString()+".png");
            }
        }

    },

    refreshRightContent: function (selectedindex) {
        if (!this.scrolItemArray[selectedindex]) {
            this.panel_up.setVisible(false);
            this.panel_down.setVisible(false);
            return;
        }
        this.panel_up.setVisible(true);
        var item = this.scrolItemArray[selectedindex];
        var itemid = item.getUserData();
        var itemcounts = ModuleMgr.inst().getData("ItemModule").getCountsByItemId(itemid);

        var icon = this.panel_up.getChildByName("Image_10_0");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(itemid));
        icon.setScale(0.6);

        var name = this.panel_up.getChildByName("Text_2");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(itemid + "0"));

        var des1 = this.panel_up.getChildByName("Text_3");
        des1.ignoreContentAdaptWithSize(true);
        des1.setString(ResMgr.inst().getString("bag_1"));
        var des2 = this.panel_up.getChildByName("Text_3_0");
        des2.ignoreContentAdaptWithSize(true);
        des2.setString(itemcounts);
        var des3 = this.panel_up.getChildByName("Text_3_1");
        des3.ignoreContentAdaptWithSize(true);
        des3.setString(ResMgr.inst().getString("bag_2"));
        //postionx自适应
        des2.setPositionX(des1.getPositionX() + des1.getContentSize().width + 2);
        des3.setPositionX(des2.getPositionX() + des2.getContentSize().width + 2);

        var detail = this.panel_up.getChildByName("Text_4");
        //detail.ignoreContentAdaptWithSize(true);
        detail.setString(ResMgr.inst().getString(itemid + "1"));

        if (modelMgr.call("Table", "getTableItemByValue", ["item", itemid]) == null) {
            return;
        }
        //down
        var canuse = modelMgr.call("Table", "getTableItemByValue", ["item", itemid]).class;
        if ([4,10,11,12,14].indexOf(canuse) == -1) {
            this.panel_down.setVisible(false);
            return;
        }
        this.panel_down.setVisible(true);
        var label1 = this.panel_down.getChildByName("Text_5");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("bag_3"));

        var textField = this.panel_down.getChildByName("TextField_1");
        textField.setPlaceHolder(ResMgr.inst().getString("bag_4"));
        textField.setString(itemcounts);
        textField.addEventListener(this.textFieldCallback, this);
        this.countsMax = itemcounts;

        var sub = this.panel_down.getChildByName("Panel_4");
        sub.setTouchEnabled(true);
        sub.addTouchEventListener(this.subcallback, this);
        var add = this.panel_down.getChildByName("Image_15_0");
        add.setTouchEnabled(true);
        add.addTouchEventListener(this.addcallback, this);

        var slider = this.panel_down.getChildByName("Slider_1");
        slider.addEventListener(this.sliderCall, this);
        var percent = 1 / this.countsMax * 100;
        this.setTextFieldString(1);
        slider.setPercent(percent);

        var button = this.panel_down.getChildByName("Button_1");
        button.addTouchEventListener(this.usingItem, this);
        var btn_title = button.getChildByName("Text_6");
        btn_title.ignoreContentAdaptWithSize(true);
        btn_title.setString(ResMgr.inst().getString("bag_5"));
    },

    usingItem: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        if (this.panel_down.isVisible()) {
            if (!this.scrolItemArray[this.selectingGridIndex]) return;
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
            var item = this.scrolItemArray[this.selectingGridIndex];
            var itemid = item.getUserData();

            var countsInput = this.panel_down.getChildByName("TextField_1");
            var text = countsInput.getString();
            var use_counts = parseInt(text);

            cc.log("usingItem", itemid, use_counts);
            this.openItemId = null;
            if (use_counts > 0) {
                var data = modelMgr.call("Table", "getTableItemByValue", ["item", itemid]).class;
                var castleid = mainData.uiData.currentCastleId;
                cc.log("mainData.uiData.currentCastleId", castleid, data);
                if (data == 10) {
                    var msg = new SocketBytes();
                    msg.writeUint(417);//使用资源箱
                    msg.writeString(castleid);
                    msg.writeUint(itemid);
                    msg.writeUint(use_counts);
                    NetMgr.inst().send(msg);
                }
                else {
                    this.netUsingItem(itemid, use_counts);
                }

                this.openItemId = itemid;
            }
            else {
                ModuleMgr.inst().openModule("AlertString", {
                    str: ResMgr.inst().getString("bag_6"),
                    color: null,
                    time: null,
                    pos: null
                });
                this.setUseCounts(1);
            }
        }

    },

    netUsingItem: function (itemid, counts) {
        var msg = new SocketBytes();
        msg.writeUint(503);//使用礼包
        msg.writeUint(itemid);
        msg.writeUint(counts);
        NetMgr.inst().send(msg);
    },

    sliderCall: function (sender, type) {
        if (type == ccui.Slider.EVENT_PERCENT_CHANGED) {
            var num = sender.getPercent();
            var use_counts = num * this.countsMax / 100;
            this.setTextFieldString(parseInt(use_counts));
            //cc.log("percent",num,use_counts,parseInt(use_counts));
        }
    },

    setSliderPercent: function (value) {
        if (this.panel_down.isVisible()) {
            var slider = this.panel_down.getChildByName("Slider_1");
            if (value < 0) {
                value = 0;
            }
            if (value > 100) {
                value = 100;
            }
            slider.setPercent(value);
        }
    },

    //滚动框事件回调
    scrollCall: function (node, type) {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                this.setScrollbar();
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    //更新滑块位置
    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY - (this.barTotalHeight - 15 - this.scrollbar.height) * percent / 100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },

    setSelectingGrid: function (index) {
        if(this.scrolItemArray[index]){
            var itemid = this.scrolItemArray[index].getUserData();
            if(itemid==0){
                this.selectingGridIndex -= 1;
            }
        }

        for (var i in this.scrolItemArray) {
            var selecting = this.scrolItemArray[i].getChildByName("Image_5_0_0");
            if (this.selectingGridIndex == i) {
                selecting.setVisible(true);
            }
            else {
                selecting.setVisible(false);
            }
        }

        this.refreshRightContent(this.selectingGridIndex);
    },

    textFieldCallback: function (sender, type) {
        if (type == ccui.TextField.EVENT_INSERT_TEXT || type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            //cc.log("textfield",sender.getString());
            var text = sender.getString();
            var use_counts = parseInt(text);
            //纯数字
            var reg = new RegExp("^[0-9]*$");
            if (!reg.test(text)) {
                this.setTextFieldString(use_counts);
            }
            if (text == "") {
                this.setSliderPercent(0);
                return;
            }
            if (use_counts > this.countsMax) {
                use_counts = this.countsMax;
                this.setTextFieldString(use_counts);
            }
            if (use_counts < 1) {
                use_counts = 1;
                this.setTextFieldString(use_counts);
            }
            //cc.log("use_counts",use_counts);
            if (!use_counts) {
                use_counts = this.countsMax;
                this.setTextFieldString(use_counts);
            }
            var per = use_counts * 100 / this.countsMax;
            //cc.log("use_counts",use_counts,per);
            this.setSliderPercent(per);
        }
        //if(type == ccui.TextField.EVENT_DETACH_WITH_IME) {
        //    cc.log("EVENT_DETACH_WITH_IME");
        //}
    },

    setTextFieldString: function (value) {
        if (this.panel_down.isVisible()) {
            var countsInput = this.panel_down.getChildByName("TextField_1");
            countsInput.setString(value);
        }
    },

    subcallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));

        if (this.panel_down.isVisible()) {
            var countsInput = this.panel_down.getChildByName("TextField_1");
            var text = countsInput.getString();
            var use_counts = parseInt(text);
            if (text == "") {
                use_counts = 0;
            }
            use_counts--;
            this.setUseCounts(use_counts);
        }
    },

    addcallback: function (sender, type) {
        if (type != ccui.Widget.TOUCH_ENDED) return;
        SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));

        if (this.panel_down.isVisible()) {
            var countsInput = this.panel_down.getChildByName("TextField_1");
            var text = countsInput.getString();
            var use_counts = parseInt(text);
            if (text == "") {
                use_counts = 0;
            }
            use_counts++;
            this.setUseCounts(use_counts);
        }
    },

    setUseCounts: function (use_counts) {
        if (use_counts < 0) use_counts = 0;
        if (use_counts > this.countsMax) use_counts = this.countsMax;

        this.setTextFieldString(use_counts);

        var per = use_counts * 100 / this.countsMax;
        this.setSliderPercent(per);
    },

    updateBag: function (event, data) {
        if (data == 500 || data == 503 || data == 417) {//请求道具
            //ModuleMgr.inst().openModule("BagModule");
            this.afterUsedUpdatingBag();

            if (data == 503 || data == 417) {
                SoundPlay.playEffect(ResMgr.inst().getSoundPath(8));
                if(this.openItemId){
                    //播放获得礼包特效
                    var arr = this.doBag({"id":this.openItemId,"num":100,"type":2});
                    ModuleMgr.inst().openModule("AlertGainModule",{"arr":arr});
                }
            }
        }
    },

    doBag: function (data) {
        var arr = [];
        var itemid = data.id;//使用的道具ID
        var data = modelMgr.call("Table", "getTableItemByValue", ["item", itemid]);
        if(data.class == 10){
            arr.push(ResMgr.inst().getIcoPath(data.type));
        }
        else{
            if(data.canuse==0) return;

            var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data.canuse ]);
            var temp = itemdata.obtain_item;
            var tempjson = eval("(" + temp + ")");
            for (var i in tempjson) {
                arr.push(ResMgr.inst().getIcoPath(i));
            }
        }
        return arr;
        //this.play(arr);
    },

    updateScrollviewSelecting: function (scrollview, length, itemH, selecting) {
        var size = scrollview.getContentSize();
        var h = scrollview.getInnerContainerSize().height;
        var number = parseInt(size.height / itemH);
        if (selecting >= length - number) {
            this.runAction(cc.Sequence(cc.DelayTime(0.001), cc.CallFunc(function () {
                scrollview.jumpToBottom();
            })));
        }
        else {
            this.runAction(cc.Sequence(cc.DelayTime(0.001), cc.CallFunc(function (sender) {
                var percent = (selecting - 1) * (itemH + 5) / (h - size.height) * 100;
                scrollview.jumpToPercentVertical(percent);
            })));
        }
    },

    //背包刷新
    afterUsedUpdatingBag: function () {
        this.getBagData();//更新背包道具ID数据

        var counts = this.getBagGridsCounts();
        var counts_ex = this.itemData.length;

        for(var i = 0; i < counts; i++){
            if(this.scrolItemArray[i]){
                var item = this.scrolItemArray[i];
                item.setTag(i);//格子索引
                if (i >= counts_ex) {
                    item.setUserData(0);//该索引的为空格子
                }
                else {
                    var itemid = this.itemData[i];
                    item.setUserData(itemid);//道具ID,空格子置0
                }
                this.setItem(item);
            }
            else{
                //需要新建新的格子
                var item = this.item_root.clone();
                item.setVisible(true);
                this.scrol.addChild(item);
                this.scrolItemArray.push(item);
                item.setTouchEnabled(true);
                item.addTouchEventListener(this.itemCallback, this);

                item.setTag(i);//格子索引
                if (i >= counts_ex) {
                    //该索引的为空格子
                    item.setUserData(0);
                }
                else {
                    var itemid = this.itemData[i];
                    item.setUserData(itemid);//道具ID,空格子置0
                }

                this.setItem(item);
            }
        }
        //删除多余的格子
        var gridLength = this.scrolItemArray.length - counts;
        if(gridLength>0){
            var len = this.scrolItemArray.length;
            for(var i = 1; i <= gridLength; i++){
                this.scrolItemArray[len-i].removeFromParent(true);
                this.scrolItemArray.pop();
            }
        }

        this.updateItemPosition(counts);

        this.setScrollbar();//更新滑块

        this.setSelectingGrid(this.selectingGridIndex);
    },

    sortData: function () {
        for (var i = 0; i < this.itemData.length; i++) {
            for (var j = i + 1; j < this.itemData.length; j++) {
                var item_i = modelMgr.call("Table", "getTableItemByValue", ["item", this.itemData[i]]);
                var item_j = modelMgr.call("Table", "getTableItemByValue", ["item", this.itemData[j]]);
                if (item_i.class > item_j.class) {
                    var temp = this.itemData[i];
                    this.itemData[i] = this.itemData[j];
                    this.itemData[j] = temp;
                }
                else if (item_i.class == item_j.class) {
                    if (parseInt(item_i.itemid) > parseInt(item_j.itemid)) {
                        var temp = this.itemData[i];
                        this.itemData[i] = this.itemData[j];
                        this.itemData[j] = temp;
                    }
                }
            }
        }
    },

    setScrollbar: function () {
        var pos = this.scrol.getInnerContainer().getPosition();
        var number = this.barPercent_total + pos.y;
        var per = number * 100 / this.barPercent_total;
        if (per < 0) {
            per = 0
        }
        if (per > 100) {
            per = 100
        }
        this.refreshScrollbarState(per);
    }
});