/**
 * 执行地图上的操作
 * @param type
 * @param params
 * @constructor
 */
function MapCommand(type, params) {
    switch (type) {
        case MapCommand.CLEAR_RECT:
            this.clearRect.apply(this,params);
            break;
    }
}

/**
 * 清除地图上某个范围内所有对象
 * 包含：建筑、角色、购买地块、可砍伐资源以及地图不可走动的信息
 */
MapCommand.prototype.clearRect = function (x,y,width,height) {
    var ex = x + width;
    var ey = y + height;
    //for(var i = 0; i < )
}


MapCommand.CLEAR_RECT = "clear_rect";