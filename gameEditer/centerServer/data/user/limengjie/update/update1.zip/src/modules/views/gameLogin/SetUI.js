/**
 * Created by Administrator on 2015/12/14.
 */


var SetUI = cc.Node.extend( {

    _ui: null,
    _errorLabel:null,

    _input: null,
    _account:null,//账号
    _regain:null,//验证码

    ctor: function(ip,rg)
    {
        this._super();
        this._account = ip;
        this._regain = rg;
    },

    onEnter: function()
    {
        this._super();
        this._ui = ccs.load( "res/images/ui/login/set.json", "res/images/ui/" ).node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //下一步按钮
        var but = this._ui.getChildByName( "ui_mainban" ).getChildByName( "denglu" );
        but.addTouchEventListener( this.nextCall, this );
        but.setTitleText( ResMgr.inst().getString("login_22"));

        //密码输入框
        this._input = this._ui.getChildByName( "ui_mainban" ).getChildByName( "TextField_2" );
        //this._input.ignoreContentAdaptWithSize( true );
        this._input.setPlaceHolder( ResMgr.inst().getString("login_21") );

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2_0_0" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_31"));
        txt.setVisible(false);
        this._errorLabel = txt;

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_19"));

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2_0" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_20") + this._account);

        NetMgr.inst().addEventListener(0, this.netGetError, this);
    },

    onExit: function()
    {
        this._super();
        NetMgr.inst().removeEventListener(0, this.netGetError, this);
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /**
     * 下一步回调
     * @param node
     * @param type
     */
    nextCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            this.nextStep();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    nextStep: function () {
        var newpassword = this._input.getString();
        if(newpassword.length < 6 || newpassword.length > 20)
        {
            this._errorLabel.setVisible(true);
            return;
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "reset_password";
        var url = head;
        url += "?loginName=" + encodeString(this._account);
        url += "&verificationCode=" + encodeString(this._regain);
        url += "&newPassword=" + encodeString(newpassword);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
                cc.log("nextStep SetUI data:" + data);
                var ret = JSON.parse(data);
                if(ret)
                {
                    if(0 == ret.err_code)
                    {
                        //登录
                        //ModuleMgr.inst().openModule("GameLoginModule" );
                        param.owner.loginCallback();
                    }
                    else
                    {
                        var value = ResMgr.inst().getString(ret.err_code);
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                    }
                }
            }, null, {"objs":null, "onAccountStatus":null, "owner":this}
        );
    },

    //登录
    loginCallback: function () {
        var token = null;
        var cache = this.fetchUserInfo();
        if(null != cache && undefined != cache)
        {
            token = cache.token;
        }
        else
        {
            token = CD.genRandToken();
        }
        var password = this._input.getString();

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "check_login";
        var url = head;
        url += "?loginName=" + encodeString(this._account);
        url += "&password=" + encodeString(password);
        url += "&token=" + encodeString(token);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
            cc.log("loginCallback 接收:" + data);
            var ret = JSON.parse(data);
            if(ret)
            {
                switch(ret.err_code)
                {
                    case 0:
                        cc.error("用户登录验证成功，登录ing");
                        var hasBeenActivated = ret.hasBeenActivated;
                        if(hasBeenActivated){
                            ModuleMgr.inst().getData("GameLoginModule").recordUserInfo([param.owner._account, password, token]);
                            param.request.apply(param.owner,[param.owner._account, password, token]);
                        }
                        else{
                            cc.log("@打开激活界面，",account,token);
                            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"key","ip":account,"tk":token});
                        }
                        break;
                    default:
                        var value = ResMgr.inst().getString(ret.err_code);
                        ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                        break;
                }
            }
            else
            {
                var value = ResMgr.inst().getString("denglu_20");
                ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
            }
        }, null, {"objs":null, "request":this.loginRequest, "owner":this});
    },

    loginRequest : function (v1, v2, v3) {
        ReconnectionMgr.getInstance();
        NetMgr.inst().connectWebSocket(GameConfig.serverAddress);
        NetMgr.inst().addEventListener(NetEvent.socket.SOCKET_CONNECT, function () {
            var account = v1;
            var password = v2;
            var token = v3;
            cc.error("token:" + token);
            cc.error("account:" + account);
            cc.error("password:" + password);

            var msg = new SocketBytes();
            msg.writeUint(200);//账号登录
            msg.writeUint(GameConfig.PLATFORM_DEFAULT_ID);
            msg.writeString(account);
            msg.writeString(token);
            NetMgr.inst().send(msg);
        },this);
    },

    fetchUserInfo : function()
    {
        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var fileExist = jsb.fileUtils.isFileExist(storagePath + "cache");
        cc.log("文件存在标识:" + storagePath);

        if(fileExist)
        {
            var string = jsb.fileUtils.getValueMapFromFile(storagePath + "cache");
            cc.log("cache:" + JSON.stringify(string["lastLoginName"]) + "_" + (string["lastLoginPassword"]) + "_" + (string["lastLoginToken"]));
            return {"username":string["lastLoginName"], "password":string["lastLoginPassword"], "token":string["lastLoginToken"]};
        }
        return null;
    },

    netGetError : function (cmd,data) {
        if(cmd == 0){
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            cc.log("2@netGetError",data0,data1,data2);
            if(data0 == 200 && data1 == 0){
                ModuleMgr.inst().openModule("GameLoginModule",{"ui":"loading","login":true});
                startGameData.step = 6;
            }
        }
    }

});