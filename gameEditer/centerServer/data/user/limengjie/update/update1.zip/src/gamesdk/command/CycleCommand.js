var CycleCommand = (function (_super) {
    __extends(CycleCommand, _super);

    function CycleCommand(name, cycler, cycleState) {
        _super.call(this, name);
        //回收器
        this.cycler = cycler;
        //表示是否可回收
        this.cycleState = !!cycleState;
    }

    var d = __define, c = CycleCommand;
    p = c.prototype;

    /**
     * 回收，回收时应该断开与外界的任何联系，以及各种引用
     * @return 是否回收成功，如果回收成功则返回 true
     */
    p.cycle = function () {
        if (this.cycleState) {
            this.cycler.cycleLogic(this);
        }
    }

    p.dispose = function() {
        this.cycler = null;
    }

    return CycleCommand;
})(Command);