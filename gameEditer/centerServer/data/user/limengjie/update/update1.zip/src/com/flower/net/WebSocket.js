var CocosWebSocket = WebSocket;
var flower;
(function (flower) {
    var WebSocket = (function (_super) {
        __extends(WebSocket, _super);

        function WebSocket() {
            _super.call(this);
            this.socket = null;
            this.hasConnect = false;
            this.backs = {};
            this.zbacks = {};
        }

        var d = __define, c = WebSocket;
        p = c.prototype;

        p.connect = function (url) {
            if (this.socket) {
                this.close();
            }
            this.url = url;
            this.socket = new CocosWebSocket(url);
            this.socket.onopen = this.onConnect.bind(this);
            this.socket.onmessage = this.onReceiveMessage.bind(this);
            this.socket.onerror = this.onError.bind(this);
            this.socket.onclose = this.onClose.bind(this);
        }

        //链接上服务器
        p.onConnect = function () {
            this.hasConnect = true;
            this.dispatchEvent(new flower.Event(flower.Event.CONNECT));
        }

        p.register = function (cmd, backFunction, thisObj) {
            if (!this.backs[cmd]) {
                this.backs[cmd] = [];
            }
            this.backs[cmd].push({func: backFunction, thisObj: thisObj, id: WebSocket.id++});
        }

        p.once = function (cmd, backFunction, thisObj) {
            if (!this.backs[cmd]) {
                this.backs[cmd] = [];
            }
            this.backs[cmd].push({func: backFunction, thisObj: thisObj, once: true, id: WebSocket.id++});
        }

        p.registerZero = function (cmd, backFunction, thisObj) {
            if (!this.zbacks[cmd]) {
                this.zbacks[cmd] = [];
            }
            this.zbacks[cmd].push({func: backFunction, thisObj: thisObj, id: WebSocket.id++});
        }

        p.onceZero = function (cmd, backFunction, thisObj) {
            if (!this.zbacks[cmd]) {
                this.zbacks[cmd] = [];
            }
            this.zbacks[cmd].push({func: backFunction, thisObj: thisObj, once: true, id: WebSocket.id++});
        }

        p.remove = function (cmd, backFunction, thisObj) {
            if (!this.backs[cmd]) {
                return;
            }
            var list = this.backs[cmd];
            for (var i = 0; i < list.length; i++) {
                if (list[i].func == backFunction && list[i].thisObj == thisObj) {
                    list.splice(i, 1);
                    i--;
                }
            }
        }

        p.removeZero = function (cmd, backFunction, thisObj) {
            if (!this.zbacks[cmd]) {
                return;
            }
            var list = this.zbacks[cmd];
            for (var i = 0; i < list.length; i++) {
                if (list[i].func == backFunction && list[i].thisObj == thisObj) {
                    list.splice(i, 1);
                    i--;
                }
            }
        }

        /**
         * 通过查找 this 移除所有相关的监听
         * @param thisObj
         */
        p.removeByThis = function (thisObj) {
            var keys = Object.keys(this.backs);
            for (var i = 0; i < keys.length; i++) {
                var cmd = keys[i];
                var list = this.backs[cmd];
                for (var c = 0; c < list.length; c++) {
                    if (list[c].thisObj == thisObj) {
                        list.splice(c, 1);
                        c--;
                    }
                }
            }
            keys = Object.keys(this.zbacks);
            for (var i = 0; i < keys.length; i++) {
                var cmd = keys[i];
                var list = this.zbacks[cmd];
                for (var c = 0; c < list.length; c++) {
                    if (list[c].thisObj == thisObj) {
                        list.splice(c, 1);
                        c--;
                    }
                }
            }
        }

        p.send = function (bytes) {
            bytes.position = 0;
            //console.log("[Send Debug] len = " + bytes.length + ", cmd = " + bytes.readUIntV() + ", data =" + bytes.toString());
            if (this.socket) {
                var buffer = new Uint8Array(bytes.getData());
                this.socket.send(buffer);
            }
        }

        //收到服务器消息
        p.onReceiveMessage = function (event) {
            if (event.data instanceof ArrayBuffer) {
                var list = [];
                var data = new Uint8Array(event.data);
                for (var i = 0; i < data.length; i++) {
                    list.push(data[i]);
                }
                var bytes = new flower.VByteArray();
                bytes.readFromArray(list);
                var cmd = bytes.readUIntV();
                if (cmd == 0) {
                    var backCmd = bytes.readUIntV();
                    var errorCode = bytes.readUIntV();
                    trace("收到调试服务器消息",cmd,backCmd);
                    var list = this.zbacks[backCmd];
                    if (list) {
                        list = list.concat();
                        var removeList = [];
                        for (var i = 0; i < list.length; i++) {
                            var zitem = list[i];
                            if (zitem.func) {
                                zitem.func.apply(zitem.thisObj, [backCmd, errorCode]);
                            }
                            if (zitem.once) {
                                removeList.push(zitem.id);
                            }
                        }
                        list = this.zbacks[backCmd];
                        for (var i = 0; i < removeList.length; i++) {
                            for (var f = 0; f < list.length; f++) {
                                if (list[f].id == removeList[i]) {
                                    list.splice(f, 0);
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    var list = this.backs[cmd];
                    if (list) {
                        var pos = bytes.position;
                        list = list.concat();
                        var removeList = [];
                        for (var i = 0; i < list.length; i++) {
                            var zitem = list[i];
                            if (zitem.func) {
                                bytes.position = pos;
                                zitem.func.apply(zitem.thisObj, [cmd, bytes]);
                            }
                            if (zitem.once) {
                                removeList.push(zitem.id);
                            }
                        }
                        list = this.backs[backCmd];
                        for (var i = 0; i < removeList.length; i++) {
                            for (var f = 0; f < list.length; f++) {
                                if (list[f].id == removeList[i]) {
                                    list.splice(f, 0);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        /**
         * WebSocket 链接出错
         */
        p.onError = function (event) {
            //trace("链接服务器出错啦", event);
            this.close();
            this.dispatchEvent(new flower.Event(flower.Event.CONNECT_ERROR));
        }

        /**
         * WebSocket 关闭
         */
        p.onClose = function () {
            this.close();
            this.dispatchEvent(new flower.Event(flower.Event.DISCONNECT));
        }

        /**
         * 关闭当前链接
         */
        p.close = function () {
            if (this.socket) {
                this.url = null;
                this.socket.onopen = null;
                this.socket.onmessage = null;
                this.socket.onerror = null;
                this.socket.onclose = null;
                this.socket.close();
                this.socket = null;
            }
        }

        WebSocket.id = 0;

        return WebSocket;
    })(flower.EventDispatcher);

    flower.WebSocket = WebSocket;
})(flower || (flower = {}));
