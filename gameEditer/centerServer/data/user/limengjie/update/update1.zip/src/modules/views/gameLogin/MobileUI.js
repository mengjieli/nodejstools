/**
 * Created by Administrator on 2015/12/14.
 */


var MobileUI = cc.Node.extend( {

    _ui: null,
    _errorLabel:null,

    _input: null,
    _next:false,

    ctor: function()
    {
        this._super();
    },

    onEnter: function()
    {
        this._super();
        this._ui = ccs.load( "res/images/ui/login/mobile.json", "res/images/ui/" ).node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //下一步按钮
        var but = this._ui.getChildByName( "ui_mainban" ).getChildByName( "denglu" );
        but.addTouchEventListener( this.nextCall, this );
        but.setTitleText( ResMgr.inst().getString("login_13"));

        //手机号码输入框
        this._input = this._ui.getChildByName( "ui_mainban" ).getChildByName( "TextField_2" );
        this._input.addEventListener(this.inputCallback,this);
        this._input.setPlaceHolder( ResMgr.inst().getString("login_0") );
        //返回
        var reg = this._ui.getChildByName( "ui_mainban" ).getChildByName( "yongh_zhuce" );
        reg.addTouchEventListener( this.loginCall, this );
        reg.ignoreContentAdaptWithSize(true);
        reg.setString( ResMgr.inst().getString("login_11") );
        var reg_x = reg.getChildByName("Panel_3");
        var s = reg.getContentSize();
        s.height = 2;
        reg_x.setContentSize( s );

        var txt = this._ui.getChildByName("ui_mainban" ).getChildByName("Text_2_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("login_9") );

        var txt = this._ui.getChildByName("ui_mainban" ).getChildByName("Text_2_0_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("login_12") );
        txt.setVisible(false);
        this._errorLabel = txt;

    },

    onExit: function()
    {
        this._super();
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /**
     * 注册按钮回调
     * @param node
     * @param type
     */
    nextCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            //下一步,请求验证码
            this.nextStep();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    /**
     * 用户注册
     * @param node
     * @param type
     */
    loginCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            //登录
            ModuleMgr.inst().openModule("GameLoginModule" );
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    inputCallback: function (node, type) {
        switch (type){
            case ccui.TextField.EVENT_ATTACH_WITH_IME:
                this._errorLabel.setVisible(false);
                break;
            case  ccui.TextField.EVENT_DETACH_WITH_IME:
                //this.checkAccount();
                break;
        }
    },

    //验证账号是否存在
    //checkAccount: function () {
    //    var account = this._input.getString();
    //    if(0 == account.length || !CD.isPhoneNum(account))
    //    {
    //        this._errorLabel.setVisible(true);
    //        return;
    //    }
    //
    //    var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "check";
    //    var url = head;
    //    url += "?accountName=" + account;
    //
    //    NetMgr.inst().sendHttp(url, null, false, function(data, param){
    //            cc.log("checkAccount data:" + data);
    //            var ret = JSON.parse(data);
    //            if(ret)
    //            {
    //                if(0 == ret.errCode)
    //                {
    //                    //用户名不存在
    //                    param.owner._errorLabel.setVisible(true);
    //                }
    //                else
    //                {
    //                    param.owner._errorLabel.setVisible(false);
    //                    param.owner._next = true;
    //                }
    //            }
    //        }, null, {"objs":null, "onAccountStatus":null, "owner":this}
    //    );
    //},

    nextStep: function () {
        var account = this._input.getString();//手机号
        if(0 == account.length)// || !this._next  || !CD.isPhoneNum(account)
        {
            this._errorLabel.setVisible(true);
            return;
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "regain";
        var url = head;
        url += "?loginName=" + encodeString(account);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
                cc.log("nextStep 接收:" + data);
                var ret = JSON.parse(data);
                if(ret)
                {
                    switch(ret.err_code)
                    {
                        case 80111://发送短信过快，请稍后重试
                            var value = ResMgr.inst().getString("denglu_40");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                            break;
                        case 0:
                            cc.error("短信有效时间:" + ret.verificationCodeExpiryDuration);
                            ModuleMgr.inst().openModule("GameLoginModule",{"ui":"verify","ip":account,"cd":ret.verificationCodeCoolDown});
                            break;
                        default:
                            var value = ResMgr.inst().getString(ret.err_code);
                            ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                            break;
                    }
                }
            }, null, {"objs":null, "changeMode":null, "errorTip":null, "owner":this}
        );
    }


});