var flower;
(function (flower) {
    var ParserItem = (function () {
        function ParserItem() {
        }
        return ParserItem;
    })();
    flower.ParserItem = ParserItem;
})(flower || (flower = {}));
//# sourceMappingURL=ParserItem.js.map