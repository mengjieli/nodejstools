var ValidTextModel = (function (_super) {
    __extends(ValidTextModel, _super);

    function ValidTextModel() {
        _super.call(this, "ValidText");
        this.views = [];
        this.configs = {};
    }

    var d = __define, c = ValidTextModel;
    p = c.prototype;

    p.load = function () {
        var loader = new flower.URLLoader();
        loader.load("res/configs/table/txts/bannedWords.txt");
        loader.addEventListener(flower.Event.COMPLETE, this.loadConfigComplete, this);
    }

    p.loadConfigComplete = function (event) {
        event.currentTarget.removeEventListener(flower.Event.COMPLETE, this.loadConfigComplete, this);
        var str = event.currentTarget.data;
        this.list = JSON.parse(str);
        this.replace = [];
        for (var i = 0; i < this.list.length; i++) {
            var word = this.list[i];
            var replace = "";
            for (var a = 0; a < word.length; a++) {
                replace += "*";
            }
            this.replace[i] = replace;
        }
        this.dispatchEvent(new flower.Event(flower.Event.COMPLETE));
    }

    /**
     * 替换非法字符为 * 号
     * @param text
     */
    p.replaceText = function (text) {
        for (var i = 0; i < this.list.length; i++) {
            text = text.replace(this.list[i], this.replace[i]);
        }
        return text;
    }

    return ValidTextModel;
})(ModelBase);