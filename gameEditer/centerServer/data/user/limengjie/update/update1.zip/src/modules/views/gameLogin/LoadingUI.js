/**
 * Created by Administrator on 2015/12/14.
 */

var LoadingUI = cc.Node.extend({
    _ui: null,
    _login: null,
    _loadingBar: null,
    ctor: function (data) {
        this._super();

        this._login = data.login;
    },
    onEnter: function () {
        this._super();

        var backImg = new ccui.ImageView();
        backImg.setAnchorPoint(0.5, 0.5);
        backImg.loadTexture("login/dutiao_beijing.png", ccui.Widget.PLIST_TEXTURE);
        var pos = cc.p(0, 0);
        backImg.setScale(1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(true));
        pos.x = GameMgr.inst().viewSize.width >> 1;
        pos.y = GameMgr.inst().viewSize.height >> 1;
        backImg.setPosition(pos);
        this.addChild(backImg);

        this._ui = ccs.load("res/images/ui/login/loading.json", "res/images/ui/").node;
        this.addChild(this._ui);

        //var uiPanel = this._ui.getChildByName( "ui_mainban" );
        //uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize(size);
        ccui.helper.doLayout(this._ui);

        //关闭自己
        this._loadingBar = this._ui.getChildByName("Panel_1").getChildByName("LoadingBar_1");

        var bg = this._ui.getChildByName("Panel_1").getChildByName("Image_1");

        var tips = this._ui.getChildByName("Panel_1").getChildByName("Text_1");
        //tips.setVisible(false);
        tips.ignoreContentAdaptWithSize(true);
        tips.setString("100%");

        //设置进度条数据
        //EventMgr.inst().addEventListener("set_loading_loadingBar", this.loadingBarCall, this );
        //this.scheduleUpdate();
        if (this._login) {
            NetMgr.inst().addEventListener(0, this.netGetError, this);
        }
        else {
            NetMgr.inst().addEventListener(0, this.netGetErrorEX, this);
        }

        var data = GameSDK.DataManager.getInstance().loadingData.model;
        data.addListener("progress",this.onModelProgress,this);



        if(GameSDK.DataManager.getInstance().startGameData.step == 6) {
            //正在加载中 99/100
            this._loadingBar.setPercent(99);
            tips.setString(ResMgr.inst().getString("tips_4")+" 99%");

            bg.setVisible(true);
            var _tips = this._ui.getChildByName("Panel_1").getChildByName("Text_1_0");
            _tips.setVisible(true);
            _tips.ignoreContentAdaptWithSize(true);
            _tips.runAction(cc.RepeatForever(cc.Sequence(cc.CallFunc(function (sender) {
                var index = Math.floor(Math.random()*10)%LoadingUI.TIPS.length;
                var str = LoadingUI.TIPS[index];
                sender.setString(ResMgr.inst().getString(str));
            }),cc.DelayTime(3))));

        }
    },
    onExit: function () {
        //EventMgr.inst().removeEventListener("set_loading_loadingBar", this.loadingBarCall, this );
        //this.unscheduleUpdate();
        this._super();
        if (this._login) {
            NetMgr.inst().removeEventListener(0, this.netGetError, this);
        }
        else {
            NetMgr.inst().removeEventListener(0, this.netGetErrorEX, this);
        }
    },
    onModelProgress:function() {
        /*if(this._loadingBar) {
            this._loadingBar.setPercent(100*GameSDK.DataManager.getInstance().loadingData.model.progress/GameSDK.DataManager.getInstance().loadingData.model.max);
        }*/
    },
    update: function (dt) {
        cc.log("@update ", startGameData.updatePercent);
        this._loadingBar.setPercent(startGameData.updatePercent);
    },
    loadingBarCall: function (e, value) {
        this._loadingBar.setPercent(value);
    },
    netGetError: function (cmd, data) {
        if (cmd == 0) {
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            cc.log("@netGetError", data0, data1, data2);
            if (data0 == 200 && data1 == 0) {
                startGameData.step = 6;
            }
        }
    },
    netGetErrorEX: function (cmd, data) {
        if (cmd == 0) {
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            if (data0 == 200 && data1 == 0) {
                //设置昵称
                ModuleMgr.inst().openModule("Presetting", {
                    "data": null,
                    "openSound": true,
                    "loginAccount": null,
                    "loginToken": null
                });
            }
            if (data0 == 202 && data1 == 0) {
                ModuleMgr.inst().closeModule("Presetting", {"closeSound": false});
                startGameData.step = 6;
            }
        }
    }
});

LoadingUI.TIPS = ["tips_1","tips_2","tips_3"];
