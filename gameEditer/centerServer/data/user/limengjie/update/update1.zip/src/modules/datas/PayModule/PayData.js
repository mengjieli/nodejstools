/**
 * Created by cgMu on 2015/11/10.
 */

var PayData = DataBase.extend({
    _data:null,

    ctor:function() {
        this._data = {};
        this._data[1]=[];//充值钻石
        this._data[2]=[];//钻石换金币
        this._data[3]=[{"recharge_id":0,"icon":2810001,"price_id":3,"price_type":2,"trading_id":2810001,"type":4}];//钻石换礼包
        this._data[4]=[];//黄金换金币
        this._data[5]=[{"recharge_id":0,"icon":2811001,"price_id":5,"price_type":2,"trading_id":2811001,"type":4}];//黄金换礼包

        var paydata = modelMgr.call("Table","getTableList",["Pay"]);
        for(var key in paydata) {
            switch (parseInt(paydata[key].price_id)) {
                case 1:
                    this._data[1].push(paydata[key]);
                    break;
                case 2:
                    this._data[2].push(paydata[key]);
                    break;
                case 3:
                    this._data[3].push(paydata[key]);
                    break;
                case 4:
                    this._data[4].push(paydata[key]);
                    break;
                case 5:
                    this._data[5].push(paydata[key]);
                    break;
                default :
                    this._data[5].push(paydata[key]);
                    break;
            }
        }

    },

    init:function()
    {
        return true;
    },

    destroy:function() {

    }
});