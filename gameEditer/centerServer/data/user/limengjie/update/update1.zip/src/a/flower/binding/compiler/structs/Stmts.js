var flower;
(function (flower) {
    var Stmts = (function () {
        function Stmts() {
            this.type = "stmts";
            this.list = [];
        }
        Stmts.prototype.addStmt = function (stmt) {
            this.list.push(stmt);
        };
        Stmts.prototype.execute = function () {
        };
        Stmts.prototype.checkPropertyBinding = function (checks, commonInfo) {
            if (checks == null) {
                return;
            }
            for (var i = 0; i < this.list.length; i++) {
                this.list[i].checkPropertyBinding(checks, commonInfo);
            }
        };
        return Stmts;
    })();
    flower.Stmts = Stmts;
})(flower || (flower = {}));
//# sourceMappingURL=Stmts.js.map