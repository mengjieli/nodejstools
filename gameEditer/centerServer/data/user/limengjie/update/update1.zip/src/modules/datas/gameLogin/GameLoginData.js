/**
 * Created by cgMu on 2015/12/17.
 */

var GameLoginData = DataBase.extend({
    ctor : function()
    {
        this._super();
    },

    init : function()
    {
        this._super();
    },

    destroy : function()
    {
        this._super();
    },

    //本地存储账号信息
    recordUserInfo : function(info)
    {
        cc.error("info:" + JSON.stringify(info));
        var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
        var file = jsb.fileUtils.writeToFile({"lastLoginName":info[0], "lastLoginPassword":info[1], "lastLoginToken":info[2]}, storagePath + "cache");
    },

    //验证账号是否激活
    isActivateAccount: function () {
        return true;
    }
});