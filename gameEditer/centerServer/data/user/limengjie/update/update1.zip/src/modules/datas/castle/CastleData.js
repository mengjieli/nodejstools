/**
 * Created by Administrator on 2015/10/27/0027.
 */

//模块间事件
CastleEvent = {};
CastleEvent.MOVETO_BUILDING = "castle_moveto_building";//收到视角锁定到建筑事件
CastleEvent.MOVETO_POS = "castle_moveto_pos";//收到视角锁定到坐标
CastleEvent.BUILD_SUCCESS = "castle_build_success";//模块间收到 建造事件  发包
CastleEvent.CANCEL_SUCCESS = "castle_cancel_success";//模块间收到 取消当前状态事件 发包
CastleEvent.UPGRADE_SUCCESS = "castle_upgrade_success";//模块间收到 升级建筑事件 发包
CastleEvent.REMOVE_SUCCESS = "castle_remove_success";//模块间收到 拆除建筑事件 发包
CastleEvent.SPEED_SUCCESS = "castle_speed_success";//模块间收到 花钱立即完成当前状态事件 发包
CastleEvent.BLOCK_SUCCESS = "castle_block_success";//模块间收到 请求单个地块建筑信息事件 发包

CastleEvent.TECH_UPGRADE_SUCCESS = "castle_tech_upgrade_success";//模块间收到 科技升级事件 发包
CastleEvent.TECH_CANCEL_SUCCESS = "castle_tech_cancel_success";//模块间收到 取消科技当前状态事件 发包
CastleEvent.TECH_SPEED_SUCCESS = "castle_tech_speed_success";//模块间收到 立即完成科技升级事件 发包
CastleEvent.TECH_SUCCESS = "castle_tech_success";//模块间收到 获取科技信息 事件 发包
//广播事件 便于其他模块接受消息处理
CastleEvent.MOVE_SCREEN = "castle_move_screen";//广播间屏幕移动事件
CastleEvent.UPDATE_BLOCK_TIME = "castle_update_block_time";//广播更新地块建筑状态 倒计时
CastleEvent.UPDATE_ARMYTRAIN_TIME = "castle_update_armytrain_time";//广播更新兵营训练 倒计时
CastleEvent.REMOVE_ARMYTRAIN = "castle_update_armytrain_time";//广播移除训练特效
CastleEvent.UPDATE_TECH_TIME = "castle_update_tech_time";//广播更新科技状态 倒计时
CastleEvent.UPDATE_TECH = "castle_update_tech";//广播更新科技信息
CastleEvent.UPDATE_RESOURCE = "castle_update_resource";//广播更新资源信息
CastleEvent.UPDATE_BUILDING = "castle_update_building";//广播更新地块建筑信息
CastleEvent.NET_COMPLETE = "castle_net_complete";//广播 通讯请求成功返回
CastleEvent.UPGRADE_COMPLETE = "castle_upgrade_complete";//广播 建筑升级成功
CastleEvent.TECH_UPGRADE_COMPLETE = "castle_tech_upgrade_complete";//广播 科技升级成功
CastleEvent.USE_ITEM_SPEED = "castle_use_item_speed"; //加速消息
//建造部队
CastleEvent.BUILD_ARMY = "castle_build_army";
CastleEvent.GET_BUILD_ARMY = "castle_get_build_army";//收取部队事件
CastleEvent.UNLOCK_ARMY = "castle_unlock_army";
//CastleEvent.DISSOLVE_ARMY = "castle_dissolve_army";
CastleEvent.SPEED_ARMY = "castle_speed_army";
CastleEvent.CANCEL_ARMY = "castle_cancel_army";
CastleEvent.CREATE_ARMY = "castle_create_army";

CastleEvent.SHOW_BUILDING_DEQUE = "SHOW_BUILDING_DEQUE"; //显示建筑队列图标

//通讯部分
CastleNetEvent = {};

CastleNetEvent.ERROR = 0;//错误信息

CastleNetEvent.SEND_CASTLE = 400;//获得城堡信息

CastleNetEvent.SEND_BUILD = 401;//建造建筑
CastleNetEvent.SEND_CANCEL = 402;//取消建造/升级/拆除任务
CastleNetEvent.SEND_UPGRADE = 403;//升级建筑
CastleNetEvent.SEND_REMOVE = 404;//拆除建筑

CastleNetEvent.SEND_SPEED = 405;//405 花钱立即完成建造/升级/拆除任务
CastleNetEvent.SEND_BLOCK = 406;//获得单个地块信息

CastleNetEvent.SEND_TECH_UPGRADE = 407;//升级科技
CastleNetEvent.SEND_TECH_CANCEL = 408;//取消升级科技
CastleNetEvent.SEND_TECH_SPEED = 409;//花钱立即完成科技升级
CastleNetEvent.SEND_TECH = 410;//获得城堡单个科技信息

CastleNetEvent.SEND_USE_ITEM_SPEED_BLOCK = 415;//建筑加速
CastleNetEvent.SEND_USE_ITEM_SPEED_TECH = 416;//科技加速
CastleNetEvent.SEND_USE_ITEM_SPEED_ARMY = 421;//部队建造加速

CastleNetEvent.SEND_BUILD_ARMY = 418;
CastleNetEvent.SEND_CANCEL_ARMY = 419;//取消建造部队
CastleNetEvent.SEND_GETBUILD_ARMY = 420;//收取 建造完成的部队
CastleNetEvent.SEND_UNLOCK_ARMY = 422;
CastleNetEvent.SEND_CREATE_ARMY = 423;//创建军团
CastleNetEvent.SEND_ARMY_SPEED = 424;//花钱立即完成部队建造

CastleNetEvent.GET_ARMY_TRAIN = 495; //城堡兵营训练信息
CastleNetEvent.GET_ARMY = 496; //城堡部队集结信息
CastleNetEvent.GET_TECH = 497;//城堡科技信息
CastleNetEvent.GET_RESOURCE = 498;//城堡资源信息
CastleNetEvent.GET_BUILDING = 499;//每个城堡地基建筑信息


var CastleData = DataBase.extend({

    _arrBlockBean: null,//csv地块数组
    _arrBuildingxyBean: null,//csv建筑偏移数组

    _castleTimer: null,//计时器 处理各种倒计时

    _movePos: null, //保存移动屏幕坐标

    //通讯数据
    _arrNetTech: null,//科技数据
    _arrNetResource: null,//资源数据
    _arrNetBlock: null,//地块建筑数据
    _arrCastleId: null,//城堡id数组
    _currentCastleId: null,//城堡id

    _clickPos:null,//记录屏幕点击位置 用于其他模块调用
    _scaleValue:1,//缩放值
    ctor: function () {
        //测试数组排序工具
        var arr=[1,5,4,2,3];
        var arrObj=[];
        for(var i=0;i<arr.length;i++){
            var obj={};
            obj.num=arr[i];
            arrObj.push(obj);
        }
        Tools.sortArray(arrObj,"num",true);
        cc.log(arrObj[0].num+"n"+arrObj[1].num+"n"+arrObj[3].num+"n");


    },
    //初始化
    init: function () {
        cc.log("城堡id   CastleData初始化城堡data  init ",mainData.uiData.currentCastleId);//LoadingModule.CASTLE_ID
        //this._currentCastleId="150B80EB-B720-0009-DEB9-FF9AAE0DB2CC";
        //this._currentCastleId=LoadingModule.CASTLE_ID;
        //this._arrCastleId=[this._currentCastleId];
        if (mainData.uiData.currentCastleId != "") {
            this._currentCastleId = mainData.uiData.currentCastleId;
            this._arrCastleId = [];
            for (var i = 0; i < mainData.mapData.castleList.length; i++) {
                this._arrCastleId.push(mainData.mapData.castleList.getItemAt(i).id);
            }
        } else {
            cc.log("mainData.uiData.currentCastleId 不存在");
            return;
        }

        //var csvblock = ResMgr.inst().getCSV("castle_block");
        var csvblock = modelMgr.call("Table","getTableList",["castle_block"]);
        if (this._arrBlockBean == null) this._arrBlockBean = {};

        if (this._arrNetTech == null) this._arrNetTech = {};
        if (this._arrNetResource == null) this._arrNetResource = {};
        if (this._arrNetBlock == null) this._arrNetBlock = {};

        for (var i = 0; i < this._arrCastleId.length; i++) {
            cc.log("各城堡id" + this._arrCastleId[i]);
            this._arrNetTech[this._arrCastleId[i]] = {};
            this._arrNetResource[this._arrCastleId[i]] = {};
            this._arrNetBlock[this._arrCastleId[i]] = {};
        }

        for (var key in csvblock) {
            //cc.log(key+"####key"+(key==2));  暂时只开放城内20索引以前的
            if (key < 19) {
                var blockbean = new CastleBlockBeanCSV(csvblock[key]);
                //cc.log(blockbean._index+"####"+key);
                this._arrBlockBean[blockbean._index] = blockbean;
                //初始化空地块
                for (var j = 0; j < this._arrCastleId.length; j++) {
                    this.getNetBlock(this._arrCastleId[j])[blockbean._index] = new CastleBlockBeanNet([this._arrCastleId[j], blockbean._index, 0, 0, 0, 0, 0, 0, 0]);//blockbean._building_id[0]
                }
                //this.getNetBlock(null)[blockbean._index]=new CastleBlockBeanNet([this._currentCastleId,blockbean._index,0,0,0,0,0,0,0]);//blockbean._building_id[0]
            }
        }
        //cc.log("this._arrBlockBean.length@@"+this._arrBlockBean.length);
        //var csvbuildingxy = ResMgr.inst().getCSV("castle_buildingxy");
        var csvbuildingxy = modelMgr.call("Table","getTableList",["castle_buildingxy"]);
        if (this._arrBuildingxyBean == null) this._arrBuildingxyBean = {};
        for (var key in csvbuildingxy) {
            var buildingxybean = new CastleBuildingxyBeanCSV(csvbuildingxy[key]);
            this._arrBuildingxyBean[buildingxybean._id] = buildingxybean;
        }

        //--------------------------------------  监听
        mainData.uiData.addListener("currentCastleId", this.updataCastleCount, this);
        mainData.mapData.castleList.addListener("length", this.updataCastleCount, this);
        //城堡建筑
        EventMgr.inst().addEventListener(CastleEvent.BUILD_SUCCESS, this.onSendBuild, this);
        EventMgr.inst().addEventListener(CastleEvent.CANCEL_SUCCESS, this.onSendCancel, this);
        EventMgr.inst().addEventListener(CastleEvent.UPGRADE_SUCCESS, this.onSendUpgrade, this);
        EventMgr.inst().addEventListener(CastleEvent.REMOVE_SUCCESS, this.onSendRemove, this);
        EventMgr.inst().addEventListener(CastleEvent.SPEED_SUCCESS, this.onSendSpeed, this);
        EventMgr.inst().addEventListener(CastleEvent.BLOCK_SUCCESS, this.onSendBlock, this);
        //城堡科技
        EventMgr.inst().addEventListener(CastleEvent.TECH_UPGRADE_SUCCESS, this.onSendTechUpgrade, this);
        EventMgr.inst().addEventListener(CastleEvent.TECH_CANCEL_SUCCESS, this.onSendTechCancel, this);
        EventMgr.inst().addEventListener(CastleEvent.TECH_SPEED_SUCCESS, this.onSendTechSpeed, this);
        EventMgr.inst().addEventListener(CastleEvent.TECH_SUCCESS, this.onSendTech, this);
        //建造部队
        EventMgr.inst().addEventListener(CastleEvent.BUILD_ARMY, this.onSendArmyBuild, this);
        EventMgr.inst().addEventListener(CastleEvent.GET_BUILD_ARMY, this.onSendGetArmyBuild, this);
        EventMgr.inst().addEventListener(CastleEvent.UNLOCK_ARMY, this.onSendArmyUnlock, this);
        //EventMgr.inst().addEventListener(CastleEvent.DISSOLVE_ARMY, this.onSendArmyDissolve, this);
        EventMgr.inst().addEventListener(CastleEvent.SPEED_ARMY, this.onSendArmySpeed, this);
        EventMgr.inst().addEventListener(CastleEvent.CANCEL_ARMY, this.onSendCancelArmy, this);
        EventMgr.inst().addEventListener(CastleEvent.CREATE_ARMY, this.onSendCreateArmy, this);

        EventMgr.inst().addEventListener(CastleEvent.USE_ITEM_SPEED, this.onSendUseItemCall, this);

        //通讯监听
        NetMgr.inst().addEventListener(CastleNetEvent.ERROR, this.netGetError, this);

        //if(this.isTest){
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,15,1907001,1,0,0,0,0,0]);
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,16,1901001,1,0,0,0,0,0]);
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,17,1909001,1,0,0,0,0,0]);
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,18,1913001,1,0,0,0,0,0]);
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,19,1913002,1,0,0,0,0,0]);
        //
        //    NetMgr.inst().dispatchEvent(CastleNetEvent.GET_BUILDING,[this._currentCastleId,3,1902001,1,0,0,0,0,0]);
        //}

        return true;
    },
    //事件
    updataCastleCount: function (type) {
        cc.log(mainData.uiData.currentCastleId+"更新城堡数量updataCastleCount$$$"+type);
        if (mainData.uiData.currentCastleId != "") {
            this._currentCastleId = mainData.uiData.currentCastleId;
            this._arrCastleId = [];
            for (var i = 0; i < mainData.mapData.castleList.length; i++) {
                this._arrCastleId.push(mainData.mapData.castleList.getItemAt(i).id);
            }
            //重置初始数据  解决新建城堡BUG
            var csvblock = modelMgr.call("Table","getTableList",["castle_block"]);
            var newIndex=-1;
            for (var i = 0; i < this._arrCastleId.length; i++) {
                if(!this._arrNetTech[this._arrCastleId[i]]){
                    this._arrNetTech[this._arrCastleId[i]] = {};
                    newIndex=i;
                }
                if(!this._arrNetResource[this._arrCastleId[i]]){
                    this._arrNetResource[this._arrCastleId[i]] = {};
                    newIndex=i;
                }
                if(!this._arrNetBlock[this._arrCastleId[i]]){
                    this._arrNetBlock[this._arrCastleId[i]] = {};
                    newIndex=i;
                }
            }
            for (var key in csvblock) {
                if (key < 19) {
                    var blockbean = new CastleBlockBeanCSV(csvblock[key]);
                    this._arrBlockBean[blockbean._index] = blockbean;
                    //初始化空地块
                    //for (var j = 0; j < this._arrCastleId.length; j++) {
                        this.getNetBlock(this._arrCastleId[newIndex])[blockbean._index] = new CastleBlockBeanNet([this._arrCastleId[newIndex], blockbean._index, 0, 0, 0, 0, 0, 0, 0]);
                    //}
                }
            }
        } else {
            cc.log("mainData.uiData.currentCastleId 不存在");
        }
    },
    judgeMovePos:function(pos){
        var w=180;
        var h=115;
        var offx=0;
        var offy=0;
        var bool=false;
        var size = cc.director.getVisibleSize();
        if(pos.x<w) {
            offx=pos.x-w;
            pos.x=w;
            bool=true;
        }
        if(pos.x>size.width-w) {
            offx=pos.x-(size.width-w);
            pos.x=size.width-w;
            bool=true;
        }
        if(pos.y<h) {
            offy=pos.y-h;
            pos.y=h;
            bool=true;
        }
        if(pos.y>size.height-h) {
            offy=pos.y-(size.height-h);
            pos.x=size.height-h;
            bool=true;
        }
        this._movePos=pos;
        //return;
        if(bool) EventMgr.inst().dispatchEvent(CastleEvent.MOVETO_POS,offx,offy);
    },
    //通讯部分-----------------------------
    //------------------发送-------
    //建造请求
    onSendBuild: function (type, index, buildingId, castleId) {
        //cc.log(index+"###index城堡发送建造请求信息id###"+buildingId);
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_BUILD);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        msg.writeUint(buildingId);
        NetMgr.inst().send(msg);
    },

    onSendCancel: function (type, index, castleId) {
        //cc.log(index+"###index城堡发送取消状态信息id###");
        if(this.getNetBlock(castleId)[index]){
            //cc.log("_state 取消状态"+this.getNetBlock(castleId)[index]._state);
            if(this.getNetBlock(castleId)[index]._state==CastleData.STATE_UPGRADE){
                var value = ResMgr.inst().getString("castle_3");
                ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "okFun":function(){
                    var msg = new SocketBytes();
                    msg.writeUint(CastleNetEvent.SEND_CANCEL);
                    msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
                    msg.writeUint(index);
                    NetMgr.inst().send(msg);
                }, "owner":this});
            }
        }
    },

    onSendCancelArmy: function (type, index, castleId) {
        if(this.getArmyTrainState(index)){
            var value = ResMgr.inst().getString("castle_5");
            ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "okFun":function(){
                var msg = new SocketBytes();
                msg.writeUint(CastleNetEvent.SEND_CANCEL_ARMY);
                msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
                msg.writeUint(index);
                NetMgr.inst().send(msg);
            }, "owner":this});
        }
    },

    onSendUpgrade: function (type, index, array, castleId) {
        //cc.log(index+"###index城堡发送升级请求信息id###");
        //cc.log("测试发送升级##########################################################################################################");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_UPGRADE);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);

        //添加代币
        msg.writeUint(array.length);
        for(var i = 0; i < array.length; i++){
            msg.writeUint(array[i].itemId);
            msg.writeUint(array[i].counts);
            cc.log("@ ",array.length,array[i].itemId,array[i].counts);
        }

        NetMgr.inst().send(msg);
    },

    onSendRemove: function (type, index, castleId) {
        //cc.log(index+"###index城堡发送拆除请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_REMOVE);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        NetMgr.inst().send(msg);
    },

    onSendSpeed: function (type, index, castleId) {
        //cc.log(index+"###index城堡发送加速状态请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_SPEED);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        NetMgr.inst().send(msg);
    },

    onSendBlock: function (type, index, castleId) {
        //cc.log(index+"###index城堡发送单个地块请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_BLOCK);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        NetMgr.inst().send(msg);
    },

    onSendTechUpgrade: function (type, techId,array, castleId) {
        //cc.log(techId+"###techid科技升级请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_TECH_UPGRADE);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(techId);
        //添加代币
        msg.writeUint(array.length);
        for(var i = 0; i < array.length; i++){
            msg.writeUint(array[i].itemId);
            msg.writeUint(array[i].counts);
            cc.log("@ ",array.length,array[i].itemId,array[i].counts);
        }
        NetMgr.inst().send(msg);
    },
    onSendTechCancel: function (type, techId, castleId) {
        //cc.log(techId+"###techid取消科技状态请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_TECH_CANCEL);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(techId);
        NetMgr.inst().send(msg);
    },
    onSendTechSpeed: function (type, techId, castleId) {
        //cc.log(techId+"###techid科技加速 立即完成请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_TECH_SPEED);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(techId);
        NetMgr.inst().send(msg);
    },
    onSendTech: function (type, techId, castleId) {
        //cc.log(techId+"###techid科技信息 请求信息id###");
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_TECH);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(techId);
        NetMgr.inst().send(msg);
    },

    //建造部队
    onSendArmyBuild: function (type,index,armyid,count,array,castleId) {
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_BUILD_ARMY);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        msg.writeUint(armyid);
        msg.writeUint(count);
        //添加代币
        msg.writeUint(array.length);
        for(var i = 0; i < array.length; i++){
            msg.writeUint(array[i].itemId);
            msg.writeUint(array[i].counts);
            cc.log("@ ",array.length,array[i].itemId,array[i].counts);
        }
        NetMgr.inst().send(msg);
        cc.log("@onSendArmyBuild",castleId == undefined ? this._currentCastleId : castleId,index,armyid,count);
    },
    //收取建造完成的部队
    onSendGetArmyBuild: function (type,index,castleId) {
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_GETBUILD_ARMY);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(index);
        NetMgr.inst().send(msg);
        //cc.log("@onSendArmyBuild",castleId == undefined ? this._currentCastleId : castleId,index,armyid,count);
    },
    //解锁部队
    onSendArmyUnlock: function (type, armyid, castleId) {
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_UNLOCK_ARMY);
        msg.writeString(castleId == undefined ? this._currentCastleId : castleId);
        msg.writeUint(armyid);
        NetMgr.inst().send(msg);
    },

    //onSendArmyDissolve: function (type, armid, count, castleId) {
    //    var msg = new SocketBytes();
    //    msg.writeUint(CastleNetEvent.SEND_DISSOLVE_ARMY);//部队解散
    //    msg.writeString((castleId == undefined ? this._currentCastleId : castleId));
    //    msg.writeUint(armyid);
    //    msg.writeUint(count);
    //    NetMgr.inst().send(msg);
    //},

    onSendArmySpeed: function (type, index, castleId) {
    var msg = new SocketBytes();
    msg.writeUint(CastleNetEvent.SEND_ARMY_SPEED);//部队出城
    msg.writeString((castleId == undefined ? this._currentCastleId : castleId));
    msg.writeUint(index);
    NetMgr.inst().send(msg);
},

    onSendCreateArmy: function (type, armyid, count, castleId) {
        var msg = new SocketBytes();
        msg.writeUint(CastleNetEvent.SEND_CREATE_ARMY);
        msg.writeString((castleId == undefined ? this._currentCastleId : castleId));
        msg.writeUint(armyid);
        msg.writeUint(count);
        NetMgr.inst().send(msg);
    },

    onSendUseItemCall: function (event, type, id, itemId, num) {
        //AccelerateModuleType.common = 1; 通用加速
        //AccelerateModuleType.drill = 2; //训练加速
        //AccelerateModuleType.build = 3; //建造加速
        //AccelerateModuleType.college = 4; //学院加速
        if (type == 1) {

        }
        else if (type == 2) {
            var msg = new SocketBytes();
            msg.writeUint(CastleNetEvent.SEND_USE_ITEM_SPEED_ARMY);
            msg.writeString(this._currentCastleId);
            msg.writeUint(id);
            msg.writeUint(itemId);
            msg.writeUint(num);
            NetMgr.inst().send(msg);
        }
        else if (type == 3) {
            var msg = new SocketBytes();
            msg.writeUint(CastleNetEvent.SEND_USE_ITEM_SPEED_BLOCK);
            msg.writeString(this._currentCastleId);
            msg.writeUint(id);
            msg.writeUint(itemId);
            msg.writeUint(num);
            NetMgr.inst().send(msg);
        }
        else if (type == 4) {
            var msg = new SocketBytes();
            msg.writeUint(CastleNetEvent.SEND_USE_ITEM_SPEED_TECH);
            msg.writeString(this._currentCastleId);
            msg.writeUint(id);
            msg.writeUint(itemId);
            msg.writeUint(num);
            NetMgr.inst().send(msg);
        }
        cc.log("使用道具" + itemId + ":" + num);
    },
    //=========================收到通讯处理数据=========================
    isTest: false,//是否是测试数据

    //错误信息
    netGetError: function (cmd, data) {
        if (CastleNetEvent.ERROR == cmd) {
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();

            if (data1 != 0 && data0 != 0 && data0 != 305) {
                var content = ResMgr.inst().getString(data1 + "");
                if(content == null || content == "") {
                    content = ResMgr.inst().getString("errorTip") + ":" + data1;
                }
                cc.log("收到错误信息  对应协议号" + data0 + "@@@错误信息@@@" + content + "@@@处理id@@@" + data2);
                ModuleMgr.inst().openModule("AlertString", {
                    str: content,
                    color: null,
                    time: null,
                    pos: null
                });

            }
            if (data0 != 0 && data1 == 0) {
                //cc.log("请求成功 返回消息 协议号" + data0);
                EventMgr.inst().dispatchEvent(CastleEvent.NET_COMPLETE, data0);
                if (data0 == CastleNetEvent.SEND_UPGRADE) {
                    SoundPlay.playEffect(ResMgr.inst().getSoundPath(7));
                }
                else if (data0 == CastleNetEvent.SEND_REMOVE) {
                    SoundPlay.playEffect(ResMgr.inst().getSoundPath(23));
                }
            }

        }
    },
    //获取兵营训练
    netGetArmyTrain:function(cmd,data){
        if (CastleNetEvent.GET_ARMY_TRAIN == cmd) {
            //cc.log("GET_ARMY_TRAIN  GET_ARMY_TRAIN  GET_ARMY_TRAIN");
            //data.resetCMDData();
            //var arrData = [data.readString(), data.readUint(), data.readUint(), data.readUint(), data.readUint(), data.readUint()];
            //this.updateNetArmyTrain(data);
            //EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_ARMYTRAIN_TIME, arrData);
            cc.log(data.blockId+"blockid  armyid"+data.armyId+"updateNetArmyTrain^^^^^^^^^^^^^^^^^updateNetArmyTrain"+data.remainTime);
            if (data.remainTime > 0 &&data.armyId!=0) {//无计时器的时候初始化  && techNet._state != CastleData.STATE_NORMAL
                if (this._castleTimer == null) this._castleTimer = new IntervalCall(this.timeUpdate, this, 1);
                EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_ARMYTRAIN_TIME, data );//this.getNetArmyTrain(data.castleId,data.blockId)
            }
            if(data.armyId==0){
                EventMgr.inst().dispatchEvent(CastleEvent.REMOVE_ARMYTRAIN, data.blockId );
            }
        }
    },
    //获取科技信息
    netGetTech: function (cmd, data) {
        if (CastleNetEvent.GET_TECH == cmd) {
            data.resetCMDData();
            var arrData = [data.readString(), data.readUint(), data.readUint(), data.readUint(), data.readUint(), data.readUint(), data.readUint(), data.readUint()];
            //cc.log(arrData[1]+"####arrData[1]@@@@@"+arrData[2]+"dispatchEvent( CastleEvent.UPDATE_BUILDIN"+arrData[3],"remain time",arrData[7]);
            this.updateNetTech(arrData);
            EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_TECH, arrData);
        }
    },

    //更新科技信息
    updateNetTech: function (data) {
        var techNet = new CastleTechBeanNet(data);
        //cc.log(this.getNetTech(null)+"this.getNetTech"+this.getNetTech(null)[techNet._tech_id]);

        //完成科技升级，用于科技从0级升到1级，菜单cd时间0
        if(techNet._state != CastleData.STATE_NORMAL && techNet._state_remain == 0){
            //cc.log("完成科技升级，用于科技从0级升到1级，菜单cd时间0");
            this.onSendTech(null, techNet._tech_id);//更新数据
            EventMgr.inst().dispatchEvent(CastleEvent.TECH_UPGRADE_COMPLETE, techNet);//抛消息
        }

        if (this.getNetTech(null)[techNet._tech_id] != null && this.getNetTech(null)[techNet._tech_id] != undefined && this.getNetTech(null)[techNet._tech_id]._tech_level < techNet._tech_level) {
            EventMgr.inst().dispatchEvent(CastleEvent.TECH_UPGRADE_COMPLETE, techNet);//抛消息
        }
        this.getNetTech(null)[techNet._tech_id] = techNet;
        //cc.log(techNet+"techNet"+techNet._state);
        if (techNet._state_remain > 0 && techNet._state != CastleData.STATE_NORMAL) {//无计时器的时候初始化
            if (this._castleTimer == null) this._castleTimer = new IntervalCall(this.timeUpdate, this, 1);

            EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_TECH_TIME, techNet);
        }
    },

    //更新地块建筑物信息
    updateNetBlock: function (arr) {
        var blockNet = new CastleBlockBeanNet(arr);
        if (this.getNetBlock(null)[blockNet._index] != null && this.getNetBlock(null)[blockNet._index]._building_level < blockNet._building_level && this.getNetBlock(null)[blockNet._index]._building_level != 0) {
            EventMgr.inst().dispatchEvent(CastleEvent.UPGRADE_COMPLETE, blockNet._index);//抛消息
        }
        this.getNetBlock(null)[blockNet._index] = blockNet;

        if (blockNet._state_remain > 0 && blockNet._state != CastleData.STATE_NORMAL) {//无计时器的时候初始化
            if (this._castleTimer == null) this._castleTimer = new IntervalCall(this.timeUpdate, this, 1);
            this.lastTime = (new Date()).getTime();
            EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_BLOCK_TIME, blockNet);
            //cc.log("#################测试 抛出倒计时事件啊啊啊啊啊啊");
            //cc.log("#################测试 抛出倒计时事件啊啊啊啊啊啊");
        }
    },

    //每秒更新
    lastTime:null,
    timeUpdate: function () {
        //cc.log("测试  计时器@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //城堡地块建筑倒计时
        var num = 0;
        for (var i in this.getNetBlock()) {
            var blockNet = new CastleBlockBeanNet(this.getNetBlock()[i]._data);
            if (blockNet._state != CastleData.STATE_NORMAL) num += 1;
            if (blockNet._state_remain > 0 && blockNet._state != CastleData.STATE_NORMAL) {//&&blockNet._state!=CastleData.STATE_NORMAL
                var now = (new Date()).getTime();
                blockNet._state_remain -= now - this.lastTime;
                this.lastTime = now;
                blockNet._data[8] = blockNet._state_remain;
                if (blockNet._state_remain <= 0) {
                    var dtime = -blockNet._state_remain;
                    cc.log(dtime + "倒计时归零 特殊处理 请求 ###地块###信息" + blockNet._state);
                    blockNet._state_remain = 0;
                    blockNet._data[8] = blockNet._state_remain;
                    this.onSendBlock(null, blockNet._index);
                    //var ac = cc.sequence( cc.delayTime(0.5), cc.callFunc( this.xxxxx, this ));
                }
                //事件 倒计时
                EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_BLOCK_TIME, blockNet);//if(blockNet._state!=CastleData.STATE_NORMAL)
            }
        }
        //城堡科技倒计时
        for (var i in this.getNetTech()) {
            var techNet = new CastleTechBeanNet(this.getNetTech()[i]._data);
            if (techNet._state != CastleData.STATE_NORMAL) num += 1;
            if (techNet._state_remain > 0 && techNet._state != CastleData.STATE_NORMAL) {
                techNet._state_remain -= 1000;
                techNet._data[7] = techNet._state_remain;
                if (techNet._state_remain <= 0) {
                    cc.log("倒计时归零 特殊处理 请求 @科技@信息");
                    techNet._state_remain = 0;
                    techNet._data[7] = techNet._state_remain;
                    this.onSendTech(null, techNet._tech_id);
                }
                //事件 倒计时
                EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_TECH_TIME, techNet);//if(techNet._state!=CastleData.STATE_NORMAL)
            }
        }
        //兵营训练倒计时
        //var list = mainData.castleData.armyTrainList;
        var allTrainList=mainData.castleData.armyTrainList;
        var list =[];
        for(var i=0;i<allTrainList.length;i++){
            var armyAll = allTrainList.getItemAt(i);
            if(armyAll.castleId==this._currentCastleId){
                list.push(armyAll);
            }
        }
        for(var i = 0;i< list.length;i++){
            //var army = list.getItemAt(i);
            var army = list[i];
            //cc.log("army.remainTime*********"+army.remainTime+"blockid"+army.blockId);
            if(army.remainTime>0){
                //cc.log("remainTime@@@@@@@@@@@@@@@@@@"+army.remainTime);
                num+=1;
                army.remainTime-=1000;
            }
            if (army.remainTime <= 0&&army.armyId!=0) {
                //cc.log(army.armyId+"倒计时归零 特殊处理 兵营  可点击收取 %%%%%%%%%%%%%%%%%%"+army.blockId+"count:"+army.num);
                army.remainTime = 0;
            }
            if(army.armyId!=0)  {
                //cc.log(army.armyId+"army.remainTime*********"+army.remainTime+"blockid"+army.blockId);
                EventMgr.inst().dispatchEvent(CastleEvent.UPDATE_ARMYTRAIN_TIME, army);
            }
        }

        //cc.log(num+"num@@@@@@@@@");
        if (num == 0) {
            this.clear();
            //this._castleTimer.clear();
            //this._castleTimer=null;
            //this._castleTimer=new IntervalCall(this.timeUpdate,this,1);
        }

    },

    //-------------------@@@@@@@@@@@@@@@@@@@@@@@@@其他模块常用 获取数据方法@@@@@@@@@@@@@@@@@@@@@@@@@@@-----------------------
    //获取可建造建筑物过滤数组
    getCanBuilding: function (index, castleId) {
        var blockbean = new CastleBlockBeanCSV(this._arrBlockBean[index]._data);
        var arr = blockbean._building_id;
        //cc.log(arr.length+"%%%%arr.length1"+arr+"###"+castleId);
        if (arr.length == 1) return arr;
        for (var i in this.getNetBlock(castleId)) {
            //cc.log(this.getNetBlock(castleId)[i]._data+"###########");
            var blockNet = new CastleBlockBeanNet(this.getNetBlock(castleId)[i]._data);
            //cc.log(blockNet._building_id+"<<arr   blockNet._building_id"+arr.indexOf(1902001)+"###"+arr.indexOf("1902001"));
            var sindex = arr.indexOf(String(blockNet._building_id));//blockNet._building_id
            if (sindex != -1) {
                arr.splice(sindex, 1);
            }
        }
        //cc.log(arr.length+"<<<<arr.length2"+arr);
        return arr;
    },

    //根据科技id获取 科技数据  //用法：getNetTech(castleId)[科技id]   可以用new CastleTechBeanCSV( 前面的对象._data)
    getNetTech: function (castleId, techId) {
        //cc.log(castleId+"$$$$$$$$$$"+this._currentCastleId)
        var dic = null;
        if (castleId == null || castleId == undefined) {
            dic = this._arrNetTech[this._currentCastleId];
        }
        else {
            dic = this._arrNetTech[castleId];
        }

        if (dic && techId != undefined) {
            dic = dic[techId];
        }

        return dic;
    },

    //根据城堡id获取城堡内netblock地块数据  //用法：getNetBlock(castleId,blockId地块index)   可以new CastleBlockBeanCSV( 前面的对象._data)
    getNetBlock: function (castleId, blockId) {
        //cc.log(castleId+"$$$$getNetBlock$$$$$$"+this._currentCastleId)
        var dic = null;
        if(!this._currentCastleId) return dic;
        if (castleId == null || castleId == undefined) {
            dic = this._arrNetBlock[this._currentCastleId];
        }
        else {
            dic = this._arrNetBlock[castleId];
        }
        if (blockId != undefined) {
            return dic[blockId];
        }
        return dic;
    },

    //根据城堡id获取  netResource  资源对象   //用法：getNetResource(castleId,资源id)  获取对应资源的值
    //若resourceId为null，返回castleId的所有资源
    getNetResource: function (castleId, resourceId) {
        var dic = null;
        if (castleId == null || castleId == undefined) {
            castleId = this._currentCastleId;
        }
        if (resourceId) {
            var list = mainData.castleData.resourceList;
            for (var i = 0; i < list.length; i++) {
                var res = list.getItemAt(i);
                if (castleId == res.castleId && String(resourceId) == String(res.resourceId)) {
                    dic = res.num;
                    break;
                }
            }
        }
        else {
            dic = {};
            var arr = [];
            var list = mainData.castleData.resourceList;
            for (var i = 0; i < list.length; i++) {
                var res = list.getItemAt(i);
                if (castleId == res.castleId) {
                    arr.push({"resourceId": res.resourceId, "num": res.num});
                }
            }
            for (var i in arr) {
                var temp = arr[i];
                dic[temp.resourceId] = temp.num;
            }
        }
        return dic;
    },
    //获取兵营训练部队信息
    getNetArmyTrain:function(castleId,blockId){
        var dic = null;
        if (castleId == null || castleId == undefined) {
            castleId = this._currentCastleId;
        }
        if(blockId){
            var list = mainData.castleData.armyTrainList;
            for (var i = 0; i < list.length; i++) {
                var army = list.getItemAt(i);
                if (castleId == army.castleId && blockId == army.blockId) {
                    dic = army;
                    break;
                }
            }
        }
        else dic=mainData.castleData.armyTrainList;
        return dic;
    },

    //获取部队
    getNetArmy: function (castleId, armyid) {
        var dic = null;
        if (castleId == null || castleId == undefined) {
            castleId = this._currentCastleId;
        }
        if (armyid) {
            var list = mainData.castleData.armyList;
            for (var i = 0; i < list.length; i++) {
                var army = list.getItemAt(i);
                if (castleId == army.castleId && armyid == army.armyId) {
                    dic = army.num;
                    break;
                }
            }
        }
        else {
            dic = {};
            var arr = [];
            var list = mainData.castleData.armyList;
            for (var i = 0; i < list.length; i++) {
                var army = list.getItemAt(i);
                if (castleId == army.castleId) {
                    arr.push({"armyId": army.armyId, "num": army.num});
                }
            }
            for (var i in arr) {
                var temp = arr[i];
                dic[temp.armyId] = temp.num;
            }
        }
        return dic;
    },

    //根据建筑id取netBlock地块数据 参照netblock
    getNetBlockByBuildingId: function (buildingId, castleId) {
        var arr = [];
        var blockObj = this.getNetBlock(castleId);
        for (var i in blockObj) {
            var blockNet = new CastleBlockBeanNet(blockObj[i]._data);
            if (Number(blockNet._building_id) == buildingId) {
                arr.push(blockNet);
            }
        }
        return arr;
    },

    //根据升级拆除等状态获取netBlock地块建筑列表  状态看最下面静态属性
    getNetBlockByState: function (state, castleId) {
        var arr = [];
        var blockObj = this.getNetBlock(castleId);
        for (var i in blockObj) {
            var blockNet = new CastleBlockBeanNet(blockObj[i]._data);
            if (Number(blockNet._state) == state) {
                arr.push(blockNet);
            }
        }
        return arr;
    },
    //根据兵营地块索引 获取是否训练中
    getArmyTrainState: function (blockId, castleId) {
        if(!castleId) castleId=mainData.uiData.currentCastleId;
        var bool=false;
        var list = mainData.castleData.armyTrainList;
        for(var i = 0;i< list.length;i++){
            var army = list.getItemAt(i);
            if(castleId == army.castleId && army.blockId == blockId&&army.remainTime>0){
                bool = true;
                break;
            }
        }
        return bool;
    },

    //根据升级拆除等状态获取netTech科技列表  状态看最下面静态属性
    getNetTechByState: function (state, castleId) {
        var arr = [];
        var techObj = this.getNetTech(castleId);
        for (var i in techObj) {
            var techNet = new CastleTechBeanNet(techObj[i]._data);
            if (Number(techNet._state) == state) {
                arr.push(techNet);
            }
        }
        return arr;
    },
    destroy: function () {
        //NetMgr.inst().removeEventListener( MapCmd.SERVER_LIST, this.nsGetServerList, this );

    },
    clear: function () {
        if (this._castleTimer)   {
            this._castleTimer.clear();
            this._castleTimer=null;
        }
    },
});

//静态属性
CastleData.STATE_NORMAL = 0;//无状态 正常状态
CastleData.STATE_BUILD = 1;//正在建造
CastleData.STATE_UPGRADE = 2;//正在升级
CastleData.STATE_REMOVE = 3;//正在拆除
CastleData.STATE_PRODUCE = 4;//正在生产