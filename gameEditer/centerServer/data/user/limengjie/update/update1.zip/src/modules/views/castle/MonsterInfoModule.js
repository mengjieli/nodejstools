/**
 * Created by cgMu on 2016/3/9.
 */

var MonsterInfoModule = ModuleBase.extend({
    _root:null,

    ctor: function () {
        this._super();
    },

    initUI: function () {
        var root = ccs.load("res/images/ui/castleInfo/MonsterInfo.json","res/images/ui/").node;
        this.addChild(root);
        this._root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var close = this._root.getChildByName("Panel_1").getChildByName("guanbi");
        close.addTouchEventListener( this.closeCall, this );

        var Text_1 = this._root.getChildByName("Panel_1").getChildByName("Text_1");
        Text_1.ignoreContentAdaptWithSize(true);
        Text_1.setString(ResMgr.inst().getString("monsterInfo_1"));

        var Text_2 = this._root.getChildByName("Panel_1").getChildByName("Text_2");
        Text_2.ignoreContentAdaptWithSize(true);
        Text_2.setString(ResMgr.inst().getString("monsterInfo_2"));

        var Text_2_1 = this._root.getChildByName("Panel_1").getChildByName("Text_2_1");
        Text_2_1.ignoreContentAdaptWithSize(true);
        Text_2_1.setString(ResMgr.inst().getString("monsterInfo_3"));
        var Text_2_1_0 = this._root.getChildByName("Panel_1").getChildByName("Text_2_1_0");
        Text_2_1_0.ignoreContentAdaptWithSize(true);
        Text_2_1_0.setString(ResMgr.inst().getString("monsterInfo_4"));
    },

    show: function (info) {
        var data = info.data;
        cc.log("@mosnter info", data.id,data.type,"---------->>"+data.userAccount,data.level);

        var panel = this._root.getChildByName("Panel_1");

        var Image_48 = panel.getChildByName("Image_48");
        Image_48.ignoreContentAdaptWithSize(true);
        Image_48.loadTexture(ResMgr.inst().getIcoPath(data.type));

        var Text_armyName = panel.getChildByName("Text_armyName");
        Text_armyName.ignoreContentAdaptWithSize(true);
        Text_armyName.setString(ResMgr.inst().getItemName(data.type));//name

        var Text_playerName = panel.getChildByName("Text_playerName");
        Text_playerName.ignoreContentAdaptWithSize(true);
        Text_playerName.setString("LV "+data.level);//lv

        var Text_playerName_0 = panel.getChildByName("Text_playerName_0");
        Text_playerName_0.ignoreContentAdaptWithSize(true);
        Text_playerName_0.setString(ResMgr.inst().getItemMsg(data.type));


        var ScrollView_2 = panel.getChildByName("ScrollView_2");
        var root = ScrollView_2.getChildByName("Image_154");
        root.setVisible(false);

        var itemList = this.getDropList(data.type);
        var count = itemList.length;
        var size = ScrollView_2.getContentSize();
        var width = root.getContentSize().width;
        var gap = 5;
        var totalWidth =(gap+width)*count+gap;
        totalWidth = totalWidth<size.width?size.width:totalWidth;

        ScrollView_2.setInnerContainerSize(cc.size(totalWidth,size.height));

        for(var i=0; i < count; i++){
            var it = root.clone();
            it.setVisible(true);
            it.setPositionX((gap+width)*i+gap+width*0.5);
            ScrollView_2.addChild(it);

            var info = itemList[i];

            var ico = it.getChildByName("Image_155");
            ico.ignoreContentAdaptWithSize(true);
            ico.loadTexture(ResMgr.inst().getIcoPath(info.key));
            ico.setScale(0.6);

            var num = it.getChildByName("Text_29");
            num.ignoreContentAdaptWithSize(true);
            num.setString(info.value);
        }

    },

    destroy: function () {

    },

    closeCall:function( node,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().closeModule("MonsterInfoModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    getDropList: function (monsterId) {
        var dropList = [];
        var dropdata = modelMgr.call("Table", "getTableItemByValue", ["monster", monsterId]).drop;
        var json = JSON.parse(dropdata);
        for(var i in json){
            cc.log("@drop data ", i, json[i]);
            var temp = this.getDrop(i);
            if(temp) dropList.push(temp);
        }
        return dropList;
    },

    getDrop: function (name) {
        var list = [];
        var data =  modelMgr.call("Table","getTableList",["monster_reward"]);
        for(var i in data){
            var it = data[i];
            if(it.name == name){
                list.push(it.id);
            }
        }

        cc.log("@------------>",list);

        var counts = list.length;
        if(counts==0) return null;

        var item = null;
        var id = null;
        if(counts==1) {
            id = list[0];
        }
        else{
            var temp = Math.floor(Math.random()*counts);
            id = list[temp];
        }
        item = modelMgr.call("Table", "getTableItemByValue", ["monster_reward", id]).item;
        var json = JSON.parse(item);
        for(var i in json){
            return {"key":i,"value":json[i]};
        }
    }
});
