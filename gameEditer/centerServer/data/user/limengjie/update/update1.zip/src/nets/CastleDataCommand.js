/**
 * Created by Administrator on 2015/12/3.
 */

var CastleDataCommand =  function() {
    var blockCall = function( cmd, msg ) {
        if(CastleNetEvent.GET_BUILDING==cmd){
            msg.resetCMDData();
            var obj = DataManager.getInstance().getNewData("CastleBlockItemData");
            obj.castleId        = msg.readString();
            obj.index           = msg.readUint();
            obj.buildId         = msg.readUint();
            obj.buildLevel      = msg.readUint();
            obj.state           = msg.readUint();
            obj.upgradeTime     = msg.readUint();
            obj.stateParam      = msg.readUint();
            obj.beginTime       = msg.readUint();
            obj.remainTime      = msg.readUint();

            var exist = false;
            var list = mainData.castleData.blockList;
            for(var i = 0;i< list.length;i++){
                var block = list.getItemAt(i);
                if(obj.castleId == block.castleId && obj.index == block.index){
                    exist = true;
                    list.setItemAt(i,obj);
                    break;
                }
            }
            if(!exist){
                cc.log("@blockCall",obj.buildId);
                mainData.castleData.blockList.push(obj);
            }

            var arrData=[obj.castleId,obj.index,obj.buildId,obj.buildLevel,obj.state,obj.upgradeTime,obj.stateParam,obj.beginTime,obj.remainTime];

            EventMgr.inst().dispatchEvent( CastleEvent.UPDATE_BUILDING,arrData);
            ModuleMgr.inst().getData("CastleModule").updateNetBlock(arrData);//更新地块建筑物信息

        }
    };

    var resourceCall = function( cmd, msg ) {
        if(CastleNetEvent.GET_RESOURCE==cmd){
            msg.resetCMDData();
            var obj = DataManager.getInstance().getNewData("ResourceItemData");
            obj.castleId        = msg.readString();
            obj.resourceId      = msg.readUint();
            obj.num             = msg.readUint();

            var numEx = ModuleMgr.inst().getData("CastleModule").getNetResource(obj.castleId,obj.resourceId);
            if(numEx>0){
                var differ = obj.num-numEx;
                EventMgr.inst().dispatchEvent( CastleEvent.UPDATE_RESOURCE,{castleId:obj.castleId,resourceId:obj.resourceId,differ:differ,current:obj.num});//城堡id 资源id 增减差值 当前值
            }

            var exist = false;
            var list = mainData.castleData.resourceList;
            for(var i = 0;i<list.length;i++){
                var res = list.getItemAt(i);
                if(obj.castleId == res.castleId && obj.resourceId==res.resourceId){
                    //cc.log("@CastleDataCommand true",obj.castleId,obj.resourceId);
                    exist = true;
                    list.setItemAt(i,obj);
                    break;
                }
            }
            if(!exist){
                //cc.log("@CastleDataCommand false",obj.castleId,obj.resourceId,obj.num);
                mainData.castleData.resourceList.push(obj);
            }
            EventMgr.inst().dispatchEvent( CastleEvent.UPDATE_RESOURCE);
        }
    };

    var techCall = function (cmd, msg) {
        if(CastleNetEvent.GET_TECH == cmd) {
            msg.resetCMDData();
            var obj = DataManager.getInstance().getNewData("TechData");
            obj.castleId        = msg.readString();
            obj.techId         = msg.readUint();
            obj.techLevel      = msg.readUint();
            obj.state           = msg.readUint();
            obj.upgradeTime     = msg.readUint();
            obj.stateParam      = msg.readUint();
            obj.beginTime       = msg.readUint();
            obj.remainTime      = msg.readUint();

            var exist = false;
            var list = mainData.castleData.techList;
            for(var i = 0;i< list.length;i++){
                var tech = list.getItemAt(i);
                if(obj.castleId == tech.castleId && obj.techId == tech.techId){
                    exist = true;
                    list.setItemAt(i,obj);
                    break;
                }
            }
            if(!exist){
                mainData.castleData.techList.push(obj);
            }

            ModuleMgr.inst().getData("CastleModule").netGetTech(cmd,msg);
        }
    };

    var armyCall = function (cmd, msg) {
        if(CastleNetEvent.GET_ARMY == cmd) {
            msg.resetCMDData();
            var obj = DataManager.getInstance().getNewData("ArmyData");
            obj.castleId = msg.readString();
            obj.armyId = msg.readUint();
            obj.num = msg.readUint();
            obj.enabled = msg.readUint();

            var exist = false;
            var list = mainData.castleData.armyList;
            for(var i = 0;i< list.length;i++){
                var army = list.getItemAt(i);
                if(obj.castleId == army.castleId && obj.armyId == army.armyId){
                    exist = true;
                    list.setItemAt(i,obj);
                    break;
                }
            }
            if(!exist){
                cc.log("@armyCall",obj.castleId,obj.armyId,obj.num,obj.enabled);
                mainData.castleData.armyList.push(obj);
            }
        }
    };

    var armyTrainCall = function (cmd, msg) {
        if(CastleNetEvent.GET_ARMY_TRAIN == cmd) {
            cc.log("CastleNetEvent.GET_ARMY_TRAIN$$$$$$$$$$$$$$$$$$$$$$$ "+cmd);
            msg.resetCMDData();
            var obj = DataManager.getInstance().getNewData("ArmyTrainData");
            obj.castleId = msg.readString();
            obj.blockId = msg.readUint();
            obj.armyId = msg.readUint();
            obj.num = msg.readUint();
            obj.duration = msg.readUint();
            obj.remainTime = msg.readUint();

            var exist = false;
            var list = mainData.castleData.armyTrainList;
            for(var i = 0;i< list.length;i++){
                var army = list.getItemAt(i);
                if(obj.castleId == army.castleId && obj.blockId == army.blockId){
                    exist = true;
                    list.setItemAt(i,obj);
                    break;
                }
            }
            if(!exist){
                cc.log("**********************@armyTrainCall****************************"+"castleid"+obj.castleId+"blockid"+obj.blockId+"armid"+obj.armyId+"num"+obj.num+"remoain"+obj.remainTime);
                mainData.castleData.armyTrainList.push(obj);
            }
            ModuleMgr.inst().getData("CastleModule").netGetArmyTrain(cmd,obj);
        }
    };

    var init = function() {
        NetMgr.inst().addEventListener( CastleNetEvent.GET_BUILDING, blockCall, this );
        NetMgr.inst().addEventListener( CastleNetEvent.GET_RESOURCE, resourceCall, this );
        NetMgr.inst().addEventListener( CastleNetEvent.GET_TECH, techCall, this );
        NetMgr.inst().addEventListener( CastleNetEvent.GET_ARMY, armyCall, this );
        NetMgr.inst().addEventListener( CastleNetEvent.GET_ARMY_TRAIN, armyTrainCall, this );
    };

    init();
};