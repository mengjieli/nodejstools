/**
 * Created by cgMu on 2015/11/16.
 */

ITEM_EVENT = {};
ITEM_EVENT.ITEM_UPDATE = "item_update"; //道具数量更新 事件


var ItemData = DataBase.extend({
    //items:null,
    loadItemsTag: true,//背包更新时，区分是请求的还是自动推送的？？

    ctor: function () {
        this._super();
        //cc.log("ItemData ctor");
        NetMgr.inst().addEventListener(0, this.netComplete, this);//请求成功返回
    },

    init: function () {
        return true;
    },

    destroy: function () {
        NetMgr.inst().removeEventListener(0, this.netComplete, this);//请求成功返回
    },

    //请求加载道具列表
    loadItem: function () {
        this.loadItemsTag = true;
        var msg = new SocketBytes();
        msg.writeUint(500);//加载道具列表
        NetMgr.inst().send(msg);
    },

    netComplete: function (cmd, data) {
        if (cmd == 0) {//请求道具
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            if(data0==500){
                //cc.log("@请求道具 netComplete");
                if (this.loadItemsTag) {
                    this.loadItemsTag = false;
                }
            }
        }
    },

    initSignModule: function () {
        var sign_item = ModuleMgr.inst().getData("ItemModule").getCountsByItemId(SignModule.SIGH_ITEM_ID);//2100020:签到数量道具ID
        if (sign_item > 0) {
            if(mainData.playerData.guide==GuideModule.END_GUIDE_ALL||GuideModule.IS_CLOSE) ModuleMgr.inst().openModule("SignModule");//引导打开签到条件 引导完跳出
        }
    },

    //道具更新时，获取新增道具和数量(自己调用)
    autoGetCounts: function (itemid, counts) {
        var exist = false;
        var list = mainData.bagDataList;
        for (var i = 0; i < list.length; i++) {
            var item = list.getItemAt(i);
            if (item.itemid == itemid) {
                exist = true;
                if (counts > item.counts) {
                    return counts - item.counts;
                }
            }
        }

        if (!exist) {
            return counts;
        }
        return 0;
    },

    //查询itemid道具数量
    getCountsByItemId: function (itemid) {
        //cc.log("查找道具",itemid);
        var counts = 0;
        var list = mainData.bagDataList;
        for (var i = 0; i < list.length; i++) {
            var item = list.getItemAt(i);
            if (item.itemid == itemid) {
                counts = item.counts;
                break;
            }
        }
        //cc.log("counts",counts);
        return counts;
    },

    //查询同类型道具，返回道具ID列表
    getTypeList: function (itemclass) {
        var return_list = [];
        var list = mainData.bagDataList;
        for (var i = 0; i < list.length; i++) {
            var item = list.getItemAt(i);
            var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item",item.itemid ]);
            if (itemdata.class == itemclass) {
                return_list.push(item.itemid);
            }
        }
        return return_list;
    }

});