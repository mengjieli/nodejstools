var Command = (function () {

    function Command(name) {
        //名称
        this._name = name;
    }

    var d = __define, c = Command;
    p = c.prototype;

    __define(p, "name",
        function () {
            return this._name;
        },
        function(val){

        }
    )

    /**
     * 初始化
     * @param params Object
     */
    p.init = function (params) {
    }

    return Command;
})();