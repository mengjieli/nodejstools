var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var Sprite = (function (_super) {
        __extends(Sprite, _super);
        function Sprite() {
            _super.call(this);
            this._childs = new Array();
            this._show = System.getNativeShow("DisplayObjectContainer");
        }
        Sprite.prototype.addChild = function (child) {
            if (child.parent)
                child.parent.removeChild(child);
            this._childs.push(child);
            child.$parentAlpha = this.$parentAlpha * this.alpha;
            child.$setParent(this);
            if (System.IDE == "cocos2dx") {
                flower.CallLater.add(this._resetChildIndex, this);
            }
        };
        Sprite.prototype.getChildAt = function (index) {
            index = +index & ~0;
            return this._childs[index];
        };
        Sprite.prototype.addChildAt = function (child, index) {
            if (index === void 0) { index = 0; }
            if (child.parent == this) {
                this.setChildIndex(child, index);
            }
            else {
                if (child.parent)
                    child.parent.removeChild(child);
                this._childs.splice(index, 0, child);
                child.$parentAlpha = this.$parentAlpha * this.alpha;
                child.$setParent(this);
                if (System.IDE == "cocos2dx") {
                    flower.CallLater.add(this._resetChildIndex, this);
                }
            }
        };
        Sprite.prototype.removeChild = function (child) {
            for (var i = 0; i < this._childs.length; i++) {
                if (this._childs[i] == child) {
                    this._childs.splice(i, 1);
                    child.$parentAlpha = 1;
                    child.$setParent(null);
                    if (System.IDE == "cocos2dx") {
                        flower.CallLater.add(this._resetChildIndex, this);
                    }
                    return;
                }
            }
        };
        Sprite.prototype.removeChildAt = function (index) {
            var child = this._childs.splice(index, 1)[0];
            child.$parentAlpha = 1;
            child.$setParent(null);
            if (System.IDE == "cocos2dx") {
                flower.CallLater.add(this._resetChildIndex, this);
            }
        };
        Sprite.prototype.setChildIndex = function (child, index) {
            var childIndex = this.getChildIndex(child);
            if (childIndex == index) {
                return;
            }
            this._childs.splice(childIndex, 1);
            this._childs.splice(index, 0, child);
            var p = flower.Sprite.displayObjectContainerProperty.setChildIndex;
            if (System.IDE == "cocos2dx") {
                flower.CallLater.add(this._resetChildIndex, this);
            }
            else {
                this._show[p.func].apply(this._show, [child.$nativeShow, index]);
            }
        };
        Sprite.prototype._resetChildIndex = function () {
            if (System.IDE == "cocos2dx") {
                for (var i = 0; i < this._childs.length; i++) {
                    this._childs[i].$nativeShow["setLocalZOrder"].apply(this._childs[i].$nativeShow, [i]);
                }
            }
        };
        Sprite.prototype.getChildIndex = function (child) {
            for (var i = 0; i < this._childs.length; i++) {
                if (this._childs[i] == child) {
                    return i;
                }
            }
            return null;
        };
        Sprite.prototype.contains = function (child) {
            if (child.parent == this)
                return true;
            return false;
        };
        Sprite.prototype._alphaChange = function () {
            for (var i = 0; i < this._childs.length; i++) {
                this._childs[i].$parentAlpha = this.$parentAlpha * this.alpha;
            }
        };
        Sprite.prototype.$onFrameEnd = function () {
            for (var i = 0, len = this._childs.length; i < len; i++) {
                this._childs[i].$onFrameEnd();
            }
        };
        Sprite.prototype.dispose = function () {
            while (this._childs.length) {
                this._childs[0].dispose();
            }
            if (this.parent) {
                this.parent.removeChild(this);
            }
        };
        Sprite.prototype._getMouseTarget = function (matrix, mutiply) {
            if (this.touchEnabled == false)
                return null;
            if (mutiply == true && this.mutiplyTouchEnabled == false)
                return null;
            matrix.save();
            matrix.translate(-this.x, -this.y);
            if (this.rotation)
                matrix.rotate(-this.radian);
            if (this.scaleX != 1 || this.scaleY != 1) {
                matrix.scale(1 / this.scaleX, 1 / this.scaleY);
            }
            this._touchX = matrix.tx;
            this._touchY = matrix.ty;
            var target;
            var len = this._childs.length;
            for (var i = len - 1; i >= 0; i--) {
                if (this._childs[i].touchEnabled && (mutiply == false || (mutiply == true && this._childs[i].mutiplyTouchEnabled == true))) {
                    if (this._childs[i] instanceof flower.Sprite) {
                        target = this._childs[i]._getMouseTarget(matrix, mutiply);
                        if (target != null)
                            break;
                    }
                    else if (this._childs[i].$isMouseTarget(matrix, mutiply) == true) {
                        target = this._childs[i];
                        break;
                    }
                }
            }
            matrix.restore();
            return target;
        };
        Object.defineProperty(Sprite.prototype, "numChildren", {
            get: function () {
                return this._childs.length;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Sprite.prototype, "mesureWidth", {
            get: function () {
                var sx = 0;
                var ex = 0;
                for (var child_key_a in this._childs) {
                    var child = this._childs[child_key_a];
                    if (child.x < sx) {
                        sx = child.x;
                    }
                    if (child.x + child.width > ex) {
                        ex = child.x + child.width;
                    }
                }
                return Math.floor(ex - sx);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Sprite.prototype, "mesureHeight", {
            get: function () {
                var sy = 0;
                var ey = 0;
                for (var child_key_a in this._childs) {
                    var child = this._childs[child_key_a];
                    if (child.y < sy) {
                        sy = child.y;
                    }
                    if (child.y + child.width > ey) {
                        ey = child.y + child.height;
                    }
                }
                return Math.floor(ey - sy);
            },
            enumerable: true,
            configurable: true
        });
        return Sprite;
    })(flower.DisplayObject);
    flower.Sprite = Sprite;
})(flower || (flower = {}));
flower.Sprite.displayObjectContainerProperty = System.DisplayObjectContainer;
flower.Sprite._EVENT_ADD_TO_STAGE_LIST = [];
flower.Sprite._EVENT_REMOVE_FROM_STAGE_LIST = [];
//# sourceMappingURL=Sprite.js.map