var MapBuildRange = cc.Sprite.extend({
    ctor:function(data){
        this._super();
        //主城范围
        this.shader = new cc.Sprite("res/fight/ui/cityRange" + IdChange.changeToResource(IdType.CASTLE, data.id) + ".png");
        this.addChild(this.shader);
        this.shader.setPosition(MapUtils.width / 2, 0);

        this.powerShader = new cc.Sprite();
        this.addChild(this.powerShader);
        this.powerShader.setPosition(0, 0);
        var lv = data.attributes.getItem("type", 2500007).value;
        //if(mainData.castleData.blockList.getItem("buildId", 1901001) != null) {
        //    var lv = mainData.castleData.blockList.getItem("buildId", 1901001).buildLevel;
        //} else {
        //    var lv = 1;
        //}
        var testTable = modelMgr.call("Table", "getTableItemByValue", ["City_Castel", lv]);
        var range = testTable.range;
        var pts = [
            {
                x: -range * MapUtils.width,
                y: 0,
                images: [
                    {
                        name: "2",
                        anchorX: 0,
                        anchorY: 5,
                        offx: -MapUtils.width / 2,
                        offy: 0
                    },
                    {
                        name: "3",
                        anchorX: 1,
                        anchorY: 0,
                        offx: 0,
                        offy: -MapUtils.height / 2
                    }
                ],
                disx: MapUtils.width / 2,
                disy: -MapUtils.height * 0.75
            },
            {
                x: -range * MapUtils.width / 2,
                y: -range * MapUtils.height * 0.75,
                images: [
                    {
                        name: "3",
                        anchorX: 1,
                        anchorY: 0,
                        offx: 0,
                        offy: -MapUtils.height / 2
                    },
                    {
                        name: "1",
                        anchorX: 0,
                        anchorY: 0,
                        offx: 0,
                        offy: -MapUtils.height / 2
                    }
                ],
                disx: MapUtils.width,
                disy: 0
            },
            {
                x: range * MapUtils.width / 2,
                y: -range * MapUtils.height * 0.75,
                images: [
                    {
                        name: "1",
                        anchorX: 0,
                        anchorY: 0,
                        offx: 0,
                        offy: -MapUtils.height / 2
                    },
                    {
                        name: "2",
                        anchorX: 0,
                        anchorY: 0.5,
                        offx: MapUtils.width / 2,
                        offy: 0
                    }
                ],
                disx: MapUtils.width / 2,
                disy: MapUtils.height * 0.75
            },
            {
                x: range * MapUtils.width,
                y: 0,
                images: [
                    {
                        name: "2",
                        anchorX: 0,
                        anchorY: 0.5,
                        offx: MapUtils.width / 2,
                        offy: 0
                    },
                    {
                        name: "3",
                        anchorX: 0,
                        anchorY: 1,
                        offx: 0,
                        offy: MapUtils.height / 2
                    }
                ],
                disx: -MapUtils.width / 2,
                disy: MapUtils.height * 0.75
            },
            {
                x: range * MapUtils.width / 2,
                y: range * MapUtils.height * 0.75,
                images: [

                    {
                        name: "3",
                        anchorX: 0,
                        anchorY: 1,
                        offx: 0,
                        offy: MapUtils.height / 2
                    },
                    {
                        name: "1",
                        anchorX: 1,
                        anchorY: 1,
                        offx: 0,
                        offy: MapUtils.height / 2
                    }
                ],
                disx: -MapUtils.width,
                disy: 0
            },
            {
                x: -range * MapUtils.width / 2,
                y: range * MapUtils.height * 0.75,
                images: [
                    {
                        name: "1",
                        anchorX: 1,
                        anchorY: 1,
                        offx: 0,
                        offy: MapUtils.height / 2
                    },
                    {
                        name: "2",
                        anchorX: 0,
                        anchorY: 0.5,
                        offx: -MapUtils.width / 2,
                        offy: 0
                    }
                ],
                disx: -MapUtils.width / 2,
                disy: -MapUtils.height * 0.75
            }
        ];
        var sp;
        for (var i = 0; i < pts.length; i++) {
            for (var m = 0; m < pts[i].images.length; m++) {
                for (var r = 0; r <= range; r++) {
                    if (r == range && m != 0) continue;
                    sp = new cc.Sprite("res/fight/ui/power" + IdChange.changeToResource(IdType.CASTLE, data.id) + pts[i].images[m].name + ".png");
                    trace(pts[i].images[m].anchorX, pts[i].images[m].anchorY);
                    sp.setAnchorPoint(pts[i].images[m].anchorX, pts[i].images[m].anchorY);
                    trace(pts[i].x + pts[i].images[m].offx + r * pts[i].disx, pts[i].y + pts[i].images[m].offy + r * pts[i].disy);
                    sp.setPosition(pts[i].x + pts[i].images[m].offx + r * pts[i].disx, pts[i].y + pts[i].images[m].offy + r * pts[i].disy);
                    this.powerShader.addChild(sp);
                }
            }
        }
    },
    dispose:function(){
        if (this.shader) {
            this.shader.getParent().removeChild(this.shader);
            this.shader = null;
            this.powerShader.getParent().removeChild(this.powerShader);
            this.powerShader = null;
        }
        if(this.getParent()) {
            this.getParent().removeChild(this);
        }
    }
});
