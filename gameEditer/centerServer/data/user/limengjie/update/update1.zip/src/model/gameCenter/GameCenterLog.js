var GameCenterLog = function () {
    GameCenterLogWithColor.call(null,0x899caf,arguments)
}

var GameCenterLogWithColor = function(color,list) {
    var bytes = new flower.VByteArray();
    bytes.writeUIntV(1002);
    bytes.writeUIntV(color);
    bytes.writeUIntV(list.length);
    for (var i = 0; i < list.length; i++) {
        bytes.writeUTFV(list[i] + "");
    }
    if(modelMgr) {
        modelMgr.call("GameCenter", "sendData", [bytes]);
    }
    var str = "";
    for (var i = 0; i < list.length; i++) {
        str += list[i] + (i < list.length - 1 ? "  " : "");
    }
    cc.log(str);
}

var gmlog = GameCenterLog;
var gmcolorlog = GameCenterLogWithColor;