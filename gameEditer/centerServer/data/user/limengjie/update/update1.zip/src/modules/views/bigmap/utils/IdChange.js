function IdChange() {

}

IdChange.changeToResource = function (type, id) {
    //trace("判断id",type);
    var relation = RALATION.OTHER;
    switch (type) {
        case IdType.PLAYER:
            break;
        case IdType.CASTLE:
            if (mainData.mapData.myCastleList.getItem("id", id)) {
                relation = RALATION.MY;
            }
            break;
        case IdType.ARMY:
            break;
        case IdType.EARTH:
            trace("判断土地是不是自己的",id,mainData.mapData.myEarthList.length);
            if (mainData.mapData.myEarthList.getItem("id", id)) {
                relation = RALATION.MY;
            }
            break;
    }
    return relation;
}

var IdType = {
    "PLAYER": "player",
    "ARMY": "army",
    "CASTLE": "castle",
    "EARTH": "earth"
}

var RALATION = {
    "MY": "My",
    "OTHER": "Other",
    "FAMILY": "family"
}