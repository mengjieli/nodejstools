/**
 * Created by Administrator on 2015/11/24.
 * 收藏夹
 */


var CollectModule = ModuleBase.extend({

    _ui:null,

    _scroll:null,
    //_sliderBack:null,
    //_slider:null,
    scrollbar: null,
    scrollbar_bg:null,
    barTotalHeight: 0,
    barPercent_total: 0,
    scrollPosY: 0,
    isOnePage: null,

    _item:null,                        //单元

    _tabs:null,                        //tab标签列表
    _selectTab:null,                   //当前Tab
    _itemPanels:null,
    _itemLists:null,
    _selectItem:null,
    ctor:function()
    {
        this._super();
    },

    initUI:function()
    {
        this._ui = ccs.load("res/images/ui/collect/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        var Image_4 = this._ui.getChildByName("Panel_1").getChildByName("Image_4");
        sizeAutoLayout(Image_4);
        var Panel_1_0 = this._ui.getChildByName("Panel_1").getChildByName("Panel_1_0");
        sizeAutoLayout(Panel_1_0);
        var Panel_3  = this._ui.getChildByName("Panel_1").getChildByName("Panel_3");
        posAutoLayout(Panel_3);
        var Image_5 = this._ui.getChildByName("Panel_1").getChildByName("Image_5");
        posAutoLayout(Image_5);

        var Image_158 = this._ui.getChildByName("Panel_5").getChildByName("Image_158");
        sizeAutoLayout(Image_158);
        this.scrollbar_bg = Image_158;

        var Image_159 = this._ui.getChildByName("Panel_5").getChildByName("Image_159");
        posAutoLayout(Image_159);
        this.scrollbar = Image_159;
        this.scrollPosY = this.scrollbar.getPositionY();
        this.barTotalHeight = Image_158.getContentSize().height;

        //var counts = this.getTagCounts();
        //var data = modelMgr.call("Table", "getTableItemByValue", ["Public", 100046]);
        //var max = data?data.numerical:0;
        var Text_8 = this._ui.getChildByName("Panel_5").getChildByName("Text_8");
        posAutoLayout(Text_8);
        Text_8.ignoreContentAdaptWithSize(true);
        Text_8.setString(ResMgr.inst().getString("collect_11"));
        Text_8.setLocalZOrder(10);
        this.setTagLabel();

        this._scroll        = this._ui.getChildByName("Panel_5").getChildByName("ScrollView_1");
        //this._sliderBack    = this._ui.getChildByName("Panel_5").getChildByName("Panel_7");
        //this._slider        = this._ui.getChildByName("Panel_5").getChildByName("Panel_7").getChildByName("Slider_2");
        this._item          = this._ui.getChildByName("Panel_5").getChildByName("item");
        var editButton      = this._item.getChildByName("Button_0");
        var deleteButton    = this._item.getChildByName("Button_1");

        this._tabs = [];
        var panel = this._ui.getChildByName("Panel_1").getChildByName("Panel_3");
        var tab = panel.getChildByName("Image_0_0");
        tab.setTouchEnabled(true);
        tab.ignoreContentAdaptWithSize( true );
        tab.addTouchEventListener( this.tabItemCall,this );
        var title = tab.getChildByName("Text");
        title.ignoreContentAdaptWithSize( true );
        title.setString( ResMgr.inst().getString("collect_10"));
        tab.index = 0;
        this._tabs.push(tab);
        for( var i=0; i<4; i++ )
        {
            var ui = panel.getChildByName( "Image_"+i );
            ui.setTouchEnabled(true);
            ui.ignoreContentAdaptWithSize( true );
            ui.addTouchEventListener( this.tabItemCall,this );
            var uiText = ui.getChildByName("Text");
            uiText.ignoreContentAdaptWithSize( true );
            uiText.setString( ResMgr.inst().getString("collect_0_"+i));
            ui.index = i+1;
            this._tabs.push(ui);
        }
        //var xt = this._ui.getChildByName("Panel_2").getChildByName("Panel_3").getChildByName("xiaotiao");
        //xt.setLocalZOrder(20);

        //this._itemPanels = [];
        this._itemLists = [];
        //for( var i=0; i<5; i++ )
        //{
        //    var ui  = this._scroll.getChildByName("Panel_"+i);
        //    ui.setVisible( false );
        //    this._itemPanels.push( ui );
        //    this._itemLists[i] = [];
        //}

        //var bgl             = this._ui.getChildByName("Panel_5").getChildByName("Image_11");
        //var bgr             = this._ui.getChildByName("Panel_5").getChildByName("Image_11_0");

        //editButton.setTitleText( ResMgr.inst().getString("collect_2") );
        //deleteButton.setTitleText( ResMgr.inst().getString("public_delete") );
        var txt = editButton.getChildByName("Text_6");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("collect_2"));

        txt = deleteButton.getChildByName("Text_7");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("public_delete"));

        //this._sliderBack.setVisible( false );
        this._item.setVisible( false );
        this._item.setTouchEnabled(true);
        this._item.addTouchEventListener( this.itemTouchCall, this );
        //适配
        var sc              = 1/GameMgr.inst().scaleX;
        var down            = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down                = down * sc;
        //var size            = bgl.getContentSize();
        //size.height         += (down >> 1);
        //bgl.setContentSize( size );
        //bgr.setContentSize( size );
        var size            = this._scroll.getContentSize();
        size.height         += down;
        this._scroll.setContentSize( size );
        //var size            = this._sliderBack.getContentSize();
        //size.height         += down;
        //this._sliderBack.setContentSize( size );
        //var size            = this._slider.getContentSize();
        //size.width          += down;
        //this._slider.setContentSize( size );
        var size            = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        this._scroll.addTouchEventListener(         this.scrollTouchCall, this );
        this._scroll.addEventListener(              this.scrollEventCall, this );
        editButton.addTouchEventListener(           this.editButtonTouchCall, this );
        deleteButton.addTouchEventListener(         this.deleteButtonTouchCall, this );

        this.setSelectTab( 0 );

        EventMgr.inst().addEventListener( CollectEvent.SEND_NEW_ITEM,       this.newItemCall, this );
        EventMgr.inst().addEventListener( CollectEvent.SEND_DELETE_ITEM,    this.deleteItemCall, this );
        EventMgr.inst().addEventListener( CollectEvent.SEND_UPDATE_ITEM,    this.updateItemCall, this );
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    destroy:function()
    {
        EventMgr.inst().removeEventListener( CollectEvent.SEND_NEW_ITEM,       this.newItemCall, this );
        EventMgr.inst().removeEventListener( CollectEvent.SEND_DELETE_ITEM,    this.deleteItemCall, this );
        EventMgr.inst().removeEventListener( CollectEvent.SEND_UPDATE_ITEM,    this.updateItemCall, this );
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    show:function( data )
    {
        //ModuleMgr.inst().getData("CollectModule").resetData();
        //var list = mainData.favoritesData;
        //for(var i=0; i<list.length;i++){
        //    var it = list.getItemAt(i);
        //    cc.log("@favoritesData",it.id,it.name);
        //}
    },

    close:function()
    {
    },

    setTagLabel: function () {
        //cc.log("@setTagLabel");
        var counts = ModuleMgr.inst().getData("CollectModule").getTagCounts();
        var data = modelMgr.call("Table", "getTableItemByValue", ["Public", 100046]);
        var max = data?data.numerical:1;
        var Text_8 = this._ui.getChildByName("Panel_5").getChildByName("Text_8");
        Text_8.setString(ResMgr.inst().getString("collect_11")+counts+"/"+max);
    },

    netComplete: function (event, data) {
        if(data == 201){
            this.setTagLabel();
        }
    },

    //设置Tab
    setSelectTab:function( index, b )
    {
        if(b){
            index++;
        }
        cc.log("@setSelectTab",index);
        if (this._selectTab && this._selectTab.index == index && !b) return;
        //还原上一个按钮
        if( this._selectTab != null )
        {
            this._selectTab.ignoreContentAdaptWithSize( true );
            this._selectTab.loadTexture("ty_shangbiaoweiqianxuanzhong.png", ccui.Widget.PLIST_TEXTURE);
            ccui.helper.doLayout( this._selectTab );
            this._selectTab = null;
        }

        //for( var i in this._itemPanels )
        //{
        //    this._itemPanels[i].setVisible( false );
        //}

        //设置当前选择的按钮。
        var len = this._tabs.length;
        for( var i=0; i<len; i++ )
        {
            var tab = this._tabs[i];
            if( tab.isVisible() == false ) continue;
            var txt = tab.getChildByName("Text");
            if( i == index )
            {
                tab.ignoreContentAdaptWithSize( true );
                tab.loadTexture("ty_shangbiaoqianxuanzhong1.png", ccui.Widget.PLIST_TEXTURE);
                tab.setLocalZOrder(10);
                this._selectTab = tab;
                ccui.helper.doLayout( this._selectTab );
            }
            else
            {
                tab.setLocalZOrder( len - i );
            }

            txt.setColor( i == index ? cc.color(252,250,155) : cc.color( 175,151,86) );
            txt.setFontSize(i==index ? 24:20);
        }
        this.updateUI();
    },

    updateUI:function()
    {
        if( this._selectTab == null ) return;

        var index       = this._selectTab.index;
        //var listPanel   = this._itemPanels[index];
        //if( listPanel )
        //{
        //    listPanel.setVisible(true);
        //    listPanel.removeAllChildren();
        //}
        //this.deleteItemsByType( index );
        //var itemList        = this._itemLists[index];
        //if( itemList == null || itemList.length <= 0 )
        //{
        //    this.createItemList( index );
        //}
        //else
        //{
        //    this.itemItemPos( index );
        //}
        for(var i in this._itemLists){
            this._itemLists[i].removeFromParent(true);
        }
        this._itemLists = [];

        this.createItemList( index );
    },

    //deleteItemsByType:function( index )
    //{
    //    this._itemLists[index] = [];
    //},

    sortList: function (list) {
        var arr1 = new Array();
        var arr2 = new Array();
        for(var i in list){
            var it = list[i];
            if(it.tag){
                arr1.push(it);
            }
            else{
                arr2.push(it);
            }
        }
        arr1 = arr1.concat(arr2);
        return arr1;
    },

    createItemList:function( type )
    {
        var data        = ModuleMgr.inst().getData("CollectModule");
        if( data == null ) return;
        var infoList = [];
        if(type==0){
            for(var i in data._itemList){
                for(var j in data._itemList[i]){
                    infoList.push(data._itemList[i][j]);
                }
            }
        }
        else{
            infoList    = data.getItemList( type-1 );
        }

        //var len         = data.getListLenght( type );
        if( infoList == null ) return;

        //sort 被标记的置顶
        var list = this.sortList(infoList);
        for( var key in list )
        {
            var objInfo = list[key];
            this.createItem( type, objInfo );
        }
        this.itemItemPos( type );
    },

    //创建item
    createItem:function( type, info )
    {
        var itemUI  = this._item;
        var ui = itemUI.clone();
        this.setItemInfo( ui, info );
        ui.setPosition(0,0);
        ui.setVisible(true);
        this.addItemTOList( type, ui );
    },

    deleteItemTOList:function( type , id )
    {
        var list = this.getItemList( type );
        for( var key in list )
        {
            var item = list[key];
            if( item.id == id )
            {
                item.removeFromParent();
                list.splice( key, 1 );
                break;
            }
        }
        this.itemItemPos( type );
    },

    //设置Item数据
    setItemInfo:function( ui, info )
    {
        var ico     = ui.getChildByName("sb").getChildByName("ico");
        var name    = ui.getChildByName("zb");
        var pos     = ui.getChildByName("dgcc");

        var tag = ui.getChildByName("Image_160");
        tag.setVisible(info.tag);

        ico.loadTexture( ResMgr.inst().getIcoPath(info.type) );
        name.ignoreContentAdaptWithSize(true);
        name.setString( info.name );

        var str     = ResMgr.inst().getString("collect_3");
        str         += "X: " + info.pos.x + " Y: " + info.pos.y;
        pos.ignoreContentAdaptWithSize(true);
        pos.setString( str );
        ui.id       = info.id;
    },

    addItemTOList:function( type , item )
    {
        //var panel = this._itemPanels[type];
        var list = this.getItemList( type );
        list.push(item);
        //panel.addChild(item);
        this._scroll.addChild(item);
    },

    //updateInfoTOItem:function( type , id )
    //{
    //    var data = ModuleMgr.inst().getData("CollectModule");
    //    if( data == null ) return;
    //    var list = this.getItemList( type );
    //    for( var key in list )
    //    {
    //        var item = list[key];
    //        if( item.id == id )
    //        {
    //            var info = data.getItemInfo( type, id );
    //            this.setItemInfo( item, info );
    //            break;
    //        }
    //    }
    //},


    itemItemPos:function( type )
    {
        var item0       = this._item;
        var scroll      = this._scroll;
        var list        = this.getItemList( type );
        if( list == null || list.length<=0 )return;
        var len         = list.length;
        var itemH       = item0.getContentSize().height;
        itemH           += 2;
        var h           = len * itemH;
        var size        = scroll.getContentSize();
        size.height     = h > size.height ? h : size.height;
        for( var i =0; i<len; i++ )
        {
            var it = list[i];
            it.index = i;
            it.setPosition( 0, (size.height - itemH) - i*itemH );
        }
        scroll.setInnerContainerSize( size );
        scroll.jumpToTop();

        var pos = this._scroll.getInnerContainer().getPosition();
        this.barPercent_total = Math.abs(pos.y);
        //重置滑块大小
        var innerContainerSize = this._scroll.getInnerContainerSize();
        //重置滑块位置
        if (innerContainerSize.height < size.height) {
            this.isOnePage = true;
        }
        else {
            this.isOnePage = false;
        }
        if (this.isOnePage) {
            this.refreshScrollbarState(100);
        }
        else {
            this.refreshScrollbarState(0);
        }
    },

    //更新滑块位置
    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY - (this.barTotalHeight - this.scrollbar.height) * percent / 100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },

    /*updateSlider:function()
    {
        if( this._scroll == null || this._slider == null ) return;

        var panelH  = this._scroll.getContentSize().height;
        var textH   = this._scroll.getInnerContainerSize().height ;
        var pos     = this._scroll.getInnerContainer().getPosition();
        if( textH<= panelH )
        {
            //this._sliderBack.setVisible( false );
            //this._sliderBack.setOpacity(0);
            return;
        }
        else
        {
            //this._sliderBack.setVisible( true );
        }
        if( pos.y > 0 ) pos.y = 0;
        if( pos.y < (panelH - textH) ) pos.y = panelH - textH;
        var posY            = Math.abs( pos.y );
        var p               = 0;
        p                   = posY / ( textH - panelH );
        p                   = Math.round(p * 100);
        if (p < 0) p        = 0;
        if (p > 100) p      = 100;
        p                   = (100 - p);
        if( isNaN(p) ) p    = 0;

        this._slider.setPercent( p );
    },*/


    getItemList:function( i )
    {
        return this._itemLists;
    },

    /************************
     * 控件回调
     */

    tabItemCall:function( node ,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.setSelectTab( node.index );
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    /**
     * 整个元素点击
     * @param node
     * @param type
     */
    itemTouchCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {

            var data = ModuleMgr.inst().getData("CollectModule");
            if( data == null ) return;
            var info = data.getItemInfo( null, node.id );
            var pos = info.pos;

            //if(UIData.getInstance().showType == UIData.getInstance())
            ModuleMgr.inst().closeModule("CollectModule");

            if(mainData.uiData.showMap == MapChangeModule.MAP) {
                pos = MapUtils.transPointToPosition(pos.x,pos.y);
                modelMgr.call("BigMap", "cameraLookAt", [pos.x,pos.y]);
            } else {
                pos = MapUtils.transPointToPosition(pos.x,pos.y);
                ModuleMgr.inst().openModule("MapChangeModule",{"type":MapChangeModule.MAP,moduleData:{x:pos.x,y:pos.y}});
            }
        }
    },

    scrollTouchCall:function( node, type )
    {
        if( ccui.Widget.TOUCH_BEGAN == type )
        {
            //this._sliderBack.stopAllActions();
            //var sc = cc.fadeTo(0.2,255);
            //this._sliderBack.runAction( sc );
        }
        if( type == ccui.Widget.TOUCH_ENDED || type == ccui.Widget.TOUCH_CANCELED )
        {
            //this._sliderBack.stopAllActions();
            //var sc = cc.fadeTo(0.2,0);
            //this._sliderBack.runAction( sc );
        }
    },

    scrollEventCall:function( node, type )
    {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                var pos = this._scroll.getInnerContainer().getPosition();
                var number = this.barPercent_total + pos.y;
                var per = number * 100 / this.barPercent_total;
                if (per < 0) {
                    per = 0
                }
                if (per > 100) {
                    per = 100
                }
                this.refreshScrollbarState(per);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    editButtonTouchCall:function( node,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            var pan = node.getParent();
            cc.log("点击" + pan.id ,this._selectTab);
            if( this._selectTab == null ) return;
            var data = ModuleMgr.inst().getData("CollectModule");
            if( data == null ) return;
            var info = data.getItemInfo( null, pan.id  );
            if( info ) ModuleMgr.inst().openModule("AddCollectModule", { id:info.id, pos:info.pos } );
        }
    },

    deleteButtonTouchCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            cc.log("点击");
            var data = ModuleMgr.inst().getData("CollectModule");
            if( data == null ) return;
            var pan = node.getParent();
            if( pan.id ) data.ncDelete( pan.id );
        }
    },


    /************************
     * 事件回调
     */

    newItemCall:function( event, type, id )
    {
        var data = ModuleMgr.inst().getData("CollectModule");
        if( data == null ) return;
        var info = data.getItemInfo( type, id );
        if( info == null ) return;
        this.createItem(    type, info );
        this.itemItemPos(   type );
    },

    deleteItemCall:function( event, type, id )
    {
        this.deleteItemTOList( type, id );
    },

    updateItemCall:function( event, type, id, oldType )
    {
        this.setSelectTab( oldType, true );
    },


});