var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var Label = (function (_super) {
        __extends(Label, _super);
        function Label() {
            _super.call(this);
            this._topAlgin = "";
            this._bottomAlgin = "";
            this._top = 0;
            this._bottom = 0;
            this._leftAlgin = "";
            this._rightAlgin = "";
            this._left = 0;
            this._right = 0;
            this._percentWidth = -1;
            this._percentHeight = -1;
            this._binds = {};
        }
        Label.prototype.add = function (a, b) {
            return a + b;
        };
        Label.prototype.minus = function (a, b) {
            return a - b;
        };
        Label.prototype.dispose = function () {
            for (var key in this._binds) {
                this._binds[key].dispose();
            }
            this._binds = null;
            _super.prototype.dispose.call(this);
        };
        Label.prototype.bindProperty = function (property, content) {
            if (this._binds[property]) {
                this._binds[property].dispose();
            }
            this._binds[property] = new flower.Binding(this, [this, flower.DataManager.ist, flower.Engine.global], property, content);
        };
        Label.prototype.removeBindProperty = function (property) {
            if (this._binds[property]) {
                this._binds[property].dispose();
                delete this._binds[property];
            }
        };
        Object.defineProperty(Label.prototype, "topAlgin", {
            get: function () {
                return this._topAlgin;
            },
            set: function (val) {
                if (flower.Engine.DEBUG) {
                    if (val != "" && val != "top" && val != "bottom") {
                        flower.DebugInfo.debug("非法的 topAlgin 值:" + val + "，只能为 \"\" 或 \"top\" 或 \"bottom\"", flower.DebugInfo.ERROR);
                    }
                }
                this._topAlgin = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "top", {
            get: function () {
                return this._top;
            },
            set: function (val) {
                this._top = +val || 0;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "bottomAlgin", {
            get: function () {
                return this._bottomAlgin;
            },
            set: function (val) {
                if (flower.Engine.DEBUG) {
                    if (val != "" && val != "top" && val != "bottom") {
                        flower.DebugInfo.debug("非法的 bottomAlgin 值:" + val + "，只能为 \"\" 或 \"top\" 或 \"bottom\"", flower.DebugInfo.ERROR);
                    }
                }
                this._bottomAlgin = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "bottom", {
            get: function () {
                return this._bottom;
            },
            set: function (val) {
                this._bottom = +val || 0;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "leftAlgin", {
            get: function () {
                return this._leftAlgin;
            },
            set: function (val) {
                if (flower.Engine.DEBUG) {
                    if (val != "" && val != "left" && val != "right") {
                        flower.DebugInfo.debug("非法的 leftAlgin 值:" + val + "，只能为 \"\" 或 \"left\" 或 \"right\"", flower.DebugInfo.ERROR);
                    }
                }
                this._leftAlgin = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "left", {
            get: function () {
                return this._left;
            },
            set: function (val) {
                this._left = +val || 0;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "rightAlgin", {
            get: function () {
                return this._rightAlgin;
            },
            set: function (val) {
                if (flower.Engine.DEBUG) {
                    if (val != "" && val != "left" && val != "right") {
                        flower.DebugInfo.debug("非法的 rightAlgin 值:" + val + "，只能为 \"\" 或 \"left\" 或 \"right\"", flower.DebugInfo.ERROR);
                    }
                }
                this._rightAlgin = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "right", {
            get: function () {
                return this._right;
            },
            set: function (val) {
                this._right = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "percentWidth", {
            get: function () {
                return this._percentWidth < 0 ? 0 : this._percentWidth;
            },
            set: function (val) {
                val = +val;
                val = val < 0 ? 0 : val;
                this._percentWidth = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Label.prototype, "percentHeight", {
            get: function () {
                return this._percentHeight < 0 ? 0 : this._percentHeight;
            },
            set: function (val) {
                val = +val;
                val = val < 0 ? 0 : val;
                this._percentHeight = val;
                this.$addFlag(10);
            },
            enumerable: true,
            configurable: true
        });
        Label.prototype.$onFrameEnd = function () {
            _super.prototype.$onFrameEnd.call(this);
            if (this.$getFlag(10) || this.parent.$getFlag(10)) {
                this.$removeFlag(10);
                if (this._percentWidth >= 0) {
                    this.width = this.parent.width * this._percentWidth / 100;
                }
                if (this._percentHeight >= 0) {
                    this.height = this.parent.height * this._percentHeight / 100;
                }
                if (this._topAlgin != "") {
                    if (this._topAlgin == "top") {
                        this.y = this._top;
                    }
                    else if (this._topAlgin == "bottom") {
                        this.y = this.parent.height - this._top;
                    }
                    if (this._bottomAlgin != "") {
                        if (this._bottomAlgin == "top") {
                            this.height = this.bottom - this._y;
                        }
                        else if (this._bottomAlgin == "bottom") {
                            this.height = this.parent.height - this.bottom - this._y;
                        }
                    }
                }
                else {
                    if (this._bottomAlgin != "") {
                        if (this._bottomAlgin == "top") {
                            this.y = this._bottom - this._height * this.scaleY;
                        }
                        else if (this._bottomAlgin == "bottom") {
                            this.y = this.parent.height - this._bottom - this._height * this.scaleY;
                        }
                    }
                }
                if (this._leftAlgin != "") {
                    if (this._leftAlgin == "left") {
                        this.x = this._left;
                    }
                    else if (this._leftAlgin == "right") {
                        this.x = this.parent.width - this._x;
                    }
                    if (this._rightAlgin != "") {
                        if (this._rightAlgin == "left") {
                            this.width = this._right - this._x;
                        }
                        else if (this._rightAlgin == "right") {
                            this.width = this.parent.width - this._right - this._x;
                        }
                    }
                }
                else {
                    if (this._rightAlgin != "") {
                        if (this._rightAlgin == "left") {
                            this.x = this._right - this._width * this.scaleX;
                        }
                        else if (this._rightAlgin == "right") {
                            this.x = this.parent.width - this._right - this._width * this.scaleX;
                        }
                    }
                }
            }
        };
        return Label;
    })(flower.TextField);
    flower.Label = Label;
})(flower || (flower = {}));
//# sourceMappingURL=Label.js.map