function InitModule() {
    ModuleMgr.inst().init();


    var txt = ccui.Text();
    txt.setFontSize(25);
    txt.setAnchorPoint(0, 0);
    txt.setString(mainData.version);
    txt.setPosition(CD.screenWidth - 100, 0);
    ModuleMgr.inst().addNodeTOLayer(txt, ModuleLayer.LAYER_TYPE_TOP);

    //var stepTxt = ccui.Text();
    //stepTxt.setFontSize(25);
    //stepTxt.setAnchorPoint(0, 0);
    //stepTxt.setString("步骤:" + GameSDK.DataManager.getInstance().startGameData.step);
    //stepTxt.setPosition(CD.screenWidth - 100, 30);
    //ModuleMgr.inst().addNodeTOLayer(stepTxt, ModuleLayer.LAYER_TYPE_TOP);

    GameSDK.DataManager.getInstance().startGameData.addListener("step", function () {
        //stepTxt.setString("步骤:" + GameSDK.DataManager.getInstance().startGameData.step);
        if (GameSDK.DataManager.getInstance().startGameData.step == 7) {
            txt.getParent().removeChild(txt);
            //stepTxt.getParent().removeChild(stepTxt);
        }
    });

    //公共资源
    registerModuleAndData("Language", null, null, [
        "res/configs/csvs/CN.csv",
        "res/configs/csvs/EN.csv",
        "res/configs/csvs/KR.csv",
        "res/configs/csvs/ZH.csv",
        "res/configs/csvs/sounds.csv"
    ]);
    //注册登录模块
    registerModuleAndData("GameLoginModule",
        {className: "GameLoginModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "GameLoginData", isInit: true},
        ["res/images/ui/login/loading.json",
            "res/images/ui/login/login.json",
            "res/images/ui/login/login_plist.plist",
            "res/images/ui/login/mobile.json",
            "res/images/ui/login/register.json",
            "res/images/ui/login/set.json",
            "res/images/ui/login/treaty.json",
            "res/images/ui/login/key.json",
            "res/images/ui/login/verify.json"]
    );

    //预加载公共
    registerModuleAndData("NetWaitView", {
        className: "NetWaitView",
        layer: ModuleLayer.LAYER_TYPE_TOP
    }, null, []);

    //预加载公共
    registerModuleAndData("AlertPanel", {
        className: "AlertPanelModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    }, null, ["res/AlertPanel/AlertPanel.json", "res/AlerPanel/alertPanel/Plist.plist"]);
    registerModuleAndData("AlertString", {
        className: "AlertStringModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    }, null, []);
    registerModuleAndData("NetworkWaitModule", {
        className: "NetworkWaitModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    }, null, []);
    //欢迎页
    //registerModuleAndData("Loading", {
    //    className: "LoadingModule",
    //    layer: ModuleLayer.LAYER_TYPE_UI
    //}, {className: "LoadingData", isInit: false}, ["res/loadingAndLogining/loadingUI.json"]);

    //昵称
    registerModuleAndData("Presetting", {
        className: "PresettingModule",
        layer: ModuleLayer.LAYER_TYPE_UI
    }, null, ["res/loadingAndLogining/presettingUI.json"]);

    //公共资源
    var list = this.getPublicResourcesList();
    registerModuleAndData("public", null, null, list);

    // 地图切换模块
    registerModuleAndData("MapChangeModule",
        {className: "MapChangeModule", layer: ModuleLayer.LAYER_TYPE_TOP},
        {className: null, isInit: false},
        null);

    // 二级地图模块
    registerModuleAndData("BigMapModule",
        {className: "BigMapModule", layer: ModuleLayer.LAYER_TYPE_MAP},
        {className: "BigMapData", isInit: false},
        null);

    //对象模块
    registerModuleAndData("PlayerData",
        null,
        {className: "PlayerData", isInit: true},
        null);

    //二级地图UI弹框
    registerModuleAndData("TileMenuModule",
        {className: "TileMenuModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "TileMenuData", isInit: false},
        ["res/images/ui/TileMenuModule/ex_menuitemlayer.json",
            "res/images/ui/TileMenuModule/MenuLayer.json"]);

    //一级地图UI弹框
    registerModuleAndData("BuildingUIModule",
        {className: "BuildingUIModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "BuildingUIData", isInit: false},
        ["res/images/ui/TileMenuModule/ex_menuitemlayer.json",
            "res/images/ui/TileMenuModule/MenuLayer.json"]);

    //空地建造建筑UI弹框
    registerModuleAndData("CreateBuildingUIModule",
        {className: "CreateBuildingUIModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "CreateBuildingUIData", isInit: false},
        ["res/images/ui/TileMenuModule/ex_menuitemlayer.json",
            "res/images/ui/TileMenuModule/MenuLayer.json"]);

    //主界面资源
    registerModuleAndData("MainResourcesModule",
        {className: "MainResourcesModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/mainResourcesModule/Layer.json", "res/images/ui/mainResourcesModule/main_menu_plist.plist"]);

    //主界面菜单
    registerModuleAndData("MainMenuModule",
        {className: "MainMenuModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/mainMenuModule/Layer.json", "res/images/ui/mainResourcesModule/main_menu_plist.plist"]);

    //公告
    registerModuleAndData("announcement",
        null,
        {className: "AnnouncementData", isInit: true},
        null);

    //详情
    registerModuleAndData("ParticularsModule",
        {className: "ParticularsModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/warehouseParticulars/Layer.json",
            "res/images/ui/publicBackdrop/Layer.json",
            "res/images/ui/TheWall/Wall_Particulars_Layer.json"]);

    //升级
    registerModuleAndData("UpgradeModule",
        {className: "UpgradeModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/warehouseUpgrade/Layer.json",
            "res/images/ui/publicBackdrop/Layer.json",
            "res/images/animation/ui/upgrade/upgrade.plist",
            "res/images/ui/TheWall/Wall_Upgrade_Layer.json"]);

    //城墙
    registerModuleAndData("TheWallModule",
        {className: "TheWallLayer", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/TheWall/thewall.plist",
            "res/images/ui/TheWall/TheWallLayer.json"]);

    //学院
    registerModuleAndData("CollegeModule",
        {className: "CollegeModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "CollegeData", isInit: false},
        ["res/images/ui/College/college_plist.plist",
            "res/images/ui/College/CollegeLayer.json",
            "res/images/ui/College/College_Skill_LevelUp.json",
            "res/images/ui/College/College_Skill_CancelLayer.json"]);

    //主城堡
    registerModuleAndData("CastleModule",
        {className: "CastleModule", layer: ModuleLayer.LAYER_TYPE_MAP},
        {className: "CastleData", isInit: false},
        [
            "res/images/map/castle/castle.plist", "res/images/map/castle/castlebg.plist", "res/images/map/castle/castlebuilding.plist", "res/images/map/castle/castlebuilding1.plist",
            "res/images/map/castle/castlecloud.plist", "res/images/animation/ui/guide/guide_handtouch.plist",
            "res/images/animation/ui/castle/castle_upgrade_hammer.plist",
            //"res/images/animation/ui/castle/castle_upgrade_down.plist",
            //"res/images/animation/ui/castle/castle_upgrade_up.plist",
            "res/images/animation/ui/castle/castle_upgrade_complete.plist",
            "res/images/animation/ui/castle/castle_tech_upgrade.plist",
            //"res/images/animation/ui/castle/castle_tech_upgrade_complete.plist",
            "res/images/animation/ui/castle/castle_waterfall_l.plist",
            //"res/images/animation/ui/castle/castle_waterfall_m.plist",
            "res/images/animation/ui/castle/castle_waterfall_s_wide.plist",
            "res/images/animation/ui/castle/castle_waterfall_s.plist",
            "res/images/animation/ui/castle/castle_fountain.plist",
            //"res/images/animation/ui/castle/castle_waterwave1.plist","res/images/animation/ui/castle/castle_waterwave2.plist",
            "res/images/animation/ui/castle/castle_ship_up.plist",
            "res/images/animation/ui/castle/castle_ship_down.plist",
            //"res/images/animation/ui/castle/castle_soldier_patrol_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_soldier_patrol_stand_rightdown.plist","res/images/animation/ui/castle/castle_soldier_patrol_stand_leftup.plist",
            //"res/images/animation/ui/castle/castle_soldier_patrol_stand_leftdown.plist",
            "res/images/animation/ui/castle/castle_soldier_patrol_move_rightdown.plist","res/images/animation/ui/castle/castle_soldier_patrol_move_leftup.plist",
            "res/images/animation/ui/castle/castle_soldier_patrol_move_leftdown.plist","res/images/animation/ui/castle/castle_soldier_patrol_move_rightup.plist",
            "res/images/animation/ui/castle/castle_guard_stand.plist","res/images/animation/ui/castle/castle_guard_watch.plist",
            "res/images/animation/ui/castle/castle_guard_move_up.plist",
            "res/images/animation/ui/castle/castle_guard_move_down.plist",
            "res/images/animation/ui/castle/castle_merchant1_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant1_stand_rightdown.plist","res/images/animation/ui/castle/castle_merchant1_stand_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant1_stand_leftdown.plist", "res/images/animation/ui/castle/castle_merchant1_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant1_move_rightdown.plist","res/images/animation/ui/castle/castle_merchant1_move_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant1_move_leftdown.plist", "res/images/animation/ui/castle/castle_merchant2_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant2_stand_rightdown.plist","res/images/animation/ui/castle/castle_merchant2_stand_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant2_stand_leftdown.plist", "res/images/animation/ui/castle/castle_merchant2_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant2_move_rightdown.plist","res/images/animation/ui/castle/castle_merchant2_move_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant2_move_leftdown.plist", "res/images/animation/ui/castle/castle_merchant3_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant3_stand_rightdown.plist","res/images/animation/ui/castle/castle_merchant3_stand_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant3_stand_leftdown.plist", "res/images/animation/ui/castle/castle_merchant3_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant3_move_rightdown.plist","res/images/animation/ui/castle/castle_merchant3_move_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant3_move_leftdown.plist", "res/images/animation/ui/castle/castle_merchant4_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant4_stand_rightdown.plist","res/images/animation/ui/castle/castle_merchant4_stand_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant4_stand_leftdown.plist", "res/images/animation/ui/castle/castle_merchant4_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant4_move_rightdown.plist","res/images/animation/ui/castle/castle_merchant4_move_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant4_move_leftdown.plist", "res/images/animation/ui/castle/castle_merchant5_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant5_stand_rightdown.plist","res/images/animation/ui/castle/castle_merchant5_stand_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant5_stand_leftdown.plist", "res/images/animation/ui/castle/castle_merchant5_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_merchant5_move_rightdown.plist","res/images/animation/ui/castle/castle_merchant5_move_leftup.plist",
            "res/images/animation/ui/castle/castle_merchant5_move_leftdown.plist", "res/images/animation/ui/castle/castle_carriage_rightup.plist",
            //"res/images/animation/ui/castle/castle_carriage_rightdown.plist","res/images/animation/ui/castle/castle_carriage_leftup.plist",
            "res/images/animation/ui/castle/castle_carriage_leftdown.plist", "res/images/animation/ui/castle/castle_royalguard_stand.plist",
            "res/images/animation/ui/castle/castle_royalguard_move_rightup.plist","res/images/animation/ui/castle/castle_royalguard_move_rightdown.plist",
            "res/images/animation/ui/castle/castle_royalguard_move_leftup.plist","res/images/animation/ui/castle/castle_royalguard_move_leftdown.plist",
            "res/images/animation/ui/castle/castle_fish.plist", "res/images/animation/ui/castle/castle_rabbit_rightup.plist",
            "res/images/animation/ui/castle/castle_rabbit_rightdown.plist", "res/images/animation/ui/castle/castle_rabbit_leftup.plist",
            "res/images/animation/ui/castle/castle_rabbit_leftdown.plist", "res/images/animation/ui/castle/castle_snake_rightup.plist",
            "res/images/animation/ui/castle/castle_snake_rightdown.plist", "res/images/animation/ui/castle/castle_snake_leftup.plist",
            "res/images/animation/ui/castle/castle_snake_leftdown.plist", "res/images/animation/ui/castle/castle_frog_stand_rightup.plist",
            //"res/images/animation/ui/castle/castle_frog_stand_rightdown.plist","res/images/animation/ui/castle/castle_frog_stand_leftup.plist",
            //"res/images/animation/ui/castle/castle_frog_stand_leftdown.plist","res/images/animation/ui/castle/castle_frog_move_rightup.plist",
            //"res/images/animation/ui/castle/castle_frog_move_rightdown.plist","res/images/animation/ui/castle/castle_frog_move_leftup.plist",
            //"res/images/animation/ui/castle/castle_frog_move_leftdown.plist",
            "res/images/animation/ui/castle/castle_movegoods.plist",
            "res/images/animation/ui/castle/castle_eagle.plist", "res/images/animation/ui/castle/castle_immigrant.plist","res/images/animation/ui/castle/castle_immigrant_down.plist","res/images/animation/ui/castle/castle_immigrant_up.plist",
            "res/images/animation/ui/castle/castle_whitesmoke.plist", "res/images/animation/ui/castle/castle_blacksmoke.plist",
            "res/images/animation/ui/castle/castle_flag.plist", "res/images/animation/ui/castle/castle_windmill.plist",
            "res/images/animation/ui/castle/castle_clock.plist", "res/images/animation/ui/castle/castle_horseclock.plist",
            "res/images/animation/ui/castle/castle_battle_hammer.plist", "res/images/animation/ui/castle/castle_out_train.plist",
            "res/images/animation/ui/castle/castle_armytrain_icon.plist", "res/images/animation/ui/castle/castle_armytrain_light.plist",
            "res/images/animation/ui/castle/castle_armytrain_getLight.plist", "res/images/animation/ui/castle/castle_armytrain_getOneLight.plist",
            "res/images/animation/ui/castle/castle_armytrain_star.plist"
        ]);


    //加速
    registerModuleAndData("AccelerateModule",
        {className: "AccelerateModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/accelerate/Layer.json", "res/images/ui/accelerate/accelerate_plist.plist"]);

    //城堡资源
    registerModuleAndData("CitadelResourceModule",
        {className: "CitadelResourceModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/citadelResource/Layer.json", "res/images/ui/citadelResource/citadelResource_plist.plist"]);

    //城市增益
    registerModuleAndData("CityGainModule",
        {className: "CityGainModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/HeadModule/CHBLayer.json"]);

    //头像
    registerModuleAndData("HeadModule",
        {className: "HeadModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/HeadModule/HeadLayer.json",
            "res/images/ui/HeadModule/CostLayer.json",
            "res/images/ui/HeadModule/ChangeLayer.json",
            "res/images/ui/HeadModule/ChangeNameLayer.json",
            "res/images/ui/HeadModule/Selecting.json",
            "res/images/ui/HeadModule/PlaceLayer.json",
            "res/images/animation/ui/head/head_change.plist",
            "res/images/ui/HeadModule/head_plist.plist"]);

    //充值
    registerModuleAndData("PayModule",
        {className: "PayModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "PayData", isInit: false},
        ["res/images/ui/PayModule/PayLayer.json",
            "res/images/ui/PayModule/ScrolItem.json",
            "res/images/ui/PayModule/pay_plist.plist"]);

    //邮箱
    registerModuleAndData("MailModule",
        {className: "MailModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "MailData", isInit: false},null
        /*["res/images/ui/HeadModule/HeadLayer.json",
            "res/images/ui/HeadModule/head_plist.plist"]*/);

    //gameover 注销游戏模块
    registerModuleAndData("GameOverModule",
        {className: "GameOverModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        null);

    //朋友
    registerModuleAndData("FriendModule",
        {className: "FriendModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "FriendData"},
        ["res/images/ui/friend/Layer.json", "res/images/ui/friend/Layer1.json", "res/images/ui/friend/friend_plist.plist"]);

    //每日签到
    registerModuleAndData("SignModule",
        {className: "SignModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/SignModule/sign_plist.plist",
            "res/images/animation/ui/sign/mrqd_xuanzhong.plist",
            "res/images/ui/SignModule/SignLayer.json"]);

    //商城
    registerModuleAndData("StoreModule",
        {className: "StoreModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/StoreModule/store_plist.plist",
            "res/images/ui/StoreModule/buyconfirmlayer.json",
            "res/images/ui/StoreModule/storelayer.json"]);

    //物品道具
    registerModuleAndData("ItemModule",
        {className: "ItemModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "ItemData", isInit: true},
        null);

    //背包
    registerModuleAndData("BagModule",
        {className: "BagModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/BagModule/Layer.json",
            "res/images/ui/BagModule/bag_plist.plist"]);

    //军团集结
    registerModuleAndData("CorpsAssembledModule",
        {className: "CorpsAssembledModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/CorpsAssembled/Layer.json",
            "res/images/ui/CorpsAssembled/addLayer.json",
            "res/images/ui/CorpsAssembled/dissolveLayer.json",
            "res/images/ui/CorpsAssembled/assembled_plist.plist",
            "res/images/ui/CorpsAssembled/supplementLayer.json"]);

    //收藏夹
    registerModuleAndData("CollectModule",
        {className: "CollectModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "CollectData"},
        ["res/images/ui/collect/Layer.json"]);

    //添加收藏夹
    registerModuleAndData("AddCollectModule",
        {className: "AddCollectModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/collect/Layer1.json"]);

    //我的主城
    registerModuleAndData("MainCitysModule",
        {className: "MainCitysModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/mainCitys/Layer.json", "res/images/ui/mainCitys/Citys_Plist.plist"]);

    //土地使用倦
    registerModuleAndData("UseScrollModule",
        {className: "UseScrollModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/useScroll/Layer.json", "res/images/ui/useScroll/rouleau_plist.plist"]);

    //聊天
    registerModuleAndData("ChatModule",
        {className: "ChatModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        {className: "ChatData", isInit: true},
        ["res/images/ui/chatModule/chat_plist.plist",
            "res/images/ui/chatModule/Layer.json"]);

    //玩家信息
    registerModuleAndData("PlayerInfoModule",
        {className: "PlayerInfoModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        {className: null, isInit: true},
        ["res/images/ui/playerInfo/Layer.json"]);

    //私聊
    registerModuleAndData("PrivateChatModule",
        {className: "PrivateChatModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "PrivateChatData", isInit: true},
        ["res/images/ui/chatModule/chat_plist.plist",
            "res/images/ui/chatModule/Pirvate.json"]);

    //地块详情和升级
    registerModuleAndData("BlockInfoModule",
        {className: "BlockInfoModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/Block/blockinfo.plist","res/images/ui/Block/BlockInfoLayer.json"]);
    registerModuleAndData("BlockLevelupModule",
        {className: "BlockLevelupModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/Block/BlockLevelupLayer.json"]);

    //战斗UI
    registerModuleAndData("BattleUIModule",
        {className: "BattleUIModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "BattleUIData", isInit: false},
        ["res/images/ui/BattleUIModule/Layer.json",
            "res/images/ui/BattleUIModule/battleUI_plist.plist",
            "res/images/ui/BattleUIModule/item.json"]);

    registerModuleAndData("BattleLogModule",
        {className: "BattleLogModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
    null,["res/images/ui/BattleUIModule/BattleLogLayer.json"]);

    //服务器时间
    registerModuleAndData("ServerTimeData",
        null,
        {className: "ServerTimeData"},
        null);

    registerModuleAndData("BuildEditerModule", {
        className: "BuildEditerModule",
        layer: ModuleLayer.LAYER_TYPE_UI
    }, null, []);

    registerModuleAndData("GuideModule", {
            className: "GuideModule",
            layer: ModuleLayer.LAYER_TYPE_TOP
        },
        {className: "GuideData", isInit: true}
        , ["res/images/ui/guide/Layer.json", "res/images/ui/guide/guide_plist.plist",//"res/images/animation/ui/guide/guide_landuse.plist",
            "res/images/animation/ui/guide/guide_handtouch.plist", "res/images/animation/ui/guide/guide_upcolumn.plist",
            "res/images/animation/ui/guide/guide_wordstouch.plist"]);

    // 交易市场
    registerModuleAndData("MarketModule", {
            className: "MarketModule",
            layer: ModuleLayer.LAYER_TYPE_UI
        },
        {className: "MarketData", isInit: false}, null);

    //金币消费弹框提示
    registerModuleAndData("AlertCostModule",{
        className: "AlertCostModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/ui/HeadModule/CostLayer.json"]);

    //文本框
    registerModuleAndData("TextboxModule",{
        className: "TextboxModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/ui/textbox/Layer.json","res/images/ui/textbox/testbox.plist"]);

    //礼包收取特效
    registerModuleAndData("AlertGainModule",{
        className: "AlertGainModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/animation/ui/bag/bag_getItems.plist"]);

    // 城堡详情
    registerModuleAndData("CastleInfoModule",{
        className: "CastleInfoModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/ui/castleInfo/CastleInfo.json"]);

    // 部队详情
    registerModuleAndData("ArmyInfoModule",{
        className: "ArmyInfoModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/ui/castleInfo/ArmyInfo.json"]);

    //怪物详情
    registerModuleAndData("MonsterInfoModule",{
        className: "MonsterInfoModule",
        layer: ModuleLayer.LAYER_TYPE_TOP
    },null,["res/images/ui/castleInfo/MonsterInfo.json"]);

    //训练士兵
    registerModuleAndData("TrainingModule",{
        className: "TrainingModule",
        layer: ModuleLayer.LAYER_TYPE_UI
    },{className: "TrainingData", isInit: true},["res/images/ui/training/trainingLayer.json",
        "res/images/ui/training/unlockingLayer.json",
        "res/images/ui/training/training_plist.plist",
        "res/images/ui/training/trainingLayer2.json",
        "res/images/animation/ui/train/train_lock1.plist",
        "res/images/animation/ui/train/train_lock2.plist"]);

    //代币
    registerModuleAndData("TokenModule",
        {className: "TokenModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,
        ["res/images/ui/daibi/Layer.json"]);

    //礼包详情
    registerModuleAndData("ShowBagModule",
        {className: "ShowBagModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        null,["res/images/ui/PayModule/showbag.json"]);

    //税收记录
    registerModuleAndData("TaxRecordModule",
        {className: "TaxRecordModule", layer: ModuleLayer.LAYER_TYPE_TOPUI},
        {className: "TaxRecordData", isInit: true},["res/images/ui/taxRecord/Layer.json"]);

    //任务
    registerModuleAndData("TaskModule",
        {className: "TaskModule", layer: ModuleLayer.LAYER_TYPE_UI},
        {className: "TaskData", isInit: true},
        ["res/images/ui/task/task_plist.plist",
            "res/images/ui/task/Layer.json"]);

    //小地图
    registerModuleAndData("SmallmapModule",
        {className: "SmallmapModule", layer: ModuleLayer.LAYER_TYPE_UI},
        null,
        ["res/images/ui/smallmap/Layer.json",
            "res/images/ui/smallmap/searchLayer.json",
            "res/images/ui/smallmap/smallmap_plist.plist"]);

}

InitModule.prototype.getPublicResourcesList = function () {
    var list = [];

    //list.push("res/configs/csvs/ZH.csv");
    list.push("res/images/ui/new_public_plist.plist");
    list.push("res/images/ui/public_plist.plist");
    list.push("res/images/animation/ui/button/pay_icon.plist");//充值按钮特效文件
    list.push("res/configs/csvs/ui_Listi.csv");
    list.push("res/configs/csvs/ui_city.csv");
    list.push("res/configs/csvs/animationConfig.csv");
    list.push("res/configs/csvs/guideConfig.csv");
    list.push("res/configs/csvs/head.csv");

    list.push("res/configs/jsons/server.json");

    return list;
}