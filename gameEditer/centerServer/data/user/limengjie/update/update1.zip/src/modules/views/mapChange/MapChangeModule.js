/**
 * 切换地图模块
 */
var MapChangeModule = ModuleBase.extend({
    animation1: null,
    animation2: null,
    effectWidth: 960,
    effectHeight: 640,
    allTime: 1,
    speedStart: 1.2,
    minSpeed: 0.8,
    speed: null,
    addSpeed: 0.6,
    time: null,
    step: null,
    data: null,
    openModuleFlag: null,
    ctor: function () {
        this._super();
    },
    initUI: function () {
        var screenWidth = cc.Director.getInstance().getWinSize().width;
        var screenHeight = cc.Director.getInstance().getWinSize().height;
        var scaleX = screenWidth / this.effectWidth;
        var scaleY = screenHeight / this.effectHeight;
        //var scale = scaleX > scaleY ? scaleX : scaleY;

        /*this.animation1 = new Animation({
            url: "res/fight/effect/cloud/cloud_up00",
            format: "png",
            start: 1,
            end: 13,
            frameRate: 18,
            x: 0,
            y: 0,
            anchorX: 0,
            anchorY: 0,
            scaleX: 2,
            scaleY: 2
        });
        this.addChild(this.animation1);*/
        this.animation1 = new cc.Sprite("res/fight/effect/cloud/cloud_up01.png");
        this.animation1.setAnchorPoint(0, 0);
        this.animation1.setScaleX(scaleX*3);
        this.animation1.setScaleY(scaleY*3);
        this.addChild(this.animation1);

        this.animation2 = new cc.Sprite("res/fight/effect/cloud/cloud_down01.png");
        this.animation2.setAnchorPoint(0, 0);
        this.animation2.setScaleX(scaleX*3);
        this.animation2.setScaleY(scaleY*3);
        this.addChild(this.animation2);

        this.time = 0;
        this.step = 1;
        this.speed = this.speedStart;
        this.update(0);
    },
    update: function (dt) {
        if (this.step == 1 || this.step == 3) {
            this.animation1.setPosition(this.effectWidth * (1 - this.time) - this.effectWidth*0.25, this.effectHeight * (1 - this.time) - this.effectHeight*0.25);
            this.animation2.setPosition(this.effectWidth * (this.time - 1) - this.effectWidth*0.25, this.effectHeight * (this.time - 1) - this.effectHeight*0.25);
        }
        if (this.step == 1) {
            dt *= this.speed;
            this.speed -= this.addSpeed * dt;
            if (this.speed < this.minSpeed) {
                this.speed = this.minSpeed;
            }
            this.time += dt*1.7;
            if (this.time >= 1) {
                this.time = 0.3;
                this.step = 2;
                ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
                this.openModuleFlag = false;
                if (this.data.id) {
                    mainData.uiData.currentCastleId = this.data.id;
                }
                trace("切换mb", this.data.type, mainData.uiData.showMap);
                if (this.data.type == MapChangeModule.CASTLE) {
                    var _this = this;
                    mainData.uiData.showCastleFinish = false;
                    var back1 = function () {
                        _this.openModuleFlag = true;
                        mainData.uiData.removeListener("showCastleFinish", back1);
                    }
                    mainData.uiData.addListener("showCastleFinish", back1);
                    if (mainData.uiData.showMap == MapChangeModule.CASTLE) {
                        ModuleMgr.inst().openModule("BuildingUIModule", {objectid: null});
                        ModuleMgr.inst().openModule("CreateBuildingUIModule", {objectid: null});
                        ModuleMgr.inst().closeModule("CastleModule");
                    } else {
                        ModuleMgr.inst().closeModule("BattleUIModule");//战斗UI刷新
                        ModuleMgr.inst().closeModule("BigMapModule");
                    }
                    mainData.uiData.showMap = this.data.type;
                    ModuleMgr.inst().openModule("CastleModule", this.data.moduleData);
                } else if (this.data.type == MapChangeModule.MAP) {
                    var _this = this;
                    mainData.uiData.showMapFinish = false;
                    var back2 = function () {
                        _this.openModuleFlag = true;
                        mainData.uiData.removeListener("showMapFinish", back2);
                    }
                    mainData.uiData.addListener("showMapFinish", back2);
                    if (mainData.uiData.showMap == MapChangeModule.CASTLE) {
                        ModuleMgr.inst().openModule("BuildingUIModule", {objectid: null});
                        ModuleMgr.inst().openModule("CreateBuildingUIModule", {objectid: null});
                        ModuleMgr.inst().closeModule("CastleModule");
                    } else {
                        //ModuleMgr.inst().closeModule("BattleUIModule");//战斗UI刷新
                        ModuleMgr.inst().closeModule("BigMapModule");
                    }
                    mainData.uiData.showMap = this.data.type;
                    ModuleMgr.inst().openModule("BigMapModule", this.data.moduleData);
                    ModuleMgr.inst().openModule("BattleUIModule");//战斗UI刷新
                }
            }
        } else if (this.step == 2) {
            this.time -= dt*2;
            if (this.time <= 0 && this.openModuleFlag) {
                this.time = 1;
                this.step = 3;
                this.speed = this.minSpeed;
            }
        } else {
            dt *= this.speed;
            this.speed += this.addSpeed * dt;
            if (this.speed > this.speedStart) {
                this.speed = this.speedStart;
            }
            this.time -= dt;
            if (this.time <= 0) {
                this.time = 0;
                this.step = 1;
                this.unscheduleUpdate();
                ModuleMgr.inst().closeModule("MapChangeModule");

                var guideData = ModuleMgr.inst().getData("GuideModule");
                if (guideData._guideBean && guideData._guideBean._idStep == "2_1") {//还要隐藏按钮特殊处理  地图切换完成 触发引导下一步
                    EventMgr.inst().dispatchEvent("next_guide");
                    //ModuleMgr.inst().openModule("GuideModule",{id:"2_2"});
                }//引导
                if (guideData._guideBean && guideData._guideBean._idStep == "3_1") {
                    EventMgr.inst().dispatchEvent("next_guide");
                    //ModuleMgr.inst().openModule("GuideModule",{id:"2_2"});
                }//引导
                if (guideData._guideBean && guideData._guideBean._idStep == "4_3") {
                    EventMgr.inst().dispatchEvent("next_guide");
                }
            }
        }
    },
    show: function (data) {
        trace("消息：", data.type);
        mainData.uiData.mapChangeModule = true;
        this.data = data;
        this.scheduleUpdate();
        //切换地图时，更新切换按钮状态 返回按钮状态
        ModuleMgr.inst().getData("BattleUIModule").updateStateExchangeBtn(data.type);
        ModuleMgr.inst().getData("BattleUIModule").updateStateBackBtn(data.type);
    },
    destroy: function () {
        trace("销毁切换地图模块");
        mainData.uiData.mapChangeModule = false;
        this.removeChild(this.animation1);
        this.removeChild(this.animation2);
        this.animation1 = null;
        this.animation2 = null;
        var txt = cc.TextureCache.getInstance().getTextureForKey("res/fight/effect/cloud/cloud_up01.png");
        cc.TextureCache.getInstance().removeTexture(txt);
        var txt = cc.TextureCache.getInstance().getTextureForKey("res/fight/effect/cloud/cloud_down01.png");
        cc.TextureCache.getInstance().removeTexture(txt);
    }
});

//显示城内
MapChangeModule.CASTLE = "castle";
//显示大地图
MapChangeModule.MAP = "map";