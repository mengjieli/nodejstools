var flower;
(function (flower) {
    var ObjectDo = (function () {
        function ObjectDo() {
        }
        ObjectDo.toString = function (obj, maxDepth, before, depth) {
            if (maxDepth === void 0) { maxDepth = 4; }
            if (before === void 0) { before = ""; }
            if (depth === void 0) { depth = 0; }
            before = before || "";
            depth = depth || 0;
            maxDepth = maxDepth || 4;
            var str = "";
            if (typeof (obj) == "string" || typeof (obj) == "number") {
                str += obj;
            }
            else if (obj instanceof Array) {
                if (depth > maxDepth) {
                    return "...";
                }
                str = "[\n";
                for (var i = 0; i < obj.length; i++) {
                    str += before + "\t" + flower.ObjectDo.toString(obj[i], maxDepth, before + "\t", depth + 1) + (i < obj.length - 1 ? ",\n" : "\n");
                }
                str += before + "]";
            }
            else if (obj instanceof Object) {
                if (depth > maxDepth) {
                    return "...";
                }
                str = "{\n";
                for (var key in obj) {
                    str += before + "\t" + key + "\t: " + flower.ObjectDo.toString(obj[key], maxDepth, before + "\t", depth + 1);
                    str += ",\n";
                }
                if (str.slice(str.length - 2, str.length) == ",\n") {
                    str = str.slice(0, str.length - 2) + "\n";
                }
                str += before + "}";
            }
            else {
                str += obj;
            }
            return str;
        };
        ObjectDo.keys = function (obj) {
            var list = new Array();
            for (var key in obj) {
                list.push(key);
            }
            return list;
        };
        ObjectDo.copy = function (obj) {
            return obj;
        };
        return ObjectDo;
    })();
    flower.ObjectDo = ObjectDo;
})(flower || (flower = {}));
//# sourceMappingURL=ObjectDo.js.map