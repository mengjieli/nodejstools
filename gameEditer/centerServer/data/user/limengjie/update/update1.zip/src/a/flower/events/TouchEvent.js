var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var TouchEvent = (function (_super) {
        __extends(TouchEvent, _super);
        function TouchEvent(type, bubbles) {
            if (bubbles === void 0) { bubbles = true; }
            _super.call(this, type, bubbles);
        }
        return TouchEvent;
    })(flower.Event);
    flower.TouchEvent = TouchEvent;
})(flower || (flower = {}));
flower.TouchEvent.TOUCH_BEGIN = "touch_begin";
flower.TouchEvent.TOUCH_MOVE = "touch_move";
flower.TouchEvent.TOUCH_END = "touch_end";
//# sourceMappingURL=TouchEvent.js.map