/**
 * Created by Administrator on 2015/10/26.
 */



var WarehouseUI = cc.Node.extend({

    _ui:null,
    _id:0,
    _blockId:null,
    _info:null,
    _demandItems:null,
    _resourceItems:null,

    ctor:function( id, blockId )
    {
        this._super();
        this._id = id;
        this._blockId = blockId;

        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        var info = null;
        if( data )
        {
            list = data.getNetBlock( );
        }
        if( list != null && list[this._blockId] != null )
        {
            this._info = list[this._blockId];
        }

        this.initUI();
    },

    initUI:function()
    {
        this._ui = ccs.load("res/images/ui/warehouseParticulars/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        //适配
        var Image_4 = this._ui.getChildByName("Image_4");
        sizeAutoLayout(Image_4);

        var Image_3 = this._ui.getChildByName("Image_3");
        posAutoLayout(Image_3);
        sizeAutoLayout(Image_3);
        var Image_3_0 = this._ui.getChildByName("Image_3_0");
        posAutoLayout(Image_3_0);

        var control = this._ui.getChildByName("Image_1");
        posAutoLayout(control);

        var control = this._ui.getChildByName("Panel0");
        posAutoLayout(control);

        var control = this._ui.getChildByName("ScrollView_1");
        sizeAutoLayout(control);

        control = this._ui.getChildByName("Image_2");
        sizeAutoLayout(control);

        //control = this._ui.getChildByName("Panel1");
        //posAutoLayout(control,0.5);

        //control = this._ui.getChildByName("ScrollView_2");
        //sizeAutoLayout(control,0.5);

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        var txt = this._ui.getChildByName("Panel0").getChildByName("Text_0");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_2") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_1");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_3") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_2");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_4") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_3");
        txt.ignoreContentAdaptWithSize( true );
        txt.setString( ResMgr.inst().getString("xiangqing_5") );

        txt = this._ui.getChildByName("Panel0").getChildByName("Text_3_0");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("xiangqing_14"));

        //txt = this._ui.getChildByName("Panel1").getChildByName("Text_0");
        //txt.ignoreContentAdaptWithSize( true );
        //txt.setString( ResMgr.inst().getString("xiangqing_6") );
        //
        //txt = this._ui.getChildByName("Panel1").getChildByName("Text_1");
        //txt.ignoreContentAdaptWithSize( true );
        //txt.setString( ResMgr.inst().getString("xiangqing_7") );
        //
        //txt = this._ui.getChildByName("Panel1").getChildByName("Text_2");
        //txt.ignoreContentAdaptWithSize( true );
        //txt.setString( ResMgr.inst().getString("xiangqing_8") );
        //
        //txt = this._ui.getChildByName("Panel1").getChildByName("Text_3");
        //txt.ignoreContentAdaptWithSize( true );
        //txt.setString( ResMgr.inst().getString("xiangqing_9") );
        //
        //txt = this._ui.getChildByName("Panel1").getChildByName("Text_4");
        //txt.ignoreContentAdaptWithSize( true );
        //txt.setString( ResMgr.inst().getString("xiangqing_14") );

        var item0 = this._ui.getChildByName("item0");
        item0.setVisible(false);
        var scroll = this._ui.getChildByName("ScrollView_1");
        scroll.addEventListener(this.scrollOneCall, this );

        this.updateUp();
    },

    updateUp:function()
    {
        if( this._demandItems )
        {
            for( var i in this._demandItems )
            {
                var item = this._demandItems[i];
                item.removeFromParent();
            }
        }

        this._demandItems = [];

        var item0 = this._ui.getChildByName("item0");
        item0.setVisible(false);
        var scroll = this._ui.getChildByName("ScrollView_1");

        var config = modelMgr.call("Table","getTableList",["City_Storage"]);
        var level = this._info._building_level;
        var dataList = [];

        for( var i in config )
        {
            dataList.push( config[i] );
        }
        var len = dataList.length;
        for( var i=0; i<len; i++  )
        {
            var it = item0.clone();
            scroll.addChild( it );
            it.setVisible(true);
            this._demandItems.push( it );

            var data = dataList[i];
            it.info = {};
            it.info.level = data.storage_level;
            var resourceObj = data.resource_max;
            if( typeof resourceObj == "string" )
            {
                resourceObj = JSON.parse( resourceObj );
            }

            var itemUI = it.getChildByName("txt0");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( data.storage_level );
            itemUI = it.getChildByName("txt1");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( StringUtils.getUnitNumber(resourceObj["1101001"]==undefined?0:resourceObj["1101001"]) );
            itemUI = it.getChildByName("txt2");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( StringUtils.getUnitNumber(resourceObj["1101002"]==undefined?0:resourceObj["1101002"]) );
            itemUI = it.getChildByName("txt3");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( StringUtils.getUnitNumber(resourceObj["1101003"]==undefined?0:resourceObj["1101003"]) );
            itemUI = it.getChildByName("txt3_0");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.setString( data.prosperity );
        }
        this.updateDemandScrollItemPos( 0 );

        this.updateScrollviewSelecting( scroll, len,item0.getContentSize().height, level );

    },

    //更新滚动层里的item坐标
    updateDemandScrollItemPos:function( n )
    {

        var item0 = null;
        var scroll = null;
        var list = null;
        if( n == 0 )
        {
            list = this._demandItems;
            item0 = this._ui.getChildByName("item0");
            scroll = this._ui.getChildByName("ScrollView_1");
        }
        else
        {
            list = this._resourceItems;
            item0 = this._ui.getChildByName("item1");
            scroll = this._ui.getChildByName("ScrollView_2");
        }

        var gap = 3;
        var len  = list.length;
        var itemH = item0.getContentSize().height;
        var h = len * itemH + (len+1)*gap;
        var size = scroll.getContentSize();
        size.height = h > size.height ? h : size.height;
        for( var i =0; i<len; i++ )
        {
            var it = list[i];
            it.setPosition( 0, (size.height - itemH - gap) - i*(itemH + gap) );
        }
        var level = this._info._building_level;
        var select = scroll.getChildByName("select");
        select.setVisible(true);
        select.setPosition(0, (size.height - itemH - gap)- (level -1)*(itemH + gap) );
        select.setLocalZOrder(1);

        scroll.setInnerContainerSize( size );
        scroll.jumpToTop();
    },

    scrollOneCall:function( node, type )
    {
        if( type ==  ccui.ScrollView.EVENT_SCROLLING || type == ccui.ScrollView.EVENT_BOUNCE_TOP || type == ccui.ScrollView.EVENT_BOUNCE_BOTTOM )
        {
        }
    },

    updateScrollviewSelecting: function (scrollview, length,itemH,selecting)
    {
        var size = scrollview.getContentSize();
        var h = scrollview.getInnerContainerSize().height;
        var number = parseInt(size.height / (itemH+3));
        if (selecting> length-number)
        {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function () {
                scrollview.jumpToBottom();
            })));
        }
        else
        {
            this.runAction(cc.Sequence(cc.DelayTime(0.001),cc.CallFunc(function (sender) {
                //var size = scrollview.getContentSize();
                var percent = (selecting-1)*(itemH+3) / (h- size.height) * 100;
                scrollview.jumpToPercentVertical(percent)
            })));
        }
    }

});