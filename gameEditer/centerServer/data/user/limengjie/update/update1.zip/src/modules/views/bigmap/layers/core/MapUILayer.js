var MapUILayer = cc.Sprite.extend({
    selectMode: null,
    favrityList: null,
    ctor: function () {
        this._super();
        this.initSelectionMode();
        this.initFavrityList();
    },
    initSelectionMode: function () {
        this.selectMode = new cc.Sprite();
        this.addChild(this.selectMode);

        var sp = new cc.Sprite("res/fight/ui/selectionMode.png");
        sp.setAnchorPoint(0, 0);
        sp.setScaleX(4);
        sp.setScaleY(4);
        this.selectMode.addChild(sp);

        sp = new cc.Sprite("res/fight/ui/selectionMode.png");
        sp.setPosition(0, mainData.systemData.screenHeight);
        sp.setAnchorPoint(0, 0);
        sp.setScaleX(4);
        sp.setScaleY(-4);
        this.selectMode.addChild(sp);

        sp = new cc.Sprite("res/fight/ui/selectionMode.png");
        sp.setPosition(mainData.systemData.screenWidth, 0);
        sp.setAnchorPoint(0, 0);
        sp.setScaleX(-4);
        sp.setScaleY(4);
        this.selectMode.addChild(sp);

        sp = new cc.Sprite("res/fight/ui/selectionMode.png");
        sp.setPosition(mainData.systemData.screenWidth, mainData.systemData.screenHeight);
        sp.setAnchorPoint(0, 0);
        sp.setScaleX(-4);
        sp.setScaleY(-4);
        this.selectMode.addChild(sp);

        this.selectMode.setVisible(mainData.uiData.map.selectionMode);
        mainData.uiData.map.addListener("selectionMode", this.onSelectionModeChange, this);
    },
    //是否进入指令模式
    onSelectionModeChange: function () {
        this.selectMode.setVisible(mainData.uiData.map.selectionMode);
    },
    initFavrityList:function(){
        this.favrityList = [];
        for(var i = 0; i < mainData.favoritesData.length; i++) {
            this.onAddCollection(mainData.favoritesData.getItemAt(i));
        }
        mainData.favoritesData.addListener("add", this.onAddCollection, this);
        mainData.favoritesData.addListener("del", this.onDelCollection, this);
    },
    //添加收藏夹
    onAddCollection: function (collectionData) {
        var arrow = new CollectionArrow(collectionData);
        ModuleMgr.inst().addNodeTOLayer(arrow, ModuleLayer.LAYER_TYPE_UI);
        this.favrityList.push(arrow);
    },
    onDelCollection: function(item) {
        for(var i = 0; i < this.favrityList.length; i++) {
            if(this.favrityList[i].coordX == item.x && this.favrityList[i].coordY == item.y) {
                this.favrityList[i].dispose();
                this.favrityList.splice(i,1);
                break;
            }
        }
    },
    dispose: function () {
        mainData.uiData.map.removeListener("selectionMode", this.onSelectionModeChange, this);
        this.removeChild(this.selectMode);
        var txt = cc.TextureCache.getInstance().getTextureForKey("res/fight/ui/selectionMode.png");
        cc.TextureCache.getInstance().removeTexture(txt);

        mainData.favoritesData.removeListener("add", this.onAddCollection, this);
        mainData.favoritesData.removeListener("del", this.onDelCollection, this);
        while(this.favrityList.length) {
            this.favrityList.pop().dispose();
        }
    }
});