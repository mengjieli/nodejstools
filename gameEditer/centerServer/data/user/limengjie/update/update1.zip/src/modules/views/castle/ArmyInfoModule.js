/**
 * Created by Administrator on 2016/1/9 0009.
 */

var ArmyInfoModule = ModuleBase.extend({
    _root:null,

    ctor: function () {
        this._super();
    },

    initUI:function()
    {
        var root = ccs.load("res/images/ui/castleInfo/ArmyInfo.json","res/images/ui/").node;
        this.addChild(root);
        this._root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var panel = this._root.getChildByName("Panel_1");

        var close = panel.getChildByName("guanbi");
        close.addTouchEventListener( this.closeCall, this );

        var txt = panel.getChildByName("Text_2");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("armyinfo_1"));

        txt = panel.getChildByName("Text_2_0");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("armyinfo_2"));

        txt = panel.getChildByName("Text_2_1");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("armyinfo_3"));

        txt = panel.getChildByName("Text_2_0_0");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("armyinfo_4"));

        txt = panel.getChildByName("Text_2_1_0");
        txt.ignoreContentAdaptWithSize(true);
        txt.setString(ResMgr.inst().getString("armyinfo_5"));
    },

    destroy: function () {

    },

    show: function (info) {
        var data = info.data;
        cc.log("ddddddddddddddd------->"+data.type);
        //this.initUI();
        var pnl = this._root.getChildByName("Panel_1");
        var pdata = mainData.playerDataList.getItem("account", data.userAccount);
        var castlename = pnl.getChildByName("Text_castleName");
        var castleData = mainData.mapData.castleList.getItem("id",data.castleId);
        if(castleData != null)
            castlename.setString(castleData.name);
        else
            castlename.setString("未知");

        var armyConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",data.type]);
        var armyType = armyConfig.arm_type;
        var ico = pnl.getChildByName("Image_48");
        ico.ignoreContentAdaptWithSize(true);
        ico.loadTexture(ResMgr.inst().getIcoPath(armyType));

        var playername = pnl.getChildByName("Text_playerName");
        playername.setString(pdata.nick);

        var blood = data.attributes.getItem("type",2500011).value;
        var fullBlood = data.attributes.getItem("type",2500077).value;
        var armyCnt = pnl.getChildByName("Text_armyCnt");
        armyCnt.ignoreContentAdaptWithSize(true);

        if(data.relation=="myself"){
            armyCnt.setString(blood+"/"+fullBlood);
        }
        else{
            var id = ModelManager.getInstance().call("Table","getTableItemByRange",["arm_display",blood]).id;
            armyCnt.setString(ResMgr.inst().getString(id + "0"));
        }

        var armyName = pnl.getChildByName("Text_armyName");
        var str = ResMgr.inst().getString(data.type+"0");
        armyName.setString(str);
        var miaoshu = pnl.getChildByName("Text_miaoshu");
        str = ResMgr.inst().getString(data.type+"1");
        miaoshu.setString(str);

        var Text_armyLVL = pnl.getChildByName("Text_armyLVL");
        Text_armyLVL.ignoreContentAdaptWithSize(true);
        Text_armyLVL.setString(data.level);

        //负重
        var Text_armyName_0 = pnl.getChildByName("Text_armyName_0");
        Text_armyName_0.ignoreContentAdaptWithSize(true);
        Text_armyName_0.setString(data.resource+"/"+data.maxResource);
        cc.log("@------->",data.resource,data.maxResource);
    },

    closeCall:function( node,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().closeModule("ArmyInfoModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

});