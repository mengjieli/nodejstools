/**
 * Created by cgMu on 2016/1/21.
 */

var HouseUpgradeUI = cc.Node.extend({
    _ui: null,
    _id: 0,
    _index: 0,
    _level: 0,

    _building: null,//当前是否正在升级
    _need: null,//升级限制
    _needResources: null,//升级资源

    _resIDArray: null,
    _resCountsArray: null,

    _itemArray: null,
    _scrollview: null,
    _itemRoot: null,


    //tokenLabelDict:null,//存储label，使用代币数量
    tokenCountsDict: null,//存储数据
    //resLabelDict:null,
    resCountsDict: null,
    itemDict: null,
    remainTime: 0,

    ctor: function (id, index) {
        this._super();
        this._id = id;
        this._index = index;
        this._itemArray = [];

        //根据当前等级获取升级数据
        var blockData = ModuleMgr.inst().getData("CastleModule").getNetBlock()[this._index];
        this._level = blockData._building_level;

        this.initUI();

        EventMgr.inst().addEventListener(CastleEvent.UPGRADE_COMPLETE, this.upgradeCall, this);
        EventMgr.inst().addEventListener("using_token", this.usingCallback, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
    },

    initUI: function () {
        this._ui = ccs.load("res/images/ui/TheWall/Wall_Upgrade_Layer.json", "res/images/ui/").node;
        this.addChild(this._ui);

        //适配
        var size = cc.director.getVisibleSize();
        this._ui.setContentSize(size);
        ccui.helper.doLayout(this._ui);

        var Image_14 = this._ui.getChildByName("Image_14");
        posAutoLayout(Image_14, 0.5);
        sizeAutoLayout(Image_14, 0.5);

        var Image_14_0 = this._ui.getChildByName("Image_14_0");
        sizeAutoLayout(Image_14_0, 0.5);

        var Image_15 = this._ui.getChildByName("Image_15");
        posAutoLayout(Image_15);
        sizeAutoLayout(Image_15, 0.5);

        var Image_1 = this._ui.getChildByName("Image_1");
        posAutoLayout(Image_1);

        var Image_15_0 = this._ui.getChildByName("Image_15_0");
        posAutoLayout(Image_15_0, 0.5);
        sizeAutoLayout(Image_15_0, 0.5);

        var Image_1_0 = this._ui.getChildByName("Image_1_0");
        posAutoLayout(Image_1_0, 0.5);

        var Image_4 = this._ui.getChildByName("Image_4");
        posAutoLayout(Image_4);

        var Image_4_0 = this._ui.getChildByName("Image_4_0");
        posAutoLayout(Image_4_0, 0.5);

        var Image_5 = this._ui.getChildByName("Image_5");
        posAutoLayout(Image_5, 0.5);

        var Image_3 = this._ui.getChildByName("Image_3");
        posAutoLayout(Image_3, 0.5);
        sizeAutoLayout(Image_3, 0.5);

        var Image_3_0 = this._ui.getChildByName("Image_3_0");
        sizeAutoLayout(Image_3_0, 0.5);

        var text1 = this._ui.getChildByName("Text_1");
        posAutoLayout(text1);
        text1.ignoreContentAdaptWithSize(true);
        text1.setString(ResMgr.inst().getString("shengji_1"));

        var text2 = this._ui.getChildByName("Text_1_0");
        posAutoLayout(text2, 0.5);
        text2.ignoreContentAdaptWithSize(true);

        var data = modelMgr.call("Table", "getTableList", ["City_House"]);
        if (data.length == this._level) {
            text2.setString("Max");//满级
        }
        else {
            text2.setString(ResMgr.inst().getString("shengji_2") + " " + (this._level + 1));//下一等级
        }

        var scrollview = this._ui.getChildByName("ScrollView_1");
        posAutoLayout(scrollview, 0.5);
        sizeAutoLayout(scrollview, 0.5);

        scrollview.addEventListener(this.scrollCall, this);
        this._scrollview = scrollview;

        var item0 = scrollview.getChildByName("Panel_1");
        item0.setVisible(false);
        this._itemRoot = item0;

        this.refreshContent();

        //获取数据
        var nextLevel = this._level + 1;
        var levelUpData = modelMgr.call("Table", "getTableItemByValue", ["City_House", nextLevel]);
        var nowleveldata = modelMgr.call("Table", "getTableItemByValue", ["City_House", this._level]);
        if (!levelUpData) levelUpData = nowleveldata;


        var Text_4_1 = ccui.helper.seekWidgetByName(this._ui, "Text_4_1");
        //Text_4_1.setVisible(false);
        Text_4_1.ignoreContentAdaptWithSize(true);
        Text_4_1.setString(ResMgr.inst().getString("house_1"));
        var la = ccui.helper.seekWidgetByName(this._ui, "Text_4_0");
        la.setVisible(true);
        la.ignoreContentAdaptWithSize(true);
        la.setString(data.length == this._level ? "-" : levelUpData.population_produce);
        var arrow = ccui.helper.seekWidgetByName(this._ui, "Image_6");
        //arrow.setVisible(false);
        var des = ccui.helper.seekWidgetByName(this._ui, "Text_4");
        des.setVisible(true);
        des.ignoreContentAdaptWithSize(true);
        des.setString(nowleveldata.population_produce);
        var Text_5 = ccui.helper.seekWidgetByName(this._ui, "Text_5");
        Text_5.ignoreContentAdaptWithSize(true);
        Text_5.setVisible(false);
        Text_5.setString(ResMgr.inst().getString("college_1"));

        //
        var Text_2 = this._ui.getChildByName("Text_2");
        Text_2.setVisible(true);
        Text_2.ignoreContentAdaptWithSize(true);
        Text_2.setString(ResMgr.inst().getString("house_2") + StringUtils.getUnitNumber(this.getHouseCounts()));
        posAutoLayout(Text_2);
    },

    refreshContent: function () {
        this._building = [];
        this._need = [];
        this._needResources = [];
        this._resIDArray = [];
        this._resCountsArray = [];

        //this.tokenLabelDict = {};
        this.tokenCountsDict = {};
        //this.resLabelDict = {};
        this.resCountsDict = {};
        this.itemDict = {};

        for (var i in this._itemArray) {
            if (this._itemArray[i]) {
                this._itemArray[i].removeFromParent(true);
            }
        }
        this._itemArray = [];

        //获取数据
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();

        var nextLevel = this._level + 1;
        var levelUpData = modelMgr.call("Table", "getTableItemByValue", ["City_House", nextLevel]);

        var gap = 3;
        var scrollview = this._scrollview;
        var item0 = this._itemRoot;
        var size = scrollview.getContentSize();
        var itemH = item0.getContentSize().height;

        if (levelUpData == null) {
            for (var i = 0; i < 4; i++) {
                var it = item0.clone();
                scrollview.addChild(it);
                this._itemArray.push(it);
                it.setVisible(true);
                it.setPosition(0, size.height - (i + 1) * (itemH + gap));
                this.setVoidItem(it);
            }
            scrollview.setInnerContainerSize(size);
            scrollview.jumpToTop();
            return;
        }

        var building = ModuleMgr.inst().getData("CastleModule").getNetBlockByState(CastleData.STATE_UPGRADE);
        if (building.length > 0) {
            this._building.push(building[0]);
        }
        //this._need.push(eval("(" + levelUpData.need + ")"));
        var needdata = eval("(" + levelUpData.need + ")");
        for (var i in needdata) {
            var temp = {};
            temp.key = i;
            temp.value = needdata[i];
            this._need.push(temp);
        }

        var temp3 = eval("(" + levelUpData.need_resource + ")");
        for (var i in temp3) {
            var temp = {};
            temp.key = i;
            temp.value = temp3[i];
            this._needResources.push(temp);
        }

        //加载UI
        var counts = this._building.length + this._need.length + this._needResources.length;
        var h = counts * itemH + (counts + 1) * gap;
        h = h > size.height ? h : size.height;

        var index = 0;

        /*tag 1:加速；2:跳转；>3:获取更多*/
        for (var i = 0; i < this._building.length; i++) {
            index += 1;
            var it = item0.clone();
            scrollview.addChild(it);
            this._itemArray.push(it);
            it.setVisible(true);
            it.setPosition(0, h - index * (itemH + gap));

            var itemUI = it.getChildByName("Image_2");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.loadTexture("gy_shalou.png", ccui.Widget.PLIST_TEXTURE);
            var itemCounts = it.getChildByName('Text_3');
            itemCounts.ignoreContentAdaptWithSize(true);
            itemCounts.setString(ResMgr.inst().getString(this._building[i]._building_id + "0") + ResMgr.inst().getString("xiangqing_18"));
            itemCounts.setTextColor(cc.color(255, 0, 0, 255));

            this._resIDArray.push(this._building[i]._building_id);
            this._resBlockIndex = this._building[i]._index;

            this._resCountsArray.push(-1);

            var itemCheck = it.getChildByName("Image_2_0");
            itemCheck.ignoreContentAdaptWithSize(true);
            itemCheck.loadTexture("xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE);
            var btn = ccui.helper.seekWidgetByName(it, "Button_1");
            btn.addTouchEventListener(this.btnCallback, this);
            btn.setTag(index);
            btn.infoTag = 1;
            var btnTitle = ccui.helper.seekWidgetByName(it, "Text_2");
            btnTitle.ignoreContentAdaptWithSize(true);
            btnTitle.setString(ResMgr.inst().getString("xiangqing_16"));
            //btnTitle.enableOutline(cc.color(0,0,0,255));
            btnTitle = BorderText.replace(btnTitle);
        }
        for (var i = 0; i < this._need.length; i++) {
            index += 1;
            var it = item0.clone();
            scrollview.addChild(it);
            this._itemArray.push(it);
            it.setVisible(true);
            it.setPosition(0, h - index * (itemH + gap));

            var key = this._need[i].key;

            var itemUI = it.getChildByName("Image_2");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.loadTexture(ResMgr.inst()._icoPath + "11040010.png");//(ResMgr.inst()._icoPath+key+"0.png");
            //itemUI.setScale(0.1);
            var itemCounts = it.getChildByName('Text_3');
            itemCounts.ignoreContentAdaptWithSize(true);
            itemCounts.setString(ResMgr.inst().getString(key + "0") + ResMgr.inst().getString("xiangqing_1") + this._need[i].value);

            this._resIDArray.push(key);
            this._resCountsArray.push(this._need[i].value);

            var blockData = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(key);
            //cc.log("need",key,"当前等级",blockData.length,blockData[0]._building_id,blockData[0]._building_level);
            var nowLevel = 0;
            if (blockData[0]) {
                nowLevel = blockData[0]._building_level;
            }

            //判断是否满足
            if (this._need[i].value > nowLevel) {
                itemCounts.setTextColor(cc.color(255, 0, 0, 255));
                var itemCheck = it.getChildByName("Image_2_0");
                itemCheck.ignoreContentAdaptWithSize(true);
                itemCheck.loadTexture("xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE);
                var btn = ccui.helper.seekWidgetByName(it, "Button_1");
                btn.addTouchEventListener(this.btnCallback, this);
                btn.setTag(index);
                btn.infoTag = 2;
                var btnTitle = ccui.helper.seekWidgetByName(it, "Text_2");
                btnTitle.ignoreContentAdaptWithSize(true);
                btnTitle.setString(ResMgr.inst().getString("xiangqing_17"));
                //btnTitle.enableOutline(cc.color(0,0,0,255));
                btnTitle = BorderText.replace(btnTitle);
            }
            else {
                var btn = ccui.helper.seekWidgetByName(it, "Button_1");
                btn.setVisible(false);
            }
        }
        for (var i = 0; i < this._needResources.length; i++) {
            index += 1;
            var it = item0.clone();
            scrollview.addChild(it);
            this._itemArray.push(it);
            it.setVisible(true);
            it.setPosition(0, h - index * (itemH + gap));

            var key = this._needResources[i]["key"];
            cc.log("res", key, this._needResources[i]["value"]);

            this._resIDArray.push(key);
            this._resCountsArray.push(this._needResources[i]["value"]);

            var itemUI = it.getChildByName("Image_2");
            itemUI.ignoreContentAdaptWithSize(true);
            itemUI.loadTexture(ResMgr.inst()._icoPath + key + "0.png");
            var itemCounts = it.getChildByName('Text_3');
            itemCounts.ignoreContentAdaptWithSize(true);
            itemCounts.setString(this._needResources[i]["value"]);

            //this.resLabelDict[key] = itemCounts;
            this.resCountsDict[key] = this._needResources[i]["value"];
            this.itemDict[key] = it;

            //if (parseInt(this._needResources[i]["value"]) > parseInt(resData[key])) {
            var forbattle = BattleRes.indexOf(key)==-1?false:true;

            var btn = ccui.helper.seekWidgetByName(it, "Button_1");
            btn.addTouchEventListener(this.btnCallback, this);
            btn.setTag(index);
            btn.infoTag = 3;
            var btnTitle = ccui.helper.seekWidgetByName(it, "Text_2");
            btnTitle.ignoreContentAdaptWithSize(true);
            btnTitle.setString(ResMgr.inst().getString("xiangqing_15"));
            //btnTitle.enableOutline(cc.color(0,0,0,255));
            btnTitle = BorderText.replace(btnTitle);
            //}
            //else {
            //    var btn = ccui.helper.seekWidgetByName(it,"Button_1");
            btn.setVisible(!forbattle);
            //}

            //var tokenid =
            var Image_2_1_0 = it.getChildByName("Image_2_1_0");
            Image_2_1_0.setVisible(!forbattle);
            var Image_2_2 = it.getChildByName("Image_2_2");
            Image_2_2.setVisible(!forbattle);
            Image_2_2.setScale(0.8);
            Image_2_2.loadTexture(this.getIconUrl(key));
            var Text_6 = it.getChildByName("Text_6");
            Text_6.ignoreContentAdaptWithSize(true);
            Text_6.setVisible(!forbattle);
            Text_6.setString(0);
            //this.tokenLabelDict[key] = Text_6;
            this.tokenCountsDict[key] = 0;

            //资源是否够……
            if (parseInt(this._needResources[i]["value"]) > parseInt(resData[key])) {
                itemCounts.setTextColor(cc.color(212, 87, 87, 255));
                var itemCheck = it.getChildByName("Image_2_0");
                itemCheck.ignoreContentAdaptWithSize(true);
                itemCheck.loadTexture("xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE);
            }
        }

        size.height = h > size.height ? h : size.height;
        scrollview.setInnerContainerSize(size);
        scrollview.jumpToTop();
    },

    btnCallback: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            SoundPlay.playEffect(ResMgr.inst().getSoundPath(5));
            var tag = sender.getTag();
            //cc.log("touch callback tag ",tag, "id ",this._resIDArray[tag-1]);
            switch (sender.infoTag) {
                case 1:
                    cc.log("加速");
                    ModuleMgr.inst().openModule("AccelerateModule", {
                        id: this._resIDArray[tag - 1],
                        blockId: this._resBlockIndex,
                        collegeId: null,
                        type: 3,
                        time: this.remainTime
                    });
                    break;
                case 2://跳转
                    cc.log("跳转");
                    ModuleMgr.inst().closeModule("UpgradeModule");
                    EventMgr.inst().dispatchEvent(CastleEvent.MOVETO_BUILDING, this._resIDArray[tag - 1]);
                    break;
                case 3:
                    cc.log("获取更多", tag, "id ", this._resIDArray[tag - 1], "value", this._resCountsArray[tag - 1]);
                    ModuleMgr.inst().openModule("TokenModule", {
                        "resid": this._resIDArray[tag - 1],
                        "resnum": this._resCountsArray[tag - 1]
                    });
                    break;
                default :
                    cc.log("default");
                    break;
            }
        }
    },

    scrollCall: function (node, type) {
        if (type == ccui.ScrollView.EVENT_SCROLLING) {
            //this.updateScroll();
        }
    },

    updateScroll: function () {
        var scrollview = this._ui.getChildByName("ScrollView_1");
        var down = this._ui.getChildByName("gy_xiala_01_5_0");
        var up = this._ui.getChildByName("gy_xiala_01_5");

        var scrollSize = scrollview.getContentSize();
        var size = scrollview.getInnerContainerSize();
        var inner = scrollview.getInnerContainer();
        var pos = inner.getPosition();

        up.setVisible(false);
        down.setVisible(false);

        if (size.height <= scrollSize.height) {
            return;
        }

        if (pos.y >= 0 && size.height <= scrollSize.height) {
            up.setVisible(false);
        }
        else {
            up.setVisible(pos.y >= 0 ? false : true);
        }

        var endY = scrollSize.height - size.height;

        down.setVisible(pos.y <= endY ? false : true);
    },

    onExit: function () {
        this._super();
        EventMgr.inst().removeEventListener(CastleEvent.UPGRADE_COMPLETE, this.upgradeCall, this);
        EventMgr.inst().removeEventListener("using_token", this.usingCallback, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
    },

    upgradeCall: function (event, data) {
        this.refreshContent();
    },

    setVoidItem: function (item) {
        var Image_2_1 = item.getChildByName("Image_2_1");
        Image_2_1.setVisible(false);
        var Image_2 = item.getChildByName("Image_2");
        Image_2.setVisible(false);
        var Text_3 = item.getChildByName("Text_3");
        Text_3.setVisible(false);
        var Image_2_0 = item.getChildByName("Image_2_0");
        Image_2_0.setVisible(false);
        var Button_1 = item.getChildByName("Button_1");
        Button_1.setVisible(false);
    },

    //id:资源ID exinfo:还要消耗的资源数量
    usingCallback: function (event, id, counts, exinfo) {
        cc.log("@usingCallback", event, id, counts);
        this.tokenCountsDict[id] = counts;
        var tokenlabel = this.itemDict[id].getChildByName("Text_6");
        tokenlabel.setString(counts);

        if (exinfo < 0) exinfo = 0;
        this.resCountsDict[id] = exinfo;
        var reslabel = this.itemDict[id].getChildByName("Text_3");
        reslabel.setString(exinfo);

        var rescheck = this.itemDict[id].getChildByName("Image_2_0");

        //刷新状态
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
        if (parseInt(exinfo) > parseInt(resData[id])) {
            //不满足
            reslabel.setTextColor(cc.color(212, 87, 87, 255));
            rescheck.loadTexture("xueyuan_cuo.png", ccui.Widget.PLIST_TEXTURE);
        }
        else {
            //满足
            reslabel.setTextColor(cc.color(255, 255, 255, 255));
            rescheck.loadTexture("xueyuan_dui.png", ccui.Widget.PLIST_TEXTURE);
        }
    },

    getIconUrl: function (resid) {
        var url = ResMgr.inst()._icoPath;
        switch (parseInt(resid)) {
            case 1101001:
                url += "11012010.png";
                break;
            case 1101002:
                url += "11012020.png";
                break;
            case 1101003:
                url += "11012030.png";
                break;
        }
        return url;
    },

    netUpdateTime: function (event, data) {
        if (data._index == this._resBlockIndex) {
            var remain = data._state_remain;
            this.remainTime = remain;
        }
    },

    //民房 城内+城外
    getHouseCounts: function () {
        var max = 0;
        var arr = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(1904001);//城内
        for(var i in arr){
            var data = arr[i];
            var configNow = modelMgr.call("Table", "getTableItemByValue", ["City_House", data._building_level]).population_max;
            max += configNow;
        }
        return max;
    }

});