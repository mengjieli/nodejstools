/**
 * Created by cgMu on 2016/1/6.
 */

var AlertGainModule = ModuleBase.extend({
    ctor:function() {
        this._super();
    },

    initUI:function() {

    },

    destroy:function() {
        this._super();
    },

    //获得的礼包或道具 数量 data {"id":1001,"num":100,"type":1,"arr":[ResMgr.inst().getIcoPath(i)]}
    //1:pay
    show:function( data ){
        if(data.type==null && data.arr){
            this.play(data.arr);
        }
        else{
            switch (data.type){
                case 1://pay
                    this.doPay(data);
                    break;
                case 2://bag
                    this.doBag(data);
                    break;
                case 3://sign
                    this.doSign(data);
                    break;
                case 4://task
                    this.doTask(data);
                    break;
            }
        }
    },

    doPay: function (data) {
        var itemid = null;
        var buyid = data.id;
        if(buyid==0){
            itemid =2100033;
        }
        else{
            var d = modelMgr.call("Table", "getTableItemByValue", ["Pay",buyid]);
            var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",d.trading_id ]);
            var temp = itemdata.obtain_item;
            var tempjson = eval("(" + temp + ")");
            for (var i in tempjson) {
                itemid = i;
            }
        }

        var arr = [];
        arr.push(ResMgr.inst().getIcoPath(itemid));
        this.play(arr);
    },

    doBag: function (data) {
        var arr = [];
        var itemid = data.id;//使用的道具ID
        var data = modelMgr.call("Table", "getTableItemByValue", ["item", itemid]);
        if(data.class == 10){
            arr.push(ResMgr.inst().getIcoPath(data.type));
        }
        else{
            if(data.canuse==0) return;

            var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data.canuse ]);
            var temp = itemdata.obtain_item;
            var tempjson = eval("(" + temp + ")");
            for (var i in tempjson) {
                arr.push(ResMgr.inst().getIcoPath(i));
            }
        }
        this.play(arr);
    },

    doSign: function (data) {
        var arr = [];
        var day = data.id;//任务
        if(day==0) day = 7;
        var data = modelMgr.call("Table","getTableItemByValue",["sign",day]);
        var trading_data = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data.trading_id ]);
        var temp = trading_data.obtain_item;
        var tempjson = eval("(" + temp + ")");
        for (var i in tempjson) {
            arr.push(ResMgr.inst().getIcoPath(i));
        }
        this.play(arr);
    },

    doTask:function(data){
        var arr = [];
        var taskId = data.id;//id
        var taskType = data.num;//类型
        var tableName=data.num==1?"task":"task_everyday";
        var taskData = modelMgr.call("Table","getTableItemByValue",[tableName,data.id]);
        if(!taskData){
            cc.error(data.id+"<<<id 取不到任务数据");
            //ModuleMgr.inst().openModule("AlertString",{str:"取不到任务数据  id:"+data.id,color:null,time:null,pos:null});
            return;
        }
        var temp = taskData.task_reward;
        var tempjson = eval("(" + temp + ")");
        for (var i in tempjson) {
            arr.push(ResMgr.inst().getIcoPath(i));
        }
        this.play(arr);
    },

    play: function (array) {
        for(var i in array){
            var num = parseInt(i);
            var p = this.effectPosition(num+1,array.length);
            this.showItem(array[i], p.x, p.y,num+1==array.length);
        }
    },

    //url:icon路径
    showItem: function (url,x,y,close) {
        var size = cc.director.getVisibleSize();
        var csv = ResMgr.inst().getCSV("animationConfig","bag_getItems");
        var effect =new AnimationSprite();
        effect.setPosition(cc.p(x,y));
        effect.setName("bag_getItems");
        effect.setAnimationByCount(csv,1,this.effectCallback,this,effect);
        this.addChild(effect);

        var item = new ccui.ImageView();
        item.loadTexture(url);
        item.setPosition(cc.p(x,y-50));
        item.setScale(0.5);
        this.addChild(item);
        item.runAction( cc.Sequence(
            cc.Spawn(cc.ScaleTo(0.3,1),cc.MoveBy(0.3,cc.p(0,50))),
            cc.MoveTo(0.4,cc.p(size.width*0.5,100)),
            cc.FadeOut(0.1),
            cc.CallFunc(function(){
                if(close){
                    ModuleMgr.inst().closeModule("AlertGainModule");
                }

            })
        ) );
    },

    //index:1+
    effectPosition: function (index,sum) {

        var size = cc.director.getVisibleSize();
        var p = {"x":size.width*0.5,"y":size.height*0.5};
        var t = index;
        if(sum%2==0){
            t = sum / 2;
        }
        else{
            t = (sum+1)/2;
        }
        p.x = p.x + (index-t)*110;
        return p;
    },

    close:function() {

    },

    effectCallback: function (sender) {
        sender.removeFromParent(true);
    }
});