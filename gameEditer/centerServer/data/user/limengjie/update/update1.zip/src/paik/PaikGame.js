function PaikGame() {
    this.ctor.apply(this, arguments);
};

PaikGame.prototype =
{
    txt: null,
    stage: null, 
    bm: null,
    sp: null,
    input: null,
    ctor: function () {
        flower.StageCocos2DX.start();
        var stage = flower.StageCocos2DX.getInstance();
        this.stage = stage;

        this.stage.addChild(this.sp = flower.DisplayObjectContainer.create());
        this.bm = flower.Bitmap.create("res/mm.png");
        this.sp.addChild(this.bm);
        this.bm.x = this.bm.y = 200;

        this.sp.addEventListener(flower.MouseEvent.CLICK, this.click, this);
    },
    loadComplete: function (event) {
        var loader = event.currentTarget;
        loader.data.delCount();
    },
    click: function (e) {
        trace("click", e.mouseX, e.mouseY);

        if (this.sp) {
            this.sp.dispose();
        }
        this.stage.addChild(this.sp = flower.DisplayObjectContainer.create());

        this.input = flower.InputTextField.create(24, 0xff0000, 150, 30);
        this.input.setText("就是个测试而已");
        this.sp.addChild(this.input);
        this.input.setPosition2(100, 100);

        this.sp.addEventListener(flower.MouseEvent.CLICK, this.click, this);
    }
};

PaikGame.run = function () {
    new PaikGame();
};
PaikGame.extend = extendClass;