var ChangeLayer = cc.Sprite.extend({
    shaderLayer: null,
    frontLayer: null,
    data: null,
    config: null,
    list: null,
    //selects: null, //选择的对象
    showClick: null,//显示了菜单
    clickObject: null,//当前点击对象
    clickShowObject: null,//点击显示的特效
    clickShowImage: null,//点击后显示的图片
    clickShowEffect: null,//点击对象特效
    otherShowRangeCastle: null,//其它显示主城范围的主城
    ctor: function (shaderLayer, frontLayer) {
        this._super();
        this.shaderLayer = shaderLayer;
        this.frontLayer = frontLayer;
        this.list = [];
        //this.selects = [];
        this.config = ServerMapConfig.getInstance();
        this.data = mainData.mapData;
        this.data.armyList.addListener("add", this.addRoler, this);
        this.data.armyList.addListener("del", this.delObject, this);
        this.data.castleList.addListener("add", this.addBuild, this);
        this.data.castleList.addListener("del", this.delObject, this);
        this.data.resourceList.addListener("add", this.addResouce, this);
        this.data.resourceList.addListener("del", this.delObject, this);
        mainData.uiData.addListener("closeTileMenu", this.onCloseTileMenu, this);
        mainData.uiData.map.addListener("shineGrid",this.showShineGrid,this);
        jc.EnterFrame.add(this.update, this);
        if (mainData.playerData.guide) {
            var arrJudgeGuide = ["2_2", "2_8", "2_14", "3_1", "4_4", "4_6"];//引导 半身像对话
            if (arrJudgeGuide.indexOf(mainData.playerData.guide) != -1) ModuleMgr.inst().openModule("GuideModule", {id: mainData.playerData.guide});
        }
    },
    update: function (dt) {
        var arr = this.list;
        //从大到小排序
        arr.sort(function (a, b) {
            return (a.py == b.py) ? (a.px == b.px ? 0 : (a.px < b.px ? 1 : -1)) : (a.py < b.py ? 1 : -1);
        });
        //for(var i = 0; i < arr.length; i++) {
        //    trace("排序后：",i,arr[i].data.name,arr[i].py);
        //}
        var len = arr.length;
        for (var i = 0; i < len; i++) {
            var item = arr[i];
            item.setLocalZOrder(i);
        }
    },
    updateShow: function (camera) {
        this.setPosition(-camera.x, -camera.y);
        //移除范围之外的对象
        for (var i = 0; i < this.list.length; i++) {
            var item = this.list[i];
            if (item.px > camera.x - 200 && item.px < camera.x + camera.width + 200 &&
                item.py > camera.y - 200 && item.py < camera.y + camera.height + 200) {

            } else {
                this.list.splice(i, 1);
                i--;
                item.dispose();
            }
        }

        var buildList = this.data.castleList;
        var rolerList = this.data.armyList;
        var resourceList = this.data.resourceList;
        var find;
        for (var i = 0; i < buildList.length; i++) {
            var build = buildList.getItemAt(i);
            if (build.showX > camera.x - 200 && build.showX < camera.x + camera.width + 200 &&
                build.showY > camera.y - 200 && build.showY < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    //trace("比较",this.list.length,f,this.list[f].data.name,build.name);
                    if (this.list[f].data == build) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    trace("添加建筑");
                    var build = new MapBuild(this.shaderLayer, build);
                    this.addChild(build);
                    this.list.push(build);
                }
            }
        }
        for (var i = 0; i < rolerList.length; i++) {
            var rolerData = rolerList.getItemAt(i);
            if (rolerData.castleId == mainData.uiData.currentCastleId ||
                rolerData.showX > camera.x - 200 && rolerData.showX < camera.x + camera.width + 200 &&
                rolerData.showY > camera.y - 200 && rolerData.showY < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    //trace("比较",this.list.length,f,this.list[f].data.name,build.name);
                    if (this.list[f].data == rolerData) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    trace("添加部队");//,flower.ObjectDo.toString(rolerData));
                    var roler = new MapRoler(this.shaderLayer, rolerData);
                    this.addChild(roler);
                    this.list.push(roler);
                }
            }
        }
        for (var i = 0; i < resourceList.length; i++) {
            var resourceData = resourceList.getItemAt(i);
            if (resourceData.showX > camera.x - 200 && resourceData.showX < camera.x + camera.width + 200 &&
                resourceData.showY > camera.y - 200 && resourceData.showY < camera.y + camera.height + 200) {
                find = false;
                for (var f = 0; f < this.list.length; f++) {
                    //trace("比较",this.list.length,f,this.list[f].data.name,build.name);
                    if (this.list[f].data == resourceData) {
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    trace("添加资源");
                    var resource = new MapResource(this.shaderLayer, resourceData);
                    this.addChild(resource);
                    this.list.push(resource);
                }
            }
        }
    },
    addRoler: function (roler) {
        //var roler = new MapRoler(this.shaderLayer, rolerData);
        //this.addChild(roler);
        //this.list.push(roler);
        var camera = MapCamera.getInstance();
        if (roler.showX > camera.x - 100 && roler.showX < camera.x + camera.width + 100 &&
            roler.showY > camera.y - 100 && roler.showY < camera.y + camera.height + 100) {
            this.updateShow(camera);
        }
    },
    addBuild: function (build) {
        var camera = MapCamera.getInstance();
        if (build.showX > camera.x - 200 && build.showX < camera.x + camera.width + 200 &&
            build.showY > camera.y - 200 && build.showY < camera.y + camera.height + 200) {
            this.updateShow(camera);
        }
    },
    addResouce: function (resourceData) {
        var camera = MapCamera.getInstance();
        //trace("添加了资源:", resourceData.showX, resourceData.showY,camera.x,camera.y,camera.width,camera.height);
        if (resourceData.showX > camera.x - 200 && resourceData.showX < camera.x + camera.width + 200 &&
            resourceData.showY > camera.y - 200 && resourceData.showY < camera.y + camera.height + 200) {
            this.updateShow(camera);
        }
    },
    delObject: function (data) {
        //for (var i = 0; i < this.selects.length; i++) {
        //    if (this.selects[i].data == data) {
        //        this.selects.splice(i, 1);
        //        i--;
        //    }
        //}
        for (var i = 0; i < this.list.length; i++) {
            if (this.list[i].data == data) {
                trace("找到删除的资源啦!");
                var resource = this.list.splice(i, 1)[0];
                resource.dispose();
                break;
            }
        }
    },
    dragMap: function () {
        if (this.showClick) {
            this.closeSelect();
            return;
        }
    },
    onCloseTileMenu: function () {
        mainData.uiData.map.shineGrid = "";
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
        mainData.uiData.clickMenuVisible = false;
        //if (this.showClick) {
        //    this.closeSelect();
        //    return;
        //}
    },
    showShineGrid:function() {
        if (this.clickShowObject) {
            this.clickShowObject.getParent().removeChild(this.clickShowObject);
            this.clickShowObject = null;
        }
        if(this.clickShowImage) {
            this.clickShowImage.getParent().removeChild(this.clickShowImage);
            this.clickShowImage = null;
        }
        if (this.clickShowEffect) {
            this.clickShowEffect.dispose();
            this.clickShowEffect = null;
        }
        if(mainData.uiData.map.showImage) {
            this.clickShowImage = new cc.Sprite("res/fight/ui/" + mainData.uiData.map.showImage + ".png");
            this.addChild(this.clickShowImage);
            this.clickShowImage.setPosition(mainData.uiData.map.shineGridX, mainData.uiData.map.shineGridY);
        }
        if(mainData.uiData.map.shineGrid != "") {
            this.clickShowObject = new cc.Sprite("res/fight/ui/" + mainData.uiData.map.shineGrid + ".png");
            this.addChild(this.clickShowObject);
            this.clickShowObject.setPosition(mainData.uiData.map.shineGridX, mainData.uiData.map.shineGridY);
            this.clickShowEffect = new EarthEffect(this.clickShowObject);
        }
    },
    showEarthEffect: function (position, earthData) {
        if (earthData) {
            if (earthData.user == mainData.playerData.account) {
                this.clickShowObject = new cc.Sprite("res/fight/ui/selectEarth.png");
            } else {
                this.clickShowObject = new cc.Sprite("res/fight/ui/selectEarthOther.png");
            }
        } else {
            this.clickShowObject = new cc.Sprite("res/fight/ui/selectEarth.png");
            this.clickShowObject.scaleY = 78 / 104;
        }
        this.addChild(this.clickShowObject);
        this.clickShowObject.setPosition(position.x, position.y);
        this.clickShowEffect = new EarthEffect(this.clickShowObject);
    },
    closeSelect: function () {
        //if (this.showClick != false && this.showClick != true && this.showClick && this.showClick.type == MapDisplayType.Build) {
        //    if (!this.showClick.isMyCastle()) {
        //        this.showClick.showRange(false);
        //    }
        //}
        this.showClick = false;
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
        if (this.clickShowObject) {
            this.clickShowObject.getParent().removeChild(this.clickShowObject);
            this.clickShowObject = null;
        }
        if (this.clickShowEffect) {
            this.clickShowEffect.dispose();
            this.clickShowEffect = null;
        }
    },
    dispose: function () {
        this.closeSelect();
        while (this.list.length) {
            this.list.pop().dispose();
        }
        jc.EnterFrame.del(this.update, this);
        MapBuild.showCastleRange = {};
        mainData.uiData.map.shineGrid = "";
        this.data.armyList.removeListener("add", this.addRoler, this);
        this.data.armyList.removeListener("del", this.delObject, this);
        this.data.castleList.removeListener("add", this.addBuild, this);
        this.data.castleList.removeListener("del", this.delObject, this);
        this.data.resourceList.removeListener("add", this.addResouce, this);
        this.data.resourceList.removeListener("del", this.delObject, this);
        mainData.uiData.removeListener("closeTileMenu", this.onCloseTileMenu, this);
        mainData.uiData.map.removeListener("shineGrid",this.showShineGrid,this);
    }
});