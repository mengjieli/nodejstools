﻿/**
 * Created by yx on 2015/10/26/0026.
 */

var CastleModule = ModuleBase.extend({

    _castleData:null,//data数据
    _arrBlock:null,//地块数组
    _arrIconTf:null,//地块数组

    _bgLayer:null,//远景底图
    _effectBgLayer:null,//背景特效层
    _bottomLayer:null,//近景底图
    _effectBottomLayer:null,//地面特效层
    _buildingLayer:null,//建筑物层
    _effectTopLayer:null,//顶层特效层
    _iconTfLayer:null,//图标文本层//
    _testLayer:null,//测试按钮层

    _immigrant:null,//移民
    _immigrant_up:null,//移民上感叹号
    _immigrant_down:null,//移民下光圈
    _touchArea:null,//移民点击
    _effImmigrant:null,//移民提示特效
    _lvCastle:null,//领主府等级记录

    _cameraPos: null,        //背景图摄像机坐标
    _cameraPos2: null,        //远景背景图摄像机坐标
    _cameraPosInit2: null,        //远景背景图初始点摄像机坐标

    _scaleValue:null,//缩放倍率
    _selectBlock:null,//选中的地块建筑

    _interval:null,//动作特效随机时间
    _isInterval:null,//是否存在特效

    _size:null,//屏幕尺寸

    _isMoveToBuilding:null,//是否在移动到建筑物缓动中
    _intervalMoveToBuilding:null,//移动到建筑物缓动interval

    _isTest:false,//测试用true
    _isTest2:false,//测试用true
    _arrTest:[1906001,1907001,1903001,1913001,1913002,1901001,1909001,1911001,1910001,1902001,1902002,1902003,1902004,1904001],//这些建筑以外的建筑点击未开放
    _arrTest2:[1,6,7,8,17],//初始建筑///
    _arrTest3:[1915001,1911001,1910001,1912001,1909001],//初始建筑///


    ctor: function ()
    {
        this._super();
    },

    initUI: function ()
    {
        cc.log("主城堡initUI 初始化  当前金币值：",ModuleMgr.inst().getData("ItemModule").getCountsByItemId(1103001));
        //this.anchorX=this.anchorY=0;
        ChatModule.ISSCALE=true;//可以缩放 屏蔽false
        this._size = cc.director.getVisibleSize();
        if(this._isTest2){
            this.test2();
            return;
        }

        //EventMgr.inst().dispatchEvent( CastleEvent.UPDATE_RESOURCE);
        //建筑物地块数据  修改
        this._castleData = ModuleMgr.inst().getData("CastleModule");
        this.scale=this._castleData._scaleValue=this._scaleValue=1;//this.scale=

        mainData.mapData.myArmyList.addListener("add",this.addFun,this)

        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().addEventListener(CastleEvent.MOVETO_BUILDING, this.moveToBuilding, this);//屏幕锁定到建筑坐标
        EventMgr.inst().addEventListener(CastleEvent.MOVETO_POS, this.moveToPosDispatch, this);//屏幕锁定到坐标
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_TECH_TIME, this.netUpdateTechTime, this);//1903001学院
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_TECH, this.netUpdateTech, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_ARMYTRAIN_TIME, this.netUpdateArmyTrainTime, this);//兵营训练信息
        EventMgr.inst().addEventListener(CastleEvent.REMOVE_ARMYTRAIN, this.netRemoveArmyTrain, this);//移除兵营训练
        EventMgr.inst().addEventListener(CastleEvent.TECH_UPGRADE_COMPLETE, this.netTechUpgradeComplete, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BUILDING, this.netUpdateBuilding, this);
        EventMgr.inst().addEventListener(CastleEvent.UPGRADE_COMPLETE, this.netUpgradeComplete, this);

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);//请求成功返回


        //150B80D2-5A50-0009-DE4C-30748E7EC20F
        //150B80E7-2950-0009-DEB0-93B673677553
        //150B80EB-B720-0009-DEB9-FF9AAE0DB2CC


        //cc.eventManager.addListener(
        //    {
        //        event: cc.EventListener.TOUCH_ONE_BY_ONE,
        //        swallowTouches: true,
        //        onTouchBegan: this.onTouchBegan.bind(this),
        //        onTouchMoved: this.onTouchMoved.bind(this),
        //        onTouchEnded: this.onTouchEnded.bind(this)
        //    },
        //    this);
        cc.eventManager.addListener(//和单点有冲突
            {
                prevTouchId: -1,
                event: cc.EventListener.TOUCH_ALL_AT_ONCE,
                swallowTouches: true,
                onTouchesBegan: this.onTouchBegan.bind(this),//onTouchesBegan
                onTouchesMoved: this.onTouchMoved.bind(this),//onTouchesMoved
                onTouchesEnded: this.onTouchEnded.bind(this)//onTouchesEnded
            },
            this);


        this._isMove=false;

        this._bgLayer = new cc.Layer();
        this.addChild(this._bgLayer);
        this._effectBgLayer = new cc.Layer();
        this.addChild(this._effectBgLayer);

        this._bottomLayer = new cc.Layer();
        this.addChild(this._bottomLayer);
        this._effectBottomLayer = new cc.Layer();
        this.addChild(this._effectBottomLayer);

        this._buildingLayer = new cc.Layer();
        this.addChild(this._buildingLayer);

        //最顶层
        this._effectTopLayer = new cc.Layer();
        this.addChild(this._effectTopLayer);
        //倒计时图标层
        this._iconTfLayer=new cc.Layer();
        this.addChild(this._iconTfLayer);
        //设置锚点用于缩放
        this._bgLayer.anchorX=this._bgLayer.anchorY=this._effectBgLayer.anchorX=this._effectBgLayer.anchorY=this._bottomLayer.anchorX=this._bottomLayer.anchorY=this._effectBottomLayer.anchorX=this._effectBottomLayer.anchorY
        =this._buildingLayer.anchorX=this._buildingLayer.anchorY=this._effectTopLayer.anchorX=this._effectTopLayer.anchorY=this._iconTfLayer.anchorX=this._iconTfLayer.anchorY=0;
        //this.anchorX=this.anchorY=0;
        //特效层部分

        //瀑布
        var arr=["castle_waterfall_l","castle_waterfall_l","castle_waterfall_s_wide","castle_waterfall_s_wide","castle_waterfall_s",//castle_waterfall_m
            "castle_eagle","castle_fish","castle_rabbit_rightup","castle_rabbit_rightdown","castle_rabbit_leftup","castle_rabbit_leftdown",
            "castle_snake_leftup","castle_frog_stand_rightup","castle_out_train","castle_out_train","castle_out_train","castle_out_train","castle_out_train","castle_out_train",
            "castle_guard_stand","castle_guard_stand","castle_fish"
        ];
        //,"castle_frog_move_rightup",
        var arrP=[cc.p(485,1240),cc.p(1905,1390-55),cc.p(1940,1100),cc.p(1815,610),cc.p(2140,462),
            cc.p(500,1100),cc.p(1600,585),cc.p(1730,700),cc.p(1730,685),cc.p(1700,700),cc.p(1700,685),
            cc.p(1900,710),cc.p(1850,700),cc.p(290,715),cc.p(300,710),cc.p(310,705),cc.p(275,705),cc.p(285,700),cc.p(295,695),
            cc.p(710,580),cc.p(830,520),cc.p(1855,540)
        ];//,cc.p(1824,600)
        for(var i=0;i<arr.length;i++){
            //cc.log(arr[i]+"name")
            var csvEffect = ResMgr.inst().getCSV("animationConfig",arr[i]);
            var animate=new AnimationSprite();
            //animate.setName(arr[i]);
            animate.setAnimationByCount(csvEffect);
            animate.setPosition(arrP[i]);
            if(i==1) {
                animate.scaleX=0.8;
                animate.scaleY=1;
            }//特殊处理
            //animate.setBlendFunc(gl.ONE,gl.ONE);
            if(i==3) animate.scaleX=-1;
            //if(i==13) this._effectTopLayer.addChild(animateMove);
            this._effectBottomLayer.addChild(animate);
            //cc.log(animate+"animate"+i+"iiii");
        }
        //随机移动巡逻类特效
        var ranMove=parseInt(Math.random()*2);
        if(ranMove>-1){
            var patrolMove=new AnimationMove();
            patrolMove.initMove("castle_soldier_patrol_",[[cc.p(870,670),cc.p(1170,810)],[cc.p(1170,810),cc.p(1250,760)],[cc.p(1250,760),cc.p(950,610)],[cc.p(950,610),cc.p(870,670)]],[15,4,15,4],1,0);
            this._effectBottomLayer.addChild(patrolMove);
            var layer=this._effectBottomLayer;
            setTimeout(function(){
                var patrolMove=new AnimationMove();
                patrolMove.initMove("castle_soldier_patrol_",[[cc.p(870,670),cc.p(1170,810)],[cc.p(1170,810),cc.p(1250,760)],[cc.p(1250,760),cc.p(950,610)],[cc.p(950,610),cc.p(870,670)]],[15,4,15,4],1,0);
                layer.addChild(patrolMove);
            },500);
            setTimeout(function(){
                var patrolMove=new AnimationMove();
                patrolMove.initMove("castle_soldier_patrol_",[[cc.p(870,670),cc.p(1170,810)],[cc.p(1170,810),cc.p(1250,760)],[cc.p(1250,760),cc.p(950,610)],[cc.p(950,610),cc.p(870,670)]],[15,4,15,4],1,0);
                layer.addChild(patrolMove);
            },1000);
        }else{
            var patrolMove1=new AnimationMove();
            patrolMove1.initMove("castle_soldier_patrol_",[[cc.p(870,670),cc.p(1170,810)],[cc.p(1170,810),cc.p(1250,760)],[cc.p(1170,810),cc.p(870,670)],[cc.p(950,610),cc.p(870,670)]],[15,4,15,4],2,0);
            this._effectBottomLayer.addChild(patrolMove1);
            var patrolMove2=new AnimationMove();
            patrolMove2.initMove("castle_soldier_patrol_",[[cc.p(950,610),cc.p(1250,760)],[cc.p(1170,810),cc.p(1250,760)],[cc.p(1250,760),cc.p(950,610)],[cc.p(950,610),cc.p(870,670)]],[15,4,15,4],2,2);
            this._effectBottomLayer.addChild(patrolMove2);
        }
        //1170,810  -220  100
        var ranMove1=parseInt(Math.random()*2);
        if(ranMove1==1){
            var patrolMove1=new AnimationMove();
            patrolMove1.initMove("castle_soldier_patrol_",[[cc.p(870,670),cc.p(1170,810)],[cc.p(770,1010),cc.p(950,915)],[cc.p(1170,810),cc.p(870,670)],[cc.p(950,915),cc.p(770,1010)]],[15,10,15,10],2,1);
            this._effectBottomLayer.addChild(patrolMove1);
        }
        //test显隐
        //var patrolMove1=new AnimationMove();
        //patrolMove1.initMovePathTime("castle_soldier_patrol_",[cc.p(870,670),cc.p(1170,810),cc.p(1250,760),cc.p(950,610)],[4,2,4],true,false);
        //patrolMove1.initMovePathSpeed("castle_soldier_patrol_",[cc.p(870,670),cc.p(1170,810),cc.p(1250,760),cc.p(950,610)],100,true,false);
        //this._effectBottomLayer.addChild(patrolMove1);
        //var testDis= MathUtils.twoPointsDistance(cc.p(100,100),cc.p(50,50));
        //cc.error("test dis"+testDis);


        if(this._interval==null)  this._interval = setInterval(this.animationInterVal, 5*1000,this);

        //云
        for(var i=0;i<7;i++){
            //cc.log("castle/castlecloud"+(i+1)+".png");
            var cloud=new ccui.ImageView("castle/castlecloud"+(i+1)+".png",ccui.Widget.PLIST_TEXTURE);
            //var cloud=new ccui.ImageView("castle/dikuai_01.png",ccui.Widget.PLIST_TEXTURE);
            //cloud.x=100*i;
            cloud.x=CastleModule.COLUMN*CastleModule.GRID_WIDTH+cloud.width/2;
            cloud.y=CastleModule.ROW*CastleModule.GRID_HEIGHT-cloud.height/2+i*20;
            if(i==1||i==2)  cloud.y=900;
            //cloud.x=i*100;
            if(i==0) {
                //cloud.anchorX=0;
                cloud.scaleX=cloud.scaleY=5;
                this._effectBgLayer.addChild(cloud);
            }
            else {
                this._effectTopLayer.addChild(cloud);
            }
            this.createAction(cloud,i==0?60:(40+i*3),cc.p( cloud.x,cloud.y),cc.p( -cloud.width/2,cloud.y));//cc.p( cloud.x,cloud.y)
        }
        //测试层
        if(this._isTest){

            this._testLayer = new cc.Layer();
            this.addChild(this._testLayer);
            for(var i=0;i<4;i++){
                var touchArea= new ccui.Layout();
                touchArea.setBackGroundColorType(ccui.Layout.BG_COLOR_SOLID);
                touchArea.setContentSize( cc.size(30,20) );
                touchArea.setBackGroundColor(cc.color(100,100,100,255));
                touchArea.index=i;
                touchArea.setTouchEnabled(true);
                touchArea.addTouchEventListener(this.onTestTouch,this);
                this._testLayer.addChild(touchArea);
                touchArea.setPosition(cc.p(250+35*i,140));
            }
        }


        //摄像机显示部分
        this.moveToPos(500, 500);//750
        cc.log(this.anchorX+"this. anchorx))))))))))))))"+this.anchorY);
        //背景部分
        this.showMap();
        cc.audioEngine.stopMusic();

        //cc.audioEngine.setMusicVolume(0.1);
        SoundPlay.playMusic( ResMgr.inst().getSoundPath(2));


        //SoundPlay.playEffectLoop( ResMgr.inst().getSoundPath(32));
        //SoundPlay.playMusic( ResMgr.inst().getSoundPath(34));

    },


    show:function( data )
    {
        //ModuleMgr.inst().openModule("ChatModule");
        if(this._isTest2) return;
        cc.log(" 主城堡一级地图打开  show------------"+this._castleData._currentCastleId);
        //if(this._buildingLayer==null) {
        //    cc.log("return 掉 测试用")
        //    return;
        //}
        this.showBlock();
        //cc.log("城堡发送请求信息 城堡id"+this._castleData._currentCastleId);
        if(this._castleData._currentCastleId){
            var msg = new SocketBytes();
            msg.writeUint(CastleNetEvent.SEND_CASTLE);
            msg.writeString(this._castleData._currentCastleId);
            NetMgr.inst().send(msg);
            mainData.uiData.showCastleFinish = true;
        }
        //特殊处理
        //this.setLayerPos(this._cameraPos);
        //this.setBgLayerPos(this._cameraPos2);

    },
    //背景 远景近景 显示
    showMap:function()
    {
        //var img=new ccui.ImageView(MapModule.bottomPath+id+".png");
        for(var i=0;i<2;i++){
            for(var j=0;j<CastleModule.COLUMN*2;j++){
                var urlbg="castle/castlebg_" + i+"_"+j+ ".png";
                var imgbg=new ccui.ImageView();
                imgbg.ignoreContentAdaptWithSize(false);
                imgbg.loadTexture(urlbg,ccui.Widget.PLIST_TEXTURE);
                imgbg.anchorX=imgbg.anchorY=0;
                //imgbg.scaleX=imgbg.scaleY=2;
                var sizebg = imgbg.getContentSize();
                sizebg.width =CastleModule.GRID_WIDTH/2+1.5;//0.5
                sizebg.height =CastleModule.BG_GRID_HEIGHT/2+1.5;//0.5
                imgbg.setSize(sizebg);
                imgbg.x=j*CastleModule.GRID_WIDTH/2;
                imgbg.y=CastleModule.ROW*CastleModule.GRID_HEIGHT-CastleModule.BG_GRID_HEIGHT+i*(CastleModule.BG_GRID_HEIGHT/2);//-CastleModule.BG_GRID_HEIGHT/2   //+i*(CastleModule.BG_GRID_HEIGHT/2)
                //cc.log(i+"bg"+j+">>>")
                this._bgLayer.addChild(imgbg);
            }

        }

        for(var i=0;i< CastleModule.ROW;i++) {
            for (var j = 0; j < CastleModule.COLUMN; j++) {
                var url="castle_" + i+"_"+j + ".png";//castle/
                var img=new ccui.ImageView();
                img.ignoreContentAdaptWithSize(false);
                img.loadTexture(url,ccui.Widget.PLIST_TEXTURE);
                img.anchorX=img.anchorY=0;
                var size = img.getContentSize();
                size.width =CastleModule.GRID_WIDTH+0.5;
                size.height =CastleModule.GRID_HEIGHT+0.5;
                img.setSize(size);
                img.x=j*CastleModule.GRID_WIDTH;
                img.y=i*CastleModule.GRID_HEIGHT;
                this._bottomLayer.addChild(img);
                //cc.log( size.width +"w h" + size.height)
                //cc.log(img.x+"xy"+img.y)

            }
        }
    },

    //地块 建筑显示部分 默认建筑
    showBlock:function()
    {
        //cc.log("show block"+this._castleData.getNetBlock(null));
        if(this._arrBlock==null) this._arrBlock={};
        if(this._arrIconTf==null) this._arrIconTf={};
        for (var i in this._castleData.getNetBlock(null)){
            //cc.log("showBlock初始化地块",this._castleData.getNetBlock(null)[i])
            var blockBean=new CastleBlockBeanCSV(this._castleData._arrBlockBean[i]._data);
            //if(blockBean._index>19) continue;//超过19暂时屏蔽
            var url="castle/" + blockBean._res;
            var img=new Castle_Block();
            img._blockBean=blockBean;
            //cc.log(this._buildingLayer,"blockBean$$$$",blockBean._index,blockBean._building_id);
            img.initTouchArea();
            if(blockBean._res==0||blockBean._res==""){
            }
            else {
                img.initBlock(url,blockBean._index);
                //cc.log(url+"####################showBlock"+blockBean._index)
            };
            img.x=blockBean._x;
            img.y=blockBean._y;
            var icon=new CastleTimeIcon();//图标
            this._iconTfLayer.addChild(icon);
            //icon.setPosition(cc.p(img.x,img.y));
            icon.x=img.x;
            icon.y=img.y;
            this._buildingLayer.addChild(img);
            img._touchArea.addTouchEventListener(this.onBlockTouch,this);

            //img.setTouchEnabled(true);
            //img.setPropagateTouchEvents(true);
            //img.addTouchEventListener(this.onBlockTouch,this);
            this._arrBlock[blockBean._index]=img;
            this._arrIconTf[blockBean._index]=icon;

            //================特殊处理 默认创建某些特殊建筑==================
            if(this._arrTest2.indexOf(Number(blockBean._index))!=-1){
                this._arrBlock[blockBean._index].createBuilding(this._arrTest3[this._arrTest2.indexOf(Number(blockBean._index))]);
                this._arrBlock[blockBean._index].updateBuilding(this._castleData.getNetBlock(null)[i]);
                this._arrIconTf[blockBean._index].updateBuilding(this._castleData.getNetBlock(null)[i]);
            }
        }
        //暂时特殊处理 显示无地块的建筑
        //移民建筑特殊
        //if(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId).length > 1) {
        //    //表示当前城堡已经建立了子城堡
        //}
        //else{
        //
        //}
        var csvEffect_down = ResMgr.inst().getCSV("animationConfig","castle_immigrant_down");
        this._immigrant_down=new AnimationSprite();
        this._immigrant_down.setAnimationByCount(csvEffect_down);
        this._immigrant_down.setPosition(cc.p(1732,930));
        var csvEffect = ResMgr.inst().getCSV("animationConfig","castle_immigrant");
        this._immigrant=new AnimationSprite();
        this._immigrant.setAnimationByCount(csvEffect);
        this._immigrant.setPosition(cc.p(1732,924));
        var csvEffect_up = ResMgr.inst().getCSV("animationConfig","castle_immigrant_up");
        this._immigrant_up=new AnimationSprite();
        this._immigrant_up.setAnimationByCount(csvEffect_up);
        this._immigrant_up.setPosition(cc.p(1732,980));

        var csvHand = ResMgr.inst().getCSV("animationConfig","guide_handtouch");
        this._effImmigrant=new AnimationSprite();
        //this._effImmigrant.setName("guide_handtouch");
        this._effImmigrant.setAnimationByCount(csvHand);
        this._effImmigrant.setPosition(cc.p(1732,924));
        //cc.log("%%%%%%%%%%%%%%%%%%init移民特效#@@@@@@@@");

        this._touchArea= new ccui.Layout();
        this._touchArea.setBackGroundColorType(ccui.Layout.BG_COLOR_SOLID);
        this._touchArea.setContentSize( cc.size(40,40) );
        this._touchArea.setBackGroundColor(cc.color(100,100,100,255));
        this._touchArea.setPosition(cc.p(1732,924));
        this._touchArea.anchorX=this._touchArea.anchorY=0.5;
        this._touchArea.setTouchEnabled(true);
        this._touchArea.addTouchEventListener(this.onImmigrantTouch,this);
        this._touchArea.setOpacity(0);
        this._buildingLayer.addChild(this._immigrant_down);
        this._buildingLayer.addChild(this._immigrant);
        this._buildingLayer.addChild(this._immigrant_up);
        this._buildingLayer.addChild(this._effImmigrant);
        this._buildingLayer.addChild(this._touchArea);
        this._immigrant_down.setVisible(false);
        this._immigrant.setVisible(false);
        this._immigrant_up.setVisible(false);
        this._effImmigrant.setVisible(false);
        this._touchArea.setVisible(false);


    },
    //缓动到指定位置坐标
    easeToPos:function(x,y){
        this._cameraPos=cc.p(x,y);
        this._cameraPos2=cc.p(x,y);
        var size = cc.director.getVisibleSize();
        var limith=CastleModule.GRID_HEIGHT*CastleModule.ROW*this._scaleValue-size.height;//缩放倍率
        this._cameraPos2.y=limith-(limith-this._cameraPos2.y)/CastleModule.MOVE_SPEED;
        this._cameraPosInit2=cc.p(this._cameraPos.x, this._cameraPos.y);
        this.judgeEdge(this._cameraPos,this._cameraPos2);//判断边界
        var arrLayer=[this._bottomLayer,this._buildingLayer,this._effectBottomLayer,this._effectTopLayer,this._iconTfLayer];
        var arrBgLayer=[this._bgLayer,this._effectBgLayer];
        for(var i=0;i<arrLayer.length;i++){
            var move=cc.moveTo(0.5,cc.p(-this._cameraPos.x,-this._cameraPos.y) );
            if(arrLayer[i])arrLayer[i].runAction(move);
        }
        for(var i=0;i<arrBgLayer.length;i++){
            var moveBg=cc.moveTo(0.5,cc.p(-this._cameraPos2.x,-this._cameraPos2.y) );
            if(arrBgLayer[i])arrBgLayer[i].runAction(moveBg);
        }
        this._intervalMoveToBuilding = setTimeout(this.doMoveToBuildingInterval, 0.5, this);
        this.updateMovePos();
    },
    doMoveToBuildingInterval:function(owner){
        owner._isMoveToBuilding=false
        clearTimeout(owner._intervalMoveToBuilding);
    },
    //屏幕显示到制定位置
    moveToPos:function(x,y){
        this._cameraPos=cc.p(x,y);
        this._cameraPos2=cc.p(x,y);
        var size = cc.director.getVisibleSize();
        var limith=CastleModule.GRID_HEIGHT*CastleModule.ROW*this._scaleValue-size.height;//缩放倍率
        this._cameraPos2.y=limith-(limith-this._cameraPos2.y)/CastleModule.MOVE_SPEED;
        this._cameraPosInit2=cc.p(this._cameraPos.x, this._cameraPos.y);
        this.setCameraPos(this._cameraPos,this._cameraPos2);


    },
    //移屏设置屏幕窗口坐标
    setCameraPos:function(pos,pos2)
    {
        //cc.error(pos.x+"设置XY摄像机setCameraPosxy"+pos.y+"x2>"+pos2.x+"y2>"+pos2.y);
        this.judgeEdge(pos,pos2);//判断边界
        //缓动偏移量
        var offPos= MathUtils.pointSubtract(pos,this._cameraPos);
        this._offPos=MathUtils.pointAdd(pos,offPos);
        var offPos2 = MathUtils.pointSubtract(pos2,this._cameraPos2);
        this._offPos2=MathUtils.pointAdd(pos2,offPos2);
        //this.judgeEdge(this._offPos,this._offPos2);//判断边界  缓动二次判断？
        //赋值摄像机坐标
        this._cameraPos=pos;
        this._cameraPos2=pos2;
        //cc.log(pos.x+"setCameraPos *****************pos2.y@@@@@@@@@@@@@@");
        this.setLayerPos(pos);
        this.setBgLayerPos(pos2);
        //cc.log(this._bottomLayer.x+"底部实际x *****************pos2.y@@@@@@@@@@@@@@");

        this.updateMovePos();
    },
    //判断调整摄像机边界坐标
    judgeEdge:function(pos,pos2){
        var size = cc.director.getVisibleSize();
        //var limitw=CastleModule.GRID_WIDTH*CastleModule.COLUMN-size.width;//缩放倍率
        //var limith=CastleModule.GRID_HEIGHT*CastleModule.ROW-size.height;//缩放倍率
        var limitw=CastleModule.GRID_WIDTH*CastleModule.COLUMN*this._scaleValue-size.width;//缩放倍率
        var limith=CastleModule.GRID_HEIGHT*CastleModule.ROW*this._scaleValue-size.height;//缩放倍率
        //cc.error(limitw+"limitw"+pos.x+"posxy"+pos.y);
        //cc.log(CastleModule.GRID_WIDTH*CastleModule.COLUMN*(1-this._scaleValue)+"偏移量"+CastleModule.GRID_HEIGHT*CastleModule.ROW*(1-this._scaleValue));
        //if(this._touchMidPoint)  cc.log(CastleModule.GRID_WIDTH*CastleModule.COLUMN*(1-this._scaleValue)*this._touchAnchorX+"差值 缩放"+CastleModule.GRID_HEIGHT*CastleModule.ROW*(1-this._scaleValue)*this._touchAnchorY);//*this._touchAnchorX
        var posXL=0;
        var posXR=limitw;
        var posYD=0;
        var posYU=limith;
        if(pos.x<posXL) pos.x=posXL;
        else if(pos.x>posXR)  pos.x=posXR;
        if(pos.y<posYD) pos.y=posYD;
        else if(pos.y>posYU)  pos.y=posYU;
        //if(pos2.x<(this._cameraPosInit2.x)/CastleModule.MOVE_SPEED) pos2.x=(this._cameraPosInit2.x)/CastleModule.MOVE_SPEED;
        //if(pos2.x< this._cameraPosInit2.x-(this._cameraPosInit2.x)/CastleModule.MOVE_SPEED) pos2.x=this._cameraPosInit2.x-(this._cameraPosInit2.x)/CastleModule.MOVE_SPEED;
        //else if(pos2.x>this._cameraPosInit2.x+(limitw-this._cameraPosInit2.x)/CastleModule.MOVE_SPEED)  pos2.x=this._cameraPosInit2.x+(limitw-this._cameraPosInit2.x)/CastleModule.MOVE_SPEED;


        var pos2LimitL=(this._cameraPosInit2.x-(this._cameraPosInit2.x)/CastleModule.MOVE_SPEED);
        if(this._scaleValue!=1) pos2LimitL=0;
        //if(this._scaleValue>1) pos2LimitL=pos2LimitL*this._scaleValue;
        var pos2LimitR=this._cameraPosInit2.x+(limitw-this._cameraPosInit2.x)/CastleModule.MOVE_SPEED;
        if(this._scaleValue!=1) pos2LimitR=this._cameraPosInit2.x*this._scaleValue+(limitw-this._cameraPosInit2.x*this._scaleValue)/CastleModule.MOVE_SPEED;
        //if(this._scaleValue>1) pos2LimitR=pos2LimitR*this._scaleValue;
        //cc.error(pos.x+"pos xy"+pos.y);
        //cc.error(pos2LimitL+"lr"+pos2LimitR);
        if(pos2.x< pos2LimitL) pos2.x=pos2LimitL;
        else if(pos2.x>pos2LimitR)  pos2.x=pos2LimitR;
        //cc.log(pos2.y+"!!!!!!!!!!!!!!!!pos2.y@@@@@@@@@@@@@@"+limith+"hhhh"+(limith-CastleModule.BG_GRID_HEIGHT));
        //if(pos2.y<(limith-(limith-CastleModule.BG_GRID_HEIGHT)/CastleModule.MOVE_SPEED)) pos2.y=limith-(limith-CastleModule.BG_GRID_HEIGHT)/CastleModule.MOVE_SPEED;
        if(pos2.y<(limith-(limith-CastleModule.BG_GRID_HEIGHT)/CastleModule.MOVE_SPEED)) {
            pos2.y=limith-(limith-CastleModule.BG_GRID_HEIGHT)/CastleModule.MOVE_SPEED;
        }
        else if(pos2.y>limith)  pos2.y=limith;//CastleModule.MOVE_SPEED
        //cc.log(limith+"limith########"+pos2.y+"###"+(limith-CastleModule.BG_GRID_HEIGHT) );//-(limith-this._cameraPosInit2.y)/CastleModule.MOVE_SPEED)
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("CastleModule引导触发操作doGuide"+guideId);
        if(guideId=="1_1"){
            this.moveToBuilding(null,1901001);
        }
        else if(guideId=="1_2"){
            cc.log("this.getBlockByBuildingId(1901001)._touchArea:"+this.getBlockByBuildingId(1901001)._touchArea);
            //this.getBlockByBuildingId(1901001)._touchArea._dispatchTouchEvent();
            this.onBlockTouch(this.getBlockByBuildingId(1901001)._touchArea,ccui.Widget.TOUCH_ENDED);
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(this._castleData._movePos.x+5,this._castleData._movePos.y-85));//发送引导点击位置事件//-40
        }
        else if(guideId=="1_6"){
            this.moveToBuilding(null,1901001,9);
        }
        else if(guideId=="1_7"){
            this.onBlockTouch(this._arrBlock[9]._touchArea,ccui.Widget.TOUCH_ENDED);
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(this._castleData._movePos.x+35,this._castleData._movePos.y-80));//发送引导点击位置事件

        }
        else if(guideId=="3_2"){
            this.moveToBuilding(null,1901001);
        }
        else if(guideId=="3_3"){
            this.moveToBuilding(null,1901001);
            this.onBlockTouch(this.getBlockByBuildingId(1901001)._touchArea,ccui.Widget.TOUCH_ENDED);
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(this._castleData._movePos.x+90,this._castleData._movePos.y-70));//发送引导点击位置事件
        }
        else if(guideId=="3_6"){
            this.moveToBuilding(null,1901001,10);
        }
        else if(guideId=="3_7"){
            this.moveToBuilding(null,1901001,10);
            this.onBlockTouch(this._arrBlock[10]._touchArea,ccui.Widget.TOUCH_ENDED);
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(this._castleData._movePos.x,this._castleData._movePos.y-80));//发送引导点击位置事件
        }
        else if(guideId=="3_8"){
            this.moveToBuilding(null,1901001,10);
        }
        else if(guideId=="3_9"){
            this.moveToBuilding(null,1901001,10);
            this.onBlockTouch(this._arrBlock[10]._touchArea,ccui.Widget.TOUCH_ENDED);
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(this._castleData._movePos.x+85,this._castleData._movePos.y-80));//发送引导点击位置事件
        }
        else if(guideId=="4_1"){
            //显示移民
            //this.showEffectImmigrant();
            if(this._lvCastle&&this._lvCastle>=CastleModule.IMMIGRANT_LEVEL){
                var bool=false;
                if(mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001)) {
                    bool = true;
                }
                if(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)||bool) {
                    //表示当前城堡已经建立了子城堡
                    this._effImmigrant.setVisible(false);
                }
                else{
                    //有移民
                    this._effImmigrant.setVisible(true);
                    //cc.log("显示移民特效啊@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
                }
            }
            else this._effImmigrant.setVisible(false);
            //cc.log(this._lvCastle+"判断是否出现移民特效##################################0"+mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)+"判断有无移民"+bool);
        }
        else if(guideId=="4_3"){
            cc.log("4_3引导进入二级地图 强制引导");
            this._effImmigrant.setVisible(false);

        }
    },
    //锁定到建筑事件
    moveToBuilding:function(type,buildingId,blockId){
        var size = cc.director.getVisibleSize();
        if(blockId!=undefined&&blockId!=null)var block=this._arrBlock[blockId];
        else var block=this.getBlockByBuildingId(buildingId);
        if(block!=null){
            cc.log(type+"收到锁定到建筑"+buildingId+"xxx"+block.x+"YYYY"+block.y);
            //this.moveToPos(block.x-size.width/2,block.y-size.height/2);
            this._isMoveToBuilding=true;
            this.easeToPos(block.x-size.width/2,block.y-size.height/2);

        }

    },
    moveToPosDispatch:function(type,offx,offy){
        this.moveToPos(this._cameraPos.x+offx,this._cameraPos.y+offy);

    },
    //屏幕锁定位置 设置坐标
    setLayerPos:function(pos)
    {
        //cc.log(pos.x+"XposY"+pos.y);
        //this._bgLayer.x=-pos.x;
        this._bottomLayer.x=this._buildingLayer.x=this._effectBottomLayer.x=this._effectTopLayer.x=this._iconTfLayer.x=-pos.x;//=this._iconTfLayer.x
        //this._bottomLayer.x=this._buildingLayer.x=-pos.x;
        this._bottomLayer.y=this._buildingLayer.y=this._effectBottomLayer.y=this._effectTopLayer.y=this._iconTfLayer.y=-pos.y;//=this._iconTfLayer.y
        //this._bottomLayer.y=this._buildingLayer.y=-pos.y;
    },
    setBgLayerPos:function(pos)
    {
        this._bgLayer.x=this._effectBgLayer.x=-pos.x;
        this._bgLayer.y=this._effectBgLayer.y=-pos.y;
    },
    //不断更新处理this.unscheduleUpdate();
    update: function (dt) {
        return;
        //cc.log(this._bottomLayer.getPosition().x+"xy"+this._bottomLayer.getPosition().y+"update>>>>>>"+dt+"camerapos"+this._cameraPos.x+"cameraposxy"+this._cameraPos.y);
        this._cameraPos.x=-this._bottomLayer.x;
        this._cameraPos.y=-this._bottomLayer.y;
        this._cameraPos2.x=-this._bgLayer.x;
        this._cameraPos2.y=-this._bgLayer.y;

        this.judgeEdge(this._cameraPos,this._cameraPos2);//判断边界
        this.updateMovePos();
    },
    //更新屏幕弹出UI记录点
    updateMovePos:function(){
        //return;
        if(this._selectBlock!=null)   {
            this._castleData._movePos=cc.p(this._selectBlock.x*this._scaleValue-this._cameraPos.x,this._selectBlock.y*this._scaleValue-this._cameraPos.y);
            //this._castleData.judgeMovePos(cc.p(this._selectBlock.x*this._scaleValue-this._cameraPos.x,this._selectBlock.y*this._scaleValue-this._cameraPos.y));
            EventMgr.inst().dispatchEvent( CastleEvent.MOVE_SCREEN,this._castleData._movePos);
        }
    },
    //拖动缓动
    easeCameraPos:function(){
        return;
        var node=this;
        //return;//
        this.unscheduleUpdate();//强制停止更新
        this.scheduleUpdate();
        //cc.log("test ease^^^^^^^^^^^^^^^^^^^^^^^^^^$%%%%%%%%%%%%%%%%%%%%",this._offPos);
        var arr=["_bottomLayer","_buildingLayer","_effectBottomLayer","_effectTopLayer","_iconTfLayer"];
        for(var i=0;i<arr.length;i++){
            //var newP=MathUtils.pointAdd(this._cameraPos,this._offPos);
            var moveTo = cc.moveTo(3, cc.p(-this._offPos.x, -this._offPos.y));
            this[arr[i]].runAction(moveTo.easing(cc.easeExponentialOut()));
        }
        var arr2=["_bgLayer","_effectBgLayer"];
        for(var i=0;i<arr2.length;i++){
            var moveTo = cc.moveTo(3, cc.p(-this._offPos2.x, -this._offPos2.y));
            if(i==arr2.length-1){
                this[arr2[i]].runAction(cc.Sequence( moveTo.easing(cc.easeExponentialOut()),cc.CallFunc(function(){
                    node.unscheduleUpdate();
                })));
            }
            else  this[arr2[i]].runAction(moveTo.easing(cc.easeExponentialOut()));
        }
        //if(this._selectBlock!=null)   this._castleData._movePos=cc.p(this._selectBlock.x-this._cameraPos.x,this._selectBlock.y-this._cameraPos.y);
    },
    //根据建筑id获取castle_block地块建筑
    getBlockByBuildingId:function(buildingId){
        var block=null;
        for(var i in this._arrBlock){
            if((this._arrBlock[i])._buildingId==buildingId){//学院科技倒计时
                block=this._arrBlock[i];
                break;
            }
        }
        return block;
    },
    //根据建筑id获取icontf图标
    getTfIconByBuildingId:function(buildingId){
        var block=null;
        for(var i in this._arrBlock){
            if((this._arrBlock[i])._buildingId==buildingId){//学院科技倒计时
                block=this._arrIconTf[i];
                break;
            }
        }
        return block;
    },
    //-------------------------------------事件
    //触摸点击事件
    _touchPos:null,//多点触摸对象
    _touchPosDis:null,//多点触摸原始距离
    _touchMidPoint:null,//缩放中心点
    _touchAnchorX:null,//缩放锚点X
    _touchAnchorY:null,//缩放锚点Y
    _beganPos: null,
    _movedPos: null,
    _movedPos2: null,
    _isMove:null,//用于判断大于30像素点击地块也拖动
    _offPos:null,//拖动屏幕偏移量
    _offPos2:null,//拖动屏幕偏移量
    _beganCameraPos:null,//缩放起始 屏幕POS位置
    _beganScale:null,//缩放初始scale
    _canMove:null,//能否移动;
    onTouchBegan: function (touchs, event)
    {
        if(this._isMoveToBuilding) return;
        this._canMove=true;

        if(this._touchPos==null) this._touchPos={};
        var touch=touchs[0];
        this._touchPos[touch.getID()]=touch.getLocation();
        if(touchs.length>1) {
            var touch1=touchs[1];
            this._touchPos[touch1.getID()]=touch1.getLocation();
        }
        //cc.error("onTouchBegan"+this._touchPos[0]+"o 1"+this._touchPos[1]);\
        this.beganTouchScale();
        //cc.log("场景onTouchBegan"+touch.getLocation().x+"xy"+touch.getLocation().y);
        this.doTouchBegan(touch.getLocation());
        return true;
    },
    beganTouchScale:function(){
        var _arrTouch=[];
        for(var key in this._touchPos){
            _arrTouch.push(this._touchPos[key]);
        }
        if(this.getTouchNum()==2){
            this._canMove=false;
            this._beganCameraPos=this._cameraPos;//记录初始屏幕POS
            this._beganScale=this._scaleValue;
            //this._beganCameraPos=cc.p(this._cameraPos.x/this._scaleValue,this._cameraPos.y/this._scaleValue);//记录初始屏幕POS
            //this._touchPosDis=MathUtils.twoPointsDistance(this._touchPos[0],this._touchPos[1]);
            this._touchPosDis=MathUtils.twoPointsDistance(_arrTouch[0],_arrTouch[1]);
            this._touchPosDis=this._touchPosDis/this._scaleValue;//还原正常尺寸的亮点间距离
            //记录缩放中心点锚点
            this._touchMidPoint=MathUtils.pointMid(_arrTouch[0],_arrTouch[1]);
            //this._touchMidPoint=cc.p(this._touchMidPoint.x/this._scaleValue,this._touchMidPoint.y/this._scaleValue);
            //this._touchMidPoint=cc.p(this._size.width/2,this._size.height/2);
            this._touchAnchorX=Number( this._touchMidPoint.x/(CastleModule.GRID_WIDTH*CastleModule.COLUMN*this._scaleValue) ).toFixed(2);
            this._touchAnchorY=Number( this._touchMidPoint.y/(CastleModule.GRID_HEIGHT*CastleModule.ROW*this._scaleValue) ).toFixed(2);
            //cc.log(this._cameraPos.x+"beganTouchScale开始touch缩放camerapos"+this._cameraPos.y);
            //cc.error(this._touchPosDis+"触摸开始距离"+_arrTouch[0].x+"arrx两点xx"+_arrTouch[1].x+"中点X"+this._touchMidPoint.x+"Y"+this._touchMidPoint.y);
        }
    },
    doTouchBegan:function(pos){
        this._isMove=false;//置false
        this._beganPos = pos;
        this._movedPos = this._beganPos;

        //cc.log("doTouchBegan"+pos.x);
    },

    onTouchMoved: function (touchs, event)
    {
        if(this._isMoveToBuilding) return;
        var touch=touchs[0];
        //cc.log(event+"event ontouchmoved");
        //if(ChatModule.ISSCALE)  ModuleMgr.inst().openModule("AlertString",{str:"移动点击数量:"+touchs.length+"id:"+touch.getID(),color:null,time:null,pos:null});
        var startPos = this._beganPos;
        var endPos = touch.getLocation();

        this._touchPos[touch.getID()]=touch.getLocation();
        if(touchs.length>1) {
            var touch1=touchs[1];
            this._touchPos[touch1.getID()]=touch1.getLocation();
        };
        var bool=this.movedTouchScale();
        if(bool) return;
        //cc.error("onTouchMoved"+this._touchPos[0]+"0  1"+this._touchPos[1]);
        if(this.getTouchNum()==1&&this._canMove)    this.doTouchMoved(touch.getLocation());
        //if(this._touchPos[0]==undefined||this._touchPos[1]==undefined)    this.doTouchMoved(touch.getLocation());
    },
    movedTouchScale:function(){
        var _arrTouch=[];
        for(var key in this._touchPos){
            _arrTouch.push(this._touchPos[key]);
        }
        if(ChatModule.ISSCALE&&this.getTouchNum()==2){//进入缩放逻辑  可直接注释if里面代码屏蔽缩放功能
            var dis=MathUtils.twoPointsDistance(_arrTouch[0],_arrTouch[1]);
            var lastScale=this._scaleValue;
            //var scaleValue=Number(dis/this._touchPosDis).toFixed(2);
            var scaleValue=Number(dis/this._touchPosDis).toFixed(2);

            var currentValue=scaleValue;
            if(currentValue<0.6) currentValue=0.6;
            if(currentValue>1.6) currentValue=1.6;
            //cc.error(dis+"当前  两点间距离 原"+this._touchPosDis);
            if(lastScale!=currentValue){
                //缩放
                this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=currentValue;
                this._castleData._scaleValue=this._scaleValue=currentValue;
                var posX=this._cameraPos.x/lastScale*this._scaleValue;
                var posY=this._cameraPos.y/lastScale*this._scaleValue;
                //cc.log(this._touchMidPoint.x+"中点"+this._beganCameraPos.x+"缩放值"+this._scaleValue);
                posX=(this._touchMidPoint.x+this._beganCameraPos.x)*(this._scaleValue)/this._beganScale-  (this._touchMidPoint.x);
                posY=(this._touchMidPoint.y+this._beganCameraPos.y)*(this._scaleValue)/this._beganScale-  (this._touchMidPoint.y);
                //cc.log(posX+"重新调整摄像机摄像机xy"+posY);

                //this.moveToPos(posX,posY);
                this.moveToPos(posX,posY);
                //else this.moveToPos()
                //cc.error(this._scaleValue+"缩放距离"+dis+"进入缩放逻辑"+scaleValue+"lastvalue"+lastScale+"posx"+posX+"posy"+posY);
            }
            return true;
        }
        return false;
    },
    doTouchMoved:function(pos){
        var startPos = this._beganPos;
        var endPos = pos;
        //cc.log(startPos.x+"doTouchMoved@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"+endPos.x);
        //触摸范围大于30
        if ((Math.abs(startPos.x - endPos.x) > 30 || Math.abs(startPos.y - endPos.y) > 30))
        {
            //if(ChatModule.ISSCALE)  ModuleMgr.inst().openModule("AlertString",{str:"测试 移动:"+this._touchPos[0]+this._touchPos[1],color:null,time:null,pos:null});
            //cc.log("超过30像素"+this._isMove);
            this.unscheduleUpdate();//强制停止更新
            this._isMove=true;
            var offset = MathUtils.pointSubtract(this._movedPos, endPos);
            //offset.x=offset.x/this._scaleValue;//缩放特殊处理
            //offset.y=offset.y/this._scaleValue;//缩放特殊处理
            var cameraP = MathUtils.pointAdd(this._cameraPos, offset);
            //pos2
            //cc.log(this._movedPos.x+"this._movedPosxy"+this._movedPos.y);
            //cc.log(startPos.x+"startPosxy"+startPos.y);
            var offx=(endPos.x-startPos.x)/CastleModule.MOVE_SPEED;
            var offy=(endPos.y-startPos.y)/CastleModule.MOVE_SPEED;
            //var offx=(endPos.x-this._movedPos.x)/CastleModule.MOVE_SPEED;
            //var offy=(endPos.y-this._movedPos.y)/CastleModule.MOVE_SPEED;
            //var endPos2 = new cc.p(endPos.x+offx,endPos.y+offy);
            var endPos2 = new cc.p(startPos.x+offx,startPos.y+offy);//endPos
            var offset2 = new cc.p(offset.x/CastleModule.MOVE_SPEED, offset.y/CastleModule.MOVE_SPEED);
            var cameraP2 = MathUtils.pointAdd(this._cameraPos2, offset2);
            this.setCameraPos(cameraP,cameraP2);
            //cc.log("//触摸范围大于30")
        }
        this._movedPos = endPos;
        this._movedPos2 = endPos2;
    },

    onTouchEnded: function (touchs, event)
    {
        if(this._isMoveToBuilding) return;
        var touch=touchs[0];
        //if(ChatModule.ISSCALE)  ModuleMgr.inst().openModule("AlertString",{str:"结束点击量:"+touchs.length+"id:"+touch.getID(),color:null,time:null,pos:null});
        if(this._touchPos&&this._touchPos[touch.getID()])   {
            delete this._touchPos[touch.getID()];
            if(touchs.length>1) delete this._touchPos[touchs[1].getID()];
        }
        if(this.getTouchNum()==0)   this._canMove=true;
        //cc.error("onTouchEnded"+this.getTouchNum());
        if(this._isMove==true) {
            //cc.log("缓动 触发 onTouchEnded&&&&&&&&&");
            this.easeCameraPos();
            return;
        }
        ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
        ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null,objectpos:null,objectstate:null});
    },
    //触点数量
    getTouchNum:function(){
        var num=0;
        if(this._touchPos){
            for(var key in this._touchPos){
                num++;
            }
        }
        //cc.log("触点数量"+num);
        return num;
    },

    onBlockTouch: function (target,type) {
        //cc.log(target,"子对象onTouch"+type);
        if(this._isMoveToBuilding) return;
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                //cc.log(target.getTouchBeganPosition().x+"《《，target.getTouchEndPosition().x")
                if(this._touchPos==null) this._touchPos={};
                this._canMove=true;
                //if(this._touchPos[String(target.getParent()._buildingId)+"l"]!=undefined) return;//超过3个触点return
                //if(this._touchPos[String(target.getParent()._buildingId)]!=undefined){
                //    this._touchPos[String(target.getParent()._buildingId)+"l"]=target.getTouchBeganPosition();
                //}
                //else this._touchPos[String(target.getParent()._buildingId)]=target.getTouchBeganPosition();
                if(this._touchPos[String(target.getParent()._buildingId)]==undefined) this._touchPos[String(target.getParent()._buildingId)]=target.getTouchBeganPosition();
                this.beganTouchScale();
                this.doTouchBegan(target.getTouchBeganPosition());
                break;
            case ccui.Widget.TOUCH_MOVED:
                //cc.log(target.getTouchMovePosition().x+"《《，TOUCH_MOVED");
                var startPos = this._beganPos;
                var endPos = target.getTouchMovePosition();
                //if(this._touchPos[String(target.getParent()._buildingId)+"l"]!=undefined) return;//超过3个触点return
                //if(this._touchPos[String(target.getParent()._buildingId)+"l"]!=undefined){
                //    this._touchPos[String(target.getParent()._buildingId)+"l"]=target.getTouchMovePosition();
                //}
                //else {
                //    if(this._touchPos[String(target.getParent()._buildingId)])  this._touchPos[String(target.getParent()._buildingId)]=target.getTouchMovePosition();
                //}
                if(this._touchPos[String(target.getParent()._buildingId)])  this._touchPos[String(target.getParent()._buildingId)]=target.getTouchMovePosition();
                var bool=this.movedTouchScale();
                if(bool) return;

                if(this.getTouchNum()==1&&this._canMove)  this.doTouchMoved(target.getTouchMovePosition());
                //if(!this._touchPos||(this._touchPos&&this._touchPos[0]==undefined&&this._touchPos[1]==undefined))  this.doTouchMoved(target.getTouchMovePosition());
                break;
            case ccui.Widget.TOUCH_ENDED:
                //cc.error(this._isMove+"end"+this._touchPos+"posnum"+this.getTouchNum());
                if(this._isMove==true){
                    //清除触点
                    if(this._touchPos){
                        //cc.error(this.getTouchNum()+"blocktouchend"+target.getParent()._buildingId);
                        //if(this._touchPos[String(target.getParent()._buildingId)+"l"]!=undefined) delete this._touchPos[String(target.getParent()._buildingId)+"l"];
                        //else{
                        //    if(this._touchPos[String(target.getParent()._buildingId)]) delete this._touchPos[String(target.getParent()._buildingId)];
                        //}
                        if(this._touchPos[String(target.getParent()._buildingId)]) delete this._touchPos[String(target.getParent()._buildingId)];
                    }
                    break;
                }
                //SoundPlay.playEffect( ResMgr.inst().getSoundPath(4));
                if(this._selectBlock!=null) this._selectBlock.showBuildingName(false);
                this._selectBlock=target.getParent();
                //var p=new cc.p(target.getParent().x-this._cameraPos.x,target.getParent().y-this._cameraPos.y);
                var p=new cc.p(target.getParent().x*this._scaleValue-this._cameraPos.x,target.getParent().y*this._scaleValue-this._cameraPos.y);
                //cc.log(target.getParent().x+"点击建筑弹出位置XY%%%%%%%%%%%%%%%%%%%%%%%"+this._cameraPos.x);
                //this._castleData._movePos=p;//保存移动坐标
                //cc.log("testlog$$$$$$$$$$$$$move##################################################################")
                if(target.getParent()._buildingImg!=null){//有建筑
                    this._selectBlock.showBuildingName(true);
                    ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
                    cc.log("@onBlockTouch",target.getParent()._buildingId,target.getParent()._blockBean._index);
                    if(this._arrTest.indexOf(Number(target.getParent()._buildingId))==-1){
                        SoundPlay.playEffect( ResMgr.inst().getSoundPath(21));
                        ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("castle_1"),color:null,time:null,pos:target.getTouchBeganPosition(),uid:target.getParent()._buildingId});
                        //ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:null});
                        ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null,objectpos:null,objectstate:null});
                        //cc.audioEngine.playEffect( ResMgr.inst().getSoundPath(4));
                        //return;
                    }
                    else {
                        //播放音效
                        this._castleData._clickPos=p;
                        //测试收部队特效
                        //EventMgr.inst().dispatchEvent(CastleEvent.NET_COMPLETE, CastleNetEvent.SEND_GETBUILD_ARMY);
                        //cc.log(mainData.playerData.trade+'%%%%%%%%%%%%target.getParent()._buildingId>>>>>'+(mainData.playerData.trade=="0"));
                        //mainData.playerData.trade=1;//测试用 强制开放交易市场 请去掉本行注释
                        var isTrain=false;
                        if(Number(target.getParent()._buildingId)==1910001&&(mainData.playerData.trade=="0"||mainData.playerData.trade==undefined)){//交易市场特殊判断
                            var value = ResMgr.inst().getString("castle_4");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
                            ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null,objectpos:null,objectstate:null});
                        }else if(this.judgeArmyTrain(target.getParent()._blockBean._index)){//判断是否有训练完成状态的兵营
                            cc.log("有训练完成状态的兵营&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& 发送部队收取请求"+target.getParent()._blockBean._index);
                            EventMgr.inst().dispatchEvent( CastleEvent.GET_BUILD_ARMY,target.getParent()._blockBean._index );
                            SoundPlay.playEffect( ResMgr.inst().getSoundPath(31));
                            isTrain=true;
                            var csvEffect = ResMgr.inst().getCSV("animationConfig","castle_armytrain_getLight");
                            var animate=new AnimationSprite();
                            animate._removeSelf=true;
                            animate.setPosition(cc.p( target.getParent().getPosition().x,target.getParent().getPosition().y+20) );
                            animate.setAnimationByCount(csvEffect,1);
                            this._effectTopLayer.addChild(animate);
                        }
                        else{
                            //this._castleData._movePos=p;//保存移动坐标
                            this._castleData.judgeMovePos(p);

                            //var visiblesize = cc.director.getVisibleSize();
                            //if(p.x<100 || p.y<120 || visiblesize.width-p.x<100 || visiblesize.height-p.y < 120){
                            //    EventMgr.inst().dispatchEvent( CastleEvent.MOVETO_BUILDING,target.getParent()._buildingId );
                            //    ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null,objectpos:null,objectstate:null});
                            //    this.runAction(cc.Sequence(cc.DelayTime(0.5),cc.CallFunc(function () {
                            //        ModuleMgr.inst().openModule("BuildingUIModule",{objectid:target.getParent()._buildingId,
                            //            objectpos:p,objectstate:null,
                            //            objectindex:target.getParent()._blockBean._index});
                            //        cc.log("@CastleModule",target.getParent()._buildingId,"index: ",target.getParent()._blockBean._index)
                            //    })))
                            //}
                            //else{
                                ModuleMgr.inst().openModule("BuildingUIModule",{objectid:target.getParent()._buildingId,
                                    objectpos:p,objectstate:null,
                                    objectindex:target.getParent()._blockBean._index});
                                cc.log("@CastleModule",target.getParent()._buildingId,"index: ",target.getParent()._blockBean._index)
                            //}



                        }
                        if(!isTrain&&target.getParent()&&target.getParent()._buildingId)  this.playEffect(target.getParent()._buildingId);
                    }
                }
                else {
                    if (target.getParent()._blockBean._building_id!=0) {
                        //this._castleData._movePos=p;//保存移动坐标\
                        this._castleData.judgeMovePos(p);
                    }
                    ModuleMgr.inst().openModule("BuildingUIModule",{objectid:null,objectpos:p,objectstate:null});
                    var guideData=ModuleMgr.inst().getData("GuideModule");
                    if((!guideData&&mainData.playerData.guide=="2_1")||(guideData&&guideData._guideBean&&guideData._guideBean._idStep=="2_1")){
                        break;//特殊引导步骤不让点空地 防止造学院影响后面引导
                    }
                    ModuleMgr.inst().openModule("CreateBuildingUIModule",{objectid:target.getParent()._blockBean._index,objectpos:p})
                }
                if(this._touchPos[String(target.getParent()._buildingId)]) delete this._touchPos[String(target.getParent()._buildingId)];
                if(this.getTouchNum()==0)   this._canMove=true;
                break;
            case ccui.Widget.TOUCH_CANCELED:
                //cc.error("canceled");
                //清除触点
                if(this._touchPos){
                    //cc.error(this.getTouchNum()+"blocktouchend"+target.getParent()._buildingId);
                    //if(this._touchPos[String(target.getParent()._buildingId)+"l"]!=undefined) delete this._touchPos[String(target.getParent()._buildingId)+"l"];
                    //else{
                    //    if(this._touchPos[String(target.getParent()._buildingId)]) delete this._touchPos[String(target.getParent()._buildingId)];
                    //}
                    if(this._touchPos[String(target.getParent()._buildingId)]) delete this._touchPos[String(target.getParent()._buildingId)];
                }
                if(this.getTouchNum()==0)   this._canMove=true;
                break;
            default:
                break;
        }
    },
    onImmigrantTouch:function(target,type){
        //return;
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                //cc.log(target.getTouchBeganPosition().x+"《《，target.getTouchEndPosition().x")
                this.doTouchBegan(target.getTouchBeganPosition());
                break;
            case ccui.Widget.TOUCH_MOVED:
                //cc.log(target.getTouchMovePosition().x+"《《，TOUCH_MOVED");
                this.doTouchMoved(target.getTouchMovePosition());
                break;
            case ccui.Widget.TOUCH_ENDED:
                if (this._isMove == true) break;
                cc.log("点击移民建筑！！！！！!!!!!!!!!!!!!!!!!!");
                ModuleMgr.inst().openModule("AlertPanel", {"txt":ResMgr.inst().getString("castle_2")});

                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },
    onTestTouch:function(target,type){
        var bool=false;
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                cc.log(target.index+"onTestTouch测试按钮  cameraX",this._cameraPos.x)
                switch (target.index){
                    case 0:
                        //EventMgr.inst().dispatchEvent( ChatEvent.TIP_CHAT);
                        if(bool){
                            this.scale=this._scaleValue=1.6;
                            break;
                        }
                        //cc.log("测试拆建筑");
                        //EventMgr.inst().dispatchEvent( CastleEvent.REMOVE_SUCCESS,11);
                        //cc.log("test 发送测试 道具")
                        //var msg = new SocketBytes();
                        //msg.writeUint(500);
                        //NetMgr.inst().send(msg);
                        //ModuleMgr.inst().openModule("TaskModule");
                        //break;
                        if(this._touchPos==null) this._touchPos={};
                        if(this._touchPos[1]==undefined)    {
                            this._touchPos[1]=cc.p(480,320);
                            ChatModule.ISSCALE=true;
                        }//测试多点
                        else {
                            //this._touchPos[1]=undefined;
                            delete this._touchPos[1];
                            ChatModule.ISSCALE=false;
                        }
                        break;
                        var lastScale=this._scaleValue;
                        this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=1.5;
                        this.moveToPos(this._cameraPos.x/lastScale*this._scaleValue,this._cameraPos.y/lastScale*this._scaleValue);
                        //this.scale=this._scaleValue=1.5;
                        break;
                    case 1:
                        //EventMgr.inst().dispatchEvent( CastleEvent.SPEED_SUCCESS,11);
                        //ModuleMgr.inst().openModule("CitadelResourceModule");//测试打开城堡资源显示
                        var lastScale=this._scaleValue;
                        if(bool){
                            this.scale=this._scaleValue=1.0;
                            break;
                        }
                        this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=1.0;
                        this.moveToPos(this._cameraPos.x/lastScale*this._scaleValue,this._cameraPos.y/lastScale*this._scaleValue);
                        break;
                        //this.scale=this._scaleValue=1.2;
                        //ModuleMgr.inst().openModule("GuideModule",{id:"1_1"});
                        var obj = DataManager.getInstance().getNewData("TaskData");
                        obj.taskId = 3010001;
                        obj.taskType = 1;
                        obj.createdTime = 11111;
                        obj.remainTime = 11111111;
                        obj.taskInfoList=[{"keyProgress":1,"num":2}];
                        obj.reward = 0;
                        mainData.taskDataList.push(obj);

                        var obj = DataManager.getInstance().getNewData("TaskData");
                        obj.taskId = 3020002;
                        obj.taskType = 2;
                        obj.createdTime = 11111;
                        obj.remainTime = 11111111;
                        obj.taskInfoList=[{"keyProgress":1,"num":2}];
                        obj.reward = 0;
                        mainData.taskDataList.push(obj);

                        var obj = DataManager.getInstance().getNewData("TaskData");
                        obj.taskId = 3020001;
                        obj.taskType = 2;
                        obj.createdTime = 11111;
                        obj.remainTime = 11111111;
                        obj.taskInfoList=[{"keyProgress":1,"num":1}];
                        obj.reward = 0;
                        mainData.taskDataList.push(obj);

                        //EventMgr.inst().dispatchEvent(TaskEvent.TASK_UPDATE_TASK,1);
                        break;
                        var msg = new SocketBytes();
                        msg.writeUint(TaskNetEvent.SEND_TASK);
                        NetMgr.inst().send(msg);
                        break;
                    case 2:
                        if(bool){
                            this.scale=this._scaleValue=0.8;
                            break;
                        }
                        //EventMgr.inst().dispatchEvent( CastleEvent.CANCEL_SUCCESS,11);
                        //ModuleMgr.inst().openModule("GuideModule",{id:"2_1"});
                        //EventMgr.inst().dispatchEvent("get_announcenment_msg",0);
                        //break;
                        var lastScale=this._scaleValue;

                        this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=0.8;
                        this.moveToPos(this._cameraPos.x/lastScale*this._scaleValue,this._cameraPos.y/lastScale*this._scaleValue);
                        //this.scale=this._scaleValue=1;
                        break;
                    case 3:
                        //SoundPlay.setEffectVolume( ResMgr.inst().getSoundPath(32),0);
                        var lastScale=this._scaleValue;
                        if(bool){
                            this.scale=this._scaleValue=0.6;
                            break;
                        }

                        this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=0.6;
                        this.moveToPos(this._cameraPos.x/lastScale*this._scaleValue,this._cameraPos.y/lastScale*this._scaleValue);
                        break;
                        //ModuleMgr.inst().openModule("GuideModule",{id:"3_1"});
                        var obj = DataManager.getInstance().getNewData("ArmyTrainData");
                        obj.castleId = mainData.uiData.currentCastleId;
                        obj.blockId = 4;
                        obj.armyId = 1201101;
                        obj.num = 100;
                        obj.duration = 20000;
                        obj.remainTime = 15000;
                        var exist = false;
                        var list = mainData.castleData.armyTrainList;
                        for(var i = 0;i< list.length;i++){
                            var army = list.getItemAt(i);
                            if(obj.castleId == army.castleId && obj.armyId == army.armyId){
                                exist = true;
                                list.setItemAt(i,obj);
                                break;
                            }
                        }
                        if(!exist){
                            mainData.castleData.armyTrainList.push(obj);
                        }
                        ModuleMgr.inst().getData("CastleModule").netGetArmyTrain(CastleNetEvent.GET_ARMY_TRAIN,obj);
                        break;
                        var lastScale=this._scaleValue;
                        this._bottomLayer.scale=this._buildingLayer.scale=this._effectBottomLayer.scale=this._effectTopLayer.scale=this._iconTfLayer.scale=this._bgLayer.scale=this._effectBgLayer.scale=this._scaleValue=0.5;
                        this.moveToPos(this._cameraPos.x/lastScale*this._scaleValue,this._cameraPos.y/lastScale*this._scaleValue);
                        //this.scale=this._scaleValue=0.5;
                        //this._bottomLayer.scale=this._buildingLayer.scale=1.5;
                        break;
                        var msg = new SocketBytes();
                        msg.writeUint(201);//设置账号属性
                        msg.writeUint(198);//引导
                        msg.writeString("");
                        NetMgr.inst().send(msg);
                        break;

                }


                break;
        }
    },

    playEffect: function (type) {
        switch (type){
            case 1913001://箭塔
            case 1913002:
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(18));
                break;
            case 1906001://仓库
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(14));
                break;
            case 1903001://学院
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(15));
                break;
            case 1907001://城墙
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(16));
                break;
            case 1901001://领主府
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(17));
                break;
            case 1909001://校场
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(19));
                break;
            case 1910001://交易市场
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(20));
                break;
            case 1902003://靶场
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(25));
                break;
            case 1902001://马厩
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(26));
                break;
            case 1902002://兵营
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(27));
                break;
            case 1902004://器械
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(28));
                break;
            case 1904001://民房
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(29));
                break;
            case 1911001://活动建筑
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(30));
                break;
            default :
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(4));
                break;
        }
    },

    //通讯部分-------------
    isTest:false,//是否是测试数据
    //更新并应训练倒计时
    netUpdateArmyTrainTime:function(type, armyTrain){
        //cc.log(netTech+"1netUpdateTechTime");
        //this._arrBlock[armyTrain.blockId].updateBuildingTime(blockNet);
        if(this._arrIconTf[armyTrain.blockId])    this._arrIconTf[armyTrain.blockId].updateBuildingTime(armyTrain,2);
    },
    //移除兵营训练
    netRemoveArmyTrain:function(type,blockId){
        if(this._arrIconTf[blockId])    this._arrIconTf[blockId].removeTimeIcon();
    },
    //更新学院科技倒计时
    netUpdateTechTime:function(type, netTech){
        //cc.log(netTech+"1netUpdateTechTime");
        var techNet = new CastleTechBeanNet(netTech._data);
        for(var i in this._arrBlock){
            if((this._arrBlock[i])._buildingId==1903001){//学院科技倒计时
                //this._arrBlock[i].updateBuildingTime(techNet,true);//1218修改
                if(this._arrIconTf[i])this._arrIconTf[i].updateBuildingTime(techNet,1);
                break;
            }
        }
    },
    //更新学院科技状态
    netUpdateTech:function(type, arr){
        //cc.log(arr+"netUpdateTech");
        var techNet = new CastleTechBeanNet(arr);
        for(var i in this._arrBlock){
            if((this._arrBlock[i])._buildingId==1903001){//学院科技倒计时
                this._arrBlock[i].updateTech(techNet);
                if(this._arrIconTf[i])  this._arrIconTf[i].updateTech(techNet);
                break;
            }
        }
    },
    //学院科技升级完成
    netTechUpgradeComplete:function(type, netTech){
        var techNet = new CastleTechBeanNet(netTech._data);
        for(var i in this._arrBlock){
            if((this._arrBlock[i])._buildingId==1903001){//学院科技倒计时
                this._arrBlock[i].upgradeTechComplete();
                if(this._arrIconTf[i])  this._arrIconTf[i].upgradeTechComplete();
                break;
            }
        }
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(7));
    },
    //更新建筑倒计时
    netUpdateTime:function(type, netblock){
        var blockNet = new CastleBlockBeanNet(netblock._data);
        //cc.log(blockNet._state_remain+"#######stateTime"+blockNet._index+"###"+blockNet._building_id);
        this._arrBlock[blockNet._index].updateBuildingTime(blockNet);
        if(this._arrIconTf[blockNet._index])    this._arrIconTf[blockNet._index].updateBuildingTime(blockNet,0);
    },
    //更新建筑状态
    netUpdateBuilding:function(type, arr){
        cc.log(arr+"收到更新建筑地块事件   目测有各种蛋疼的状态判断 index  blockid"+arr[1]+"@@建筑id"+arr[2]+"@@等级"+arr[3]+"@@状态"+arr[4]+"@@4"+arr[5]+"@@"+arr[6]+"@@6");
        var blockNet=new CastleBlockBeanNet(arr);
        if(blockNet._building_id==0){
            if(this._arrBlock[blockNet._index]._buildingId!=null){
                cc.log("拆除建筑");
                this._arrBlock[blockNet._index].removeBuilding();
            }
            else{
                cc.log("空地块逻辑");
            }
        }
        else{
            //cc.log(this._arrBlock+"this._arrBlock$$$$$$$$$$$$$$$$$$")
            //for(var i in this._arrBlock){
            //    cc.log(blockNet._index+"ceshi:arrBlock"+i);
            //}
            if(this._arrBlock[blockNet._index]._buildingId==null){
                cc.log("无建筑 造一个建筑");
                this._arrBlock[blockNet._index].createBuilding(blockNet._building_id,blockNet._index);
                //引导
                if(blockNet._building_id==1901001){
                    //mainData.playerData.guide
                    this._lvCastle=blockNet._building_level;
                    cc.log(mainData.playerData.guide+"<<<<<储存的引导步骤 进城堡触发id mainData.playerData.guide")
                    if(!mainData.playerData.guide){
                        ModuleMgr.inst().openModule("GuideModule",{id:"1_1"});
                    }
                    else{
                        var arrJudgeGuide= ["1_1","1_6","2_1","3_2","3_6","3_8","4_1","4_3"];
                        if(arrJudgeGuide.indexOf(mainData.playerData.guide)!=-1) ModuleMgr.inst().openModule("GuideModule",{id:mainData.playerData.guide});
                    }
                }
            }
            if(blockNet._building_id==1906001){
                EventMgr.inst().dispatchEvent("wareHouse_event");
            }
            cc.log("更新建筑状态等信息");
            this._arrBlock[blockNet._index].updateBuilding(blockNet);
            if(this._arrIconTf[blockNet._index])    this._arrIconTf[blockNet._index].updateBuilding(blockNet);
            //判断移民逻辑
            if(blockNet._index==16){
                this._lvCastle=blockNet._building_level;
                //cc.log(mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId).length);
                //cc.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$主城等级   》》》》"+blockNet._building_level);
                //cc.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$主城等级 length  》》》》"+mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId).length );
                //cc.log("$$$$$$$$$$$$$$$$$$$$$$$$$$$主城等级 length  》》》》"+mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001).length );
                var current = modelMgr.call("Table", "getTableItemByValue", ["City_Castel",blockNet._building_level ]);
                if(blockNet._building_level>=CastleModule.IMMIGRANT_LEVEL){
                    this.addFun();
                }
                else{
                    this._immigrant_down.setVisible(false);
                    this._immigrant.setVisible(false);
                    this._immigrant_up.setVisible(false);
                    this._touchArea.setVisible(false);
                }
            }

        }
    },
    //判断有无训练完成兵营状态
    judgeArmyTrain:function(blockId){
        var bool=false;
        var list = mainData.castleData.armyTrainList;
        for(var i = 0;i< list.length;i++){
            var army = list.getItemAt(i);
            if(mainData.uiData.currentCastleId == army.castleId && army.blockId == blockId&&army.armyId!=0&&army.remainTime<=0){
                bool = true;
                //list.setItemAt(i,obj);
                break;
            }
        }
        return bool;
    },
    //删除对应数据
    removeArmyTrainData:function(blockId){
        var list = mainData.castleData.armyTrainList;
        for(var i = 0;i< list.length;i++){
            var army = list.getItemAt(i);
            if(mainData.uiData.currentCastleId == army.castleId && army.blockId == blockId){
                list.delItemAt(i);
                break;
            }
        }
    },
    //移民数量变化监听
    addFun:function(){
        cc.log(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)+"监听移民事件￥￥￥￥￥￥￥￥￥￥￥￥"+mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001))
        var bool=false;
        if(mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001)) {
            bool = true;
        }
        if(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)||bool) {
            //表示当前城堡已经建立了子城堡
            if(this._immigrant_down)    this._immigrant_down.setVisible(false);
            if(this._immigrant)   this._immigrant.setVisible(false);
            if(this._immigrant_up)   this._immigrant_up.setVisible(false);
            if(this._touchArea)   this._touchArea.setVisible(false);
        }
        else{
            if(this._immigrant_down) this._immigrant_down.setVisible(true);
            if(this._immigrant)this._immigrant.setVisible(true);
            if(this._immigrant_up)this._immigrant_up.setVisible(true);
            if(this._touchArea)this._touchArea.setVisible(true);
        }
    },
    //判断是否显示移民
    judgeImmigrant:function(obj){
        var bool=false;
        if(mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001)) {
            bool = true;
        }
        if(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)||bool) {
            //表示当前城堡已经建立了子城堡
            if(obj)obj.setVisible(false);
        }
        else{
            if(obj)obj.setVisible(true);
        }
    },
    //升级成功处理
    netUpgradeComplete:function(type, index){
        if(this._arrBlock&&this._arrBlock[index])   this._arrBlock[index].upgradeComplete();
        if(this._arrIconTf&&this._arrIconTf[index])   this._arrIconTf[index].upgradeComplete();
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(6));
        if(index==16){
            var guideData=ModuleMgr.inst().getData("GuideModule");
            if(guideData&&guideData._guideBean) cc.log(this._lvCastle+"升级成功移民特效判断##########################################################"+guideData._guideBean._idStep);
            if(guideData&&guideData._guideBean&&guideData._guideBean._idStep=="4_1"){
                //显示移民
                if(this._lvCastle&&this._lvCastle>=CastleModule.IMMIGRANT_LEVEL){
                    var bool=false;
                    if(mainData.mapData.myArmyList.getItem("castleId",mainData.uiData.currentCastleId,"type",1207001)) bool = true;
                    if(mainData.mapData.myCastleList.getItem("castleId",mainData.uiData.currentCastleId)||bool) this._effImmigrant.setVisible(false);
                    else  this._effImmigrant.setVisible(true);
                }
                else this._effImmigrant.setVisible(false);
            }
        }
    },
    //请求成功返回处理
    netComplete:function(type, index){
        if(index==CastleNetEvent.SEND_BUILD){

        }
    },
    //动作处理方法
    createAction:function(obj,time,startP,endP,reverse){
        if(reverse){
            //var moveAction=cc.MoveTo.create(time, endP);//MathUtils.pointSubtract(endP,startP)
            var moveAction=cc.moveTo(time, endP);//MathUtils.pointSubtract(endP,startP)
            var seq = cc.Sequence.create(moveAction,moveAction.reverse());//,
            //var seq = new cc.Sequence(moveAction,moveAction.reverse());//,
            var repeatAction = cc.RepeatForever.create(seq);
        }
        else{
            //var seq = cc.Sequence.create(
            //    cc.moveTo(time, endP), cc.moveTo(time, startP)
            // );
            var seq=new cc.Sequence(cc.spawn( cc.moveTo(time, endP)) ,new cc.CallFunc(function(){obj.setPosition(startP)},this)).repeatForever();//cc.moveTo(time, endP),
            //seq.setCallFunc(new cc.CallFunc(function(){obj.x=startP.x;obj.y=startP.y},this));
            //var repeatAction = cc.RepeatForever.create(seq);
        }
        obj.runAction(seq);

    },

    //一次性完成后消失
    createOnceDisappear:function(node,data){
        //cc.log("data.obj2"+data.obj2)
        data.obj1.setPosition(data.startP);
        if(data.obj2)   data.obj2.setVisible(false);
        var moveAction = cc.moveTo(data.time,data.endP );
        var seq=new cc.Sequence(moveAction,new cc.CallFunc(function(){
            var moveAction2=cc.fadeOut(2);
            if(data.obj2){//有待机动作
                data.obj2.setPosition(data.endP);
                data.obj1.setVisible(false);
                data.obj2.setVisible(true);
                var seq2=new cc.Sequence(moveAction2,new cc.CallFunc(function(){
                    data.obj1.removeFromParent();
                    data.obj1=null;
                    data.obj2.removeFromParent();
                    data.obj2=null;
                },this));
                data.obj2.runAction(seq2);
            }
           else{//无待机动作
                var seq3=new cc.Sequence(moveAction2,new cc.CallFunc(function(){
                    data.obj1.removeFromParent();
                    data.obj1=null;
                },this));
                data.obj1.runAction(seq3);
            }
            //node._isInterval=false;
        },this));
        data.obj1.runAction(seq);
    },
    //计时器产生随机动画
    merchantInterVal:function(node){
        //return;
        //node._isInterval=true;
        var startX1=320;
        var startY1=270;
        var endX1=775;
        var endY1=550;
        var arrMove=[
            ["castle_merchant1_move_rightup",cc.p(startX1-15,startY1),cc.p(endX1-15,endY1),10],["castle_merchant2_move_rightup",cc.p(startX1,startY1),cc.p(endX1,endY1),10],
            ["castle_merchant3_move_rightup",cc.p(startX1-5,startY1-5),cc.p(endX1-5,endY1-5),10],["castle_merchant4_move_rightup",cc.p(startX1+5,startY1-5),cc.p(endX1+5,endY1-5),10],
            ["castle_merchant5_move_rightup",cc.p(startX1+5,startY1-10),cc.p(endX1,endY1-10),10],["castle_carriage_rightup",cc.p(startX1+10,startY1),cc.p(endX1+10,endY1),6],
            ["castle_ship_up",cc.p(930,-40),cc.p(1715,465),15],["castle_ship_down",cc.p(1750,405),cc.p(1000,-50),15],
            ["castle_merchant5_move_leftdown",cc.p(endX1+510,endY1+255),cc.p(startX1-10,startY1-10),20],["castle_carriage_leftdown",cc.p(endX1+510,endY1+260),cc.p(startX1-10,startY1-10),12]
        ];
        var arrMoveReverse=[
            ["castle_merchant1_stand_rightup",cc.p(100,100),cc.p(300,300),5],["castle_merchant2_stand_rightup",cc.p(110,100),cc.p(310,300),5],//
            ["castle_merchant3_stand_rightup",cc.p(100,100),cc.p(300,300),5],["castle_merchant4_stand_rightup",cc.p(110,100),cc.p(310,300),5],
            ["castle_merchant5_stand_rightup",cc.p(100,100),cc.p(300,300),5],[],[],[],
            ["castle_merchant5_stand_leftdown",cc.p(100,100),cc.p(300,300),5],[]
        ]
        var ranType=parseInt(Math.random()*12);
        var ranType2=parseInt(Math.random()*3)+6;
        //cc.log(">>>>>>产生随机动画"+ranType);
        if(ranType>9) return;
        if(ranType<5){
            var ran=parseInt(Math.random()*5);
            for(var i=0;i<Math.min(ran,5);i++) {
                var csvEffect1 = ResMgr.inst().getCSV("animationConfig", arrMove[i][0]);
                var animateMove = new AnimationSprite();
                animateMove.setAnimationByCount(csvEffect1);
                node._effectBottomLayer.addChild(animateMove);
                if(arrMoveReverse[i]&&arrMoveReverse[i][0]){
                    var csvEffect2 = ResMgr.inst().getCSV("animationConfig", arrMoveReverse[i][0]);
                    var animateMove2 = new AnimationSprite();
                    animateMove2.setAnimationByCount(csvEffect2);
                    node._effectBottomLayer.addChild(animateMove2);
                }
                node.createOnceDisappear(node,{obj1:animateMove,obj2:i==5?null:animateMove2,time:arrMove[i][3],startP:arrMove[i][1],endP:arrMove[i][2]});
            }
        }
        if(ranType2<8) ranType=ranType2;
        if(ranType>4){
            var csvEffect1 = ResMgr.inst().getCSV("animationConfig", arrMove[ranType][0]);
            var animateMove = new AnimationSprite();
            animateMove.setAnimationByCount(csvEffect1);
            node._effectBottomLayer.addChild(animateMove);
            if(arrMoveReverse[ranType]&&arrMoveReverse[ranType][0]){
                var csvEffect2 = ResMgr.inst().getCSV("animationConfig", arrMoveReverse[ranType][0]);
                var animateMove2 = new AnimationSprite();
                animateMove2.setAnimationByCount(csvEffect2);
                node._effectBottomLayer.addChild(animateMove2);
            }
            node.createOnceDisappear(node,{obj1:animateMove,obj2:(arrMoveReverse[ranType]&&arrMoveReverse[ranType][0])?animateMove2:null,time:arrMove[ranType][3],startP:arrMove[ranType][1],endP:arrMove[ranType][2]});
        }

    },
    //计时器动画 包括测试用的
    animationInterVal:function(node){
        if(node._isTest2==false) {
            node.merchantInterVal(node);
            return;
        }
        node._isInterval=true;
        var arrMove=[["castle_merchant1_move_rightup",cc.p(100,100),cc.p(300,300),5],["castle_merchant2_move_rightup",cc.p(110,100),cc.p(310,300),5],
            ["castle_merchant3_move_rightup",cc.p(100,110),cc.p(300,310),5],["castle_merchant4_move_rightup",cc.p(110,110),cc.p(310,310),5],
            ["castle_merchant5_move_rightup",cc.p(90,90),cc.p(290,290),5],["castle_carriage_rightup",cc.p(120,80),cc.p(320,280),2],
        ];
        var arrMoveReverse=[
            ["castle_merchant1_stand_rightup",cc.p(100,100),cc.p(300,300),5],["castle_merchant2_stand_rightup",cc.p(110,100),cc.p(310,300),5],//
            ["castle_merchant3_stand_rightup",cc.p(100,100),cc.p(300,300),5],["castle_merchant4_stand_rightup",cc.p(110,100),cc.p(310,300),5],
            ["castle_merchant5_stand_rightup",cc.p(100,100),cc.p(300,300),5],[]
        ]
        var ran=parseInt(Math.random()*15);
        //cc.log(">>>>>>产生随机动画"+ran);
        for(var i=0;i<Math.min(ran,arrMove.length);i++) {
            var csvEffect1 = ResMgr.inst().getCSV("animationConfig", arrMove[i][0]);
            var animateMove = new AnimationSprite();
            animateMove.setAnimationByCount(csvEffect1);
            node.addChild(animateMove);
            if(arrMoveReverse[i]&&arrMoveReverse[i][0]){
                var csvEffect2 = ResMgr.inst().getCSV("animationConfig", arrMoveReverse[i][0]);
                var animateMove2 = new AnimationSprite();
                animateMove2.setAnimationByCount(csvEffect2);
                node.addChild(animateMove2);
            }
            node.createOnceDisappear(node,{obj1:animateMove,obj2:i==5?null:animateMove2,time:arrMove[i][3],startP:arrMove[i][1],endP:arrMove[i][2]});
        }
    },
    test2:function(){

        if(this._interval==null)  this._interval = setInterval(this.animationInterVal, 10*1000,this);
        //移动类的特效
        var arrMove=[
            ["castle_royalguard_move_rightdown",cc.p(300,280),cc.p(400,200),5],["castle_soldier_patrol_move_rightdown",cc.p(200,400),cc.p(280,300),7],
            ["castle_soldier_patrol_move_leftup",cc.p(240,350),cc.p(320,250),7]
        ];
        var arrMoveReverse=[
            ["castle_royalguard_move_leftup",cc.p(500,135),cc.p(360,285),5],["castle_soldier_patrol_move_leftup",cc.p(360,285),cc.p(500,135),5],
            ["castle_soldier_patrol_move_rightdown",cc.p(360,285),cc.p(500,135),5]
        ]
        for(var i=0;i<arrMove.length;i++) {
            var csvEffect1 = ResMgr.inst().getCSV("animationConfig", arrMove[i][0]);
            var animateMove = new AnimationSprite();
            animateMove.setName(arrMove[i][0]);
            animateMove.setAnimationByCount(csvEffect1);
            animateMove.setVisible(false);
            this.addChild(animateMove);

            var csvEffect2 = ResMgr.inst().getCSV("animationConfig", arrMoveReverse[i][0]);
            var animateMove2 = new AnimationSprite();
            animateMove2.setName(arrMoveReverse[i][0]);
            animateMove2.setAnimationByCount(csvEffect2);
            this.addChild(animateMove2);
            //this.createReverse(null,{obj1:animateMove,obj2:animateMove2,time:arrMove[i][3],startP:arrMove[i][1],endP:arrMove[i][2]});
        }


    },
    //清除方法
    destroy:function() {
        this._lvCastle=null;
        this._cameraPos = null;
        this._cameraPos2 = null;
        this._cameraPosInit2 = null;
        this._selectBlock = null;
        if(this._immigrant_down){
            this._immigrant_down.removeData();
            this._immigrant_down.removeFromParent();
            this._immigrant_down=null;
        }
        if(this._immigrant){
            this._immigrant.removeData();
            this._immigrant.removeFromParent();
            this._immigrant=null;
        }
        if(this._immigrant_up){
            this._immigrant_up.removeData();
            this._immigrant_up.removeFromParent();
            this._immigrant_up=null;
        }
        if(this._touchArea){
            this._touchArea.removeFromParent();
            this._touchArea=null;
        }
        if(this._effImmigrant){
            this._effImmigrant.removeData();
            this._effImmigrant.removeFromParent();
            this._effImmigrant=null;
        }

        for (var i in this._arrBlock) {
            if(this._arrBlock[i]) {
                //this._arrBlock[i]._touchArea.removeTouchEventListener(this.onBlockTouch,this);
                this._arrBlock[i].destroy();
                this._arrBlock[i].removeFromParent();
                this._arrBlock[i]=null;
            }
            if(this._arrIconTf&&this._arrIconTf[i]) {
                this._arrIconTf[i].destroy();
                this._arrIconTf[i].removeFromParent();
                this._arrIconTf[i]=null;
            }
        }
        this._arrBlock=null;
        this._arrIconTf=null;
        this._buildingLayer.removeFromParent();
        this._buildingLayer=null;

        this._bgLayer.removeAllChildren();
        this._bgLayer.removeFromParent();
        this._bgLayer=null;

        this._bottomLayer.removeAllChildren();
        this._bottomLayer.removeFromParent();
        this._bottomLayer=null;

        this._effectBgLayer.removeAllChildren();
        this._effectBgLayer.removeFromParent();
        this._effectBgLayer=null;
        this._effectBottomLayer.removeAllChildren();
        this._effectBottomLayer.removeFromParent();
        this._effectBottomLayer=null;
        this._effectTopLayer.removeAllChildren();
        this._effectTopLayer.removeFromParent();
        this._effectTopLayer=null;
        this._iconTfLayer.removeAllChildren();
        this._iconTfLayer.removeFromParent();
        this._iconTfLayer=null;

        if(this._testLayer) {
            this._testLayer.removeAllChildren();
            this._testLayer.removeFromParent();
            this._testLayer=null;
        }

        EventMgr.inst().removeEventListener(CastleEvent.MOVETO_BUILDING, this.moveToBuilding, this);//屏幕锁定到建筑坐标
        EventMgr.inst().removeEventListener(CastleEvent.MOVETO_POS, this.moveToPosDispatch, this);//屏幕锁定到坐标
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_ARMYTRAIN_TIME, this.netUpdateArmyTrainTime, this);//兵营训练
        EventMgr.inst().removeEventListener(CastleEvent.REMOVE_ARMYTRAIN, this.netRemoveArmyTrain, this);//移除兵营特效
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_TECH_TIME, this.netUpdateTechTime, this);//1903001学院
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_TECH, this.netUpdateTech, this);
        EventMgr.inst().removeEventListener(CastleEvent.TECH_UPGRADE_COMPLETE, this.netTechUpgradeComplete, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BUILDING, this.netUpdateBuilding, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPGRADE_COMPLETE, this.netUpgradeComplete, this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);//请求成功返回
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        if(this._castleData)    {
            this._castleData._scaleValue=this._scaleValue=1;//缩放1
            this._castleData.clear();
            this._castleData = null;
        }
        if(this._interval){
            clearInterval(this._interval);
        }
    }

});

//静态属性
CastleModule.ROW=4;
CastleModule.COLUMN=6;
CastleModule.GRID_WIDTH=400;
CastleModule.GRID_HEIGHT=375;//400
CastleModule.BG_GRID_HEIGHT=348;

CastleModule.MOVE_SPEED=12;//默认8分之一
CastleModule.IMMIGRANT_LEVEL=12;//移民等级