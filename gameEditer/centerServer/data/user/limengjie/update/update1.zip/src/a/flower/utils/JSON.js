var flower;
(function (flower) {
    var JSON = (function () {
        function JSON() {
        }
        return JSON;
    })();
    flower.JSON = JSON;
})(flower || (flower = {}));
//# sourceMappingURL=JSON.js.map