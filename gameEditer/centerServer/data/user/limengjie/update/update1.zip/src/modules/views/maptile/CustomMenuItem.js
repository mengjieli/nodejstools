/**
 * Created by cgMu on 2015/10/15.
 */

//buildingindex:用于金币加速，地块ID
var CustomMenuItem = cc.Node.extend({
    _tag:null,
    _buildingIndex:null,
    _label:null,
    _cost:null,
    remainTime: null,
    timeHandler:null,
    time:0,
    ctor:function(normal,disable,text,callback,buildingindex,flag) {
        this._super();

        var tag = parseInt(normal/10);
        this._tag = tag;

        var json = ccs.load("res/images/ui/TileMenuModule/ex_menuitemlayer.json","res/images/ui/");
        var root = json.node;
        this.addChild(root);

        var bg = ccui.helper.seekWidgetByName(root, "itemPanel");
        bg.setTag(tag);
        bg.setTouchEnabled(true);

        var contentSize = bg.getContentSize();
        this.setContentSize(contentSize);
        if(flag){
            this.setAnchorPoint(cc.p(0.5,0.5));
        }

        var item = ccui.helper.seekWidgetByName(root,"item");
        item.ignoreContentAdaptWithSize(true);
        item.loadTexture(ResMgr.inst()._icoPath+normal+".png");
        //item.setPositionY(item.getPositionY()+9);

        var touchEvent = function(sender, type) {
            switch (type) {
                case ccui.Widget.TOUCH_BEGAN:
                    //cc.log("TOUCH_BEGAN");
                    var action = new cc.ScaleTo(0.05,1.1);
                    sender.runAction(action);
                    break;
                case ccui.Widget.TOUCH_MOVED:
                    //cc.log("TOUCH_MOVED");
                    break;
                case ccui.Widget.TOUCH_ENDED:
                    //cc.log("TOUCH_ENDED");
                    var action = new cc.ScaleTo(0.05,1);
                    sender.runAction(action);
                    sender.exinfo = this.remainTime;
                    //cc.log("@ccui.Widget.TOUCH_ENDED: ", sender.exinfo,this.remainTime);

                    if(this.time>0 && this.time<3){
                        cc.log("@频繁操作");
                    }
                    else{
                        callback(sender);
                        this.time=1;
                        if(this.timeHandler) this.timeHandler.clear();
                        this.timeHandler = null;
                        this.timeHandler = new IntervalCall(this.timeUpdate,this,1);
                    }

                    break;
                case ccui.Widget.TOUCH_CANCELED:
                    //cc.log("TOUCH_CANCELED");
                    var action = new cc.ScaleTo(0.05,1);
                    sender.runAction(action);
                    break;
                default:
                    //cc.log("default");
                    break;
            }
        };

        var touchItem = ccui.helper.seekWidgetByName(root, "touchItem");

        bg.addTouchEventListener(touchEvent,this);

        var counts = ccui.helper.seekWidgetByName(root,"Image_1");
        counts.setVisible(false);

        var name = ccui.helper.seekWidgetByName(root, "name");
        name.ignoreContentAdaptWithSize(true);
        name = BorderText.replace(name);
        name.setString(text);

        if(tag == 1501012 || tag == 1501013) {
            EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
            if(buildingindex) this._buildingIndex = buildingindex;

            if(tag==1501013){
                var text = "";
                if(buildingindex){

                    var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",2804015 ]);//2804015:交易ID 建筑升级消耗黄金
                    var tempjson = eval("(" + itemdata.consumption_item + ")");
                    var consumption_item = {};
                    for (var jsonkey in tempjson) {
                        consumption_item.itemid = jsonkey;
                        consumption_item.counts = tempjson[jsonkey];
                    }

                    this._cost= parseInt(consumption_item.counts/100);
                }
                var cost = new ccui.Text();
                cost.setFontSize(18);
                cost.setColor(cc.color(255,165,0,255));
                cost.setString(text);
                cost.setPosition(cc.p(name.getPositionX(),name.getPositionY()-15));
                bg.addChild(cost);
                this._label = cost;
            }

        }

        if(tag==1501022 || tag == 1501023){
            EventMgr.inst().addEventListener(CastleEvent.UPDATE_ARMYTRAIN_TIME, this.netArmyUpdateTime, this);
            if(buildingindex) this._buildingIndex = buildingindex;

            if(tag == 1501023){
                var text = "";
                if(buildingindex){

                    var itemdata = modelMgr.call("Table", "getTableItemByValue", ["item_trading",2804015 ]);//2804015:交易ID 建筑升级消耗黄金
                    var tempjson = eval("(" + itemdata.consumption_item + ")");
                    var consumption_item = {};
                    for (var jsonkey in tempjson) {
                        consumption_item.itemid = jsonkey;
                        consumption_item.counts = tempjson[jsonkey];
                    }

                    this._cost= parseInt(consumption_item.counts/100);
                }
                var cost = new ccui.Text();
                cost.setFontSize(18);
                cost.setColor(cc.color(255,165,0,255));
                cost.setString(text);
                cost.setPosition(cc.p(name.getPositionX(),name.getPositionY()-15));
                bg.addChild(cost);
                this._label = cost;
            }
        }

    },

    onExit:function() {
        this._super();
        if(this._tag == 1501012 || this._tag == 1501013){
            EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.netUpdateTime, this);
        }
        if(this._tag==1501022 || this._tag == 1501023){
            EventMgr.inst().removeEventListener(CastleEvent.UPDATE_ARMYTRAIN_TIME, this.netArmyUpdateTime, this);
        }
        if(this.timeHandler) this.timeHandler.clear();
        this.timeHandler = null;
    },

    timeUpdate: function () {
        this.time++;

    },

    netUpdateTime: function (event,data) {
        if(data._index==this._buildingIndex){
            var remain = data._state_remain;
            this.remainTime = remain;

            if(this._tag == 1501013 && this._cost && this._label){
                var t = Math.ceil(remain / 1000 / 60);
                this._label.setString(t*this._cost);
            }
        }
    },

    netArmyUpdateTime: function (event,data) {
        if(data.blockId == this._buildingIndex){
            this.remainTime = data.remainTime;

            if(this._tag == 1501023 && this._cost && this._label){
                var t = Math.ceil(this.remainTime / 1000 / 60);
                this._label.setString(t*this._cost);
            }
        }
    }
});