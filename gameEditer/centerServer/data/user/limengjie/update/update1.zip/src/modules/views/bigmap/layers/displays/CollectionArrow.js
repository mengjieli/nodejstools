var CollectionArrow = cc.Sprite.extend({
    ctor: function (data) {
        this._super();
        this.data = data;
        this.coordX = data.x;
        this.coordY = data.y;

        this.arrow = new ccui.ImageView("res/fight/ui/collectionArrow.png");
        this.addChild(this.arrow);
        this.arrow.setPosition(200, 200);
        this.arrow.setAnchorPoint(0.5, 0.5);
        var txt = new BorderText();
        this.arrow.addChild(txt);
        this.arrowLabel = txt;
        txt.setString("km");
        txt.setColor({r: 196, g: 165, b: 101, a: 255});
        txt.setFontSize(14);
        txt.setPosition(41, 18);
        this.label = txt;

        this.arrow.setTouchEnabled(true);
        this.arrow.addTouchEventListener(function () {
            var pos = pos = MapUtils.transPointToPosition(data.x, data.y);
            modelMgr.call("BigMap", "cameraLookAt", [pos.x, pos.y]);
        });
        this.data.addListener("tag",this.onTagChange,this);
        this.setVisible(data.tag);
        this.scheduleUpdate();
    },
    onTagChange:function(val){
        this.setVisible(val);
    },
    update: function (dt) {
        var pos = MapUtils.transPointToPosition(this.data.x, this.data.y);
        var x = pos.x - mainData.mapData.cameraData.x;
        var y = pos.y - mainData.mapData.cameraData.y;
        var sx = 50;
        var sy = 112;
        var ex = mainData.systemData.screenWidth - 200;
        var ey = mainData.systemData.screenHeight - 110;
        var cx = (sx + ex) / 2;
        var cy = (sy + ey) / 2;
        var dis = Math.sqrt((cx - x) * (cx - x) + (cy - y) * (cy - y));
        //if(dis < 300) {
        if (x <= 0 || x >= mainData.systemData.screenWidth || y <= 0 || y >= mainData.systemData.screenHeight) {
            this.arrow.setVisible(true);
            this.label.setString(Math.ceil(Math.sqrt((cx - x) * (cx - x) / (MapUtils.width * MapUtils.width) + (cy - y) * (cy - y) / (MapUtils.height * MapUtils.height))) + "km");
        } else {
            this.arrow.setVisible(false);
        }
        var rot = Math.atan2(cy - y, cx - x);
        rot = -rot * 180 / Math.PI + 180;
        rot = rot % 360;
        this.arrow.setRotation(rot);
        if (rot < 90 || rot > 270) {
            this.arrowLabel.setScale(1);
        } else {
            this.arrowLabel.setScale(-1);
        }
        //x = x + Math.cos(rot)*dis*2/3;
        //y = y + Math.sin(rot)*dis*2/3;
        if (x < sx + 38) {
            x = sx + 38;
        }
        if (x > ex + 38) {
            x = ex + 38;
        }
        if (y < sy) {
            y = sy;
        }
        if (y > ey) {
            y = ey;
        }
        this.arrow.setPosition(x, y);
    },
    dispose: function () {
        this.data.removeListener("tag",this.onTagChange,this);
        this.unscheduleUpdate();
        this.getParent().removeChild(this);
    }
});