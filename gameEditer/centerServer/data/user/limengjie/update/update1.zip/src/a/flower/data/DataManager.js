var flower;
(function (flower) {
    var DataManager = (function () {
        function DataManager() {
            this._defines = {};
            this._root = {};
            if (flower.DataManager.ist) {
                return;
            }
        }
        DataManager.prototype.addRootData = function (name, className) {
            this[name] = this.createData(className);
        };
        DataManager.prototype.addDataDeinf = function (config) {
            this._defines[config.name] = config;
        };
        DataManager.prototype.createData = function (className) {
            var config = this._defines[className];
            if (flower.Engine.DEBUG && !config) {
                flower.DebugInfo.debug("没有定义的数据类型 :" + className, flower.DebugInfo.ERROR);
                return null;
            }
            var obj = {};
            if (config.members) {
                var members = config.members;
                for (var key in members) {
                    var member = members[key];
                    if (member.type == "int") {
                        obj[key] = new flower.IntValue(member.init);
                    }
                    else if (member.type == "uint") {
                        obj[key] = new flower.UIntValue(member.init);
                    }
                    else if (member.type == "string") {
                        obj[key] = new flower.StringValue(member.init);
                    }
                    else if (member.type == "boolean") {
                        obj[key] = new flower.BooleanValue(member.init);
                    }
                    else if (member.type == "array") {
                        obj[key] = new flower.ArrayValue(member.init);
                    }
                    else if (member.type == "*") {
                        obj[key] = member.init;
                    }
                    else {
                        obj[key] = this.createData(member.type);
                    }
                }
            }
            return obj;
        };
        return DataManager;
    })();
    flower.DataManager = DataManager;
})(flower || (flower = {}));
flower.DataManager.ist = new flower.DataManager();
//# sourceMappingURL=DataManager.js.map