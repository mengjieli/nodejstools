/**
 * Created by cgMu on 2015/12/3.
 */

var TaskDataCommand = cc.Class.extend({
    ctor: function () {
        NetMgr.inst().addEventListener(1299, this.netGetTask, this);//任务协议
    },

    netGetTask: function (cmd, data) {
        if (1299 == cmd) {
            cc.log("任务协议>>>>>");
            data.resetCMDData();
            var obj = DataManager.getInstance().getNewData("TaskData");
            obj.taskId = data.readUint();
            obj.taskType = data.readUint();
            obj.createdTime = data.readUint();
            obj.remainTime = data.readUint();
            obj.taskInfoList=[];
            var taskInfoListNum = data.readUint();
            cc.log(taskInfoListNum+"<<<taskInfoListNum");
            for(var i=0;i<taskInfoListNum;i++){
                var info={};
                info.keyProgress=data.readUint();
                info.num=data.readUint();
                obj.taskInfoList.push(info);
                cc.log(info.keyProgress+"info"+info.num);
            }
            obj.reward = data.readUint();
            //cc.log(typeof(obj.reward));
            var exist = false;
            var list = mainData.taskDataList;
            if(list) cc.log(list.length+">>原列表长度list.length");
            cc.log("netGetTask obj.taskInfoList.length"+obj.taskInfoList.length);
            if(obj.taskType==1){
                if(list) {
                    list.delItem("taskType",1);
                    cc.log(list.length+">>删除原主线后列表长度list.length");
                }
                if(obj.reward==1) {
                    cc.log("主线任务 并且已领取 return掉");
                    return;
                }
            }
            if(list){
                for(var i = 0;i< list.length;i++){
                    var task = list.getItemAt(i);
                    if(obj.taskId == task.taskId){
                        exist = true;
                        list.setItemAt(i,obj);
                        break;
                    }
                }
            }
            if(!exist){
                cc.log("**********************@netGetTask 收到任务协议task***********"+"taskId"+obj.taskId+"类型"+obj.taskType+"createdTime"+obj.createdTime+"剩余时间"+obj.remainTime+"是否已领"+obj.reward);
                mainData.taskDataList.push(obj);
            }
            cc.log("收到任务啊啊啊@@@@@@@"+(obj.taskType==1?"主线":"每日")+"任务ID"+obj.taskId);
            //每日任务根据领取奖励排序
            //cc.log(list+"listlistlistlist"+list.length);
            if(obj.taskType!=1){
                //排序 有问题
                //if(list&&list.length>0){
                //    var main=list.getItem("taskType",1);
                //    list.delItem("taskType",1);
                //
                //    Tools.sortArray(list,"reward",true);
                //    //list.unshift(main);
                //    list.addItemAt(main,0);
                //}
            }

            EventMgr.inst().dispatchEvent(TaskEvent.TASK_UPDATE_TASK,obj.taskType);
            cc.log(mainData.taskDataList.length+"dispatchEvent(TaskEven");
            //ModuleMgr.inst().getData("CastleModule").netGetArmyTrain(cmd,obj);
        }
    }
});
