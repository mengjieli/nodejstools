/**
 * Created by cgMu on 2016/1/20.
 */

var UnlockingLayer = cc.Node.extend({
    armid: null,

    ctor: function (armid) {
        this._super();

        this.armid = armid;

        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var json = ccs.load("res/images/ui/training/unlockingLayer.json","res/images/ui/");
        var root_ = json.node;
        this.addChild(root_);

        //适配
        var size = cc.director.getVisibleSize();
        root_.setContentSize(size);
        ccui.helper.doLayout(root_);

        var root = root_.getChildByName("Panel_2");
        posAutoLayout(root,0.5);
        sizeAutoLayout(root);

        var title = ccui.helper.seekWidgetByName(root,"Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("train_10"));

        var closeButton = ccui.helper.seekWidgetByName(root, "Button_1");
        closeButton.addTouchEventListener(this.touchCallback,this);

        var confirmbtn = ccui.helper.seekWidgetByName(root,"Button_2");
        confirmbtn.addTouchEventListener(this.confirmbtnCallback,this);
        var buttonTitle = confirmbtn.getChildByName("Text_12");
        buttonTitle.ignoreContentAdaptWithSize(true);
        buttonTitle.setString(ResMgr.inst().getString("public_ok"));

        var cancelbtn = ccui.helper.seekWidgetByName(root,"Button_2_0");
        cancelbtn.addTouchEventListener(this.cancelCallback,this);
        buttonTitle = cancelbtn.getChildByName("Text_12");
        buttonTitle.ignoreContentAdaptWithSize(true);
        buttonTitle.setString(ResMgr.inst().getString("public_cancel"));

        var label1 = root.getChildByName("Text_3");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("train_11"));

        var armConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",this.armid]);
        var resdata = eval("(" + armConfig.levelup_resource + ")");
        var reslist = [];
        for(var i in resdata){
            var item={};
            item.itemid = i;
            item.counts = resdata[i];
            reslist.push(item);
        }

        var icolist = [];
        var Image_239 = root.getChildByName("gy_dengji_di_6");
        Image_239.setVisible(false);
        icolist.push(Image_239);
        var Image_239_0 = root.getChildByName("gy_dengji_di_6_0");
        Image_239_0.setVisible(false);
        icolist.push(Image_239_0);
        var Image_239_1 = root.getChildByName("gy_dengji_di_6_1");
        Image_239_1.setVisible(false);
        icolist.push(Image_239_1);
        var Image_239_2 = root.getChildByName("gy_dengji_di_6_1_0");
        Image_239_2.setVisible(false);
        icolist.push(Image_239_2);

        var numlist = [];
        var Text_81 = root.getChildByName("Text_7_2");
        Text_81.ignoreContentAdaptWithSize(true);
        Text_81.setVisible(false);
        numlist.push(Text_81);
        var Text_81_0 = root.getChildByName("Text_7");
        Text_81_0.ignoreContentAdaptWithSize(true);
        Text_81_0.setVisible(false);
        numlist.push(Text_81_0);
        var Text_81_1 = root.getChildByName("Text_7_0");
        Text_81_1.ignoreContentAdaptWithSize(true);
        Text_81_1.setVisible(false);
        numlist.push(Text_81_1);
        var Text_81_2 = root.getChildByName("Text_7_1");
        Text_81_2.ignoreContentAdaptWithSize(true);
        Text_81_2.setVisible(false);
        numlist.push(Text_81_2);

        for(var i in reslist){
            if(icolist[i] && numlist[i]){
                icolist[i].setVisible(true);
                icolist[i].setTexture(ResMgr.inst().getIcoPath(reslist[i].itemid));
                numlist[i].setVisible(true);
                numlist[i].setString(StringUtils.getUnitNumber(reslist[i].counts));
            }
        }
    },

    onEnter: function () {
        this._super();
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.netCallback,this);
    },

    onExit: function () {
        this._super();
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.netCallback,this);
    },

    touchCallback: function (sender,type) {
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                this.removeFromParent(true);
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    confirmbtnCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        cc.log("@解锁兵种 ID",this.armid);
        EventMgr.inst().dispatchEvent( CastleEvent.UNLOCK_ARMY,this.armid);

    },

    cancelCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.removeFromParent(true);
    },

    netCallback: function (event, data) {
        if(data == 422){
            cc.log("@netCallback 422 兵种解锁成功",this.armid);
            EventMgr.inst().dispatchEvent(TrainingEvent.UNLOCK_SUCCESS,this.armid);
            this.removeFromParent(true);
        }
    }
});