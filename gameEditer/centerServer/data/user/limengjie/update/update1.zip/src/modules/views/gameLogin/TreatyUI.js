/**
 * Created by Administrator on 2015/12/14.
 */

/**
 * Created by Administrator on 2015/12/14.
 */


var TreatyUI = cc.Node.extend( {

    _ui: null,

    _input: null,

    ctor: function()
    {
        this._super();
    },

    onEnter: function()
    {
        this._super();

        var backImg = new ccui.ImageView();
        backImg.setAnchorPoint(0.5,0.5);
        backImg.loadTexture("login/denglu_di.png", ccui.Widget.PLIST_TEXTURE);
        var pos = cc.p(0,0);
        backImg.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(true) );
        pos.x = GameMgr.inst().viewSize.width >> 1;
        pos.y = GameMgr.inst().viewSize.height >> 1;
        backImg.setPosition( pos );
        this.addChild( backImg );

        this._ui = ccs.load( "res/images/ui/login/treaty.json", "res/images/ui/" ).node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //关闭自己
        var but = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Button_1" );
        but.addTouchEventListener( this.closeCall, this );

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_1" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_23"));

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_1_0" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_24"));

        var scrol = this._ui.getChildByName("ui_mainban").getChildByName("ScrollView_1");

        var string = this.getText();
        var label = scrol.getChildByName("Text_2");
        //label.setString(string);
        label.setString(string.substring(0,800));
        label.runAction(cc.Sequence(cc.DelayTime(0.5),cc.CallFunc(function(sender){
            sender.setString(string);
        })))

        scrol.setInnerContainerSize(label.getContentSize());
        label.setPosition(cc.p(0,0));
        label.setFontSize(18);
        scrol.jumpToTop();
    },

    onExit: function()
    {
        this._super();
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /**
     * 下一步回调
     * @param node
     * @param type
     */
    closeCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            this.removeFromParent();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    getText: function () {
        var txt = cc.loader.getRes("res/configs/table/txts/test.txt");
        return txt;
    }
});