/**
 * Created by cgMu on 2015/11/30.
 */

var BattleUIData = DataBase.extend({
    topBar:null,
    topBarS:null,
    rowBtnList:null,
    columnBtnList:null,
    bottomBar_battle:null,
    battleLogBtn:null,

    default:true,//ui初始状态
    active:false,//标识切换状态
    exchangeBtn:null,
    backBtn:null,
    smallmapBtn:null,
    resourceOutBtn:null,//资源图标

    armyItemPos:null,//军队在界面上的坐标

    ctor:function() {
        this.rowBtnList = [];
        this.columnBtnList = [];

        //[cc.p(12,10),cc.p(106,10),cc.p(202,10),cc.p(296,10),cc.p(392,10),cc.p(488,10),cc.p(580,10),cc.p(676,10),cc.p(771,10),cc.p(866,10)]
        this.armyItemPos = [cc.p(8,7),cc.p(111,7),cc.p(213,7),cc.p(315,7),cc.p(417,7)
            ,cc.p(8,115),cc.p(111,115),cc.p(213,115)];

    },

    init:function() {
        return true;
    },

    destroy:function() {

    },

    setExchangeBtn: function (btn) {
        this.exchangeBtn = btn;
    },

    setBackBtn: function (btn) {
        this.backBtn = btn;
    },

    setTopBar: function (bar) {
        this.topBar = bar;//height==80
    },

    setTopBarS: function (bar) {
        this.topBarS = bar;//height==80
    },

    setBattleBottomBar: function (bar) {
        this.bottomBar_battle = bar;
    },

    setBattleLogBtn: function (btn) {
        this.battleLogBtn = btn;
    },

    setSmallmapBtn: function (btn) {
        this.smallmapBtn = btn;
    },
    setResourceOutBtn:function(btn){
        this.resourceOutBtn = btn;
    },
    pushRowList: function (btn) {
        if(this.rowBtnList){
            this.rowBtnList.push(btn);
        }
        else{
            this.rowBtnList = [];
            this.rowBtnList.push(btn);
        }
    },

    pushColumnList: function (btn) {
        if(this.columnBtnList){
            this.columnBtnList.push(btn);
        }
        else{
            this.columnBtnList = [];
            this.columnBtnList.push(btn);
        }
    },

    switchUI: function (value) {
        if(value!=null){
            this.default = value;
        }
        if(this.active) {
            return;
        }
        this.active = true;
        var topbar_move = cc.MoveBy(BattleUIData.ACTION_TIEM,cc.p(0,100));
        var bottombar_move = cc.MoveBy(BattleUIData.ACTION_TIEM,cc.p(0,250));

        var delaytime_row = BattleUIData.ACTION_TIEM / this.rowBtnList.length;
        var rowBtn_move = cc.MoveBy(delaytime_row,cc.p(0,-120));

        var delaytime_column = BattleUIData.ACTION_TIEM / this.columnBtnList.length;
        var columnBtn_move = cc.MoveBy(delaytime_column,cc.p(120,0));

        if(this.default){
            this.default = false;
            mainData.uiData.operateMode="2";

            if(this.topBar){
                this.topBar.runAction(cc.Sequence(topbar_move,cc.CallFunc(function () {
                    ModuleMgr.inst().getData("BattleUIModule").active = false;
                })));
            }

            if(this.topBarS){
                this.topBarS.setVisible(true);
                this.topBarS.setOpacity(0);
                this.topBarS.runAction(cc.Sequence(cc.MoveBy(0.2,cc.p(0,100)),cc.CallFunc(function (sender) {
                    sender.setVisible(false);
                    sender.setOpacity(255);
                })));
            }

            for(var row in this.rowBtnList) {
                if(this.rowBtnList[row]){
                    this.rowBtnList[row].runAction(cc.Sequence(cc.DelayTime(delaytime_row*row),rowBtn_move));
                }
            }

            for(var column in this.columnBtnList){
                if(this.columnBtnList[column]){
                    this.columnBtnList[column].runAction(cc.Sequence(cc.DelayTime(delaytime_column*column),columnBtn_move));
                }
            }
            //
            if(this.bottomBar_battle){
                this.bottomBar_battle.runAction(bottombar_move);
            }

            if(this.battleLogBtn) this.battleLogBtn.setVisible(true);

            SoundPlay.playEffect( ResMgr.inst().getSoundPath(36) );
        }
        else{
            this.default = true;
            mainData.uiData.operateMode="1";

            if(this.topBar){
                this.topBar.runAction(cc.Sequence(topbar_move.reverse(),cc.CallFunc(function () {
                    ModuleMgr.inst().getData("BattleUIModule").active = false;
                })));
            }

            if(this.topBarS){
                this.topBarS.setVisible(true);
                this.topBarS.setOpacity(0);
                this.topBarS.runAction(cc.Sequence(cc.MoveBy(0.2,cc.p(0,-100)),cc.CallFunc(function (sender) {
                    sender.setVisible(false);
                    sender.setOpacity(255);
                })));
            }

            for(var row in this.rowBtnList) {
                if(this.rowBtnList[row]){
                    this.rowBtnList[row].runAction(cc.Sequence(cc.DelayTime(delaytime_row*row),rowBtn_move.reverse()));
                }
            }

            for(var column in this.columnBtnList){
                if(this.columnBtnList[column]){
                    this.columnBtnList[column].runAction(cc.Sequence(cc.DelayTime(delaytime_column*column),columnBtn_move.reverse()));
                }
            }
            //
            if(this.bottomBar_battle){
                this.bottomBar_battle.runAction(bottombar_move.reverse());
            }

            if(this.battleLogBtn) this.battleLogBtn.setVisible(false);

            SoundPlay.playEffect( ResMgr.inst().getSoundPath(37) );
        }
    },

    updateStateExchangeBtn: function (maptype) {
        if(maptype==MapChangeModule.MAP){
            if(this.exchangeBtn)    this.exchangeBtn.setVisible(true);
            if(this.smallmapBtn)    this.smallmapBtn.setVisible(true);
            if(this.resourceOutBtn)    this.resourceOutBtn.setVisible(true);
        }
        else{
            if(this.exchangeBtn)    this.exchangeBtn.setVisible(false);
            if(this.smallmapBtn)    this.smallmapBtn.setVisible(false);
            if(this.resourceOutBtn)    this.resourceOutBtn.setVisible(false);
        }
    },

    updateStateBackBtn: function (maptype) {
        if(this.backBtn){
            var icon = this.backBtn.getChildByName("Image_7");
            icon.ignoreContentAdaptWithSize(true);
            var txt = this.backBtn.getChildByName("zi");
            if(maptype==MapChangeModule.MAP){
                icon.loadTexture("mainResourcesModule/zhujiemian_fanhuichengbao.png",ccui.Widget.PLIST_TEXTURE);
                txt.setString(ResMgr.inst().getString("mainmenu_104"));
            }
            else{
                icon.loadTexture("mainResourcesModule/zhujiemian_ditu.png",ccui.Widget.PLIST_TEXTURE);
                txt.setString(ResMgr.inst().getString("mainmenu_100"));
            }
        }
    }
});

BattleUIData.ACTION_TIEM = 0.4;