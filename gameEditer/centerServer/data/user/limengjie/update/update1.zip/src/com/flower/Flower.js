var flower;
(function (flower) {
    var Flower = (function () {
        function Flower() {
        }

        var d = __define, c = Flower;
        p = c.prototype;

        Flower.warnInfo = true;
        Flower.errorInfo = true;
        Flower.tipInfo = true;
        Flower.resrict = true;

        return Flower;
    })();
    flower.Flower = Flower;
})(flower || (flower = {}));

var IDE = {
    TYPE:2
}