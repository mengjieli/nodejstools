/**
 * Created by cgMu on 2015/11/30.
 */

var ArmyItem = cc.Node.extend({
    downLoadingbar:null,
    selectingIcon:null,
    touchIcon:null,

    armyData:null,

    ctor: function (armydata) {
        this._super();

        this.armyData = armydata;

        var root = ccs.load("res/images/ui/BattleUIModule/item.json","res/images/ui/").node;
        this.addChild(root);

        var selecting = root.getChildByName("Image_1_1");
        selecting.ignoreContentAdaptWithSize(true);
        selecting.setVisible(false);
        this.selectingIcon = selecting;

        var touch_bg = root.getChildByName("Image_1");
        touch_bg.setTouchEnabled(true);
        this.touchIcon = touch_bg;

        var urlid = modelMgr.call("Table", "getTableItemByValue", ["Arm",armydata.type]).arm_type;
        var icon = root.getChildByName("Image_1_0");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst()._icoPath+urlid+"8.png");

        var loadingbar_down = root.getChildByName("LoadingBar_1_0");
        //loadingbar_down.setPercent(100);
        this.downLoadingbar = loadingbar_down;

        var blood = this.armyData.attributes.getItem("type",2500011).value;
        var fullBlood = this.armyData.attributes.getItem("type",2500077).value;
        this.setLoadingbarDown(blood/fullBlood*100);

        var number = root.getChildByName("Text_1");
        number.ignoreContentAdaptWithSize(true);
        number.setString(armydata.level);

        cc.log("@ArmyItem",armydata.type,armydata.level);
        this.armyData.addListener("attributes",this.bloodCallback,this);
    },

    onExit: function () {
        this._super();
        if(this.armyData){
            this.armyData.removeListener("attributes",this.bloodCallback,this);
            this.armyData = null;
        }

    },

    bloodCallback: function () {
        if(this.armyData){
            this.armyData.removeListener("attributes",this.bloodCallback,this);
            //this.armyData = null;
        }

        var list = mainData.mapData.armyList.getItems("castleId",mainData.uiData.currentCastleId);//获取部队数据
        for(var i in list){
            var army = list[i];
            if(army.id == this.armyData.id){
                this.armyData = army;
                break;
            }
        }
        this.armyData.addListener("attributes",this.bloodCallback,this);

        var blood = this.armyData.attributes.getItem("type",2500011).value;
        var fullBlood = this.armyData.attributes.getItem("type",2500077).value;
        this.setLoadingbarDown(blood/fullBlood*100);
    },

    //setLoadingbarUp: function (percent) {
    //    if(this.upLoadingbar){
    //        this.upLoadingbar.setPercent(percent);
    //    }
    //},

    setLoadingbarDown: function (percent) {
        if(this.downLoadingbar){
            this.downLoadingbar.setPercent(percent);
        }
    },

    //部队选中状态
    setSelectingState: function (selecting) {
        if(!this.touchIcon.isTouchEnabled()) return;//死亡部队不处理
        if(selecting){
            //this.armyName.setColor(cc.color(255,220,80));
            this.selectingIcon.setVisible(true);
        }
        else{
            //this.armyName.setColor(cc.color(255,255,255));
            this.selectingIcon.setVisible(false);
        }
    },

    //部队死亡状态
    setDeadState: function () {
        //this.armyName.setColor(cc.color(42,42,42));
        this.touchIcon.setTouchEnabled(false);
        this.selectingIcon.setVisible(true);
        this.selectingIcon.loadTexture("BattleUIModule/zd_buduisiwang.png",ccui.Widget.PLIST_TEXTURE);
    }
});