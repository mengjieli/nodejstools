var ModelCycler = (function (_super) {

    __extends(ModelCycler, _super);

    function ModelCycler() {
        _super.call(this);
        this.event = new flower.Event(ModelCycler.CYCLE_COMMAND);
    }

    var d = __define, c = ModelCycler;
    p = c.prototype;

    p.cycleLogic = function(logic) {
        this.event.data = logic;
        this.dispatchEvent(this.event);
    }

    ModelCycler.CYCLE_COMMAND = "cycle_command";

    return ModelCycler;
})(flower.EventDispatcher);