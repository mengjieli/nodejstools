/**
 * Created by cgMu on 2015/10/27.
 */

var CollegeModule = ModuleBase.extend({
    yeqianVector:[],
    titleVector:[],
    shuolianVector:[],

    selectingTag:1,//页签tag 【科技种类】
    selecttingTech:null,//当前选中的科技ID
    upgradingTech:null,//当前正在升级的科技数据id

    barTotalHeight:0,
    barPercent_total:0,
    isOnePage:false,

    itemMap:null,
    root:null,
    scrol:null,

    _id:0,
    _index:0,
    collegeLevel:0, //学院等级

    isUpdate:false, //标识当前正在升级的科技
    updateTechData:null,

    rightScroll:null,
    rightItemRoot:null,
    rightVector:null,
    _needResources:null,
    _array:null,//是否残留上次数据
    _time:null,

    ctor:function() {
        this._super();

        cc.log("CollegeModule","ctor");

        this.itemMap = [];
        this.rightVector = [];
        this._needResources = [];
        this._array = [];

        var data = ModuleMgr.inst().getData("CollegeModule");

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netCallback, this);
        EventMgr.inst().addEventListener(CastleEvent.TECH_UPGRADE_COMPLETE, this.eventCallback, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_TECH_TIME, this.netUpdateTechTime, this);
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().addEventListener( "using_token", this.usingCallback,this );

        this._data=[];
        this._data[0]=data._techData[0];
        this._data[1]=data._techData[1];
        this._data[2]=data._techData[2];
        this._data[3]=data._techData[3];
    },

    initUI:function() {

        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var json = ccs.load("res/images/ui/College/CollegeLayer.json","res/images/ui/");
        var root_ = json.node;
        this.addChild(root_);

        //适配
        var size = cc.director.getVisibleSize();
        root_.setContentSize(size);
        ccui.helper.doLayout(root_);

        var root = root_.getChildByName("Panel_1");
        sizeAutoLayout(root);
        this.root = root;

        var Image_7 = root.getChildByName("Image_7");
        posAutoLayout(Image_7);

        var Panel_2 = root.getChildByName("Panel_55");
        sizeAutoLayout(Panel_2);

        var Image_2 = root.getChildByName("Image_2");
        posAutoLayout(Image_2);
        Image_2.setLocalZOrder(100);

        //页签
        var xy_shuolian_1 = root.getChildByName("xy_shuolian_1");
        posAutoLayout(xy_shuolian_1);
        this.shuolianVector[0]=xy_shuolian_1;

        var xy_shuolian_2 = root.getChildByName("xy_shuolian_2");
        posAutoLayout(xy_shuolian_2);
        this.shuolianVector[1]=xy_shuolian_2;
        xy_shuolian_2.setVisible(false);

        var xy_shuolian_3 = root.getChildByName("xy_shuolian_3");
        posAutoLayout(xy_shuolian_3);
        this.shuolianVector[2]=xy_shuolian_3;
        xy_shuolian_3.setVisible(false);

        var xy_shuolian_4 = root.getChildByName("xy_shuolian_3_0");
        posAutoLayout(xy_shuolian_4);
        this.shuolianVector[3]=xy_shuolian_4;
        xy_shuolian_4.setVisible(false);

        var yeqian1 = root.getChildByName("yeqian1");
        yeqian1.ignoreContentAdaptWithSize(true);
        yeqian1.setTag(1);
        posAutoLayout(yeqian1);
        yeqian1.setTouchEnabled(true);
        yeqian1.addTouchEventListener(this.yeqianCallback,this);
        this.yeqianVector[0]=yeqian1;

        var title1 = root.getChildByName("Text_12");
        posAutoLayout(title1);
        title1.ignoreContentAdaptWithSize(true);
        title1.setString(ResMgr.inst().getString("college_2"));
        title1 = BorderText.replace(title1);
        this.titleVector[0]=title1;
        //title1.setVisible(false);

        var yeqian2 = root.getChildByName("yeqian2");
        yeqian2.ignoreContentAdaptWithSize(true);
        yeqian2.setTag(2);
        posAutoLayout(yeqian2);
        yeqian2.setTouchEnabled(true);
        yeqian2.addTouchEventListener(this.yeqianCallback,this);
        this.yeqianVector[1]=yeqian2;
        //yeqian2.setVisible(false);

        var title2 = root.getChildByName("Text_13");
        title2.ignoreContentAdaptWithSize(true);
        posAutoLayout(title2);
        title2.setString(ResMgr.inst().getString("college_3"));
        title2 = BorderText.replace(title2);
        this.titleVector[1]=title2;
        //title2.setVisible(false);

        var yeqian3 = root.getChildByName("yeqian3");
        yeqian3.ignoreContentAdaptWithSize(true);
        yeqian3.setTag(3);
        posAutoLayout(yeqian3);
        yeqian3.setTouchEnabled(true);
        yeqian3.addTouchEventListener(this.yeqianCallback,this);
        this.yeqianVector[2]=yeqian3;
        yeqian3.setVisible(false);

        var title3 = root.getChildByName("Text_14");
        title3.ignoreContentAdaptWithSize(true);
        posAutoLayout(title3);
        title3.setString(ResMgr.inst().getString("college_4"));
        title3 = BorderText.replace(title3);
        this.titleVector[2]=title3;
        title3.setVisible(false);

        var yeqian4 = root.getChildByName("yeqian4");
        yeqian4.ignoreContentAdaptWithSize(true);
        yeqian4.setTag(4);
        posAutoLayout(yeqian4);
        yeqian4.setTouchEnabled(true);
        yeqian4.addTouchEventListener(this.yeqianCallback,this);
        this.yeqianVector[3]=yeqian4;
        yeqian4.setVisible(false);

        var title4 = root.getChildByName("Text_15");
        title4.ignoreContentAdaptWithSize(true);
        posAutoLayout(title4);
        title4.setString(ResMgr.inst().getString("college_5"));
        title4 = BorderText.replace(title4);
        this.titleVector[3]=title4;
        title4.setVisible(false);

        var Image_1 = root.getChildByName("Image_8");
        sizeAutoLayout(Image_1);

        var Image_154 = root.getChildByName("Image_154");
        sizeAutoLayout(Image_154);

        var scrollview = root.getChildByName("ScrollView_1");
        sizeAutoLayout(scrollview);

        scrollview.addEventListener(this.scrollCall, this );
        var item0 = scrollview.getChildByName("Panel_4");
        item0.setVisible(false);
        this.scrol = scrollview;
        this.itemRoot = item0;

        //var barBg = root.getChildByName("Image_16");
        //posAutoLayout(barBg,0.5);
        //sizeAutoLayout(barBg);

        var Image_158 = root.getChildByName("Image_158");
        sizeAutoLayout(Image_158);
        var Image_157 = root.getChildByName("Image_157");
        posAutoLayout(Image_157);
        var Panel_10 = root.getChildByName("Panel_10");
        posAutoLayout(Panel_10);
        var Image_157_0 = root.getChildByName("Image_157_0");
        posAutoLayout(Image_157_0);

        var ScrollView_2 = root.getChildByName("ScrollView_2");
        sizeAutoLayout(ScrollView_2);
        this.rightScroll = ScrollView_2;
        var rightroot = ScrollView_2.getChildByName("Panel_9");
        rightroot.setVisible(false);
        this.rightItemRoot = rightroot;
        var Button_9 = rightroot.getChildByName("Button_9");
        Button_9.addTouchEventListener(this.tokenCallback,this);
        var title = Button_9.getChildByName("Text_37");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("xiangqing_15"));
        Button_9.setVisible(false);

        var Button_10 = root.getChildByName("Button_10");
        Button_10.addTouchEventListener(this.upgradeCallback,this);
        var Text_38 = Button_10.getChildByName("Text_38");
        Text_38.ignoreContentAdaptWithSize(true);
        Text_38.setString(ResMgr.inst().getString("shengji_0"));

        var Panel_18 = this.root.getChildByName("Panel_18");
        Panel_18.setVisible(false);
        sizeAutoLayout(Panel_18);
        var Button_10_0 = this.root.getChildByName("Button_10_0");
        Button_10_0.setVisible(false);
        Button_10_0.setTag(1);
        var Button_10_1 = this.root.getChildByName("Button_10_1");
        Button_10_1.setVisible(false);
        Button_10_1.setTag(2);
        var title = Button_10_0.getChildByName("Text_38");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("college_22"));
        title = Button_10_1.getChildByName("Text_38");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("college_17"));
        Button_10_0.addTouchEventListener(this.downBtnCallback,this);
        Button_10_1.addTouchEventListener(this.downBtnCallback,this);
        var Image_167_0 = Panel_18.getChildByName("Image_167_0");
        posAutoLayout(Image_167_0);

        //this.barTotalHeight = barBg.getContentSize().height;

        //cc.log("滑动条 背景长 ", this.barTotalHeight);

        //this.scrollbar = root.getChildByName("Image_18");
        //posAutoLayout(this.scrollbar);
        //this.scrollPosY = this.scrollbar.getPositionY();

        //var bottomPanel = root.getChildByName("Image_6");
        //bottomPanel.setVisible(false);

        //var button = bottomPanel.getChildByName("Button_4");
        //button.addTouchEventListener(this.buttonCallback,this);
        //var buttonTitle = button.getChildByName("Text_23");
        //buttonTitle.ignoreContentAdaptWithSize(true);
        //buttonTitle.setString(ResMgr.inst().getString("dikuai_5"));

        //var button_accelerate = bottomPanel.getChildByName("Button_4_0");
        //button_accelerate.addTouchEventListener(this.buttonCallback2,this);
        //var buttontitle = button_accelerate.getChildByName("Text_23");
        //buttontitle.ignoreContentAdaptWithSize(true);
        //buttontitle.setString(ResMgr.inst().getString("college_17"));

        var guideData=ModuleMgr.inst().getData("GuideModule");
        if(guideData&&guideData._guideBean&&guideData._guideBean._idStep=="3_10"){//(!guideData&&mainData.playerData.guide=="2_1")||
            var size = cc.director.getVisibleSize();
            EventMgr.inst().dispatchEvent("guide_handP",cc.p(195,size.height-190));//发送引导点击位置事件
        }
    },

    upgradeCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            EventMgr.inst().dispatchEvent(CastleEvent.TECH_UPGRADE_SUCCESS, this.selecttingTech,this._array);//升级科技
            ModuleMgr.inst().closeModule("CollegeModule");
        }
    },

    scrollCall: function (node, type) {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                //cc.log("EVENT_SCROLLING");
                //var pos = this.scrol.getInnerContainer().getPosition();
                //var number = this.barPercent_total+pos.y;
                //var per = number *100 / this.barPercent_total;
                //if (per < 0) {
                //    per =0
                //}
                //if (per > 100) {
                //    per =100
                //}
                //this.refreshScrollbarState(per);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                //cc.log("EVENT_SCROLL_TO_TOP");
                //this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                //cc.log("EVENT_SCROLL_TO_BOTTOM");
                //this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    yeqianCallback:function(sender,type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            var tag = sender.getTag();
            cc.log("touch yeqian tag",tag);
            if(this.shuolianVector[tag-1].isVisible()) {
                cc.error("locking");
                ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("college_19"),color:null,time:null,pos:null});
                return;
            }

            if(tag != this.selectingTag) {
                this.selectingTag = tag;
                this.refreshYeqianState(tag)
            }
        }
    },

    buttonCallback: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            //cc.log("@@@;;;;;;",this._time);
            var layer = new CollegeLevelCancelLayer(this.selecttingTech,this._time);
            //this.addChild(layer);
            ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOPUI);
        }
    },

    buttonCallback2: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            //ModuleMgr.inst().openModule("AccelerateModule", { id:this.selecttingTech, type:4 } );
            ModuleMgr.inst().openModule("AccelerateModule", { id:null, blockId:null, collegeId:this.selecttingTech,type:4,time:this._time*1000 } );
        }
    },

    destroy:function()
    {
        this.root=null;
        this.itemMap=null;
        this.scrol=null;
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netCallback, this);
        EventMgr.inst().removeEventListener(CastleEvent.TECH_UPGRADE_COMPLETE, this.eventCallback, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_TECH_TIME, this.netUpdateTechTime, this);
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().removeEventListener( "using_token", this.usingCallback,this );
    },

    show:function( data )
    {
        this._id = data.id;
        this._index = data.blockId;

        var blockData = ModuleMgr.inst().getData("CastleModule").getNetBlock()[this._index];
        this.collegeLevel = blockData._building_level;

        var building = ModuleMgr.inst().getData("CastleModule").getNetTechByState(CastleData.STATE_UPGRADE);
        cc.log("正在升级的科技个数 ",building.length,"collegelevel ",this.collegeLevel);
        if (building.length > 0) {
            this.isUpdate = true;
            this.updateTechData = building[0];
        }

        if (this.isUpdate && this.updateTechData) {
            cc.log("正在升级的科技 ID",this.updateTechData._tech_id,this.updateTechData._tech_level);
            var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+this.updateTechData._tech_id+","+(parseInt(this.updateTechData._tech_level)==0?1:this.updateTechData._tech_level)+"]" ]);

            this.selectingTag = tech_data.tech_type;
            //this.refreshBottomInfo(this.updateTechData._tech_id);
            this.upgradingTech = this.updateTechData._tech_id;
        }
        else{
            this.upgradingTech = 0 ;
        }

        //getNetTech
        //var data = ModuleMgr.inst().getData("CastleModule").getNetTech();
        //for(var key in data) {
        //    cc.log("key",key,data[key]._tech_level);
        //}

        var tempData = [0,10,10,10];
        for (var i in tempData) {
            var tag = parseInt(i)+1;
            //cc.log("level", tag);
            var label = this.shuolianVector[i].getChildByName("level"+tag);
            label.ignoreContentAdaptWithSize(true);
            label.setString(tempData[i]);
            if (tempData[i] <= this.collegeLevel) {
                this.shuolianVector[i].setVisible(false);
                this.yeqianVector[i].setTouchEnabled(true);
            }
        }

        //cc.log("selectingTag", this.selectingTag);
        this.refreshYeqianState(this.selectingTag);

    },

    close:function() {

    },

    refreshYeqianState: function (tag) {
        for (var i = 0; i < this.yeqianVector.length; i++) {
            if (!this.shuolianVector[i].isVisible()) {
                if (tag == i+1) {
                    this.yeqianVector[i].loadTexture("ty_shangbiaoqianxuanzhong1.png",ccui.Widget.PLIST_TEXTURE);
                    this.yeqianVector[i].setLocalZOrder(10);
                    this.titleVector[i].setLocalZOrder(11);
                    this.titleVector[i].setColor(cc.color(252,250,155,255));
                    this.titleVector[i].setFontSize(24);
                }
                else {
                    this.yeqianVector[i].loadTexture("ty_shangbiaoweiqianxuanzhong.png",ccui.Widget.PLIST_TEXTURE);
                    this.yeqianVector[i].setLocalZOrder(0);
                    this.titleVector[i].setLocalZOrder(1);
                    this.titleVector[i].setColor(cc.color(175,151,86,255));
                    this.titleVector[i].setFontSize(20);
                }
            }
        }

        this.refreshScrollview(tag);
    },

    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY-(this.barTotalHeight-this.scrollbar.height)*percent/100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },

    refreshScrollview: function (type) {
        this.tempdata = this._data[type-1];

        for (var index in this.itemMap) {
            if (this.itemMap[index]) {
                this.itemMap[index].removeFromParent(true);
            }
        }
        this.itemMap = [];

        var size = this.scrol.getContentSize();
        var counts = this.tempdata.length;
        var itemH = 138;

        var n1 = parseInt(counts / 3);
        var n2 = counts % 3;

        if (n2>0) {
            n1 += 1;
        }

        cc.log("counts / 3 = ", n1, "c ounts % 3 = ", n2);

        var h = n1 * itemH;
        //h = h > size.height ? h : size.height;
        //if (h < size.height) {
        //    h = size.height;
        //    this.isOnePage = true;
        //}
        //else {
        //    this.isOnePage = false;
        //}
        //
        //if (this.isOnePage) {
        //    this.refreshScrollbarState(100);
        //}
        //else {
        //    this.refreshScrollbarState(0);
        //}

        var tempdatabool = false;

        //cc.log("h ",h,"height ",size.height);
        var data = ModuleMgr.inst().getData("CastleModule").getNetTech();
        for(var key in data) {
            cc.log("key",key,data[key]._tech_id,data[key]._tech_level);
        }

        for( var i=0; i<counts ; i++ ) {
            var temp_techid = this.tempdata[i];

            var levelstring = 0;
            if(data[temp_techid]) {
                levelstring=data[temp_techid]._tech_level;
            }

            var it = this.itemRoot.clone();
            this.itemMap.push(it);
            this.scrol.addChild( it );
            it.setVisible(true);
            it.setPosition( 61 + 137*(i%3),h - itemH*0.5 - itemH*parseInt(i/3) );

            it.setUserData(temp_techid);

            var touchBg = it.getChildByName("Image_3");
            touchBg.setTouchEnabled(true);
            touchBg.setTag(i);
            touchBg.addTouchEventListener(this.itemTouch,this);

            var iconbg = it.getChildByName("Image_8");
            iconbg.ignoreContentAdaptWithSize(true);
            //icon.setScale(0.5);

            var ico = it.getChildByName("Image_10_0");
            ico.ignoreContentAdaptWithSize(true);
            //ico.setScale(0.4);

            var lock = it.getChildByName("Image_160");
            lock.setVisible(false);
            var select = it.getChildByName("Image_159");
            select.setVisible(false);

            //是否开放
            var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+temp_techid+","+1+"]" ]);
            var open_data = JSON.parse(tech_data.level_open);
            var lv = 1;
            for(var key in open_data){
                lv = open_data[key];
            }
            if(this.collegeLevel>=lv){
                ico.loadTexture(ResMgr.inst()._icoPath+temp_techid+"0.png");
                //icontap.loadTexture("ty_sytdj_xiaanniuxuanzhongdi.png",ccui.Widget.PLIST_TEXTURE);
            }
            else {
                ico.loadTexture(ResMgr.inst()._icoPath+temp_techid+"1.png");
                //icontap.loadTexture("ty_sytdj_xiaanniuxuanzhongdi1.png",ccui.Widget.PLIST_TEXTURE);
                lock.setVisible(true);
            }

            if (this.isUpdate) {
                if(temp_techid==this.upgradingTech){
                    cc.log("@当前正在升级的科技",i,temp_techid);
                    this.setUpItemSelected(i);
                    this.selecttingTech = this.tempdata[i];//当前正在升级的科技
                    //this.upgradingTech = this.tempdata[i];
                    tempdatabool = true;
                }
            }

            var level = it.getChildByName("Text_24");
            level.ignoreContentAdaptWithSize(true);
            level.setString(levelstring);

            var name = it.getChildByName("Text_25");
            name.ignoreContentAdaptWithSize(true);
            name.setString(ResMgr.inst().getString(temp_techid+"0"));
        }

        size.height = h > size.height ? h : size.height;
        this.scrol.setInnerContainerSize( size );
        this.scrol.jumpToTop();

        //var innerContainer = this.scrol.getInnerContainer();
        //var innerContainerSize = this.scrol.getInnerContainerSize();
        //var pos = innerContainer.getPosition();
        //cc.log("x ",pos.x, "y ",pos.y);
        //this.barPercent_total = Math.abs(pos.y);
        //cc.log("barPercent_total ", this.barPercent_total, "innerContainerSize.height",innerContainerSize.height);

        //if (this.barPercent_total==0) {
        //    //this.scrollbar.height=this.barTotalHeight
        //}
        //else {
        //    var barHeight = this.barTotalHeight*(1-(this.barPercent_total/innerContainerSize.height));
        //    cc.log("滑块高度 ", barHeight);
        //    //this.scrollbar.height=barHeight;
        //}

        //this.setUpItemSelected(0);
        //this.refreshBottomInfo(0);

        if(!this.isUpdate || !tempdatabool){
            cc.log("@test---------------------@@@@@@@@@@");
            this.setUpItemSelected(0);
            this.selecttingTech = this.tempdata[0];//当前选中的科技
        }

        cc.log("@_------------------>",this.selectingTag,this.selecttingTech);

        this.setRightContent(this.selecttingTech);
    },

    setRightContent: function (techid) {
        var techname = this.root.getChildByName("Image_157").getChildByName("Text_39");
        techname.ignoreContentAdaptWithSize(true);
        techname.setString(ResMgr.inst().getString("message_5")+ResMgr.inst().getString(techid+"0"));

        var rightpanel = this.root.getChildByName("Panel_10");

        var ico = rightpanel.getChildByName("Image_169");
        ico.ignoreContentAdaptWithSize(true);
        ico.loadTexture(ResMgr.inst()._icoPath+techid+"0.png");
        //ico.setScale(0.4);

        var techlevel = ModuleMgr.inst().getData("CollegeModule").getTechLevel(techid);
        var lv = rightpanel.getChildByName("Text_41");
        lv.ignoreContentAdaptWithSize(true);
        lv.setString(techlevel);

        var techdetail = rightpanel.getChildByName("Text_42_2");
        techdetail.ignoreContentAdaptWithSize(true);
        techdetail.setString(ResMgr.inst().getString(techid+"1"));

        var label = rightpanel.getChildByName("Text_42");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("message_3"));
        label = rightpanel.getChildByName("Text_42_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("message_4"));

        var nextLevel = techlevel+1;
        var tech_data_ex = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+techid+","+techlevel+"]" ]);
        var info = 0;
        if (techlevel==0) {
            info=0;
        }
        else {
            var jsondata = eval("(" + tech_data_ex.tech_effect + ")");
            for(var k in jsondata) {
                info = jsondata[k];
            }
        }

        cc.log("data",techid,nextLevel);

        var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+techid+","+nextLevel+"]" ]);
        if(tech_data==null) {
            tech_data = tech_data_ex;
            //this.max = true;
        }

        this._needResources = [];
        var resdata = eval("(" + tech_data.need_resource + ")");
        for(var i in resdata) {
            var temp = {};
            temp.key = i;
            temp.value = resdata[i];
            this._needResources.push(temp);
            cc.log("@res------>",i);
        }

        var info_next = 0;
        var sjsondata = eval("(" + tech_data.tech_effect + ")");
        for(var i in sjsondata) {
            info_next = sjsondata[i];
        }

        var deltNum11 = info*100;
        var str = deltNum11.toFixed(1)==parseInt(deltNum11)?parseInt(deltNum11):deltNum11.toFixed(1);

        var Text_46 = rightpanel.getChildByName("Text_46");
        Text_46.ignoreContentAdaptWithSize(true);
        Text_46.setString("+"+str+"%");

        deltNum11 = info_next*100;
        str = deltNum11.toFixed(1)==parseInt(deltNum11)?parseInt(deltNum11):deltNum11.toFixed(1);
        var Text_46_0 = rightpanel.getChildByName("Text_46_0");
        Text_46_0.ignoreContentAdaptWithSize(true);
        Text_46_0.setString("+"+str+"%");


        if(this.upgradingTech==techid){
            this.rightScroll.setVisible(false);
            var Button_10 = this.root.getChildByName("Button_10");
            Button_10.setVisible(false);

            var Panel_18 = this.root.getChildByName("Panel_18");
            Panel_18.setVisible(true);
            var Button_10_0 = this.root.getChildByName("Button_10_0");
            Button_10_0.setVisible(true);
            var Button_10_1 = this.root.getChildByName("Button_10_1");
            Button_10_1.setVisible(true);

            var it = Panel_18.getChildByName("Image_167_0");
            var Image_169_0  = it.getChildByName("Image_169_0");
            Image_169_0.ignoreContentAdaptWithSize(true);
            Image_169_0.loadTexture(ResMgr.inst()._icoPath+techid+"0.png");
            var lv = it.getChildByName("Text_41_0");
            lv.ignoreContentAdaptWithSize(true);
            lv.setString(techlevel);
            var la = it.getChildByName("Text_99");
            la.ignoreContentAdaptWithSize(true);
            la.setString(ResMgr.inst().getString("college_23"));
        }
        else{
            this.rightScroll.setVisible(true);
            var Button_10 = this.root.getChildByName("Button_10");
            Button_10.setVisible(true);
            var Panel_18 = this.root.getChildByName("Panel_18");
            Panel_18.setVisible(false);
            var Button_10_0 = this.root.getChildByName("Button_10_0");
            Button_10_0.setVisible(false);
            var Button_10_1 = this.root.getChildByName("Button_10_1");
            Button_10_1.setVisible(false);

            for(var i in this.rightVector){
                if(this.rightVector[i]){
                    this.rightVector[i].removeFromParent();
                }
            }
            this.rightVector = [];
            var count = this._needResources.length;
            var size = this.rightScroll.getContentSize();
            var height = this.rightItemRoot.getContentSize().height;
            var total = height*count;
            total = Math.max(total,size.height);

            for(var i =0 ; i < count; i++){
                var it = this.rightItemRoot.clone();
                it.setVisible(true);
                it.setPosition(cc.p(0,total-height*(i+1)));
                this.rightScroll.addChild(it);

                var Button_9 = it.getChildByName("Button_9");
                Button_9.setTag(i);
                it.setUserData(this._needResources[i]);

                this.rightVector.push(it);
                this.setRightIt(it,this._needResources[i]);
            }
            this.rightScroll.setInnerContainerSize(cc.size(size.width,total));
            this.rightScroll.jumpToTop();

            this.setNeedResNumber();

        }
    },

    tokenCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var tag = sender.getTag();
            var data = this._needResources[tag];
            ModuleMgr.inst().openModule("TokenModule",{"resid":data.key,"resnum":data.value});
        }
    },

    downBtnCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var tag = sender.getTag();
            if(tag==1){
                cc.log("left");
                EventMgr.inst().dispatchEvent(CastleEvent.TECH_CANCEL_SUCCESS, this.selecttingTech);//取消升级科技
            }
            else{
                cc.log("right");
                ModuleMgr.inst().openModule("AccelerateModule", { id:null, blockId:null, collegeId:this.selecttingTech,type:4,time:this._time*1000 } );
            }
        }
    },

    setRightIt: function (node, data) {
        var ico = node.getChildByName("Image_163_0");
        ico.ignoreContentAdaptWithSize(true);
        ico.loadTexture(ResMgr.inst()._icoPath + data.key +"0.png");

        var num = node.getChildByName("Text_36");
        num.ignoreContentAdaptWithSize(true);
        num.setString(StringUtils.getUnitNumberToFixed(data.value));

        var forbattle = BattleRes.indexOf(data.key)==-1?false:true;
        var button = node.getChildByName("Button_9");
        button.setVisible(!forbattle);

        var Image_2_1_0 = node.getChildByName("Image_163_1");
        Image_2_1_0.setVisible(!forbattle);
        var Image_2_2 = node.getChildByName("Image_163_0_0");
        Image_2_2.setVisible(!forbattle);
        Image_2_2.setScale(0.8);
        Image_2_2.loadTexture(this.getIconUrl(data.key));
        var Text_6 = node.getChildByName("Text_36_0");
        Text_6.ignoreContentAdaptWithSize(true);
        Text_6.setVisible(!forbattle);
        Text_6.setString(0);
    },

    setNeedResNumber: function () {
        var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
        for(var i in this._needResources){
            if(this.rightVector[i]){
                //var Text_3 = this.rightVector[i].getChildByName("Text_3");
                var itemCheck = this.rightVector[i].getChildByName("Image_165");
                itemCheck.ignoreContentAdaptWithSize(true);

                var counts = this._needResources[i].value;
                var res_counts = resData[this._needResources[i].key];
                if(res_counts==undefined) res_counts = 0;

                //cc.log("@res test", this.needRes[i].itemid,res_cou_nts,counts);
                if(res_counts<counts){
                    //Text_3.setColor(cc.color(212,87,87));

                    itemCheck.loadTexture("xueyuan_cuo.png",ccui.Widget.PLIST_TEXTURE);
                }
                else{
                    //Text_3.setColor(cc.color(239,235,198));

                    itemCheck.loadTexture("xueyuan_dui.png",ccui.Widget.PLIST_TEXTURE);
                }
                //Text_3.setString(counts);//StringUtils.getUnitNumber(counts)
            }
        }
    },

    getIconUrl: function (resid) {
        var url = ResMgr.inst()._icoPath;
        switch (parseInt(resid)){
            case 1101001:
                url += "11012010.png";
                break;
            case 1101002:
                url += "11012020.png";
                break;
            case 1101003:
                url += "11012030.png";
                break;
        }
        return url;
    },

    itemTouch: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            var tag = sender.getTag();
            cc.log("item touch ",tag);

            var tech = this.tempdata[tag];
            //var layer = new CollegeLevelConfirmLayer(tech,this.isUpdate);
            //ModuleMgr.inst().addNodeTOLayer(layer, ModuleLayer.LAYER_TYPE_TOPUI);
            this.selecttingTech = tech;
            this.setUpItemSelected(tag);
            this.setRightContent(tech);
        }
    },

    itemDownTouch: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED) {
            //var tag = sender.getTag();
            //cc.log("item down touch ",tag);
            ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("college_18"),color:null,time:null,pos:null});
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

    setUpItemSelected: function (index) {
        for (var i = 0; i < this.itemMap.length; i++) {
            var selected = this.itemMap[i].getChildByName("Image_159");
            if (index == i) {
                selected.setVisible(true);
                //selected.loadTexture("College/kejishang_canliangdadixuanzhong.png",ccui.Widget.PLIST_TEXTURE);
            }
            else {
                selected.setVisible(false);
                //selected.loadTexture("College/kejishang_canliangdadi.png",ccui.Widget.PLIST_TEXTURE);
            }
        }
    },

    refreshBottomInfo: function (techid) {
        var techlevel = ModuleMgr.inst().getData("CollegeModule").getTechLevel(techid);
        var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+techid+","+techlevel+"]" ])
        //ResMgr.inst().getJSON("City_College_tech",""+techid+techlevel,true);

        var ddd = ModuleMgr.inst().getData("CastleModule").getNetTech()[techid];

        if(!this.root) {
            cc.log("this.root null null");
        }

        var bottomPanel = this.root.getChildByName("Image_6");
        bottomPanel.setVisible(true);

        var icon = bottomPanel.getChildByName("icon");
        icon.setTexture(ResMgr.inst()._icoPath+techid+"0.png");
        icon.setScale(0.5);

        var name = bottomPanel.getChildByName("Text_20");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(techid+"0"));

        cc.log("科技剩余时间 毫秒",ddd._state_remain);
        this._time = parseInt(ddd._state_remain/1000);
        var cd = bottomPanel.getChildByName("Text_22");
        cd.ignoreContentAdaptWithSize(true);
        cd.setString(StringUtils.formatTimer(this._time*1000));

        //this.schedule(this.scheduleCallback,1);
    },

    netUpdateTechTime: function (type, netTech) {

        var node = this.getTechNode(netTech._tech_id);
        if(node){
            this._time = parseInt(netTech._state_remain/1000);
            var Image_161 = node.getChildByName("Image_161");
            Image_161.setVisible(true);
            var cd = node.getChildByName("Text_35");
            cd.setVisible(true);
            cd.setString(StringUtils.formatTimer(this._time*1000));
        }


        //var bottomPanel = this.root.getChildByName("Image_6");
        //var cd = bottomPanel.getChildByName("Text_22");
        //cd.ignoreContentAdaptWithSize(true);
        //cd.setString(StringUtils.formatTimer(this._time*1000));
    },

    getTechNode: function (techid) {
        for(var i in this.itemMap){
            var node = this.itemMap[i];
            var data = node.getUserData();
            if(data == techid){
                return node;
            }
        }
        return null;
    },

    netCallback: function (type,data) {
        //cc.log("collegeModule",data);
        if (data == CastleNetEvent.SEND_TECH_UPGRADE) {
            var building = ModuleMgr.inst().getData("CastleModule").getNetTechByState(CastleData.STATE_UPGRADE);
            cc.log("正在升级的科技个数 ",building.length,"collegelevel ",this.collegeLevel);
            if (building.length > 0) {
                this.isUpdate = true;
                this.updateTechData = building[0];
            }

            if (this.isUpdate && this.updateTechData) {
                cc.log("正在升级的科技 ID",this.updateTechData._tech_id,this.updateTechData._tech_level);

                var tech_data = modelMgr.call("Table", "getTableItemByValue", ["City_College_tech","["+this.updateTechData._tech_id+","+this.updateTechData._tech_level+"]" ])
                //cc.log("科技type",tech_data.tech_type);


                //this.refreshBottomInfo(this.updateTechData._tech_id);
            }
            this.refreshYeqianState(this.selectingTag);
        }
        else if (data == CastleNetEvent.SEND_TECH_CANCEL) {
            //this.unschedule(this.scheduleCallback);

            this.isUpdate = false;
            this.upgradingTech = 0;
            //var bottomPanel = this.root.getChildByName("Image_6");
            //bottomPanel.setVisible(false);
            this.refreshYeqianState(this.selectingTag);
        }
    },

    eventCallback: function (type) {
        //this.unschedule(this.scheduleCallback);

        this.isUpdate = false;
        this.upgradingTech = 0;
        //var bottomPanel = this.root.getChildByName("Image_6");
        //bottomPanel.setVisible(false);
        this.refreshYeqianState(this.selectingTag);
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(7));
    },
    //引导处理方法
    doGuide:function(type,guideId){
        cc.log("college引导触发操作doGuide"+guideId);
        if(guideId=="3_11") {
            if (this.itemMap[0].getChildByName("Image_3"))   this.itemTouch(this.itemMap[0].getChildByName("Image_3"), ccui.Widget.TOUCH_ENDED);

        }
    },
    //scheduleCallback: function (ft) {
    //    var bottomPanel = this.root.getChildByName("Image_6");
    //    this._time--;
    //
    //    var data = ModuleMgr.inst().getData("CollegeModule");
    //    data.remainTime = this._time;
    //
    //    if (this._time<0) {
    //        this._time=0;
    //        data.remainTime=0;
    //        this.unschedule(this.scheduleCallback);
    //
    //        this.isUpdate = false;
    //        bottomPanel.setVisible(false);
    //        this.refreshYeqianState(this.selectingTag);
    //        return;
    //    }
    //    //var bottomPanel = this.root.getChildByName("Image_6");
    //    bottomPanel.setVisible(true);
    //    var cd = bottomPanel.getChildByName("Text_22");
    //    cd.ignoreContentAdaptWithSize(true);
    //    cd.setString(StringUtils.formatTimer(this._time*1000));
    //}

    usingCallback: function (event, id, counts,exinfo) {
        for(var i in this.rightVector){
            var it = this.rightVector[i];
            if(it){
                var userdata = it.getUserData();
                if(userdata.key==id){
                    var tokenlabel = it.getChildByName("Text_36_0");
                    tokenlabel.setString(counts);

                    var reslabel = it.getChildByName("Text_36");
                    reslabel.setString(exinfo);

                    var rescheck = it.getChildByName("Image_165");

                    //刷新状态
                    var resData = ModuleMgr.inst().getData("CastleModule").getNetResource();
                    if (parseInt(exinfo) > parseInt(resData[id])) {
                        //不满足
                        reslabel.setColor(cc.color(212,87,87,255));
                        rescheck.loadTexture("xueyuan_cuo.png",ccui.Widget.PLIST_TEXTURE);
                        //this.playEffect(this.itemDict[id],true);
                    }
                    else {
                        //满足
                        reslabel.setColor(cc.color(255,255,255,255));
                        rescheck.loadTexture("xueyuan_dui.png",ccui.Widget.PLIST_TEXTURE);
                        //this.playEffect(this.itemDict[id],false);
                    }
                    //-----------------
                    var itemId = null;
                    switch (parseInt(id)){
                        case 1101001:
                            itemId = 1101201;
                            break;
                        case 1101002:
                            itemId = 1101202;
                            break;
                        case 1101003:
                            itemId = 1101203;
                            break;
                    }
                    var count = counts;

                    var exist = false;
                    for(var i in this._array){
                        if(this._array[i].itemId==itemId){
                            this._array[i].counts = count;
                            exist = true;
                        }
                    }

                    if(!exist){
                        this._array.push({"itemId":itemId,"counts":count});
                    }
                    break;
                }
            }
        }
    }
});