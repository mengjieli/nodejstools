/**
 * Created by cgMu on 2016/2/23.
 */

var SearchLayer = cc.Node.extend({
    _textField1:null,
    _textField2:null,
    serverData:null,

    ctor: function (name,centerPoint,data) {
        this._super();
        this.serverData = data;

        var root = ccs.load("res/images/ui/smallmap/searchLayer.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var root_panel = root.getChildByName("Panel_1").getChildByName("Panel_4");

        var closebtn = root_panel.getChildByName("Button_1");
        closebtn.addTouchEventListener(this.touchCallback,this);

        var text = root_panel.getChildByName("Text_title");
        text.ignoreContentAdaptWithSize(true);
        text.setString(ResMgr.inst().getString("smallmap_2"));

        var confirm_btn = root_panel.getChildByName("Button_3");
        confirm_btn.addTouchEventListener(this.btnCallback,this);
        var confirm_text = confirm_btn.getChildByName("Text_2");
        confirm_text.ignoreContentAdaptWithSize(true);
        confirm_text.setString(ResMgr.inst().getString("smallmap_3"));

        var label = root_panel.getChildByName("Image_6").getChildByName("Text_18");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("smallmap_4"));

        label = root_panel.getChildByName("Image_6").getChildByName("Text_18_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(name);

        label = root_panel.getChildByName("Image_6_0").getChildByName("Text_18_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString("X：");

        var textField = root_panel.getChildByName("Image_6_0").getChildByName("TextField_2");
        textField.setPlaceHolder("");
        textField.setString(centerPoint.x);
        textField.addEventListener(this.fieldCallback1,this);
        this._textField1 = textField;

        label = root_panel.getChildByName("Image_6_0_0").getChildByName("Text_18_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString("Y：");

        textField = root_panel.getChildByName("Image_6_0_0").getChildByName("TextField_2_0");
        textField.setPlaceHolder("");
        textField.setString(centerPoint.y);
        textField.addEventListener(this.fieldCallback2,this);
        this._textField2 = textField;
    },

    touchCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;

        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        this.removeFromParent(true);
    },

    btnCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        var x = this._textField1.getString();
        var y = this._textField2.getString();
        if(x=="" || y==""||x=="-"||y=="-"){
            ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("smallmap_9"),color:null,time:null,pos:null});
            return;
        }
        x=parseInt(x);
        y=parseInt(y);

        if (x >= this.serverData.pointX && x < this.serverData.pointX + this.serverData.width &&
            y >= this.serverData.pointY && y < this.serverData.pointY + this.serverData.height) {
            EventMgr.inst().dispatchEvent("Search_Map",x,y);
            this.removeFromParent(true);
        }
        else{
            cc.log("@坐标不在当前地图上");
            ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("smallmap_10"),color:null,time:null,pos:null});
        }
    },

    fieldCallback1: function (sender, type) {
        if (type == ccui.TextField.EVENT_INSERT_TEXT || type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            var str = sender.getString();
            if(!str.match(/^\-?\d*$/)){
                this._textField1.setString("");
            }
        }
    },

    fieldCallback2: function (sender, type) {
        if (type == ccui.TextField.EVENT_INSERT_TEXT || type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            var str = sender.getString();
            if(!str.match(/^\-?\d*$/)){
                this._textField2.setString("");
            }
        }
    }
});