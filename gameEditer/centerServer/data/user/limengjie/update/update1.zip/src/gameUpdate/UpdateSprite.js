var UpdateSprite = cc.Sprite.extend({
    txt: null,
    _loadingBar:null,
    _percent:null,

    ctor: function () {
        this._super();
        this.initUI();
    },
    /**
     * @param percent 0 - 100
     */
    setPercent: function (percent) {
        this._loadingBar.setPercent( parseInt(percent) );
        this._percent.setString(parseInt(percent)+"%");
    },
    /**
     * 热更新完毕
     */
    updateComplete: function () {
        new StartGame();
    },

    initUI: function () {
        var scaleY = cc.Director.getInstance().getWinSize().height/640;
        var scaleX = cc.Director.getInstance().getWinSize().width/960;
        var scale = scaleX>scaleY?scaleX:scaleY;
        var winWidth = cc.Director.getInstance().getWinSize().width/scale;
        var winHeight = cc.Director.getInstance().getWinSize().height/scale;
        this.setScale(scale);

        var size = cc.director.getVisibleSize();
        var bg = ccui.ImageView();
        bg.loadTexture("res/loadingAndLogining/loading_beijing.png");
        this.addChild(bg);
        bg.setPosition(winWidth/2,winHeight/2);

        var ui = ccs.load( "res/images/ui/login/loading.json", "res/images/ui/" ).node;
        this.addChild( ui );

        ui.setContentSize( size );
        ccui.helper.doLayout( ui );

        this._loadingBar = ui.getChildByName( "Panel_1" ).getChildByName( "LoadingBar_1" );

        var bg = ui.getChildByName("Panel_1").getChildByName("Image_1");
        bg.setVisible(false);

        var tips = ui.getChildByName("Panel_1").getChildByName("Text_1");
        tips.ignoreContentAdaptWithSize(true);
        tips.setString("");
        tips.setVisible(true);
        this._percent = tips;
    }
});