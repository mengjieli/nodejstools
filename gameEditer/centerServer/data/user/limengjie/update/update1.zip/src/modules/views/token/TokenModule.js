/**
 * Created by cgMu on 2016/1/25.
 */

var TokenModule = ModuleBase.extend({
    _root:null,
    _expartLabel:null,
    _slider:null,
    _usingCountsLabel:null,
    _textField:null,
    _resNumLabel:null,

    resId:null,
    resNum:null,
    tokenNum:0,//使用代币数量
    tokenId:null,//对应代币道具ID

    tokenCounts:null,//代币数量
    tokenUnit:null,//一代币 == ？资源

    ctor:function() {
        this._super();
    },

    initUI:function() {
        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var json = ccs.load("res/images/ui/daibi/Layer.json","res/images/ui/");
        var root_ = json.node;
        this.addChild(root_);

        //适配
        var size = cc.director.getVisibleSize();
        root_.setContentSize(size);
        ccui.helper.doLayout(root_);

        var root = root_.getChildByName("Panel_1");
        posAutoLayout(root,0.5);
        sizeAutoLayout(root);
        this._root = root;

        var closeButton = ccui.helper.seekWidgetByName(root, "Button_1");
        closeButton.addTouchEventListener(this.touchCallback,this);

        var confirmbtn = ccui.helper.seekWidgetByName(root,"Button_2");
        confirmbtn.addTouchEventListener(this.confirmbtnCallback,this);
        var buttonTitle = confirmbtn.getChildByName("Text_2");
        buttonTitle.ignoreContentAdaptWithSize(true);
        buttonTitle.setString(ResMgr.inst().getString("public_ok"));

        var label1 = root.getChildByName("Text_1");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("token_1"));

        label1 = root.getChildByName("Text_29");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("token_2"));

        label1 = root.getChildByName("Text_29_0");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("token_3"));

        label1 = root.getChildByName("Text_29_0_0");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("token_4"));

        label1 = root.getChildByName("Text_29_1");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("token_5"));

        //超出部分
        var txt2 = root.getChildByName("Text_31_0");
        txt2.ignoreContentAdaptWithSize(true);
        this._expartLabel = txt2;
        //this.setExPart(0);

        txt2 = root.getChildByName("Text_31_0_0");
        txt2.ignoreContentAdaptWithSize(true);
        this._resNumLabel = txt2;

        var slider = root.getChildByName("Slider_1");
        slider.addEventListener(this.sliderCallback, this);
        //slider.setPercent(100);
        this._slider = slider;

        var using_counts = root.getChildByName("Text_34");
        using_counts.ignoreContentAdaptWithSize(true);
        this._usingCountsLabel = using_counts;

        var TextField_1 = root.getChildByName("TextField_1");
        TextField_1.addEventListener(this.fieldCallback,this);
        this._textField = TextField_1;

        var sub = root.getChildByName("Image_197");
        sub.setTouchEnabled(true);
        sub.addTouchEventListener(this.subCallback,this);

        var add = root.getChildByName("Image_197_0");
        add.setTouchEnabled(true);
        add.addTouchEventListener(this.addCallback,this);

    },

    destroy:function() {

    },

    show:function( data ) {
        this.resId = data.resid;
        this.resNum = data.resnum?data.resnum:0;

        this.tokenId = this.getTokenId();
        this.tokenUnit = this.getTokenUnit();
        this.tokenCounts = this.getTokenCounts();

        this.setContents();
    },

    close:function( ) {

    },

    touchCallback: function (sender,type) {
        switch (type) {
            case ccui.Widget.TOUCH_ENDED:
                ModuleMgr.inst().closeModule("TokenModule");
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
                break;
            default:
                break;
        }
    },

    confirmbtnCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        var num = this.resNum - this.tokenNum*this.tokenUnit;
        EventMgr.inst().dispatchEvent("using_token",this.resId,this.tokenNum,num);
        ModuleMgr.inst().closeModule("TokenModule");
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    subCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.tokenNum--;
        if(this.tokenNum<0) this.tokenNum = 0;

        this.usingToken(this.tokenNum);
    },

    addCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.tokenNum++;
        if(this.tokenNum>this.tokenCounts) this.tokenNum = this.tokenCounts;

        this.usingToken(this.tokenNum);
    },

    fieldCallback: function (sender, type) {
        if (type == ccui.TextField.EVENT_INSERT_TEXT || type == ccui.TextField.EVENT_DELETE_BACKWARD) {
            var text = sender.getString();
            var use_counts = parseInt(text);
            var reg = new RegExp("^[0-9]*$");
            if (!reg.test(text)) {
                this._textField.setString(use_counts);
            }
            if (text == "") {
                use_counts = 0;
            }

            if(use_counts<0){
                use_counts=0;
            }
            if(use_counts>this.tokenCounts){
                use_counts = this.tokenCounts;
            }
            this.tokenNum=use_counts;
            this.usingToken(this.tokenNum);

        }
    },

    getIconUrl: function (resid) {
        var url = ResMgr.inst()._icoPath;
        switch (parseInt(resid)){
            case 1101001:
                url += "11012010.png";
                break;
            case 1101002:
                url += "11012020.png";
                break;
            case 1101003:
                url += "11012030.png";
                break;
        }
        return url;
    },

    getTokenId: function () {
        var tokenid = null;
        switch (parseInt(this.resId)){
            case 1101001:
                tokenid = 1101201;
                break;
            case 1101002:
                tokenid = 1101202;
                break;
            case 1101003:
                tokenid = 1101203;
                break;
        }
        return tokenid;
    },

    setContents: function () {
        var icon = this._root.getChildByName("Image_144_0_0");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(this.resId));

        var icon_down = this._root.getChildByName("Image_144_0_0_0");
        icon_down.ignoreContentAdaptWithSize(true);
        icon_down.loadTexture(this.getIconUrl(this.resId));
        icon_down.setScale(0.5);

        //需要消耗
        var txt1 = this._root.getChildByName("Text_31");
        txt1.ignoreContentAdaptWithSize(true);
        txt1.setString(this.resNum);

        var counts = this._root.getChildByName("Text_33");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString(this.tokenCounts);



        var num = Math.ceil(this.resNum/this.tokenUnit);
        if(num>this.tokenCounts) num = this.tokenCounts;
        this.tokenNum = num;

        this.usingToken(this.tokenNum);

    },

    getTokenCounts: function () {
        return ModuleMgr.inst().getData("ItemModule").getCountsByItemId(this.tokenId);
        //return 1000;
    },

    getTokenUnit: function () {
        var itemConfig = modelMgr.call("Table", "getTableItemByValue", ["item", this.tokenId]);
        return itemConfig?itemConfig.value:1000;
    },

    sliderCallback: function (sender,type) {
        if (type == ccui.Slider.EVENT_PERCENT_CHANGED) {
            var num = sender.getPercent();
            var use_counts = num * this.tokenCounts / 100;
            this.tokenNum = parseInt(use_counts);

            this.usingToken(this.tokenNum);
        }
    },

    usingToken: function (counts) {
        this._usingCountsLabel.setString(counts);
        this._slider.setPercent(this.tokenCounts==0?0:counts*100/ this.tokenCounts);

        var num = counts*this.tokenUnit - this.resNum;
        if (num<0) num = 0;
        this._expartLabel.setString(num);
        this._resNumLabel.setString(counts*this.tokenUnit);

        this._textField.setString(counts);
    }

});