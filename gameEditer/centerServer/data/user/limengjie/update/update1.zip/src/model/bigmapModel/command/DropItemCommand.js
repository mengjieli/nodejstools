var DropItemCommand = (function (_super) {
    __extends(DropItemCommand, _super);

    function DropItemCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
    }

    var d = __define, c = DropItemCommand;
    p = c.prototype;

    /**
     * 初始化
     * @param params Object
     */
    p.init = function (params) {
        mainData.mapData.addListener("dropItem",this.fightChange,this);
    }

    p.fightChange = function(val) {
        ModuleMgr.inst().openModule("AlertGainModule",{"arr":[ResMgr.inst().getIcoPath(val.id)]});
    }

    return DropItemCommand;
})(CycleCommand);