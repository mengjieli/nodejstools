/**
 * Created by Administrator on 2015/11/7.
 *
 * 适配
 */


var AdaptiveUtils = {


    setAlign:function( fatherNode, sonNode, colLfet, colCentre )
    {

    }
};

