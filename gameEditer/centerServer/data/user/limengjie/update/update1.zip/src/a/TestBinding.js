var TestBinding = (function () {
    function TestBinding() {
        var content = "(main.viewPort.width)||b==true?mainData.playerData.nick:15+\"\wo le ge ca\"";
    }
    Object.defineProperty(TestBinding.prototype, "name", {
        set: function (val) {
        },
        enumerable: true,
        configurable: true
    });
    return TestBinding;
})();
//# sourceMappingURL=TestBinding.js.map