var ModelManager = function () {
    if (ModelManager.instance) {
        GameSDK.Error.throw("ModelManager 已经初始化过了");
        return;
    }
    ModelManager.instance = this;

    this.models = [];
}

ModelManager.prototype.registerModel = function (model) {
    for (var i = 0; i < this.models.length; i++) {
        if (this.models[i].name == model.name) {
            trace("注册模块失败，重复注册模块 :" + model.name);
            throw "注册模块失败，重复注册模块 :" + model.name;
            return;
        }
    }
    this.models.push(model);
}

ModelManager.prototype.load = function (complete, thisObj) {
    var index = -1;
    var last = (new Date()).getTime();
    var loadNextModel = function () {
        trace("加载模块:",index,this.models.length);
        var model;
        if (index >= 0) {
            model = this.models[index];
            model.removeEventListener(flower.Event.COMPLETE, loadNextModel, this);
            model.ready();
            var now = (new Date()).getTime();
        }
        if (index < this.models.length - 1) {
            index++;
            model = this.models[index];
            model.addEventListener(flower.Event.COMPLETE, loadNextModel, this);
            model.load();
        } else {
            if (complete) {
                complete.call(thisObj);
            }
        }
    }
    loadNextModel.call(this);
}

ModelManager.prototype.registerAPI = function (name, params) {

}

/**
 * 调用模块 api
 * @param modelName 模块名称
 * @param apiName api 名称
 * @param args 参数，以数组的形式传递
 */
ModelManager.prototype.call = function (modelName, apiName, args) {
    var model;
    for (var i = 0; i < this.models.length; i++) {
        if (this.models[i].name == modelName) {
            model = this.models[i];
            break;
        }
    }
    if (!model) {
        throw "调用模块 api 失败，没有找到模块:" + modelName;
        return;
    }
    //trace(model,apiName)
    if(!model[apiName]) {
        throw "调用模块 api 失败，没有找到模块对应的 api:" + modelName + "." + apiName;
        return;
    }
    return model[apiName].apply(model, args);
}

ModelManager.instance = null;

ModelManager.getInstance = function () {
    return ModelManager.instance;
}