/**
 * Created by Administrator on 2015/10/23.
 */

var MainMenuModule = ModuleBase.extend({
    initMenu:null,

    _buildingDequeItems:null,
    _item:null,

    _buildingDequeShow:true,

    ctor:function()
    {
        this._super();

        this.initMenu = [1,2,4,5,6];
        this._buildingDequeItems = [];
    },

    initUI:function()
    {
        //cc.log("init mainmenu~~~~~~~~~~~~~~~~~~~~~~~~~~");
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().addEventListener( MailEvent.SEND_NEW_MAIL, this.mailNewCall, this );
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE,this.netComplete,this);

        this._ui = ccs.load("res/images/ui/mainMenuModule/Layer.json","res/images/ui/").node;
        this.addChild( this._ui );

        //主城名称监听
        mainData.uiData.addListener("currentCastleId",this.currentCastleName,this);

        //for( var i=0; i<6; i++ )
        //{
        //    var but = this._ui.getChildByName("item" + i );
        //    but.setTouchEnabled(true);
        //    but.setTag(i);
        //    but.addTouchEventListener( this.buttonCall, this );
        //    var title = but.getChildByName("zi");
        //    title.ignoreContentAdaptWithSize(true);
        //    title.setString(ResMgr.inst().getString("mainmenu_"+i));//注意索引的对应关系
        //    //记录底边按钮，用于UI切换动画
        //    ModuleMgr.inst().getData("BattleUIModule").pushRowList(but);
        //}
        for(var i in this.initMenu) {
            var index = this.initMenu[i];
            var but = this._ui.getChildByName("item" + index );
            but.setTouchEnabled(true);
            but.setTag(index);
            but.addTouchEventListener( this.buttonCall, this );
            var title = but.getChildByName("zi");
            title.ignoreContentAdaptWithSize(true);
            title.setString(ResMgr.inst().getString("mainmenu_"+index));//注意索引的对应关系
            title = BorderText.replace(title);
            // 记录底边按钮，用于UI切换动画
            ModuleMgr.inst().getData("BattleUIModule").pushRowList(but);
            //if(index==6) but.setVisible(false);//屏蔽任务Icon入口
        }

        //返回地图
        var item_back = this._ui.getChildByName("item_back");
        item_back.setTouchEnabled(true);
        item_back.addTouchEventListener( this.backButtonCall, this );
        var title = item_back.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("mainmenu_100"));
        //title = BorderText.replace(title);

        this.doGuide();

        ModuleMgr.inst().getData("BattleUIModule").setBackBtn(item_back);


        ModuleMgr.inst().getData("BattleUIModule").pushRowList(item_back);

        //我的主城
        var item_castle = this._ui.getChildByName("item_castle");
        item_castle.setTouchEnabled(true);
        item_castle.addTouchEventListener( this.castleButtonCall, this );
        title = item_castle.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId).name);
        //title = BorderText.replace(title);

        ModuleMgr.inst().getData("BattleUIModule").pushColumnList(item_castle);

        // 升级队列
        var item_buildingdeque = this._ui.getChildByName("item_buildingdeque");
        title = item_buildingdeque.getChildByName("Text_timing");
        title.ignoreContentAdaptWithSize(true);
        //item_buildingdeque.setVisible(false);

        ModuleMgr.inst().getData("BattleUIModule").pushColumnList(item_castle);


        var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down = down * (1/GameMgr.inst().scaleX);
        var posY = item_castle.getPositionY();
        posY += down;
        item_castle.setPositionY( posY );

        posY = item_buildingdeque.getPositionY();
        posY += down;
        item_buildingdeque.setPositionY(posY);
        this._item = item_buildingdeque.clone();
        this._item.retain();
        item_buildingdeque.removeFromParent();
        this._addDefaultItem();

        //我的部队
        var item_army = this._ui.getChildByName("item_arm");
        item_army.setTouchEnabled(true);
        item_army.addTouchEventListener( this.armyButtonCall, this );
        title = item_army.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("mainmenu_102"));
        title = BorderText.replace(title);
        var posY = item_army.getPositionY();//适配
        posY += down;
        item_army.setPositionY( posY );

        //ModuleMgr.inst().getData("BattleUIModule").pushColumnList(item_army);
        item_army.setVisible(false);

        //切换，默认隐藏
        var item_exchange = this._ui.getChildByName("item_exchange");
        item_exchange.setTouchEnabled(true);
        item_exchange.setVisible(false);
        item_exchange.addTouchEventListener( this.exchangButtonCall, this );
        title = item_exchange.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("mainmenu_103"));
        title = BorderText.replace(title);

        //小地图
        var item_smallmap = this._ui.getChildByName("item_smallmap");
        item_smallmap.setTouchEnabled(true);
        item_smallmap.setVisible(false);
        item_smallmap.addTouchEventListener(this.smallmapCallback,this);
        title = item_smallmap.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("mainmenu_105"));
        title = BorderText.replace(title);

        //新资源显示图标
        var item_resource_out=this._ui.getChildByName("item_resource_out");
        item_resource_out.setTouchEnabled(true);
        item_resource_out.setVisible(false);
        //item_resource_out.addTouchEventListener(this.smallmapCallback,this);
        title = item_resource_out.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        //var trading_data = modelMgr.call("Table", "getTableItemByValue", ["item_trading",data[i].trading_id ]);
        //title.setString(ResMgr.inst().getString("mainmenu_105"));
        var posY = item_resource_out.getPositionY();//适配
        posY += down;
        item_resource_out.setPositionY( posY );

        ModuleMgr.inst().getData("BattleUIModule").setExchangeBtn(item_exchange);
        ModuleMgr.inst().getData("BattleUIModule").setSmallmapBtn(item_smallmap);
        ModuleMgr.inst().getData("BattleUIModule").setResourceOutBtn(item_resource_out);

        //适配
        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        EventMgr.inst().addEventListener(CastleEvent.UPDATE_RESOURCE, this.resUpdata, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.updateBuildingDeque, this);
        EventMgr.inst().addEventListener(CastleEvent.UPDATE_BUILDING, this.updateBuildingDeque, this);
        EventMgr.inst().addEventListener(CastleEvent.UPGRADE_COMPLETE, this.updateBuildingDeque, this);
        EventMgr.inst().addEventListener(CastleEvent.SHOW_BUILDING_DEQUE, this.showBuildingDeque, this);
        mainData.uiData.addListener("currentCastleId", this.updateBuildDequeVisibleDelay, this);
    },

    destroy:function()
    {
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_RESOURCE, this.resUpdata, this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE,this.netComplete,this);
        EventMgr.inst().removeEventListener( MailEvent.SEND_NEW_MAIL, this.mailNewCall, this );
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.updateBuildingDeque, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BUILDING, this.updateBuildingDeque, this);
        EventMgr.inst().removeEventListener(CastleEvent.UPGRADE_COMPLETE, this.updateBuildingDeque, this);
        EventMgr.inst().removeEventListener(CastleEvent.SHOW_BUILDING_DEQUE, this.showBuildingDeque, this);
        EventMgr.inst().removeEventListener(CastleEvent.FLUSH_CASTLE_DATA, this.onFlushCastleData, this);
        mainData.uiData.removeListener("currentCastleId", this.updateBuildDequeVisibleDelay, this);

        this._buildingDequeItems = null;
        this._item.release();
        this._item = null;

        mainData.uiData.removeListener("currentCastleId",this.currentCastleName,this);
    },

    show:function( data )
    {

    },

    close:function()
    {

    },

    currentCastleName: function () {
        //我的主城
        var item_castle = this._ui.getChildByName("item_castle");
        var title = item_castle.getChildByName("zi");
        title.ignoreContentAdaptWithSize(true);
        title.setString(mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId).name);
    },

    buttonCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            cc.log(node.getTag());
            this.openModuleByIndex(node.getTag());
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    //返回地图
    backButtonCall: function (node,type) {
        if(mainData.uiData.mapChangeModule == true) {
            return;
        }
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            if(mainData.uiData.showMap == MapChangeModule.CASTLE) {
                //若UI弹框打开，需要关闭
                ModuleMgr.inst().openModule("MapChangeModule",{"type":MapChangeModule.MAP});
                this.setBuildingDequeVisible(false);

            } else {
                cc.log("enter castle------------------------");
                ModuleMgr.inst().openModule("MapChangeModule",{"type":MapChangeModule.CASTLE});
                this.setBuildingDequeVisible(true);

            }
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            EventMgr.inst().dispatchEvent("remove_guide" );//特殊处理 移除上次引导效果
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    showBuildingDeque: function (event,val) {
        cc.log("!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        this.setBuildingDequeVisible(val);
    },

    //我的主城
    castleButtonCall: function (node,type) {
        if(mainData.uiData.mapChangeModule == true) {
            return;
        }
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            ModuleMgr.inst().openModule("MainCitysModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    // 点击建筑队列按钮
    buildingdequeCall: function (node ,type) {
        if(mainData.uiData.mapChangeModule == true) {
            return;
        }
        if(type==ccui.Widget.TOUCH_ENDED)
            EventMgr.inst().dispatchEvent( CastleEvent.MOVETO_BUILDING, node.getTag() );
    },

    updateBuildDequeVisibleDelay:function() {
        var _this = this;
        setTimeout(function(){
            _this.setBuildingDequeVisible(true);
        },0);
    },

    // 显示升级队列
    setBuildingDequeVisible: function (val) {
        cc.log("设置建筑队列可见性---->"+val);
        // 先清除原来的队列
        for(var i in this._buildingDequeItems)
        {
            var item = this._buildingDequeItems[i];
            item.removeFromParent(true);
        }
        this._buildingDequeItems = [];

        this._buildingDequeShow = val;
        if(val)
        {
            var data = ModuleMgr.inst().getData("CastleModule");
            var list = data.getNetBlockByState( CastleData.STATE_UPGRADE );
            for(var i in list)
            {
                var bean=new CastleBlockBeanNet(list[i]._data);
                var item = this._add2Deque(bean);
                this._startTiming(item,bean._state_remain);
            }
            trace("升级队列长度",this._buildingDequeItems.length);
            if(this._buildingDequeItems.length==0)
            {
                this._addDefaultItem();
            }
            //EventMgr.inst().addEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.updateBuildingDeque, this);
            //EventMgr.inst().addEventListener(CastleEvent.UPDATE_BUILDING, this.updateBuildingDeque, this);
            //EventMgr.inst().addEventListener(CastleEvent.UPGRADE_COMPLETE, this.updateBuildingDeque, this);
        }
        else
        {
            if(this._ui.getChildByTag(-9)!=null)
            {
                this._ui.removeChildByTag(-9);
            }
            for(var i in this._buildingDequeItems)
            {
                var item = this._buildingDequeItems[i];
                item.removeFromParent(true);
            }
            this._buildingDequeItems = [];
            //EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BLOCK_TIME, this.updateBuildingDeque, this);
            //EventMgr.inst().removeEventListener(CastleEvent.UPDATE_BUILDING, this.updateBuildingDeque, this);
            //EventMgr.inst().removeEventListener(CastleEvent.UPGRADE_COMPLETE, this.updateBuildingDeque, this);

        }
    },

    _startTiming: function (item,time) {
        if(!item) {
            cc.log("有BUG@@@@@@@@@@@@@@");
            return;
        }
        var txt = item.getChildByName("Text_timing");
        //txt.stopAllActions();
        time = time / 1000;

        var hour = Math.floor(time/3600);
        var min = Math.floor((time-hour*3600) / 60);
        var sec = Math.floor(time-hour*3600-min*60);
        var ssec = sec < 10 ? "0" + sec.toString() : sec.toString();
        var smin = min < 10 ? "0" + min.toString() : min.toString();
        var shour = hour < 10 ? "0" + hour.toString() : hour.toString();
        txt.setString( shour + ":" + smin + ":" + ssec);

        //txt.setUserData(time);
        //txt.runAction(cc.repeatForever(cc.sequence(cc.callFunc(function(target){
        //        cc.log("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+time);
        //        var time = target.getUserData();
        //        time--;
        //        if(time<=0)
        //        {
        //            target.stopAllActions();
        //            return;
        //        }
        //        var hour = Math.floor(time/3600);
        //        var min = Math.floor((time-hour*3600) / 60);
        //        var sec = Math.floor(time-hour*3600-min*60);
        //        var ssec = sec < 10 ? "0" + sec.toString() : sec.toString();
        //        var smin = min < 10 ? "0" + min.toString() : min.toString();
        //        var shour = hour < 10 ? "0" + hour.toString() : hour.toString();
        //        target.setString( shour + ":" + smin + ":" + ssec);
        //        target.setUserData(time);
        //    }
        //),cc.delayTime(1))));
    },

    _add2Deque: function (bean) {
        cc.log("add 2 deque------------->"+bean._building_id);
        if(!this._buildingDequeShow) return;

        if(this._ui.getChildByTag(-9)!=null)
        {
            this._ui.removeChildByTag(-9);
        }

        // 先清除原来的队列
        for(var i in this._buildingDequeItems)
        {
            var item = this._buildingDequeItems[i];
            item.removeFromParent(true);
        }
        this._buildingDequeItems = [];


        var item = this._item.clone();
        item.setTag(bean._building_id);
        var type = item.getChildByName("Image_type");
        type.loadTexture("res/images/ico/"+bean._building_id+"4"+".png");

        item.setTouchEnabled(true);
        item.addTouchEventListener( this.buildingdequeCall, this );

        var zzz = item.getChildByName("Image_zzz");
        zzz.setVisible(false);
        this._buildingDequeItems.push(item);
        this._ui.addChild(item);
        var y = item.getPositionY();
        var offset = item.getContentSize().height * (this._buildingDequeItems.length - 1);
        item.setPositionY(y-offset);
        return item;
    },

    _addDefaultItem: function () {
        if(this._ui.getChildByTag(-9)!=null) return;
        var item = this._item.clone();
        var txt = item.getChildByName("Text_timing");
        txt.setVisible(false);
        this._ui.addChild(item);
        item.setTag(-9);
    },

    _removeFromDeque: function (bean) {
        var item = this._ui.getChildByTag(bean._building_id);
        if(item!=null)
        {
            item.removeFromParent(true);
            var idx = this._buildingDequeItems.indexOf(item);
            if(idx!=-1)
            {
                this._buildingDequeItems.splice(idx,1);
            }
        }
        if(this._buildingDequeItems.length==0)
        {
            this._addDefaultItem();
        }
    },
    //刷新资源怪物掉落数量
    resUpdata:function( ) {
        var data = ModuleMgr.inst().getData("CastleModule");
        var num = data.getNetResource()[1105001];
        if(num==undefined||num==null) return;
        var title=this._ui.getChildByName("item_resource_out").getChildByName("zi");
        var res = modelMgr.call("Table", "getTableItemByValue", ["initial_material",1105001 ]);
        //cc.error(res.autoinc_bound);
        title.setString(num+"/"+res.autoinc_bound);
    },
    // 刷新升级队列
    updateBuildingDeque: function (event,data) {
        //cc.log("`````````````````````````````````````````upgrade building"+event);
        if(!this._buildingDequeShow) return;
        switch (event)
        {
            case CastleEvent.UPDATE_BLOCK_TIME:
                var blockNet = new CastleBlockBeanNet(data._data);
                var item =this._ui.getChildByTag(blockNet._building_id);
                if(item==null)
                {
                    this._add2Deque(blockNet);
                }
                this._startTiming(item,blockNet._state_remain);

                break;
            case CastleEvent.UPDATE_BUILDING:
                var blockNet=new CastleBlockBeanNet(data);
                if(blockNet._state==CastleData.STATE_UPGRADE)
                {
                    var item =this._ui.getChildByTag(blockNet._building_id);
                    if(item==null)
                    {
                        this._add2Deque(blockNet);
                    }
                    this._startTiming(item,blockNet._state_remain);

                }
                break;
            case CastleEvent.UPGRADE_COMPLETE:
                for(var i in this._buildingDequeItems)
                {
                    var item = this._buildingDequeItems[i];
                    item.removeFromParent(true);
                }
                this._buildingDequeItems=[];
                this._addDefaultItem();
                break;
        }

    },

    armyButtonCall: function (node,type) {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            ModuleMgr.inst().openModule("CorpsAssembledModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    exchangButtonCall: function (node,type) {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            //mainData.uiData.operateMode = mainData.uiData.operateMode=="1"?"2":"1";
            ModuleMgr.inst().getData("BattleUIModule").switchUI(null);
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    smallmapCallback: function (node,type) {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
            ModuleMgr.inst().openModule("SmallmapModule");
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.8);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    openModuleByIndex: function (index) {
        if(mainData.uiData.mapChangeModule == true) {
            return;
        }
        trace("点击？",index);
        switch (index) {
            case 0://结盟
                //ModuleMgr.inst().openModule("AlertString", {
                //    str: "功能暂未开启",
                //    color: null,
                //    time: null,
                //    pos: cc.p(cc.Director.getInstance().getWinSize().width / 2, cc.Director.getInstance().getWinSize().height / 2)
                //});
                ModuleMgr.inst().openModule("FriendModule");
                break;
            case 1://邮件
                ModuleMgr.inst().openModule("MailModule");
                break;
            case 2://收藏夹
                ModuleMgr.inst().openModule("CollectModule");
                break;
            case 3://世界地图
                ModuleMgr.inst().openModule("AlertString", {
                    str: "功能暂未开启",
                    color: null,
                    time: null,
                    pos: cc.p(cc.Director.getInstance().getWinSize().width / 2, cc.Director.getInstance().getWinSize().height / 2)
                });
                break;
            case 4://商城
                ModuleMgr.inst().openModule("StoreModule");
                break;
            case 5://背包
                ModuleMgr.inst().openModule("BagModule");
                break;
            case 6://任务
                ModuleMgr.inst().openModule("TaskModule");
                break;
            default :
                break;
        }
    },

    //邮件有更新
    mailNewCall:function( e )
    {
        var data = ModuleMgr.inst().getData("MailModule");
        if( data == null ) return;
        var v = data.getNewMailNum();
        if( v > 0 )
        {
            cc.log("有新邮件没有读:" + v);
        }
    },
    doGuide:function(type,guideId){
        var guideData=ModuleMgr.inst().getData("GuideModule");
        cc.log(guideData+"guidedata guideid$$$$$$$"+guideId+"MainMenuModule$$$$doguide"+mainData.playerData.guide);
        //this._ui.getChildByName("item_back").setVisible(true);
        //this._ui.getChildByName("item_back").setVisible(true);
        if(guideData&&guideData._guideBean){
            cc.log(guideData._guideBean._idStep+"$$$$$$$$$$$$$$$$$$$MainMenuModule$$$$doguide")
            if(guideData._guideBean._idStep==GuideModule.END_GUIDE||guideData._guideBean._idStep==GuideModule.END_GUIDE_ALL||guideData._guideBean._idStep=="2_1"||guideData._guideBean._idStep=="3_1"||guideData._guideBean._idStep=="4_1"||guideData._guideBean._idStep=="4_2"||guideData._guideBean._idStep=="4_3"||guideData._guideBean._idStep=="4_4"||guideData._guideBean._idStep=="4_10") this._ui.getChildByName("item_back").setVisible(true);
            else this._ui.getChildByName("item_back").setVisible(false);
            if(guideData._guideBean._idStep=="3_11"||guideData._guideBean._idStep=="3_6") {//暂时用 屏蔽
                //this._ui.getChildByName("item_back").setVisible(true);
            }//临时用  后面要改 暂时订到4_1
        }
        else{
            if(mainData.playerData.guide==GuideModule.END_GUIDE||mainData.playerData.guide==GuideModule.END_GUIDE_ALL||mainData.playerData.guide=="2_1"||mainData.playerData.guide=="3_1"||mainData.playerData.guide=="4_1"||mainData.playerData.guide=="4_2"||mainData.playerData.guide=="4_3"||mainData.playerData.guide=="4_4"||mainData.playerData.guide=="4_10") this._ui.getChildByName("item_back").setVisible(true);
            else this._ui.getChildByName("item_back").setVisible(false);
        }
        //if(guideData&&guideData._guideBean){
        //    if(guideData._guideBean._idStep=="4_4"){
        //        //引导  强制 切换地图
        //        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        //        //EventMgr.inst().dispatchEvent("remove_guide" );
        //        if(mainData.uiData.showMap == MapChangeModule.CASTLE) {
        //            ModuleMgr.inst().openModule("MapChangeModule",{"type":MapChangeModule.MAP});
        //        }
        //    }
        //}
        //else this._ui.getChildByName("item_back").setVisible(false);
        if(GuideModule.IS_CLOSE) this._ui.getChildByName("item_back").setVisible(true);

        //按钮功能屏蔽与否判断
        for(var i in this.initMenu) {
            var index = this.initMenu[i];
            var but = this._ui.getChildByName("item" + index);
            but.setTouchEnabled(true);
        }
        this._ui.getChildByName("item_back").setTouchEnabled(true);
        this._ui.getChildByName("item_castle").setTouchEnabled(true);
        this._ui.getChildByName("item_arm").setTouchEnabled(true);
        this._ui.getChildByName("item_exchange").setTouchEnabled(true);

        if(guideData&&guideData._guideBean){
            if(guideData._guideBean._idStep=="2_3"||guideData._guideBean._idStep=="2_9"||guideData._guideBean._idStep=="2_15"||guideData._guideBean._idStep=="4_5"||guideData._guideBean._idStep=="4_7"){

                for(var i in this.initMenu) {
                    var index = this.initMenu[i];
                    var but = this._ui.getChildByName("item" + index);
                    but.setTouchEnabled(false);
                }
                this._ui.getChildByName("item_back").setTouchEnabled(false);
                this._ui.getChildByName("item_castle").setTouchEnabled(false);
                this._ui.getChildByName("item_arm").setTouchEnabled(false);
                this._ui.getChildByName("item_exchange").setTouchEnabled(false);
            }
        }

    },

    netComplete: function (event, data) {
        if(data==CastleNetEvent.SEND_CANCEL){
            for(var i in this._buildingDequeItems)
            {
                var item = this._buildingDequeItems[i];
                item.removeFromParent(true);
            }
            this._buildingDequeItems=[];
            this._addDefaultItem();
        }
    }
});