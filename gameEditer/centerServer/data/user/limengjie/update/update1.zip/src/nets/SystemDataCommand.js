var SystemDataCommand = function () {
    mainData.systemData.screenWidth = cc.Director.getInstance().getWinSize().width;
    mainData.systemData.screenHeight = cc.Director.getInstance().getWinSize().height;
}