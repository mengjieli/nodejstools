/**
 * Created by Administrator on 2015/12/28 0028.
 */


var MarketModule = ModuleBase.extend({

    _root:null,
    _item:null,
    _IconArr:[1101002,1101003,1101001,1103002,1103004],
    _list:null,

    ctor: function () {
        this._super();
    },

    destroy: function () {

    },

    initUI: function () {
        this._root = ccs.load("res/images/ui/market/MarketView.json","res/images/ui/").node;
        this.addChild(this._root);

        var pnl = this._root.getChildByName("Panel");

        this._list = pnl.getChildByName("ListView_1");
        this._item = pnl.getChildByName("Panel_Item");
        this._item.setVisible(false);
        var icon = pnl.getChildByName("left").getChildByName("ico");
        icon.loadTexture("res/images/ico/19100014.png");

        var msg = this._root.getChildByName("Panel").getChildByName("left").getChildByName("msg");
        var str = 1910001 + "1";
        msg.setString(ResMgr.inst().getString(str));

        this._initList();

        var size = cc.director.getVisibleSize();
        this._root.setContentSize(size);
        ccui.helper.doLayout(this._root);
    },

    show: function (data) {

    },

    _initList: function () {
        for(var i in this._IconArr)
        {
            var id = this._IconArr[i];
            var item = this._item.clone();
            item.setVisible(true);
            item.setTag(id);
            var ico = item.getChildByName("Image_icon");
            var path = ResMgr.inst().getIcoPath(id);
            ico.loadTexture(path);
            var txt = item.getChildByName("Text_explain");
            var num = "";
            if(id==1103004 || id==1103002)
            {
                num = "100";
            }
            else
            {
                num = "100k"
            }
            var str = "(以"+num+ResMgr.inst().getString( id + "0")+"为一箱)";
            txt.setString( str );
            this._list.pushBackCustomItem(item);
        }
    },



});