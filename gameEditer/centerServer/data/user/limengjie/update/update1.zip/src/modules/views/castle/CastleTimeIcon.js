/**
 * Created by Administrator on 2015/12/18/0018.
 */
var CastleTimeIcon = cc.Layer.extend({

    _layerTfIcon:null,//文本图标层

    //_imgTf:null,//等级牌子图
    //_tfLevel:null,//等级文本
    //_tfName:null,//建筑名
    //_imgNameBg:null,//建筑名背景底
    _effIcon:null,//训练结束 兵营训练收获特效 按钮
    _effLight:null,//训练结束 兵营训练收获特效 光
    _tfArmyTrain:null,//兵营训练文字
    _tfStateTime:null,//状态剩余时间
    _imgProgressTfUp:null,//进度上文字底框
    _imgProgressTfDown:null,//进度下文字底框
    _imgProgressDown:null,//进度底
    _imgProgress:null,//进度条
    _imgProgressRight:null,//进度头
    _imgIcon:null,//进度左边图标


    ctor: function () {
        this._super();

        this._layerTfIcon=new cc.Layer();
        this.addChild(this._layerTfIcon);

    },
    //remove移除数据
    //var list = mainData.castleData.armyTrainList;
    //for(var i = 0;i< list.length;i++){
    //    var army = list.getItemAt(i);
    //    if(obj.castleId == army.castleId && obj.armyId == army.armyId){
    //        exist = true;
    //        list.setItemAt(i,obj);
    //        break;
    //    }
    //}

    //更新升级时间
    updateBuildingTime:function(netblock,type){// type地块0  科技1   兵营训练2
        if(type==0) var blockNet = new CastleBlockBeanNet(netblock._data);//地块
        else if(type==1) var blockNet=new CastleTechBeanNet(netblock._data);//科技
        //cc.log(blockNet._state_remain+"剩余时间"+blockNet._state);

        if(  (type<2&&blockNet._state==CastleData.STATE_NORMAL)  ) {
            this.removeTimeIcon();
            return;
        }
        if(type==2&&netblock.remainTime<=0){////兵营训练判断 可点击收取状态  训练完成
            if(this._effIcon==null){
                this.removeTimeIcon();
                //show 收取图标

                var csvEffect = ResMgr.inst().getCSV("animationConfig","castle_armytrain_light");
                this._effLight=new AnimationSprite();
                this._effLight.setName("castle_armytrain_light");
                this._effLight.setAnimationByCount(csvEffect);
                this._effLight.setAdd(true);
                this._effLight.y=20;
                this._layerTfIcon.addChild(this._effLight);
                var csvEffect = ResMgr.inst().getCSV("animationConfig","castle_armytrain_icon");
                this._effIcon=new AnimationSprite();
                this._effIcon.setName("castle_armytrain_icon");
                this._effIcon.setAnimationByCount(csvEffect);
                this._effIcon.setPosition(cc.p(0,50));
                this._layerTfIcon.addChild(this._effIcon);
            }

            return;
        }

        if(this._imgProgressTfUp==null){
            this._imgProgressTfUp=new ccui.ImageView("castlebuilding_shijiandi.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressTfUp.x=35;
            this._imgProgressTfUp.y=-69;
            this._layerTfIcon.addChild(this._imgProgressTfUp);
        }
        if(this._imgProgressTfDown==null){
            this._imgProgressTfDown=new ccui.ImageView("castlebuilding_mingchengdi_beijin.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressTfDown.y=-100;
            this._imgProgressTfDown.setVisible(false);//底框暂时屏蔽
            this._layerTfIcon.addChild(this._imgProgressTfDown);
        }
        if(this._imgProgressDown==null){
            //this._imgProgressDown=new ccui.ImageView("castlebuilding_jz_nengliangtiao_di.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressDown=new ccui.ImageView("castlebuilding_jindutiaodikuang.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressDown.y=-80;
            this._layerTfIcon.addChild(this._imgProgressDown);
        }
        if(this._imgProgress==null){
            //this._imgProgress=new ccui.ImageView("castlebuilding_jz_nengliangtiao.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgress=new ccui.ImageView("castlebuilding_jidutiao_duquicon.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgress.anchorX=0;
            this._imgProgress.x=this._imgProgressDown.x-35;
            this._imgProgress.y=this._imgProgressDown.y;
            this._layerTfIcon.addChild(this._imgProgress);
        }
        if(this._imgProgressRight==null){
            //this._imgProgressRight=new ccui.ImageView("castlebuilding_jz_nengliangtiaotou.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressRight=new ccui.ImageView("castlebuilding_tubiaodi.png",ccui.Widget.PLIST_TEXTURE);
            this._imgProgressRight.x=this._imgProgressDown.x-56;
            this._imgProgressRight.y=this._imgProgressDown.y-2;
            this._layerTfIcon.addChild(this._imgProgressRight);
        }
        if(this._imgIcon==null){
            //this._imgIcon=new ccui.ImageView("res/images/ico/15010013.png");
            this._imgIcon=new ccui.ImageView("castlebuilding_jiantou_icon.png",ccui.Widget.PLIST_TEXTURE);
            this._imgIcon.x=this._imgProgressDown.x-55;
            this._imgIcon.y=this._imgProgressDown.y;
            this._layerTfIcon.addChild(this._imgIcon);
        }
        if(this._tfStateTime==null){
            this._tfStateTime=new cc.LabelTTF("","Arial",16);
            this._tfStateTime.x=this._imgProgressDown.x+10;
            this._tfStateTime.y=this._imgProgressDown.y+18;
            this._tfStateTime.setColor(cc.color.WHITE);
            this._layerTfIcon.addChild(this._tfStateTime);
        }
        if(type<2){
            if(blockNet._state==CastleData.STATE_NORMAL) blockNet._state_remain=0;//以状态为准
            this._tfStateTime.string=StringUtils.formatTimer(blockNet._state_remain);
            var scaleTime=blockNet._state_remain/blockNet._state_param1;
            if(scaleTime>1) scaleTime=1;
            if(blockNet._state_remain<1000||blockNet._state==CastleData.STATE_NORMAL) scaleTime=0;
            this._imgProgress.scaleX=scaleTime;
        }
        else{
            if(this._tfArmyTrain==null){
                this._tfArmyTrain=new cc.LabelTTF("","Arial",14);
                this._tfArmyTrain.x=this._imgProgressDown.x+12;
                this._tfArmyTrain.y=this._imgProgressDown.y-22;
                this._tfArmyTrain.setColor(cc.color.YELLOW);
                this._layerTfIcon.addChild(this._tfArmyTrain);
                this._tfArmyTrain.string=ResMgr.inst().getString(String(netblock.armyId)+"0")+" "+netblock.num;
                this._imgProgressTfDown.setVisible(true);//底框暂时屏蔽
            }

            this._tfStateTime.string=StringUtils.formatTimer(netblock.remainTime);
            var scaleTime2=netblock.remainTime/netblock.duration;
            if(scaleTime2>1) scaleTime2=1;
            if(netblock.remainTime<1000) scaleTime2=0;
            this._imgProgress.scaleX=scaleTime2;
        }

        //this._imgProgressRight.x=this._imgProgress.x+this._imgProgress.width;
    },
    //更新建筑状态等
    updateBuilding:function(netblock){
        //this.showBuildingLevel(netblock);
        this.updateBuildingTime(netblock,0);
        //this.showEffect(netblock);
    },
    //更新科技状态
    updateTech:function(netTech){
        this.updateBuildingTime(netTech,1);
        //this.showTechEffect(netTech);
    },
    //科技升级成功
    upgradeTechComplete:function(){
        this.removeTimeIcon();
        //this.removeEffect("castle_tech_upgrade","Top");
        //this.addEffect("castle_tech_upgrade_complete","Top",1);

    },

    //升级成功
    upgradeComplete:function(){
        //cc.log("播放升级成功特效啊！！！！！！！");
        this.removeTimeIcon();
        //this.addEffect("castle_upgrade_complete","Top",1);
    },
    //清除时间图标
    removeTimeIcon:function(){
        if(this._effIcon){
            this._effIcon.removeData();
            this._effIcon.removeFromParent();
            this._effIcon=null;
        }
        if(this._effLight){
            this._effLight.removeData();
            this._effLight.removeFromParent();
            this._effLight=null;
        }

        if(this._tfArmyTrain){
            this._tfArmyTrain.removeFromParent();
            this._tfArmyTrain=null;
        }
        if(this._tfStateTime){
            this._tfStateTime.removeFromParent();
            this._tfStateTime=null;
        }
        if(this._imgProgressTfUp){
            this._imgProgressTfUp.removeFromParent();
            this._imgProgressTfUp=null;
        }
        if(this._imgProgressTfDown){
            this._imgProgressTfDown.removeFromParent();
            this._imgProgressTfDown=null;
        }
        if(this._imgProgressDown){
            this._imgProgressDown.removeFromParent();
            this._imgProgressDown=null;
        }
        if(this._imgProgress){
            this._imgProgress.removeFromParent();
            this._imgProgress=null;
        }
        if(this._imgProgressRight){
            this._imgProgressRight.removeFromParent();
            this._imgProgressRight=null;
        }
        if(this._imgIcon){
            this._imgIcon.removeFromParent();
            this._imgIcon=null;
        }
    },
    destroy : function()
    {
        this.removeTimeIcon();
        if(this._layerTfIcon&&this._layerTfIcon.getParent()){
            this._layerTfIcon.removeFromParent();
            this._layerTfIcon=null;
        }
    },


});