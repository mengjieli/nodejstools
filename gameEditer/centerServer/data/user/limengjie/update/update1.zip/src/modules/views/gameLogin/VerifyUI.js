/**
 * Created by Administrator on 2015/12/14.
 */


var VerifyUI = cc.Node.extend( {

    _ui: null,
    _timeLabel:null,
    _againLabel:null,
    _timer:null,
    _errorLabel:null,

    _input: null,
    _time:null,
    _timeEx:null,
    _account:null,//账号

    ctor: function(ip,cd)
    {
        this._super();

        this._timeEx = parseInt(cd/1000);
        this._time = this._timeEx;
        this._account = ip;
    },

    onEnter: function()
    {
        this._super();
        this._ui = ccs.load( "res/images/ui/login/verify.json", "res/images/ui/" ).node;
        this.addChild( this._ui );

        var uiPanel = this._ui.getChildByName( "ui_mainban" );
        uiPanel.setScale( 1 / GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale( false ) );

        var size = cc.director.getVisibleSize();
        this._ui.setContentSize( size );
        ccui.helper.doLayout( this._ui );

        //下一步按钮
        var but = this._ui.getChildByName( "ui_mainban" ).getChildByName( "denglu" );
        but.addTouchEventListener( this.nextCall, this );
        but.setTitleText( ResMgr.inst().getString("login_13"));

        //验证码输入框
        this._input = this._ui.getChildByName( "ui_mainban" ).getChildByName( "TextField_2" );
        this._input.addEventListener(this.inputCallback,this);
        this._input.setPlaceHolder( ResMgr.inst().getString("login_14") );

        //返回
        var reg = this._ui.getChildByName( "ui_mainban" ).getChildByName( "yongh_zhuce" );
        reg.addTouchEventListener( this.loginCall, this );
        reg.ignoreContentAdaptWithSize(true);
        reg.setString( ResMgr.inst().getString("login_11") );
        var reg_x = reg.getChildByName("Panel_3");
        var s = reg.getContentSize();
        s.height = 2;
        reg_x.setContentSize( s );

        //重发短信
        var send = this._ui.getChildByName( "ui_mainban" ).getChildByName( "duanxing" );
        send.addTouchEventListener( this.sendCall, this );
        send.ignoreContentAdaptWithSize(true);
        send.setString( ResMgr.inst().getString("login_18") );
        send.setTouchEnabled(false);
        var send_x = send.getChildByName("Panel_3_0");
        var s = reg.getContentSize();
        s.height = 2;
        send_x.setContentSize( s );
        this._againLabel = send;


        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_14"));

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2_0" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_9"));

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2_0_0" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( ResMgr.inst().getString("login_16"));
        txt.setVisible(false);
        this._errorLabel = txt;

        var txt = this._ui.getChildByName( "ui_mainban" ).getChildByName( "Text_2_1" );
        txt.ignoreContentAdaptWithSize(true);
        txt.setString( this._time + ResMgr.inst().getString("denglu_5"));
        this._timeLabel = txt;

        this._timer = new IntervalCall(this.timeUpdate, this, 1);

    },

    onExit: function()
    {
        this._super();
        if(this._timer){
            this._timer.clear();
            this._timer = null;
        }
    },

    min:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,0.95);
        node.runAction(ac);
    },
    max:function( node )
    {
        node.stopAllActions();
        var ac = cc.scaleTo(0.1,1 );
        node.runAction(ac);
    },

    /**
     * 下一步回调
     * @param node
     * @param type
     */
    nextCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            this.max( node );
            this.nextStep();

        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            this.max( node );
        }
    },

    /**
     * 返回登录
     * @param node
     * @param type
     */
    loginCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            //登录
            ModuleMgr.inst().openModule("GameLoginModule" );
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    /**
     * 重发短信
     * @param node
     * @param type
     */
    sendCall:function( node, type )
    {
        if( type == ccui.Widget.TOUCH_BEGAN )
        {
            //this.min( node );
        }
        else if( type == ccui.Widget.TOUCH_ENDED )
        {
            //登录
            cc.log("@重发短信");
            this.sendMessage();
        }
        else if( type == ccui.Widget.TOUCH_CANCELED )
        {
            //this.max( node );
        }
    },

    timeUpdate: function () {
        this._time--;
        if(this._time>=0) {
            this._timeLabel.setString( this._time + ResMgr.inst().getString("denglu_5"));
        }
        else {
            if(this._timer){
                this._time = this._timeEx;
                this._timer.clear();
                this._timer = null;
            }
            this._againLabel.setTouchEnabled(true);
            this._againLabel.setColor(cc.color(255,255,255));
        }
    },

    sendMessage: function () {
        var account = this._account;
        if(0 == account.length || !CD.isPhoneNum(account))
        {
            cc.error("@error",account);
            return;
        }

        var head = GameConfig.PLATFORM_AUTHENTICATE_ADDR + "regain";
        var url = head;
        url += "?accountName=" + encodeString(account);

        NetMgr.inst().sendHttp(url, null, false, function(data, param){
                cc.log("sendMessage 接收:" + data);
                var ret = JSON.parse(data);
                if(ret)
                {
                    switch(ret.err_code)
                    {
                        case 80111://发送短信过快，请稍后重试
                            var value = ResMgr.inst().getString("denglu_40");
                            ModuleMgr.inst().openModule("AlertPanel", {"txt":value, "type":2});
                            break;
                        case 0:
                            cc.error("短信有效时间:" + ret.verificationCodeExpiryDuration);
                            if(param.owner._timer==null){
                                this._timer = new IntervalCall(param.owner.timeUpdate, param.owner, 1);
                            }
                            param.owner._againLabel.setTouchEnabled(false);
                            param.owner._againLabel.setColor(cc.color(116,116,114));
                            break;
                        default:
                            break;
                    }
                }
            }, null, {"objs":null, "changeMode":null, "errorTip":null, "owner":this}
        );
    },

    nextStep: function () {
        var password = this._input.getString();
        if(0 == password.length)
        {
            this._errorLabel.setVisible(true);
            return;
        }
        ModuleMgr.inst().openModule("GameLoginModule",{"ui":"set","ip":this._account,"rg":password});//需要校验验证码！！
    },

    inputCallback: function (node, type) {
        switch (type){
            case ccui.TextField.EVENT_ATTACH_WITH_IME:
                this._errorLabel.setVisible(false);
                break;
            //case  ccui.TextField.EVENT_DETACH_WITH_IME:
            //    this.checkAccount();
            //    break;
        }
    }
});