/**
 * Created by cgMu on 2016/2/23.
 */

var SmallmapDataCommand = cc.Class.extend({

    ctor: function () {
        NetMgr.inst().addEventListener(389, this.netGet, this);
    },

    netGet: function (cmd, data) {
        if(cmd==389){
            data.resetCMDData();
            var obj = DataManager.getInstance().getNewData("SmallmapData");
            obj.left = data.readInt();
            obj.bottom = data.readInt();
            obj.width = data.readUint();
            obj.height = data.readUint();

            mainData.smallMapData.left = obj.left;
            mainData.smallMapData.bottom = obj.bottom;
            mainData.smallMapData.width = obj.width;
            mainData.smallMapData.height = obj.height;
            //cc.log("@SmallmapData",obj.left,obj.bottom,obj.width,obj.height);

            var list = mainData.smallMapData.castlesList;
            var len = data.readUint();
            for(var i = 0; i < len; i++) {
                var castles = DataManager.getInstance().getNewData("SmallCastleData");
                castles.x = data.readInt();
                castles.y = data.readInt();
                castles.uuid = data.readString();
                //cc.log("@SmallCastleData",castles.x,castles.y);

                var it = list.getItem("x",castles.x,"y",castles.y);
                if(it){
                    it = castles;
                }
                else{
                    list.push(castles);
                }
            }
        }
    }
});