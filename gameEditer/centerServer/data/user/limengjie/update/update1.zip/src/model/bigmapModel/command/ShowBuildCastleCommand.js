var ShowBuildCastleCommand = (function (_super) {
    __extends(ShowBuildCastleCommand, _super);

    function ShowBuildCastleCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
    }

    var d = __define, c = ShowBuildCastleCommand;
    p = c.prototype;

    /**
     * 初始化
     * @param params Object
     */
    p.init = function (params) {
        mainData.uiData.map.addListener("buildCastle", this.showBuildCastle, this);
    }

    /**
     * 显示建城界面
     */
    p.showBuildCastle = function(point) {
        ModuleMgr.inst().openModule("BuildEditerModule", point);
    }

    return ShowBuildCastleCommand;
})(CycleCommand);