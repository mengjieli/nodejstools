/**
 * Created by cgMu on 2015/11/27.
 */

var BlockLevelupModule = ModuleBase.extend({
    root:null,

    territoryId:null,
    earthid:null,

    earthX:null,
    earthY:null,

    data:null,
    posx_1:0,
    posx_2:0,

    ctor: function () {
        this._super();
        NetMgr.inst().addEventListener(0, this.netComplete, this);//请求成功返回
    },

    initUI:function() {
        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var json = ccs.load("res/images/ui/Block/BlockLevelupLayer.json","res/images/ui/");
        var root = json.node;
        this.addChild(root);
        this.root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1 = root.getChildByName("Panel_1");
        this.sizeAutoLayout(Panel_1);
        this.posAutoLayout(Panel_1,0.5);

        var title = ccui.helper.seekWidgetByName(root,"Text_9");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("dikuai_1"));

        var closeButton = ccui.helper.seekWidgetByName(root, "Button_4");
        closeButton.addTouchEventListener(this.touchCallback,this);

        var cancelButton = ccui.helper.seekWidgetByName(root, "Button_5_0");
        cancelButton.addTouchEventListener(this.touchCallback,this);
        var cancelBtnText = ccui.helper.seekWidgetByName(root,"Text_2");
        cancelBtnText.ignoreContentAdaptWithSize(true);
        cancelBtnText.setString(ResMgr.inst().getString("dikuai_5"));

        var levelUpButton = ccui.helper.seekWidgetByName(root, "Button_5");
        levelUpButton.addTouchEventListener(this.touchCallback2,this);
        var upBtnText = ccui.helper.seekWidgetByName(root,"Text_10");
        upBtnText.ignoreContentAdaptWithSize(true);
        upBtnText.setString(ResMgr.inst().getString("college_16"));

        var label = ccui.helper.seekWidgetByName(root,"Text_5");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("denglu_73"));

        label = ccui.helper.seekWidgetByName(root,"Text_8");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("block_2"));

        label = ccui.helper.seekWidgetByName(root,"Text_8_0");
        label.ignoreContentAdaptWithSize(true);
        label.setString(ResMgr.inst().getString("block_3"));

        var item1 = this.root.getChildByName("Panel_1").getChildByName("Sprite_17_0");
        this.posx_1 = item1.getPositionX();
        var cost1 = ccui.helper.seekWidgetByName(this.root,"Text_18");
        this.posx_2 = cost1.getPositionX();


    },

    destroy:function() {
        NetMgr.inst().removeEventListener(0, this.netComplete, this);//请求成功返回
        this.data.earthData.removeListener("earthCard",this.updateData,this);
    },

    show:function( data ) {
        this.data = data;
        //cc.log("######@#@#@#@#@@@@@@@@@ "+data.earthData.earthCard);
        this.data.earthData.addListener("earthCard",this.updateData,this);
        this.territoryId = data.territoryid;//data.territoryid;1603001
        this.earthid = data.earthid;//data.certificateid;2100026
        //cc.log("out put earthid --------------> "+data.earthid+" data.certificateid-->"+data.certificateid);

        this.earthX = data.x;
        this.earthY = data.y;

        this.refreshView();
    },

    refreshView: function () {
        var data = this.data;
        var productData = modelMgr.call("Table", "getTableItemByValue", ["Territory_product",this.territoryId ]);
        var productUpData = modelMgr.call("Table", "getTableItemByValue", ["Territory_levelup",this.earthid ]);

        //data
        var name = ccui.helper.seekWidgetByName(this.root,"Text_6");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(this.territoryId+"0"));

        //土地等级
        var t = modelMgr.call("Table", "getTableItemByValue", ["item",this.earthid ]);
        var level_ = t.type;
        //cc.log("##################### cur lvl->"+level_+" card->"+this.data.earthData.earthCard + " earthId->"+this.earthid);
        var level = ccui.helper.seekWidgetByName(this.root,"Text_17");
        level.ignoreContentAdaptWithSize(true);
        level.setString(ResMgr.inst().getString("block_4")+level_+ResMgr.inst().getString("block_5"));

        var icon = ccui.helper.seekWidgetByName(this.root,"Image_1");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst().getIcoPath(this.territoryId));

        var detail = ccui.helper.seekWidgetByName(this.root, "Text_3");
        detail.setString(ResMgr.inst().getString(this.territoryId+"1"));

        var res = this.root.getChildByName("Panel_1").getChildByName("Sprite_19");
        if(data.resourceid)
            res.setTexture(ResMgr.inst()._icoPath + data.resourceid + "0.png");
        else
            res.setTexture(ResMgr.inst()._icoPath+productData.production+"0.png");
        //res.setTexture(ResMgr.inst()._icoPath+productData.production+"0.png");
        //cc.log("----------------------------- upgrade block production---------->"+productData.production);
        var percent = 1;
        if (data.resourceid != productData.production) {
            percent = modelMgr.call("Table", "getTableItemByValue", ["Public",100004]).numerical;
        }
        var double = 1;
        //if(data.certificateid)
        //{
        //    double = 2;
        //}
        var output = productData.output_perminute*60*productUpData.output_multiple * percent*double;
        var counts = ccui.helper.seekWidgetByName(this.root,"Text_11");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString("+"+Math.floor(output+0.001)+"/"+ResMgr.inst().getString("useScroll_2"));

        var res_levelup = this.root.getChildByName("Panel_1").getChildByName("Sprite_19_0");
        if(data.resourceid)
            res_levelup.setTexture(ResMgr.inst()._icoPath + data.resourceid + "0.png");
        else
            res_levelup.setTexture(ResMgr.inst()._icoPath+productData.production+"0.png");
        //res_levelup.setTexture(ResMgr.inst()._icoPath+productData.production+"0.png");

        var counts = ccui.helper.seekWidgetByName(this.root,"Text_11_0");
        var item1 = this.root.getChildByName("Panel_1").getChildByName("Sprite_17_0");
        var item2 = this.root.getChildByName("Panel_1").getChildByName("Sprite_17");
        var cost1 = ccui.helper.seekWidgetByName(this.root,"Text_18");
        var cost2 = ccui.helper.seekWidgetByName(this.root,"Text_4");

        var productUpData_up = modelMgr.call("Table", "getTableItemByValue", ["Territory_levelup",this.earthid+1 ]);
        if(!productUpData_up){
            productUpData_up=productUpData;

            var levelUpButton = ccui.helper.seekWidgetByName(this.root, "Button_5");
            levelUpButton.setTouchEnabled(false);
            levelUpButton.setBright(false);
            levelUpButton.getChildByName("Text_10").setString(ResMgr.inst().getString("block_6"));

            ccui.helper.seekWidgetByName(this.root,"Text_8_0").setVisible(false);
            ccui.helper.seekWidgetByName(this.root,"Text_8").setString(ResMgr.inst().getString("block_7"));
            res_levelup.setVisible(false);
            counts.setVisible(false);
            item1.setVisible(false);
            item2.setVisible(false);
            cost1.setVisible(false);
            cost2.setVisible(false);
        }

        var output = productData.output_perminute*60*productUpData_up.output_multiple*double;

        counts.ignoreContentAdaptWithSize(true);
        counts.setString("+"+Math.floor(output+0.001)+"/"+ResMgr.inst().getString("citadelResource_6"));

        item1.setScale(0.3);
        item1.setTexture(ResMgr.inst()._icoPath+2100032+"0.png");//2100032土地升级券ID
        item2.setTexture("res/images/ico/11030010.png");
        cost1.ignoreContentAdaptWithSize(true);
        cost2.ignoreContentAdaptWithSize(true);

        //设置价格
        var cost_item_counts = ModuleMgr.inst().getData("ItemModule").getCountsByItemId(2100032);
        if(cost_item_counts==0) {
            var temp = modelMgr.call("Table", "getTableItemByValue", ["item_trading",2804013 ]);//快速购买土地升级卡交易ID
            var tempjson = eval("(" + temp.consumption_item + ")");
            var consumption_item = {};
            for (var i in tempjson) {
                consumption_item.itemid = i;
                consumption_item.counts = tempjson[i];
            }

            cost1.setColor(cc.color(255,0,0));
            cost1.setString(0);
            item2.setVisible(true);
            cost2.setVisible(true);
            item2.setTexture(ResMgr.inst()._icoPath+consumption_item.itemid+"0.png");
            cost2.setString(consumption_item.counts/100);
        }
        else {
            item2.setVisible(false);
            cost2.setVisible(false);
            cost1.setString(1);
            cost1.setColor(cc.color(255,255,255));
            item1.setPositionX(this.posx_1+50);
            cost1.setPositionX(this.posx_2+50);
        }
    },

    close:function() {

    },

    updateData: function (data) {
        //cc.log("block data update```````````````````",data.earthCard);
        this.earthid = this.data.earthData.earthCard;
        this.refreshView();
    },

    touchCallback: function (sender,type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                //this.removeFromParent(true);
                ModuleMgr.inst().closeModule("BlockLevelupModule");
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));

                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    touchCallback2: function (sender,type) {
        switch (type) {
            case ccui.Widget.TOUCH_BEGAN:
                break;
            case ccui.Widget.TOUCH_MOVED:
                break;
            case ccui.Widget.TOUCH_ENDED:
                //cc.log("升级土地````````````");
                var msg = new SocketBytes();
                msg.writeUint(305);
                msg.writeInt(this.earthX);
                msg.writeInt(this.earthY);
                NetMgr.inst().send(msg);
                SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
                break;
            case ccui.Widget.TOUCH_CANCELED:
                break;
            default:
                break;
        }
    },

    netComplete: function (cmd, data) {
        if (cmd == 0) {
            data.resetCMDData();
            var data0 = data.readUint();
            var data1 = data.readInt();
            var data2 = data.readString();
            if(data0==305){
                if(data1==0)
                {
                    cc.log("@升级土地 netComplete");
                    SoundPlay.playEffect( ResMgr.inst().getSoundPath(10));
                    var testTable = modelMgr.call("Table", "getTableItemByValue", ["item", this.data.earthid]);
                    var level = parseInt(testTable.type);
                }
                else if(data1==71317)
                {
                    var temp = modelMgr.call("Table", "getTableItemByValue", ["item_trading",2804013 ]);//快速购买土地升级卡交易ID
                    var tempjson = eval("(" + temp.consumption_item + ")");
                    var consumption_item = {};
                    for (var i in tempjson) {
                        consumption_item.itemid = i;
                        consumption_item.counts = tempjson[i];
                    }
                    //var str =ResMgr.inst().getString("block_8")+consumption_item.counts/100+ResMgr.inst().getString( consumption_item.itemid + "0")+ResMgr.inst().getString("block_9");
                    ////ModuleMgr.inst().openModule("AlertPanel", {"txt":str, "okFun":this.buyItem, "owner":this,"params":2804002});
                    //ModuleMgr.inst().openModule("AlertCostModule",{"text":str,"func": this.buyItem});
                    // 直接买升级卷
                    var msg = new SocketBytes();
                    msg.writeUint(502);//商店页面购买
                    msg.writeUint(2804002);//
                    msg.writeUint(1);//默认购买一个
                    NetMgr.inst().send(msg);
                }
                else
                {
                    cc.log("收到错误信息  对应协议号" + data0 + "@@@错误信息@@@" + ResMgr.inst().getString(String(data1)) + "@@@处理id@@@" + data2);
                    ModuleMgr.inst().openModule("AlertString", {
                        str: ResMgr.inst().getString(String(data1)),
                        color: null,
                        time: null,
                        pos: null
                    });
                }
            }
            else if(data0==502)
            {
                if(data1==0)
                {
                    var msg = new SocketBytes();
                    msg.writeUint(305);
                    msg.writeInt(this.earthX);
                    msg.writeInt(this.earthY);
                    NetMgr.inst().send(msg);
                }
            }
        }
    },

    buyItem: function () {
        var msg = new SocketBytes();
        msg.writeUint(502);//商店页面购买
        msg.writeUint(2804002);//
        msg.writeUint(1);//默认购买一个
        NetMgr.inst().send(msg);
    },

    //大小适配
    sizeAutoLayout: function (node, scale) {
        scale = scale ? scale : 1;
        var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down = down * (1 / GameMgr.inst().scaleX);
        var size = node.getContentSize();
        size.height += down * scale;
        node.setContentSize(size);
    },
    //坐标适配
    posAutoLayout: function (node, scale) {
        scale = scale ? scale : 1;
        var down = GameMgr.inst().frameSize.height - GameMgr.inst().scaleViewSize.height;
        down = down * (1 / GameMgr.inst().scaleX);
        var posY = node.getPositionY();
        posY += down * scale;
        node.setPositionY(posY);
    }
});