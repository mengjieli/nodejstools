/**
 * Created by cgMu on 2015/11/16.
 */

var ItemModule = ModuleBase.extend({
    ctor: function () {
        this._super();
    },

    initUI: function () {

    },

    show: function (value) {

    },

    close: function () {

    },

    destroy: function () {

    },
});