var TableModel = (function (_super) {
    __extends(TableModel, _super);

    function TableModel() {
        _super.call(this, "Table");
        this.views = [];
        this.configs = {};
    }

    var d = __define, c = TableModel;
    p = c.prototype;

    p.load = function () {
        var loader = new flower.URLLoader();
        loader.load("res/configs/table/server/TableList.json");
        loader.addEventListener(flower.Event.COMPLETE, function (event) {
            var list = event.currentTarget.data;
            var index = 0;
            var loadNext = function (event) {
                if (index) {
                    GameSDK.DataManager.getInstance().loadingData.model.progress = index;
                    GameSDK.DataManager.getInstance().loadingData.model.max = list.length;
                    this.addConfig(list[index - 1], loader.data);
                }
                if (index == list.length) {
                    this.loadConfig();
                    return;
                }
                loader = new flower.URLLoader();
                loader.addEventListener(flower.Event.COMPLETE, loadNext, this);
                loader.load("res/configs/table/server/" + list[index] + ".txt");
                index++;
            };
            loadNext.call(this);
        }, this);
    }

    p.loadConfig = function () {
        var list = [
            {
                url: "res/configs/fight/arm_display.csv",
                range: {
                    min: "min",
                    max: "max"
                }
            },
            {
                url: "res/configs/fight/arm_interval.csv"
            },
            {
                url: "res/configs/csvs/sounds.csv",
                key: "sounds_name"
            }
        ];
        var index = 0;
        var loadNext = function (event) {
            if (index) {
                GameSDK.DataManager.getInstance().loadingData.model.progress = index;
                GameSDK.DataManager.getInstance().loadingData.model.max = list.length;
                this.addCSVConfig(list[index - 1], event.currentTarget.data);
            }
            if (index == list.length) {
                this.dispatchEvent(new flower.Event(flower.Event.COMPLETE));
                return;
            }
            var loader = new flower.URLLoader();
            loader.addEventListener(flower.Event.COMPLETE, loadNext, this);
            loader.load(list[index].url);
            index++;
        };
        loadNext.call(this);
    }

    /**
     * 添加 csv 的表格
     id,min,max,,
     9600001,100,2000,,
     9600002,2001,5000,,
     9600003,5001,99999,,
     * @param config
     * @param content
     */
    p.addCSVConfig = function (config, content) {
        var url = config.url;
        var name = url.split("/")[url.split("/").length - 1];
        name = name.split(".")[0];
        content = flower.StringDo.replace(content, "\r", "\n");
        content = flower.StringDo.replace(content, "\n\n", "\n");
        var list = content.split("\n");
        var keys = list.shift();
        keys = keys.split(",");
        var array = new ArrayData();
        this.configs[name] = array;
        for (var i = 0; i < list.length; i++) {
            var listItem = list[i];
            var listArray = [];
            var index = 0;
            while (index < listItem.length) {
                var change = listItem.charAt(index) == "\"" ? true : false;
                if (change) {
                    index++;
                    for (var c = index; c < listItem.length; c++) {
                        if (listItem.charAt(c) == "\"") {
                            if (c + 1 < listItem.length && listItem.charAt(c + 1) == "\"") {
                                listItem = listItem.slice(0, c) + listItem.slice(c + 1, listItem.length);
                            } else {
                                break;
                            }
                        }
                    }
                    listArray.push(listItem.slice(index, c));
                    index = c + 2;
                } else {
                    for (var c = index; c < listItem.length; c++) {
                        if (listItem.charAt(c) == ",") {
                            break;
                        }
                    }
                    var value = listItem.slice(index, c);
                    value = jc.TypeHelp.parseNumber(value) || value;
                    listArray.push(value);
                    index = c + 1;
                }
            }
            var item = {};
            for (var k = 0; k < keys.length; k++) {
                var key = keys[k];
                item[keys[k]] = listArray[k];
            }
            array.push(item);
        }
        if(config.key) {
            array.setKey(config.key);
        } else {
            array.setKey(keys[0]);
        }
        //trace("CSV:",name, flower.ObjectDo.toString(array));
        if (config.range) {
            array.setRangeMinKey(config.range.min);
            array.setRangeMaxKey(config.range.max);
        }
    }

    /**
     * 添加表格，内容格式如下
     [
     ["sign_id","trading_id"],
     ["1","2805001"],
     ["2","2805002"],
     ["3","2805003"],
     ["4","2805004"],
     ["5","2805005"],
     ["6","2805006"],
     ["7","2805007"]
     ]
     * @param name 表格名称
     * @param content 表格内容
     */
    p.addConfig = function (name, content) {
        var list = JSON.parse(content);
        var len = Object.keys(list).length;
        var keys = list["0"];
        var array = new ArrayData();
        this.configs[name] = array;
        for (var i = 1; i < len; i++) {
            var obj = {};
            for (var k = 0; k < keys.length; k++) {
                var value = jc.TypeHelp.parseNumber(list[i][k]);
                if (value != null) {
                    obj[keys[k]] = value;
                } else {
                    obj[keys[k]] = list[i][k];
                }
            }
            array.push(obj);
        }
        array.setKey(keys[0]);
    }

    p.getTable = function (name) {
        trace("返回表格:", name, this.configs[name]);
        if (!this.configs[name]) {
            console.log("没有表格:" + name);
        }
        return this.configs[name];
    }

    /**
     * 查询表格列表，
     * @param name 表名
     * @returns 返回 Array
     */
    p.getTableList = function (name) {
        if (!name || !this.configs[name]) {
            console.log("没有表格:" + name);
        }
        return this.configs[name].list;
    }

    /**
     * 查询表格单行数据
     * @param tableName 表名
     * @param key 键名1
     * @param value 值1
     * @param key2 键名2
     * @param value2 值2
     * @returns 返回匹配的第一行数据
     */
    p.getTbaleItem = function (tableName, key, value, key2, value2) {
        if (jc.TypeHelp.parseNumber(value) != null) {
            value = jc.TypeHelp.parseNumber(value);
        }
        if (jc.TypeHelp.parseNumber(value2) != null) {
            value = jc.TypeHelp.parseNumber(value2);
        }
        return this.configs[tableName].getItem(key, value, key2, value2);
    }

    /**
     * 查询表格数据
     * @param tableName 表名
     * @param key 键名1
     * @param value 值1
     * @param key2 键名2
     * @param value2 值2
     * @returns 返回匹配数据数组
     */
    p.getTbaleItems = function (tableName, key, value, key2, value2) {
        if (jc.TypeHelp.parseNumber(value) != null) {
            value = jc.TypeHelp.parseNumber(value);
        }
        if (jc.TypeHelp.parseNumber(value2) != null) {
            value = jc.TypeHelp.parseNumber(value2);
        }
        return this.configs[tableName].getItem(key, value, key2, value2);
    }

    /**
     * 查询表格单行数据，以表格第一个字段为参数
     * @param tableName 表名
     * @param value 要匹配的值
     * @returns 返回匹配的第一个数据
     */
    p.getTableItemByValue = function (tableName, value) {
        if (jc.TypeHelp.parseNumber(value) != null) {
            value = jc.TypeHelp.parseNumber(value);
        }
        return this.configs[tableName].getItemByValue(value);
    }

    /**
     * 查询表格单行数据，根据设定的范围来匹配
     * @param tableName 表名
     * @param value 要匹配的值
     * @returns 返回匹配的第一个数据
     */
    p.getTableItemByRange = function (tableName, value) {
        if (jc.TypeHelp.parseNumber(value) != null) {
            value = jc.TypeHelp.parseNumber(value);
        }
        return this.configs[tableName].getItemByRange(value);
    }

    return TableModel;
})(ModelBase);