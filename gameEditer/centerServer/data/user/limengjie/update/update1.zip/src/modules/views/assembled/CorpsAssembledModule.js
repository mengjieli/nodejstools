/**
 * Created by cgMu on 2015/11/24.
 */

var CorpsAssembledModule = ModuleBase.extend({
    scrol: null,
    scrollbar: null,
    scrollbar_bg:null,
    barTotalHeight: 0,
    barPercent_total: 0,
    scrollPosY: 0,
    isOnePage: null,
    item_root: null,
    item_last:null,

    label1: null,

    rightPanel1:null,
    rightPanel2:null,
    selectingItem:null,

    corpsMax:0,//军团上限数量
    corpsData:null,

    corpsAssembled:null,

    _button1:null,
    _button2:null,
    _button3:null,
    _state:0,//0:初始状态；1:出征；2:解散

    currentCastleId:null,

    goLabel:null,
    downBtn:null,
    rightScroll:null,
    rightScrollRoot:null,

    ctor:function() {
        this._super();
        this.corpsData = [];

        //军团上限根据主城等级
        var castle_level = ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(1909001)[0]._building_level;
        this.corpsMax = modelMgr.call("Table", "getTableItemByValue", ["City_Flied", castle_level]).force_limit;

        //cc.log("@CorpsAssembledModule",castle_level,this.corpsMax,this.corpsData);

        this.corpsAssembled = [];

        EventMgr.inst().addEventListener("refresh_content",this.eventCallback,this);
        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    initUI:function() {
        var root = ccs.load("res/images/ui/CorpsAssembled/Layer.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1 = ccui.helper.seekWidgetByName(root,"Panel_1");
        sizeAutoLayout(Panel_1);

        //适配
        var Image_8_0 = Panel_1.getChildByName("Image_8_0");
        sizeAutoLayout(Image_8_0);
        var Panel_55 = Panel_1.getChildByName("Panel_55");
        sizeAutoLayout(Panel_55);
        var Image_10 = Panel_1.getChildByName("Image_10");
        posAutoLayout(Image_10);
        //var Image_157 = Panel_1.getChildByName("Image_157");
        //sizeAutoLayout(Image_157);

        var Image_25 = Panel_1.getChildByName("Image_25");
        sizeAutoLayout(Image_25);

        var Image_26 = Panel_1.getChildByName("Image_26");
        sizeAutoLayout(Image_26);

        var tag_label = ccui.helper.seekWidgetByName(root,"Text_1");
        tag_label.ignoreContentAdaptWithSize(true);
        tag_label.setString(0+"/"+this.corpsMax+" "+ResMgr.inst().getString("assembled_1"));
        posAutoLayout(tag_label);
        this.label1 = tag_label;

        var Text_1_0 = Panel_1.getChildByName("Text_1_0");
        Text_1_0.ignoreContentAdaptWithSize(true);
        Text_1_0.setString("0/0 "+ResMgr.inst().getString("assembled_26"));
        posAutoLayout(Text_1_0);
        Text_1_0.setVisible(false);

        var scrollview = ccui.helper.seekWidgetByName(root,"ScrollView_1");
        sizeAutoLayout(scrollview);
        scrollview.addEventListener(this.scrollCall, this);
        this.scrol = scrollview;

        var item_root = this.scrol.getChildByName("Image_3");
        item_root.setVisible(false);
        this.item_root = item_root;

        var item_last = this.scrol.getChildByName("Image_10");
        item_last._index = -1;
        this.item_last = item_last;

        //if(this.corpsMax<=this.corpsData.length){
        //    this.item_last.setVisible(false);
        //}

        var add_btn = item_last.getChildByName("Image_6");
        add_btn.setTouchEnabled(true);
        add_btn.addTouchEventListener(this.addcallback,this);
        var add_title = item_last.getChildByName("Text_21");
        add_title.ignoreContentAdaptWithSize(true);
        add_title.setString(ResMgr.inst().getString("assembled_18"));

        var scrolbar_bg = ccui.helper.seekWidgetByName(root,"bg");
        sizeAutoLayout(scrolbar_bg);
        this.scrollbar_bg = scrolbar_bg;

        var scrolbar = ccui.helper.seekWidgetByName(root,"bar");
        posAutoLayout(scrolbar);
        this.scrollbar = scrolbar;
        this.scrollPosY = this.scrollbar.getPositionY();
        this.barTotalHeight = scrolbar_bg.getContentSize().height;

        var Panel_2 = Panel_1.getChildByName("Panel_2");
        sizeAutoLayout(Panel_2);
        this.rightPanel1 = Panel_2;
        ccui.helper.doLayout(Panel_2);
        var Text_8 = Panel_2.getChildByName("Text_8");
        Text_8.ignoreContentAdaptWithSize(true);
        Text_8.setString(ResMgr.inst().getString("assembled_33"));

        var ScrollView_2 = Panel_2.getChildByName("ScrollView_2");
        sizeAutoLayout(ScrollView_2);
        var rightScrollroot = Panel_2.getChildByName("Panel_3");
        rightScrollroot.setVisible(false);
        rightScrollroot.addTouchEventListener(this.rightItCallback,this);
        this.rightScroll = ScrollView_2;
        this.rightScrollRoot= rightScrollroot;
        this.setAddPanel();

        var Panel_2_0 = Panel_1.getChildByName("Panel_2_0");
        sizeAutoLayout(Panel_2_0);
        this.rightPanel2 = Panel_2_0;
        ccui.helper.doLayout(Panel_2_0);
        Text_8 = Panel_2_0.getChildByName("Text_8");
        Text_8.ignoreContentAdaptWithSize(true);
        Text_8.setString(ResMgr.inst().getString("assembled_33"));

        var Button_2_0 = Panel_2_0.getChildByName("Button_2_0");
        Button_2_0.addTouchEventListener(this.dissolveCallbackEx,this);
        var title = Button_2_0.getChildByName("Text_7");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("assembled_8"));

        var Button_2_0_0 = Panel_2_0.getChildByName("Button_2_0_0");
        Button_2_0_0.addTouchEventListener(this.suppleCallabckEx,this);
        title = Button_2_0_0.getChildByName("Text_7");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("assembled_7"));

        var Text_3 = Panel_1.getChildByName("Text_3");
        Text_3.ignoreContentAdaptWithSize(true);
        Text_3.setString(ResMgr.inst().getString("assembled_34")+"0"+ResMgr.inst().getString("assembled_35"));
        Text_3.setVisible(false);
        this.goLabel = Text_3;

        var Button_2 = Panel_1.getChildByName("Button_2");
        Button_2.addTouchEventListener(this.downBtnCallback,this);
        title = Button_2.getChildByName("Text_7");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("assembled_27"));
        this.downBtn = Button_2;

        //panel down
        //var panel_down = ccui.helper.seekWidgetByName(root,"Image_8");
        //panel_down.setVisible(true);
        //var tips = panel_down.getChildByName("Text_2");
        //tips.ignoreContentAdaptWithSize(true);
        //tips.setString(ResMgr.inst().getString("assembled_9"));
        //tips.setPositionX(tips.getPositionX()-100);

        //var one_btn = panel_down.getChildByName("Button_1");
        //one_btn.addTouchEventListener(this.oneCallback,this);
        //var tit = one_btn.getChildByName("Text_4");
        //tit.ignoreContentAdaptWithSize(true);
        //tit.setString(ResMgr.inst().getString("assembled_13"));
        //one_btn.setVisible(false);
        //this._button3 = one_btn;

        //出征
        //var btn1 = panel_down.getChildByName("Image_2");
        ////btn1.setVisible(false);
        //btn1.setTouchEnabled(true);
        //btn1.addTouchEventListener(this.changeStateCallback1,this);
        //var title = btn1.getChildByName("Text_5");
        //title.ignoreContentAdaptWithSize(true);
        //title.setString(ResMgr.inst().getString("assembled_27"));

        //解散
        //var btn2 = panel_down.getChildByName("Image_2_0");
        //btn2.setTouchEnabled(true);
        //btn2.addTouchEventListener(this.changeStateCallback2,this);
        //btn2.setVisible(false);
        //title = btn2.getChildByName("Text_6");
        //title.ignoreContentAdaptWithSize(true);
        //title.setString(ResMgr.inst().getString("assembled_8"));
        //this._button1 = btn1;
        //this._button2 = btn2;
    },

    suppleCallabckEx: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            cc.log("@bu bing");
            var data = this.selectingItem.getUserData();
            var sumpplementlayer = new SupplementLayer(data);
            ModuleMgr.inst().addNodeTOLayer(sumpplementlayer,ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    dissolveCallbackEx: function (sender,type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var data = this.selectingItem.getUserData();
            var msg = new SocketBytes();
            msg.writeUint(310);// 解散部队
            msg.writeString(data.id);
            NetMgr.inst().send(msg);
        }
    },

    rightItCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            var data =sender.getUserData();
            var addlayer = new AddLayer(data);
            ModuleMgr.inst().addNodeTOLayer(addlayer,ModuleLayer.LAYER_TYPE_TOP);
        }
    },

    downBtnCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            //if(mainData.uiData.showMap==MapChangeModule.CASTLE){
            //    cc.log("@补兵");
            //}
            //else{
                cc.log("@出征");
            var arr = this.getArray();
            if(arr.length==0){
                ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("assembled_29"),color:null,time:null,pos:null});
            }

            for(var i in arr){
                var userdata = arr[i].getUserData();
                //cc.log("@1:出征",arr[i].getTag(),userdata.type,userdata.id);
                var msg = new SocketBytes();
                msg.writeUint(311);//部队出征
                msg.writeString(userdata.id);
                NetMgr.inst().send(msg);
            }
            //}
        }
    },

    setDownBtnVisible: function (visible) {
        this.downBtn.setVisible(true);
        var title = this.downBtn.getChildByName("Text_7");

        //if(mainData.uiData.showMap==MapChangeModule.CASTLE){
        //    title.setString(ResMgr.inst().getString("assembled_7"));
        //}else{
            title.setString(ResMgr.inst().getString("assembled_27"));
        //}


    },

    checkMap: function () {
        //var title = this._button1.getChildByName("Text_5");
        if(mainData.uiData.showMap==MapChangeModule.CASTLE){
            //this._button1.setTouchEnabled(false);
            //this._button1.loadTexture("ty_kejishang_huianniu.png",ccui.Widget.PLIST_TEXTURE);
            //城内

            //title.setString(ResMgr.inst().getString("assembled_8"));
            this.goLabel.setVisible(false);
            //this.downBtn.setVisible(false);
            this.setDownBtnVisible(false);
        }
        else{
            //var title = this._button1.getChildByName("Text_5");
            //title.setString(ResMgr.inst().getString("assembled_27"));
            this.goLabel.setVisible(true);
            //this.downBtn.setVisible(true);
            this.setDownBtnVisible(true);
        }

        //switch (this._state){
        //    case 0:
        //        this._button1.loadTexture("CorpsAssembled/tesu_icon.png",ccui.Widget.PLIST_TEXTURE);
        //        break;
        //    case 1:
        //        this._button1.loadTexture("CorpsAssembled/tesu_daiji_icon.png",ccui.Widget.PLIST_TEXTURE);
        //        break;
        //    case 2:
        //        this._button1.loadTexture("CorpsAssembled/tesu_daiji_icon.png",ccui.Widget.PLIST_TEXTURE);
        //        break;
        //}
    },

    show:function( value ) {
        this.currentCastleId = value?value:mainData.uiData.currentCastleId;
        this.refreshContent();
    },

    close:function() {

    },

    destroy:function() {
        this._super();
        this.corpsData = null;
        EventMgr.inst().removeEventListener("refresh_content",this.eventCallback,this);
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    gotData: function () {
        var arr = [];
        var list = mainData.castleData.armyList;
        for (var i = 0; i < list.length; i++) {
            var it = list.getItemAt(i);
            if (it.castleId == mainData.uiData.currentCastleId) {
                if (it.num > 0) {
                    cc.log("@gotData", it.castleId, it.armyId, it.num);
                    arr.push(it);
                }
            }
        }
        return arr;
    },

    setAddPanel: function () {
        this.rightScroll.removeAllChildren();

        var data = this.gotData();
        var size = this.rightScroll.getContentSize();
        var count = data.length;
        var height = this.rightScrollRoot.getContentSize().height;
        var total = height*count;
        total = Math.max(total,size.height);

        this.rightScroll.setInnerContainerSize(cc.size(size.width,total));

        for(var i =0;i<count;i++){
            var it = this.rightScrollRoot.clone();
            it.setVisible(true);
            //it.setTag()
            it.setUserData(data[i]);
            this.rightScroll.addChild(it);
            it.setPosition(cc.p(0,total-height*(i+1)));

            this.setRightIt(it,data[i]);
        }
        this.rightScroll.jumpToTop();
    },

    setRightIt: function (node, data) {
        var selecting = node.getChildByName("Image_15");
        selecting.setVisible(false);

        var urlid = modelMgr.call("Table", "getTableItemByValue", ["Arm", data.armyId]).arm_type;

        var ico = node.getChildByName("Image_4_1");
        ico.ignoreContentAdaptWithSize(true);
        ico.loadTexture(ResMgr.inst().getIcoPath(urlid));

        var name = node.getChildByName("Text_9");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(data.armyId + "0"));

        var counts = node.getChildByName("Text_9_0");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString(data.num);
    },

    setInfo: function (data) {//data:军团数据 assembled_info_0
        if(this.rightPanel2){
            for(var i = 0; i < 8; i++){
                var title = this.rightPanel2.getChildByName("title_"+i);
                title.ignoreContentAdaptWithSize(true);
                title.setString(ResMgr.inst().getString("assembled_info_"+i));
            }

            var armyConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",data.type]);
            var counts = data.attributes.getItem("type",2500011).value;

            var value = this.rightPanel2.getChildByName("Text_15_0");
            value.ignoreContentAdaptWithSize(true);
            value.setString(armyConfig.attack*counts);

            value = this.rightPanel2.getChildByName("Text_15_0_0");
            value.ignoreContentAdaptWithSize(true);
            value.setString(armyConfig.defence);

            value = this.rightPanel2.getChildByName("Text_15_0_1");
            value.ignoreContentAdaptWithSize(true);
            value.setString(armyConfig.attack_speed);

            value = this.rightPanel2.getChildByName("Text_15_0_0_0");
            value.ignoreContentAdaptWithSize(true);
            value.setString(armyConfig.shoot_range);

            value = this.rightPanel2.getChildByName("Text_15_0_2");
            value.ignoreContentAdaptWithSize(true);
            value.setString(armyConfig.speed);

            value = this.rightPanel2.getChildByName("Text_15_0_0_1");
            value.ignoreContentAdaptWithSize(true);
            value.setString((armyConfig.collect_speed*counts).toFixed(2));

            value = this.rightPanel2.getChildByName("Text_15_0_3");
            value.ignoreContentAdaptWithSize(true);
            value.setString((armyConfig.arm_load*counts).toFixed(2));

            value = this.rightPanel2.getChildByName("Text_15_0_0_2");
            value.ignoreContentAdaptWithSize(true);
            value.setString(data.force);
        }
    },

    refreshLabel: function () {
        this.label1.setString(ResMgr.inst().getString("assembled_1") + " "+this.corpsData.length + "/" + this.corpsMax);
        this._state = 0;
        this.setState(this._state);
    },

    refreshContent: function () {
        this.corpsData = mainData.mapData.myArmyList.getItems("castleId",this.currentCastleId);//获取部队数据
        this.refreshLabel();

        for (var i in this.corpsAssembled) {
            if (this.corpsAssembled[i]) {
                this.corpsAssembled[i].removeFromParent(true);
            }
        }
        this.corpsAssembled = [];

        var item_height = 138;
        var counts = this.corpsData.length;
        var size = this.scrol.getContentSize();
        var gap = 0;
        var total_height = (gap + item_height) * counts + gap + (gap + item_height);
        if(total_height<size.height) {
            total_height = size.height;
        }

        this.scrol.setInnerContainerSize(cc.size(size.width, total_height));
        this.scrol.jumpToTop();

        var pos = this.scrol.getInnerContainer().getPosition();
        this.barPercent_total = Math.abs(pos.y);

        //重置滑块大小
        var innerContainerSize = this.scrol.getInnerContainerSize();
        if (this.barPercent_total == 0) {
            //this.scrollbar.height = this.barTotalHeight
        }
        else {
            //var barHeight = this.barTotalHeight * (1 - (this.barPercent_total / innerContainerSize.height));
            //this.scrollbar.height = barHeight;
        }
        //重置滑块位置
        if (innerContainerSize.height < size.height) {
            this.isOnePage = true;
        }
        else {
            this.isOnePage = false;
        }
        if (this.isOnePage) {
            this.refreshScrollbarState(100);
        }
        else {
            this.refreshScrollbarState(0);
        }

        for (var i = 0; i < counts; i++) {
            var item = this.item_root.clone();
            item.setVisible(true);
            this.scrol.addChild(item);
            item.setPosition(cc.p(gap,total_height-(gap + item_height)*(i+1)));
            this.corpsAssembled.push(item);
            item.setTouchEnabled(true);
            item.addTouchEventListener(this.itemCallback,this);
            item.setUserData(this.corpsData[i]);
            //item.setUserData(this.corpsData.getItemAt(i));
            item.setTag(i+1);
            item._index = 0;

            this.setItem(item);
        }

        this.item_last.setPosition(cc.p(gap,total_height-(gap + item_height)*(counts+1)));

        if(counts>0){
            this.selectingItem = this.corpsAssembled[0];
            this.setSelecting(this.selectingItem,true);
            this.rightPanel1.setVisible(false);
            this.rightPanel2.setVisible(true);
            this.setInfo(this.selectingItem.getUserData());

            this.setDownBtnVisible(true);
        }
        else{
            this.selectingItem = this.item_last;
            this.rightPanel1.setVisible(true);
            this.rightPanel2.setVisible(false);
        }

    },

    setSelecting: function (item,visible) {
        if(item){
            var sel = item.getChildByName("Image_14");
            sel.setVisible(visible);
        }

    },

    setItem: function (item) {
        var tag = item.getTag();
        var data = item.getUserData();
        //cc.log("type:",data.type,"user:",data.user,mainData.playerData.account);
        var armyConfig = modelMgr.call("Table", "getTableItemByValue", ["Arm",data.type]);
        var armyType = armyConfig.arm_type;

        var Image_14 = item.getChildByName("Image_14");
        Image_14.setVisible(false);

        var icon = item.getChildByName("Image_4");
        icon.ignoreContentAdaptWithSize(true);
        icon.loadTexture(ResMgr.inst()._icoPath+armyType+"0.png");

        //var name = item.getChildByName("Text_11");
        //name.ignoreContentAdaptWithSize(true);
        //name.setString(ResMgr.inst().getString("assembled_2"));

        var name_label = item.getChildByName("Text_11_2");
        name_label.ignoreContentAdaptWithSize(true);
        //name_label.setString(ResMgr.inst().getString("assembled_19")+tag+ResMgr.inst().getString("assembled_20"));
        name_label.setString(ResMgr.inst().getString(data.type+"0"));

        //var state = item.getChildByName("Text_11_0");
        //state.ignoreContentAdaptWithSize(true);
        //state.setString(ResMgr.inst().getString("assembled_3"));

        var state_label = item.getChildByName("Text_11_2_0");
        state_label.ignoreContentAdaptWithSize(true);
        //state_label.setString(this.getArmyState(data.inCity));
        state_label.setString("Lv "+data.type%100);

        //var armyname = item.getChildByName("Text_11_1_0");
        //armyname.ignoreContentAdaptWithSize(true);
        //armyname.setString(ResMgr.inst().getString("assembled_28"));
        //
        //var armyname_label = item.getChildByName("Text_11_2_1_0");
        //armyname_label.ignoreContentAdaptWithSize(true);
        //armyname_label.setString();

        //var counts = item.getChildByName("Text_11_0_0");
        //counts.ignoreContentAdaptWithSize(true);
        //counts.setString(ResMgr.inst().getString("assembled_4"));

        var value1 = data.attributes.getItem("type",2500011).value;
        var value2 = armyConfig.force_mnax;//data.attributes.getItem("type",2500077).value;
        var counts_label = item.getChildByName("Text_11_2_0_0");
        counts_label.ignoreContentAdaptWithSize(true);
        counts_label.setString(value1+"/"+value2);

        //var location = item.getChildByName("Text_11_1");
        //location.ignoreContentAdaptWithSize(true);
        //location.setString(ResMgr.inst().getString("assembled_5"));

        var location_label = item.getChildByName("Text_11_2_1_0");
        location_label.ignoreContentAdaptWithSize(true);
        location_label.setString("X:"+data.coordX+",Y:"+data.coordY);

        var LoadingBar_1 = item.getChildByName("LoadingBar_1");
        LoadingBar_1.setPercent(value1 / value2 * 100);

        var Image_66 = item.getChildByName("Image_66");
        Image_66.setTouchEnabled(true);
        Image_66.addTouchEventListener(this.selectingCallback,this);
        Image_66.setUserData(item);
        var title = Image_66.getChildByName("Text_31");
        title.ignoreContentAdaptWithSize(true);
        title.setString("N");

        if(!data.inCity){
            Image_66.setVisible(false);
        }

        //var supplement_btn = item.getChildByName("Button_3");
        //supplement_btn.setUserData(data);
        //supplement_btn.addTouchEventListener(this.supplementCallback,this);
        //var txt = supplement_btn.getChildByName("Text_27");
        //txt.ignoreContentAdaptWithSize(true);
        //txt.setString(ResMgr.inst().getString("assembled_7"));
        //BorderText.replace(txt);
        //能否补兵要根据部队位置判断？？？？
        //if(mainData.uiData.showMap==MapChangeModule.CASTLE && data.inCity){
        //    supplement_btn.setVisible(true);
        //    if(value1<armyConfig.force_mnax){
        //        this.setButtonEnabled(supplement_btn,true);
        //    }
        //    else{
        //        this.setButtonEnabled(supplement_btn,false);
        //    }
        //}
        //else{
        //    supplement_btn.setVisible(false);
        //}

        //var dissolve_btn = item.getChildByName("Button_3_0");
        //dissolve_btn.setTitleText(ResMgr.inst().getString("assembled_8"));
        //var text = dissolve_btn.getChildByName("Text_28");
        //text.ignoreContentAdaptWithSize(true);
        //text.setString(ResMgr.inst().getString("assembled_8"));
        //text.enableOutline(cc.color(0,0,0,255));
        //dissolve_btn.addTouchEventListener(this.dissolveCallback,this);

        //var selectingTag = item.getChildByName("Image_1");
        //selectingTag.setVisible(false);

        //selectingTag.setVisible(true);
        //selectingTag.addTouchEventListener(this.selectingCallback,this);

    },

    selectingCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;


        var title = sender.getChildByName("Text_31");
        title.ignoreContentAdaptWithSize(true);


        var data = sender.getUserData();
        if(data._index==0){
            data._index=1;
            title.setString("Y");
            sender.loadTexture("xueyuan_teshudanniuxuanzhong.png",ccui.Widget.PLIST_TEXTURE);
        }
        else{
            data._index=0;
            title.setString("N");
            sender.loadTexture("xueyuan_teshudanniuxuanzhong.png",ccui.Widget.PLIST_TEXTURE);
        }
    },

    getArmyState: function (type) {
        var str = "";
        if(type){
            str = ResMgr.inst().getString("assembled_23");
        }
        else{
            str = ResMgr.inst().getString("assembled_22");
        }
        return str;
    },

    itemCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        //if(this._state==0) return;
        //if(this._state==1){
        //    var userdata = sender.getUserData();
        //    if(!userdata.inCity){
        //        return;
        //    }
        //}

        if(this.selectingItem){
            if(this.selectingItem._index>=0){
                var sel = this.selectingItem.getChildByName("Image_14");
                sel.setVisible(false);
            }
        }

        if(sender._index>=0){
            var selectingTag = sender.getChildByName("Image_14");
            selectingTag.setVisible(true);

            this.selectingItem = sender;

            this.rightPanel1.setVisible(false);
            this.rightPanel2.setVisible(true);
            this.setInfo(this.selectingItem.getUserData());

            //this.downBtn.setVisible(true);
            //var title = this.downBtn.getChildByName("Text_7");
            //title.setString(ResMgr.inst().getString("assembled_7"));
            this.setDownBtnVisible(true);
        }

        //var tag = sender.getTag();
        //cc.log("@itemCallback",tag)
        //var data = ["CorpsAssembled/tesu_weiyouxuanzhong.png","CorpsAssembled/tesu_youxuanzhong.png"];
        //if(sender._index==0){
        //    sender._index=1;
        //}
        //else{
        //    sender._index=0;
        //}
        //var selectingTag = sender.getChildByName("Image_1");
        //selectingTag.loadTexture(data[sender._index],ccui.Widget.PLIST_TEXTURE);
    },

    supplementCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        var sumpplementlayer = new SupplementLayer(sender.getUserData());
        ModuleMgr.inst().addNodeTOLayer(sumpplementlayer,ModuleLayer.LAYER_TYPE_TOP);
    },

    dissolveCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        var dissolvelayer = new DissolveLayer();
        ModuleMgr.inst().addNodeTOLayer(dissolvelayer,ModuleLayer.LAYER_TYPE_TOP);
    },

    oneCallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        if(this._state==1){
            //1:出征；
            var arr = this.getArray();
            if(arr.length==0){
                ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("assembled_29"),color:null,time:null,pos:null});
            }

            for(var i in arr){
                var userdata = arr[i].getUserData();
                //cc.log("@1:出征",arr[i].getTag(),userdata.type,userdata.id);
                var msg = new SocketBytes();
                msg.writeUint(311);//部队出征
                msg.writeString(userdata.id);
                NetMgr.inst().send(msg);
            }
        }
        else if (this._state == 2){
            //cc.log("@2:解散")
            var arr = this.getArray();
            if(arr.length==0) return;

            //EventMgr.inst().dispatchEvent(CastleEvent.DISSOLVE_ARMY)
            if(this.check(arr)){
                var dissolvelayer = new DissolveLayer(arr);
                ModuleMgr.inst().addNodeTOLayer(dissolvelayer,ModuleLayer.LAYER_TYPE_TOP);
            }
            else{
                for(var i in arr){
                    var userdata = arr[i].getUserData();
                    cc.log("@1:解散", arr[i].getTag(),userdata.type);//无人数数据
                    //EventMgr.inst().dispatchEvent(CastleEvent.DISSOLVE_ARMY)
                    var msg = new SocketBytes();
                    msg.writeUint(310);// 解散部队
                    msg.writeString(userdata.id);
                    NetMgr.inst().send(msg);
                }
            }
        }
    },

    addcallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;

        if(this.corpsMax<=this.corpsData.length){
            //校场满级？？？
            var buildingdata =ModuleMgr.inst().getData("CastleModule").getNetBlockByBuildingId(1909001)[0];
            var lv = buildingdata?buildingdata._building_level:0;
            var data = modelMgr.call("Table","getTableList",["City_Flied"]);
            var str = ResMgr.inst().getString("assembled_30");
            if(lv==data.length){
                str = ResMgr.inst().getString("assembled_31");
            }
            ModuleMgr.inst().openModule("AlertString",{str:str,color:null,time:null,pos:null});
        }
        else{
            this.rightPanel1.setVisible(true);
            this.rightPanel2.setVisible(false);
            if(this.selectingItem&&this.selectingItem._index>=0){
                this.setSelecting(this.selectingItem,false);
            }
        }

        //this.downBtn.setVisible(false)
        this.setDownBtnVisible(false);

    },

    changeStateCallback1: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;

        if(mainData.uiData.showMap==MapChangeModule.CASTLE){
            if(this._state==2) {
                this._state = 0;
            }
            else{
                this._state = 2;
            }
        }
        else{
            if(this._state==1) {
                this._state = 0;
            }
            else{
                this._state = 1;
            }
        }

        this.setState(this._state);
    },

    changeStateCallback2: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        if(this._state==2) {
            this._state = 0;
        }
        else{
            this._state = 2;
        }
        this.setState(this._state);
    },

    setState: function (state) {
        switch (state){
            case 0:
                //this._button3.setVisible(false);
                this.checkMap();
                //this._button2.loadTexture("CorpsAssembled/tesu_icon.png",ccui.Widget.PLIST_TEXTURE);
                //this.resetCellState(false);
                break;
            case 1:
                //this._button3.setVisible(true);
                this.checkMap();
                //this._button2.loadTexture("CorpsAssembled/tesu_icon.png",ccui.Widget.PLIST_TEXTURE);
                //this.resetCellState(true);
                break;
            case 2:
                //this._button3.setVisible(true);
                //this._button2.loadTexture("CorpsAssembled/tesu_daiji_icon.png",ccui.Widget.PLIST_TEXTURE);
                this.checkMap();
                //this.resetCellState(true);
                break;
        }
    },

    //滚动框事件回调
    scrollCall: function (node, type) {
        switch (type) {
            case ccui.ScrollView.EVENT_SCROLLING:
                var pos = this.scrol.getInnerContainer().getPosition();
                var number = this.barPercent_total + pos.y;
                var per = number * 100 / this.barPercent_total;
                if (per < 0) {
                    per = 0
                }
                if (per > 100) {
                    per = 100
                }
                this.refreshScrollbarState(per);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_TOP:
                this.refreshScrollbarState(0);
                break;
            case ccui.ScrollView.EVENT_SCROLL_TO_BOTTOM:
                this.refreshScrollbarState(100);
                break;
            default :
                break;
        }
    },

    //更新滑块位置
    refreshScrollbarState: function (percent) {
        if (!percent && percent != 0) {
            return;
        }
        if (!this.isOnePage) {
            this.scrollbar.y = this.scrollPosY - (this.barTotalHeight - this.scrollbar.height) * percent / 100;
        }
        else {
            this.scrollbar.y = this.scrollPosY;
        }
    },
    
    setButtonEnabled: function (btn,enabled) {
        if(btn){
            btn.setBright(enabled);
            btn.setTouchEnabled(enabled);
        }
    },
    
    resetCellState: function (value) {
        for(var i in this.corpsAssembled){
            var item = this.corpsAssembled[i];
            var selectingTag = item.getChildByName("Image_1");
            selectingTag.setVisible(value);
            selectingTag.loadTexture("CorpsAssembled/tesu_weiyouxuanzhong.png",ccui.Widget.PLIST_TEXTURE);
            item._index = 0;

            if(this._state==1){
               var data = item.getUserData();
                if(!data.inCity){
                    selectingTag.setVisible(false);
                }
            }
        }
    },

    getArray: function () {
        var array = [];
        for(var i in this.corpsAssembled){
            if(this.corpsAssembled[i]._index==1){
                //var tag = this.corpsAssembled[i].getTag();
                array.push(this.corpsAssembled[i]);
            }
        }
        return array;
    },

    //true: 有城外部队 ;false
    check: function (arr) {
        var value = false;
        for(var i in arr){
            var it = arr[i];
            var data = it.getUserData();
            if(!data.inCity){
                value = true;
                break;
            }
        }
        return value;
    },

    eventCallback: function (event) {
        this.refreshContent();
        this.setAddPanel();
    },

    netComplete: function (event, data) {
        if(data == 312){
            this.refreshContent();
        }
        else if (data==311){
            ModuleMgr.inst().closeModule("CorpsAssembledModule");
        }
        else if (data==310){
            EventMgr.inst().dispatchEvent("refresh_content");
            ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("assembled_32"),color:null,time:null,pos:null});
        }
    }

});