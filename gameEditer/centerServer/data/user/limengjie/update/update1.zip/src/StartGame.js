/**
 * 游戏启动流程
 //1. 初始化化模块管理
 //2. 初始化客户端数据结构
 //3. 加载模块管理
 //4. 加载客户端配置文件
 //5. 注册、登录流程
 //6. 请求游戏服务器数据
 //7. 流程完成，进入游戏 new Game();
 * @constructor
 */
function StartGame() {
    //TODO 换成新的引擎后可去掉
    this.test();

    this.updateGame();
}

/**
 * 登录注册流程数据
 * @type {null}
 */
var startGameData = null;

/**
 * 临时的代码，以后换成新引擎去掉
 */
StartGame.prototype.test = function () {
    var time = (new Date()).getTime();
    setInterval(function () {
        var now = (new Date()).getTime();
        var delate = now - time;
        jc.EnterFrame.update(delate);
        time = now;
    }, 33);
    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
    var fileExist = jsb.fileUtils.isFileExist(storagePath + "server");
    if (fileExist) {
        var strs = jsb.fileUtils.getValueMapFromFile(storagePath + "server");
        net = parseInt(strs["ip"]);
        GameConfig.reset();
    }
}

/**
 * 1. 初始化
 */
StartGame.prototype.updateGame = function () {
    DataManager.init();
    GameSDK.DataManager.getInstance().loadDataDefine("res/data/StartGameData.json");
    GameSDK.DataManager.getInstance().addData("startGameData", "StartGameData");
    startGameData = GameSDK.DataManager.getInstance().startGameData;
    startGameData.addListener("step", this.stepChange, this);
    startGameData.step = 1;
    startGameData.autoLogin = 1;//默认本地有账号，自动登录
    startGameData.updatePercent = 0;
}

StartGame.prototype.stepChange = function (step) {
    trace("step:", step);
    switch (step) {
        case 1:
            this.initData();
            break;
        case 2:
            this.initModuleMgr();
            break;
        case 3:
            this.loadModel();
            break;
        case 4:
            this.loadClientConfig();
            break;
        case 5:
            this.login();
            break;
        case 6:
            this.getInfoFromServer();
            break;
        case 7:
            this.gameReady();
            break;
    }
}

/**
 * 1. 初始化客户端数据
 */
StartGame.prototype.initData = function () {
    new InitClientData(function () {
        var load = new flower.URLLoader();
        load.load("res/configs/table/GameVersion.txt");
        load.addEventListener(flower.Event.COMPLETE, function (event) {
            mainData.version = load.data;
            startGameData.step = 2;
            ModuleMgr.inst().openModule("GameLoginModule", {"ui": "loading", "ip": null});
        });
    });
}

/**
 * 2. 初始化化模块管理
 */
StartGame.prototype.initModuleMgr = function () {
    CD.getInstance().init();
    AutoResizeUtils.init();

    new InitModule();

    startGameData.step = 3;
}

/**
 * 3. 加载模块管理
 */
var modelMgr;
StartGame.prototype.loadModel = function () {
    var loader = new flower.URLLoader();
    loader.load("res/net/NetData.json");
    loader.addEventListener(flower.Event.COMPLETE, function (event) {
        cc.log("@StartGame.prototype.loadConfig@@@@");
        NetCompiler.initData(loader.data);
        //TODO 目前是直接完成加载配置文件的
        new InitModel(function () {
            modelMgr = ModelManager.getInstance();
            startGameData.step = 4;
        });
    });
}

/**
 * 4. 加载客户端配置文件
 */
StartGame.prototype.loadClientConfig = function () {
    var resList = ResMgr.inst().getModuleResources("Language");
    if (resList && resList.length > 0) {
        ResMgr.inst().loadList("公共资源语言", resList,
            function (event, loadName) {
                if (event == LoadEvent.LOAD_COMPLETE) {
                    startGameData.step = 5;
                }
            }, this);
    }
    else {
        startGameData.step = 5;
    }
}

/**
 * 5. 注册、登录流程
 */
StartGame.prototype.login = function () {
    var flag = true;
    try {
        if (in192);
    } catch (e) {
        flag = false;
    }
    if (flag) {
        //登录调试用的游戏中心服务器
        ModelManager.getInstance().call("GameCenter", "login", [function () {
            //初始化网络监听
            new InitCommand(function () {
                ModuleMgr.inst().openModule("GameLoginModule");
            });
        }]);
    } else {
        //初始化网络监听
        new InitCommand(function () {
            ModuleMgr.inst().openModule("GameLoginModule");
        });
    }
}

/**
 * 6. 请求游戏服务器数据
 */
StartGame.prototype.getInfoFromServer = function () {
    //等待网络消息返回
    new EnterGameNet(function () {
        //ModuleMgr.inst().closeModule("NetworkWaitModule");
        startGameData.step = 7;
    });
}

/**
 * 7. 所有流程完成
 */
StartGame.prototype.gameReady = function () {
    //TODO 释放所有登录注册流程的内存
    new Game();
}