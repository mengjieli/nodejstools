var MapRolerPath = cc.Sprite.extend({
    data: null,//RolerPath
    displays: null,
    ctor: function (data) {
        this._super();
        this.data = data;
        this.data.path.addListener("del", this.delPoint, this);
        this.initPath();
    },
    initPath: function () {
        this.displays = [];
        var path = this.data.path;
        for (var i = 0; i < path.length; i++) {
            var pointData = path.getItemAt(i);
            var nextPointData = i < path.length - 1 ? path.getItemAt(i + 1) : this.data.endPoint;
            var dir = this.getDir(pointData, nextPointData);
            var scaleX = 1;
            var sp = new cc.Sprite();
            if(dir == Dir.Right || dir == Dir.Left) {
                var p;
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.width*1/10,0);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.width*3/10,0);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.width*5/10,0);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.width*7/10,0);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.width*9/10,0);
            }
            if(dir == Dir.RightUp || dir == Dir.LeftUp) {
                var p;
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*1/10,MapUtils.obliqueDisHeight*1/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*3/10,MapUtils.obliqueDisHeight*3/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*5/10,MapUtils.obliqueDisHeight*5/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*7/10,MapUtils.obliqueDisHeight*7/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*9/10,MapUtils.obliqueDisHeight*9/10);
            }
            if(dir == Dir.RightDown || dir == Dir.LeftDown) {
                var p;
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*1/10,-MapUtils.obliqueDisHeight*1/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*3/10,-MapUtils.obliqueDisHeight*3/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*5/10,-MapUtils.obliqueDisHeight*5/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*7/10,-MapUtils.obliqueDisHeight*7/10);
                p = new cc.Sprite("res/fight/ui/path/path" + (this.data.action==1?1:2) + ".png");
                sp.addChild(p);
                p.setPosition(MapUtils.obliqueDisWidth*9/10,-MapUtils.obliqueDisHeight*9/10);
            }
            if (dir == Dir.Left || dir == Dir.LeftUp || dir == Dir.LeftDown) {
                //dir = dir.replace("Left", "Right");
                scaleX = -1;
            }
            sp.setScaleX(scaleX);
            var pos = MapUtils.transPointToPosition(pointData.x, pointData.y);
            sp.setPosition(pos.x, pos.y);
            this.addChild(sp);
            this.displays.push({"x": pointData.x, "y": pointData.y, "sprite": sp});
        }
        var animation = new Animation(this.data.action==1?MapRolerPath.pathEnd1:MapRolerPath.pathEnd2);
        var pos = MapUtils.transPointToPosition(this.data.endPoint.x, this.data.endPoint.y);
        animation.setPosition(pos.x, pos.y);
        this.addChild(animation);
        this.displays.push({"x": this.data.endPoint.x, "y": this.data.endPoint.y, "animation": animation});
    },
    delPoint: function (point) {
        for (var i = 0; i < this.displays.length; i++) {
            var display = this.displays[i];
            if (display.x == point.x && display.y == point.y) {
                this.displays.splice(i, 1);
                if (display.sprite) {
                    display.sprite.getParent().removeChild(display.sprite);
                } else if (display.animation) {
                    display.animation.dispose();
                }
                break;
            }
        }
    },
    getDir: function (point, nextPoint) {
        var dir = "";
        if (nextPoint.y == point.y) {
            if (nextPoint.x == point.x + 1) {
                dir = Dir.Right;
            } else if (nextPoint.x == point.x - 1) {
                dir = Dir.Left;
            }
        } else {
            if (point.y % 2 == 0) {
                if (nextPoint.x == point.x) {
                    if (nextPoint.y == point.y + 1) {
                        dir = Dir.RightUp;
                    } else if (nextPoint.y == point.y - 1) {
                        dir = Dir.RightDown
                    }
                } else {
                    if (nextPoint.y == point.y + 1) {
                        dir = Dir.LeftUp;
                    } else if (nextPoint.y == point.y - 1) {
                        dir = Dir.LeftDown
                    }
                }
            } else {
                if (nextPoint.x == point.x) {
                    if (nextPoint.y == point.y + 1) {
                        dir = Dir.LeftUp;
                    } else if (nextPoint.y == point.y - 1) {
                        dir = Dir.LeftDown
                    }
                } else {
                    if (nextPoint.y == point.y + 1) {
                        dir = Dir.RightUp;
                    } else if (nextPoint.y == point.y - 1) {
                        dir = Dir.RightDown
                    }
                }
            }
        }
        return dir;
    },
    dispose: function () {
        this.data.path.removeListener("del", this.delPoint, this);
        while (this.displays.length) {
            var display = this.displays.pop();
            if (display.sprite) {
                display.sprite.getParent().removeChild(display.sprite);
            } else if (display.animation) {
                display.animation.dispose();
            }
        }
        if (this.getParent()) {
            this.getParent().removeChild(this);
        }
    }
});

MapRolerPath.pathEnd1 = {
    plist: "res/fight/effect/path/pathEnd.plist",
    name: "PathEnd_00",
    format: "png",
    start: 0,
    end: 07,
    frameRate: 9,
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1
};
MapRolerPath.pathEnd2 = {
    plist: "res/fight/effect/path/pathEnd.plist",
    name: "PathEnd_00",
    format: "png",
    start: 20,
    end: 27,
    frameRate: 9,
    x: 0,
    y: 0,
    scaleX: 1,
    scaleY: 1
};