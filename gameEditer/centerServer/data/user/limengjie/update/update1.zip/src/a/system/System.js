var global = this;
var System = (function () {
    function System() {
    }
    System.start = function (root, engine) {
        var scene = cc.Scene.extend({
            ctor: function () {
                this._super();
                this.scheduleUpdate();
                //注册鼠标事件
                cc.eventManager.addListener({
                    event: cc.EventListener.TOUCH_ONE_BY_ONE,
                    swallowTouches: true,
                    onTouchBegan: this.onTouchesBegan.bind(this),
                    onTouchMoved: this.onTouchesMoved.bind(this),
                    onTouchEnded: this.onTouchesEnded.bind(this)
                }, this);
            },
            update: function (dt) {
                trace("dt", dt);
            },
            onTouchesBegan: function (touch) {
                engine.onMouseDown(touch.getID(), Math.floor(touch.getLocation().x), System.height - Math.floor(touch.getLocation().y));
                return true;
            },
            onTouchesMoved: function (touch) {
                engine.onMouseMove(touch.getID(), Math.floor(touch.getLocation().x), System.height - Math.floor(touch.getLocation().y));
                return true;
            },
            onTouchesEnded: function (touch) {
                engine.onMouseUp(touch.getID(), Math.floor(touch.getLocation().x), System.height - Math.floor(touch.getLocation().y));
                return true;
            },
        });
        System.stage = new scene();
        System.stage.update = System._run;
        cc.director.runScene(System.stage);
        System.width = cc.Director.getInstance().getWinSize().width;
        System.height = cc.Director.getInstance().getWinSize().height;
        root.setPositionY(System.height);
        System.stage.addChild(root);
        System.$mesureTxt.retain();
    };
    System.getTime = function () {
        return (new Date()).getTime();
    };
    System.disposeTexture = function (nativeTexture, url) {
        cc.TextureCache.getInstance().removeTextureForKey(url);
    };
    System.log = function () {
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            args[_i - 0] = arguments[_i];
        }
        var str = "";
        for (var i = 0; i < args.length; i++) {
            str += args[i] + (i < args.length - 1 ? "  " : "");
        }
        console.log(str);
    };
    System.runTimeLine = function (back) {
        System._runBack = back;
    };
    System._run = function () {
        var now = (new Date()).getTime();
        System._runBack(now - System.lastTime);
        System.lastTime = now;
    };
    System.getNativeShow = function (className) {
        if (className == "DisplayObjectContainer") {
            var node = new cc.Node();
            node.setAnchorPoint(0, 0);
            return node;
        }
        if (className == "Bitmap") {
            var bm = new cc.Sprite();
            bm.setAnchorPoint(0, 0);
            return bm;
        }
        if (className == "TextField") {
            var txt = new cc.LabelTTF("", "Times Roman", 12);
            txt.setAnchorPoint(0, 1);
            return txt;
        }
        return null;
    };
    System.IDE = "cocos2dx";
    System.local = true;
    System.receverY = true;
    System.global = global;
    System.JSON_parser = JSON.parse;
    System.JSON_stringify = JSON.stringify;
    System.lastTime = (new Date()).getTime();
    System.URLLoader = {
        "loadText": {
            "func": function (url, back, errorBack) {
                cc.loader.loadTxt(url, function (error, data) {
                    if (error) {
                        errorBack();
                    }
                    else {
                        back(data);
                    }
                });
            }
        },
        "loadTexture": {
            "func": function (url, back, errorBack) {
                cc.TextureCache.getInstance().addImage(url);
                var texture = cc.TextureCache.getInstance().getTextureForKey(url);
                back(texture, texture.getContentSize().width, texture.getContentSize().height);
            }
        }
    };
    System.DisplayObject = {
        "x": { "func": "setPositionX" },
        "y": { "func": "setPositionY" },
        "scaleX": { "func": "setScaleX" },
        "scaleY": { "func": "setScaleY" },
        "rotation": { "func": "setRotation", "scale": 1 },
        "alpha": { "func": "setOpacity", "scale": 255 },
        "visible": { "func": "setVisible" }
    };
    System.DisplayObjectContainer = {
        "setChildIndex": { "func": "setZOrder" }
    };
    System.Bitmap = {
        "texture": { "func": "initWithTexture" }
    };
    System.$mesureTxt = new cc.LabelTTF("", "Times Roman", 12);
    System.TextField = {
        "color": {
            "exe": function (txt, color) {
                txt.setFontFillColor({ r: color >> 16, g: color >> 8 & 0xFF, b: color & 0xFF }, true);
            }
        },
        "size": { "func": "setFontSize" },
        "resetText": function (txt, text, width, height, size, wordWrap, multiline) {
            System.$mesureTxt.setFontSize(size);
            txt.text = "";
            var txtText = "";
            var start = 0;
            for (var i = 0; i < text.length; i++) {
                //取一行文字进行处理
                if (text.charAt(i) == "\n" || text.charAt(i) == "\r" || i == text.length - 1) {
                    var str = text.slice(start, i);
                    System.$mesureTxt.setString(str);
                    var lineWidth = System.$mesureTxt.getContentSize().width;
                    var findEnd = i;
                    //如果这一行的文字宽大于设定宽
                    while (lineWidth > width) {
                        findEnd--;
                        System.$mesureTxt.setString(text.slice(start, findEnd + (i == text.length - 1 ? 1 : 0)));
                        lineWidth = System.$mesureTxt.getContentSize().width;
                    }
                    if (wordWrap) {
                        i = findEnd;
                    }
                    txt.setString(txtText + text.slice(start, findEnd + (i == text.length - 1 ? 1 : 0)));
                    //如果文字的高度已经大于设定的高，回退一次
                    if (txt.getContentSize().height > height) {
                        txt.setString(txtText);
                        break;
                    }
                    else {
                        txtText += text.slice(start, findEnd + (i == text.length - 1 ? 1 : 0));
                    }
                    start = i;
                    if (multiline == false) {
                        break;
                    }
                }
            }
        },
        "mesure": function (txt) {
            return txt.getContentSize();
        }
    };
    return System;
})();
//# sourceMappingURL=System.js.map