/**
 * Created by Administrator on 2016/1/9 0009.
 */

var CastleInfoModule = ModuleBase.extend({
    _root:null,

    ctor: function () {
        this._super();
    },

    initUI:function()
    {
        var root = ccs.load("res/images/ui/castleInfo/CastleInfo.json","res/images/ui/").node;
        this.addChild(root);
        this._root = root;

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var close = this._root.getChildByName("Panel_1").getChildByName("guanbi");
        close.addTouchEventListener( this.closeCall, this );


    },

    destroy: function () {

    },

    show: function (info) {
        var data = info.data;
        this.initUI();
        cc.log("``````````````data->"+data.userAccount);
        var pnl = this._root.getChildByName("Panel_1");
        var pdata = mainData.playerDataList.getItem("account", data.userAccount);
        var castlename = pnl.getChildByName("Text_castleName");
        castlename.setString(data.name);

        var headImage = pnl.getChildByName("Image_48");
        var headname = pdata.headid;
        if (headname == undefined || headname == "")
            headname = ResMgr.inst().getCSV("head", 1).head_id;//默认配置第一个  var headArray = ResMgr.inst().getCSV("head");
        var headPath = ResMgr.inst().getIcoPath(headname)
        trace("头像地址:",pdata.nick,headname,headPath);
        headImage.loadTexture(headPath);

        var playername = pnl.getChildByName("Text_playerName");
        playername.setString(pdata.nick);

        var fanrongdu = pnl.getChildByName("Text_fanrongdu");
        fanrongdu.setString(data.attributes.getItem("type",2500001).value);
    },

    closeCall:function( node,type )
    {
        if( type == ccui.Widget.TOUCH_ENDED )
        {
            ModuleMgr.inst().closeModule("CastleInfoModule");
            SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        }
    },

});