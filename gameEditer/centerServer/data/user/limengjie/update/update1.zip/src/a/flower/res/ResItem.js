var flower;
(function (flower) {
    var ResItem = (function () {
        function ResItem() {
        }
        Object.defineProperty(ResItem.prototype, "loadURL", {
            get: function () {
                if (this.local) {
                    return this.localURL + this.url;
                }
                return this.serverURL + this.url;
            },
            enumerable: true,
            configurable: true
        });
        return ResItem;
    })();
    flower.ResItem = ResItem;
})(flower || (flower = {}));
//# sourceMappingURL=ResItem.js.map