/**
 * Created by Administrator on 2015/12/4.
 */

var FavoritesDataCommand = function () {
    var init = function () {
        NetMgr.inst().addEventListener(298, loadCall, this);
    }

    var loadCall = function (cmd, msg) {
        msg.resetCMDData();
        var uid = msg.readString();
        var localityId = mainData.playerData.account;
        var nick = msg.readString();
        var len = msg.readUint();
        for (var i = 0; i < len; i++) {
            var key = msg.readUint();
            var str = msg.readString();
            if (key == 199) {
                if (uid == mainData.playerData.account) {
                    var collectList = [];
                    var collectData = JSON.parse(str);
                    //简单的数据和表现，直接全部更新即可，先全部删除再添加
                    mainData.favoritesData.removeAll();
                    for (var j in collectData.list) {
                        var json = collectData.list[j];
                        for (var k in json) {
                            var collect = json[k];
                            collect.x = collect.pos.x;
                            collect.y = collect.pos.y;
                            var pos = MapUtils.transPointToPosition(collect.x, collect.y);
                            collect.showX = pos.x;
                            collect.showY = pos.y;
                            var favorityData = DataManager.getInstance().getNewData("FavorityData");
                            favorityData.receive(collect);
                            mainData.favoritesData.push(favorityData);
                        }
                    }
                }
            }
        }
    }
    init();
}