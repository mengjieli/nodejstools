var BigMapLayerManager = cc.Sprite.extend({
    data: null, //BigMapData
    backgroundLayer: null, //背景层
    shaderLayer: null,//阴影层
    treeLayer: null, //对象层
    gridLayer: null,//格子层
    hillLayer: null,//山
    changeLayer: null,//交换层
    frontLayer: null, //前景层
    arrow: null,//城堡指向游标
    arrowLabel: null,//游标上的文字
    moveX: 0,
    moveY: 0,
    ctor: function () {
        this._super();

        this.frontLayer = new FrontLayer();
        this.data = ModuleMgr.inst().getData("BigMapModule");
        this.addChild(this.backgroundLayer = new BackgroundLayer(0, 0, 0, 0, 0));
        this.addChild(this.treeLayer = new BackgroundLayer(1, -MapUtils.singleWidth / 4, -MapUtils.singleHeight / 4, MapUtils.singleWidth / 2, MapUtils.singleHeight / 2));
        this.addChild(this.shaderLayer = new ShaderLayer());
        this.addChild(this.hillLayer = new HillLayer());
        this.addChild(this.gridLayer = new GridLayer());
        this.addChild(this.frontLayer);
        this.addChild(this.changeLayer = new ChangeLayer(this.shaderLayer, this.frontLayer));
        this.addChild(this.topLayer = new TopLayer());
        this.addChild(this.mapUILayer = new MapUILayer());

        this.arrow = new ccui.ImageView("res/fight/ui/arrow.png");
        this.arrow.setTouchEnabled(true);
        ModuleMgr.inst().addNodeTOLayer(this.arrow, ModuleLayer.LAYER_TYPE_UI);
        this.arrow.setPosition(200, 200);
        this.arrow.setAnchorPoint(0.5, 0.5);
        var txt = new BorderText();
        this.arrow.addChild(txt);
        this.arrowLabel = txt;
        txt.setString(ResMgr.inst().getString("returnCastle"));
        txt.setColor({r: 196, g: 165, b: 101, a: 255});
        txt.setFontSize(14);
        txt.setPosition(41, 18);

        this.arrow.addTouchEventListener(function () {
            var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
            var pos = pos = MapUtils.transPointToPosition(castle.coordX, castle.coordY);
            modelMgr.call("BigMap", "cameraLookAt", [pos.x, pos.y]);
        });
    },
    addDisplay: function () {
    },
    /**
     * 显示区域背景
     * @param rect
     */
    updateShow: function (camera) {
        this.moveX = camera.x;
        this.moveY = camera.y;
        this.backgroundLayer.updateShow(camera);
        this.shaderLayer.updateShow(camera);
        this.treeLayer.updateShow(camera);
        if (mainData.uiData.showMapGrid) {
            this.gridLayer.updateShow(camera);
        }
        this.hillLayer.updateShow(camera);
        this.frontLayer.updateShow(camera);
        this.changeLayer.updateShow(camera);
        this.topLayer.updateShow(camera);

        if (mainData.uiData.currentCastleId) {
            var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
            var pos = MapUtils.transPointToPosition(castle.coordX, castle.coordY);
            var x = pos.x - camera.x;
            var y = pos.y - camera.y;
            var sx = 50;
            var sy = 112;
            var ex = mainData.systemData.screenWidth - 200;
            var ey = mainData.systemData.screenHeight - 110;
            var cx = (sx + ex) / 2;
            var cy = (sy + ey) / 2;
            var dis = Math.sqrt((cx - x) * (cx - x) + (cy - y) * (cy - y));
            //if(dis < 300) {
            if (x <= 0 || x >= mainData.systemData.screenWidth || y <= 0 || y >= mainData.systemData.screenHeight) {
                this.arrow.setVisible(true);
            } else {
                this.arrow.setVisible(false);
            }
            var rot = Math.atan2(cy - y, cx - x);
            rot = -rot * 180 / Math.PI + 180;
            rot = rot % 360;
            this.arrow.setRotation(rot);
            if (rot < 90 || rot > 270) {
                this.arrowLabel.setScale(1);
            } else {
                this.arrowLabel.setScale(-1);
            }
            //x = x + Math.cos(rot)*dis*2/3;
            //y = y + Math.sin(rot)*dis*2/3;
            if (x < sx + 38) {
                x = sx + 38;
            }
            if (x > ex + 38) {
                x = ex + 38;
            }
            if (y < sy) {
                y = sy;
            }
            if (y > ey) {
                y = ey;
            }
            this.arrow.setPosition(x, y);
        }
    },
    onTouchBegan: function (x, y) {
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
    },
    dragMap: function () {
        //this.changeLayer.dragMap();
        mainData.uiData.map.shineGrid = "";
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
        mainData.uiData.clickMenuVisible = false;
    },
    onTouchEnded: function (x, y) {
        var point = MapUtils.transPositionToPoint(x + this.moveX, y + this.moveY);
        ModelManager.getInstance().call("BigMap","execute",["click",{"x":point.x,"y":point.y}]);
        //this.changeLayer.onTouch(x + this.moveX, y + this.moveY);
        //this.gridLayer.onTouch(x + this.moveX, y + this.moveY);
        //this.backgroundLayer.onTouch(x + this.moveX, y + this.moveY);
    },
    longTouch:function(x,y) {
        var point = MapUtils.transPositionToPoint(x + this.moveX, y + this.moveY);
        ModelManager.getInstance().call("BigMap","execute",["click",{"x":point.x,"y":point.y,"longTouch":true}]);
    },
    dispose: function () {
        this.arrow.getParent().removeChild(this.arrow);
        this.changeLayer.dispose();
        this.frontLayer.dispose();
        this.mapUILayer.dispose();
        this.topLayer.dispose();
        this.shaderLayer.dispose();
        this.getParent().removeChild(this);
    }
});