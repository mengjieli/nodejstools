var flower;
(function (flower) {
    var Binding = (function () {
        function Binding(thisObj, checks, property, content) {
            this.singleValue = false;
            this.list = [];
            this.exprs = [];
            var lastEnd = 0;
            for (var i = 0; i < content.length; i++) {
                if (content.charAt(i) == "{") {
                    for (var j = i + 1; j < content.length; j++) {
                        if (content.charAt(j) == "{") {
                            break;
                        }
                        if (content.charAt(j) == "}") {
                            if (i == 0 && j == content.length - 1) {
                                this.singleValue = true;
                            }
                            if (lastEnd < i) {
                                this.exprs.push(content.slice(lastEnd, i));
                                lastEnd = j + 1;
                            }
                            var expr = flower.Compiler.parserExpr(content.slice(i + 1, j), property, checks, this.list);
                            this.exprs.push(expr);
                            i = j;
                            break;
                        }
                    }
                }
            }
            if (lastEnd < content.length) {
                this.exprs.push(content.slice(lastEnd, content.length));
            }
            this.thisObj = thisObj;
            this.property = property;
            for (i = 0; i < this.list.length; i++) {
                for (j = 0; j < this.list.length; j++) {
                    if (i != j && this.list[i] == this.list[j]) {
                        this.list.splice(j, 1);
                        i = -1;
                        break;
                    }
                }
            }
            for (i = 0; i < this.list.length; i++) {
                this.list[i].addListener(this.update, this);
            }
            this.update();
        }
        Binding.prototype.update = function (value, old) {
            if (value === void 0) { value = null; }
            if (old === void 0) { old = null; }
            if (this.singleValue) {
                try {
                    this.thisObj[this.property] = this.exprs[0].getValue();
                }
                catch (e) {
                    this.thisObj[this.property] = null;
                }
            }
            else {
                var str = "";
                for (var i = 0; i < this.exprs.length; i++) {
                    var expr = this.exprs[i];
                    if (expr instanceof flower.Expr) {
                        try {
                            str += expr.getValue();
                        }
                        catch (e) {
                            str += "null";
                        }
                    }
                    else {
                        str += expr;
                    }
                }
                this.thisObj[this.property] = str;
            }
        };
        Binding.prototype.dispose = function () {
            for (var i = 0; i < this.list.length; i++) {
                this.list[i].removeListener(this.update, this);
            }
        };
        return Binding;
    })();
    flower.Binding = Binding;
})(flower || (flower = {}));
//# sourceMappingURL=Binding.js.map