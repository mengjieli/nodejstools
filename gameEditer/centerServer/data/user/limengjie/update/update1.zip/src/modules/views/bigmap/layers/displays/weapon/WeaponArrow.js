var WeaponArrow = cc.Sprite.extend({
    ctor: function (data) {
        this._super();
        this.data = data;
        var position = MapUtils.transPointToPosition(data.coordX, data.coordY);
        this.setPosition(position.x, position.y);
        var endPosition = MapUtils.transPointToPosition(data.aimX, data.aimY);
        this.endX = endPosition.x - position.x;
        this.endY = endPosition.y - position.y;
        this.show = new cc.Sprite("res/fight/ui/weapon/" + data.name + ".png");
        this.show.setPositionX(this.data.offX);
        this.show.setPositionY(this.data.offY);
        this.addChild(this.show);
        this.scheduleUpdate();
        var dis = Math.sqrt(this.endX*this.endX + this.endY*this.endY);
        var speed = 500;
        var time = dis/speed;
        if(time < 0.5) {
            time = 0.5;
        } else if(time > 3) {
            time = 3;
        }
        this.g = -600 - time*200;
        this.vx = this.endX/time;
        this.vy = this.endY/time;
        this.vz = -this.g*time/2;
        this.time = time;
        //trace("开始时间",this.time,this.endX,this.endY,this.vx,this.vy,this.vz);
    },
    update: function (dt) {
        this.vz += this.g*dt;
        var x = this.vx*dt;
        var y = (this.vy + this.vz)*dt;
        this.show.setPositionX(this.show.getPositionX() + x);
        this.show.setPositionY(this.show.getPositionY() + y);
        this.time -= dt;
        var rot = Math.atan2(this.vx,this.vy+this.vz);
        this.show.setRotation(rot*180/Math.PI - 90);
        //trace("时间",this.time,this.show.getPositionX(),this.show.getPositionY());
        if(this.time <= 0) {
            this.dispose();
        }
    },
    dispose: function () {
        this.unscheduleUpdate();
        this.getParent().removeChild(this);
    }
});