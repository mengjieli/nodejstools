/**
 * Created by Administrator on 2015/10/24.
 */

//详情

var ParticularsModule = ModuleBase.extend({


    _back:null,
    _ui:null,

    _id:null,
    _blockId:0,

    _button:null,
    ctor:function()
    {
        this._super();
    },

    initUI:function()
    {

        this._back = ccs.load("res/images/ui/publicBackdrop/Layer.json","res/images/ui/").node;
        this.addChild( this._back );

        var PanelBg = this._back.getChildByName("Panel");
        sizeAutoLayout(PanelBg);

        var Panel_1 = PanelBg.getChildByName("Panel_1");
        sizeAutoLayout(Panel_1);

        var Image_bg = PanelBg.getChildByName("Image_4");
        sizeAutoLayout(Image_bg);

        var Image_top = PanelBg.getChildByName("Image_5");
        posAutoLayout(Image_top);

        var left = PanelBg.getChildByName("left");
        sizeAutoLayout(left);

        var Image_1_0_0 = left.getChildByName("Image_1_0_0");
        sizeAutoLayout(Image_1_0_0);
        posAutoLayout(Image_1_0_0,0.5);

        var leftbg = left.getChildByName("Image_1");
        sizeAutoLayout(leftbg);

        var name = left.getChildByName("name");
        posAutoLayout(name);

        var Image_1_0 = left.getChildByName("Image_1_0");
        posAutoLayout(Image_1_0,0.5);

        var ico = left.getChildByName("ico");
        posAutoLayout(ico,0.5);

        var Image_1_1 = left.getChildByName("Image_1_1");
        posAutoLayout(Image_1_1);

        var btn = this._back.getChildByName("Panel").getChildByName("left").getChildByName("Button");
        btn.addTouchEventListener( this.particularsCall, this );
        this._button = btn;

        var size = cc.director.getVisibleSize();
        this._back.setContentSize(size);
        ccui.helper.doLayout(this._back);

        EventMgr.inst().addEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeLevelCall, this );
    },

    destroy: function ()
    {
        EventMgr.inst().removeEventListener( CastleEvent.UPGRADE_COMPLETE, this.upgradeLevelCall, this );
    },

    show:function( data )
    {
        if( data == null ) return;

        this._id = data.id;
        this._blockId = data.blockId;
        this.showUI();
    },

    close:function()
    {

    },

    showUI: function ()
    {
        this.updateLeft();
        this.updateRight();
        this.setRemove( this._id );
        this.upgradeLevelCall();
    },

    updateLeft:function()
    {
        var img = this._back.getChildByName("Panel").getChildByName("left").getChildByName("ico");
        img.ignoreContentAdaptWithSize( true );
        //cc.log( this._id );
        img.loadTexture( ResMgr.inst()._icoPath + this._id + "4.png" );

        var name = this._back.getChildByName("Panel").getChildByName("left").getChildByName("name");
        name.ignoreContentAdaptWithSize( true );
        name.setString(ResMgr.inst().getString(this._id + "0"));
        var msg = this._back.getChildByName("Panel").getChildByName("left").getChildByName("msg");
        var str = this._id + "1";
        msg.setString(ResMgr.inst().getString(str));

        var buttonText = this._back.getChildByName("Panel").getChildByName("left").getChildByName("Button").getChildByName("Text");
        buttonText.ignoreContentAdaptWithSize( true );
        buttonText.setString( ResMgr.inst().getString("xiangqing_0") );
        buttonText = BorderText.replace(buttonText);
    },

    _son:null,
    updateRight:function()
    {
        if( this._son )
        {
            this._son.removeFromParent();
        }

        var ui = null;
        if( this._id == 1901001 )//主城堡
        {
            ui = new CastleParticularsUI( this._id ,this._blockId );
            this.addChild( ui );
        }
        if( this._id == 1906001 )
        {
            ui = new WarehouseUI( this._id ,this._blockId );
            this.addChild( ui );
        }
        else if( this._id == 1913001 || this._id == 1913002 )
        {
            ui = new TowerParticularsUI(this._id ,this._blockId);
            this.addChild(ui);
        }
		else if(this._id == 1903001) //学院
		{
            ui = new CollegeUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1907001) //城墙
        {
            ui = new TheWallUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1902001 || this._id == 1902002 || this._id == 1902003 || this._id == 1902004) //马厩 兵营 弓手 器械
        {
            ui = new StableUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1904001) //民房
        {
            ui = new HouseUI( this._id,this._blockId );
            this.addChild( ui );
        }
        else if(this._id == 1909001) //校场
        {
            ui = new DrillGroundUI( this._id,this._blockId );
            this.addChild( ui );
        }

        this._son = ui;
    },

    setRemove: function ( id )
    {
        this._button.setVisible( false );

        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        var info = null;
        if( data )
        {
            list = data.getNetBlock( );
        }

        if( list == null || list[this._blockId] == null )
        {
            return;
        }

        info = list[this._blockId];

        var buildingConfig = modelMgr.call("Table", "getTableItemByValue", ["castle_buildingxy",id ]);//ResMgr.inst().getJSON( "castle_buildingxy", id ,true );
        var config = modelMgr.call("Table", "getTableItemByValue", [this.getConfigPath( buildingConfig.type ),info._building_level ]);

        if( config == null ) return;

        this._button.setVisible( config.demolition == 0 ? false : true );
    },

    getConfigPath:function( type )
    {

        var str = "City_";
        if( type == 6 )//仓库
        {
            str += "Storage";
        }
        else if( type = 8 ) //箭塔
        {
            str += "Tower";
        }
        else if( type == 3 )//学院
        {
            str += "College";
        }
        else if( type == 7 )//城墙
        {
            str += "Wall";
        }
        else if( type == 9 )//校场
        {
            str += "Flied";
        }
        else if( type == 2)
        {
            switch (this._id){
                case 1902001:
                    str += "Camp_horse";
                    break;
                case 1902002:
                    str += "Camp_Barracks";
                    break;
                case 1902003:
                    str += "Camp_target";
                    break;
                case 1902004:
                    str += "Camp_instrument";
                    break;
                default :
                    str += "Camp";
                    break;
            }
        }

        return str;
    },

    particularsCall:function( node, type )
    {
        if( type != ccui.Widget.TOUCH_ENDED )return;
        ModuleMgr.inst().closeModule("ParticularsModule");
        EventMgr.inst().dispatchEvent( CastleEvent.REMOVE_SUCCESS, this._blockId );
        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
    },

    upgradeLevelCall:function( node, type )
    {
        var level = this._back.getChildByName("Panel").getChildByName("left").getChildByName("level");
        level.ignoreContentAdaptWithSize(true);

        var level_ = 0;
        var data = ModuleMgr.inst().getData("CastleModule");
        var list = null;
        var info = null;
        if( data )
        {
            list = data.getNetBlock( );
        }
        // ( this._blockId );
        if( list != null && list[this._blockId] != null )
        {
            info = list[this._blockId];
            if( info )
            {
                level_ = info._building_level;
            }
        }
        level.setString(ResMgr.inst().getString("xiangqing_1") + " " + level_);
    }
});