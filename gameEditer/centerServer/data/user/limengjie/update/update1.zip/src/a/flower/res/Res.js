var flower;
(function (flower) {
    var Res = (function () {
        function Res() {
        }
        return Res;
    })();
    flower.Res = Res;
})(flower || (flower = {}));
//# sourceMappingURL=Res.js.map