function GameCenterConfig() {

}

GameCenterConfig.getConfig = function(key) {
    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
    var fullHeadPath = storagePath + "gameCenter";
    var fileExist = jsb.fileUtils.isFileExist(fullHeadPath);
    if(!fileExist) return null;
    var content = jsb.fileUtils.getValueMapFromFile(fullHeadPath);
    var json = JSON.parse(content.content);
    return json[key];
}

GameCenterConfig.saveConfig = function(key,value) {
    var storagePath = jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./";
    var fullHeadPath = storagePath + "gameCenter";
    var fileExist = jsb.fileUtils.isFileExist(fullHeadPath);
    var json = {};
    if(fileExist) {
        var content = jsb.fileUtils.getValueMapFromFile(fullHeadPath);
        var str = content.content;
        json = JSON.parse(str);
    }
    json[key] = value;
    var saveData = {
        "content":JSON.stringify(json)
    }
    var file = jsb.fileUtils.writeToFile(saveData, fullHeadPath);
}

//自动连接的用户名
GameCenterConfig.LINK_CLIENT = "linkClient";