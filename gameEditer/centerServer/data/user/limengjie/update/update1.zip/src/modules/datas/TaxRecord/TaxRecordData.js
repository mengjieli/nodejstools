/**
 * Created by Administrator on 2016/2/3 0003.
 */

var TaxRecord = cc.Class.extend({
    autoInc:0,              // 序列号，单调递减
    timestamp:0,
    fromAccountUuid:"",
    reason:0,               // 673011 等级税收  673012 个人所得税  673013 元老等级税收
    oldAmount:0,            // 税收之前黄金
    newAmount:0,            // 税收之后黄金
});

var TaxRecordData = DataBase.extend({
    _preIdx:0,
    _beginIndex:0,
    _records:null,
    _totalCount:0,

    ctor: function () {
        this._super();
    },

    init: function () {
        this._records = [];

        NetMgr.inst().addEventListener(1199, this.taxRecordHandler, this);//请求成功返回


    },

    destroy: function () {
        this._preIdx = 0;
        this._beginIndex = 0;
        this._totalCount = 0;
        this._records = [];
    },

    requestTaxRecord: function () {
        var msg = new SocketBytes();
        msg.writeUint( 1100 );
        msg.writeUint( this._beginIndex );
        msg.writeUint( TaxRecordData.RecordPerPage );
        cc.log("sending requst $$$$$$$$$ begin idx->"+this._beginIndex+" count --->"+TaxRecordData.RecordPerPage);
        NetMgr.inst().send( msg );
    },

    taxRecordHandler: function (cmd,data) {
        data.resetCMDData();
        //uint        totalCount             // 总记录数
        //uint        begin
        //array       records
        //uint        autoInc              // 序列号，单调递减
        //uint        timestamp
        //string      fromAccountUuid
        //uint        reason               // 673011 等级税收  673012 个人所得税  673013 元老等级税收
        //uint        oldAmount            // 税收之前黄金
        //uint        newAmount            // 税收之后黄金
        this._totalCount = data.readUint();
        var begin = data.readUint();
        var len = data.readUint();
        cc.log("$$$$$$$$$ on server return: total->"+this._totalCount+" len--->"+len);

        if(len > 0) {
            for (var i = 0; i < len; i++) {
                var record = new TaxRecord();
                record.autoInc = data.readUint();
                record.timestamp = data.readUint();
                record.fromAccountUuid = data.readString();
                record.reason = data.readUint();
                record.oldAmount = data.readUint();
                record.newAmount = data.readUint();
                this._records.push(record);
            }
            this._preIdx = this._beginIndex;
            this._beginIndex += len;

            EventMgr.inst().dispatchEvent("Receive_Tax_Record", this._preIdx, len);
        }
        data.resetCMDData();
    },

    getMaxPageIdx: function () {
        return Math.floor(this._totalCount / TaxRecordData.RecordPerPage);
    },

    getRequestedPageIdx: function () {
        return Math.floor(this._beginIndex / TaxRecordData.RecordPerPage);
    },

});

TaxRecordData.RecordPerPage = 8;