﻿/**
 * 2015-10-16 by shenwei
 * 游戏配置
 */
var GameConfig = cc.Class.extend({});

GameConfig.reset = function () {


//2 正式服务器
//0 内网
    try {
        if (in192) {
            net = 0
        }
    } catch (e) {
        try {
            if (inqa) {
                net = 1;
            }
        } catch (e) {
            net = 2;
        }
    }
    cc.log("@@@@GameConfig", net);
    if (net == 1) { //qa
        GameConfig.serverIP = "106.75.143.19";
        GameConfig.serverIP_2 = "106.75.143.19";
        GameConfig.testHttpPort = ":13215/empery/account/promotion/";
        GameConfig.PLATFORM_DEFAULT_ID = 8500;
    } else if (net == 2) { //广州
        GameConfig.serverIP = "106.75.141.67";
        GameConfig.serverIP_2 = "106.75.141.67";
        GameConfig.testHttpPort = ":13215/empery/account/promotion/";//":13212/empery/data/";
        GameConfig.PLATFORM_DEFAULT_ID = 8500;
    } else if (net == 0) { //内网
        GameConfig.serverIP = "192.168.1.204";//203 耿坤鹏  201 刘昊  204 内网
        GameConfig.serverIP_2 = "192.168.1.204";//203 耿坤鹏
        GameConfig.testHttpPort = ":13215/empery/account/promotion/";
        GameConfig.PLATFORM_DEFAULT_ID = 8500;//7800
    }

//登陆地址
    GameConfig.serverAddress = "ws://" + GameConfig.serverIP_2 + ":13211/empery";

//配置表地址
    GameConfig.tableAddress = "http://" + GameConfig.serverIP + ":13212/empery/data/";

//GameConfig.tableAddress_DEBUG = "http://" + GameConfig.serverIP + ":8388/texas/resources/";

//登陆-注册地址
//账号是否存在 : check
//注册 : create
//登陆 : login
//刷新令牌 : renewal
//忘记密码 : regain
//GameConfig.PLATFORM_DEFAULT_ID = 7800;
    GameConfig.PLATFORM_AUTHENTICATE_ADDR = "http://" + GameConfig.serverIP_2 + GameConfig.testHttpPort;
//"http://" + GameConfig.serverIP_2 + ":13206" + "/empery_gate_westwalk/account/"

//GameConfig.UPLOAD_CUSTOM_PORTRAIT = "http://" + GameConfig.serverIP_2 + ":13206" + "/empery/avatar/put";
//GameConfig.DOWNLOAD_CUSTOM_PORTRAIT = "http://" + GameConfig.serverIP_2 + ":13206" + "/empery/avatar/get";

//语言版本
    GameConfig.Language = "JP";//中国CN 英文EN  日文JP

//某种情况下需要停止所有声音
    GameConfig.StopSound = false;

//是否播放动画
    GameConfig.isAnimation = true;

//人物模型路径
    GameConfig.AvatarAddress = "res/avatar/";
}

GameConfig.reset();