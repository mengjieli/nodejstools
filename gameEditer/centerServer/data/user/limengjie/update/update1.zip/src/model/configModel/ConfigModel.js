var ConfigModel = (function (_super) {
    __extends(ConfigModel, _super);

    function ConfigModel() {
        _super.call(this, "Config");

    }

    var d = __define, c = ConfigModel;
    p = c.prototype;

    p.load = function () {
        var list = [
            {
                "url": "res/configs/fight/rolerAction.csv",
                "function": "doRolerAction"
            },
            {
                "url":"res/configs/fight/clickMenu.csv",
                "function": "resolveClickMenuConfig"
            }
        ];

        var index = 0;
        var loadNext = function (event) {
            if (index) {
                GameSDK.DataManager.getInstance().loadingData.model.progress = index;
                GameSDK.DataManager.getInstance().loadingData.model.max = list.length;
                this[list[index - 1]["function"]](event.currentTarget.data,list[index - 1].url);
            }
            if (index == list.length) {
                this.dispatchEvent(new flower.Event(flower.Event.COMPLETE));
                return;
            }
            var loader = new flower.URLLoader();
            loader.addEventListener(flower.Event.COMPLETE, loadNext, this);
            loader.load(list[index].url);
            index++;
        };
        loadNext.call(this);
    }

    p.doRolerAction = function (content) {
        var cfg = {};
        var list = content.split("\n");
        for (var i = 1; i < list.length; i++) {
            var items = list[i].split(",");
            var end = items[items.length-1];
            while(end.charAt(end.length-1) == "\r" || end.charAt(end.length-1) == "\n") {
                end = end.slice(0,end.length-1);
            }
            items[items.length-1] = end;
            var id = jc.TypeHelp.parseNumber(items[0]);
            if (!id) {
                continue;
            }
            var roler = cfg[id] = cfg[id] || {};
            roler[items[1]] = {
                "plist":items[2],
                "name":items[3],
                "start":jc.TypeHelp.parseNumber(items[4]),
                "end":jc.TypeHelp.parseNumber(items[5]),
                "frameRate":jc.TypeHelp.parseNumber(items[6]),
                "x":jc.TypeHelp.parseNumber(items[7]),
                "y":jc.TypeHelp.parseNumber(items[8]),
            };
        }
        for(var key in cfg) {
            addRolerAction(jc.TypeHelp.parseNumber(key),cfg[key]);
        }
    }

    p.resolveClickMenuConfig = function(content) {
        var configs = [];
        var list = content.split("\n");
        for (var i = 1; i < list.length; i++) {
            var items = list[i].split(",");
            var end = items[items.length-1];
            while(end.charAt(end.length-1) == "\r" || end.charAt(end.length-1) == "\n") {
                end = end.slice(0,end.length-1);
            }
            items[items.length-1] = end;
            if (items[0] == "") {
                continue;
            }
            configs.push({
                "mode":items[0].split("/"),
                "selectAim":items[1].split("/"),
                "clickAim":items[2].split("/"),
                "shineColor":items[3],
                "showImage": items[4],
                "noSelectClick":items[5],
                "selectClick":items[6],
                "enterSelectionMode":items[7],
                "clickMenu1":items[8].split(":"),
                "clickMenu2":items[9].split(":"),
                "clickMenu3":items[10].split(":"),
                "clickMenu4":items[11].split(":"),
                "clickMenu5":items[12].split(":")
            });
        }
        BigMapClickCommand.menuConfig = configs;
    }

    return ConfigModel;
})(ModelBase);