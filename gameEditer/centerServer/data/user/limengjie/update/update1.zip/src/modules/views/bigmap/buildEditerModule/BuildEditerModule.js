var BuildEditerModule = ModuleBase.extend({
    grids1: null,
    grids2: null,
    coords1: null,
    coords2: null,
    point:null,
    ctor: function () {
        this._super();

        this.coords1 = [
            [-1, 0],
            [0, 0],
            [1, 0],
            [2, 0],
            [-1, 1],
            [0, 1],
            [1, 1],
            [-1, -1],
            [0, -1],
            [1, -1]
        ];
        this.coords2 = [
            [-1, 0],
            [0, 0],
            [1, 0],
            [2, 0],
            [0, 1],
            [1, 1],
            [2, 1],
            [0, -1],
            [1, -1],
            [2, -1]
        ];

        this.grids1 = [];
        this.grids2 = [];
        for (var i = 0; i < this.coords1.length; i++) {
            var grid1 = new cc.Sprite("res/fight/ui/blockOK.png");
            this.addChild(grid1);
            var pos = MapUtils.transPointToPosition(this.coords1[i][0], this.coords1[i][1]);
            grid1.setPosition(pos.x, pos.y);
            this.grids1.push(grid1);
            grid1.setScaleY(78 / 104);

            var grid2 = new cc.Sprite("res/fight/ui/blockNo.png");
            this.addChild(grid2);
            grid2.setPosition(pos.x, pos.y);
            this.grids2.push(grid2);
            grid2.setScaleY(78 / 104);
        }

        var sp = new cc.Sprite("res/fight/build/zhuchengbao_01.png");
        this.addChild(sp);
        sp.setOpacity(160);
        sp.setPosition(MapUtils.width / 2 - 50 + 48, 23 - 67 + 24);


        var btn = new ccui.Button();
        btn.loadTextureNormal("gy_anniu_meian_01.png", ccui.Widget.PLIST_TEXTURE);
        btn.loadTexturePressed("gy_anniu_anxia_01.png", ccui.Widget.PLIST_TEXTURE);
        btn.setTitleColor({r: 255, g: 255, g: 255, a: 255});
        btn.setTitleFontSize(14);
        btn.setTitleText("确定");
        this.addChild(btn);
        btn.setPosition(150, -135);
        btn.addTouchEventListener(this.buildCastle, this);


        var cancle = new ccui.Button();
        cancle.loadTextureNormal("gy_anniu_meian_01.png", ccui.Widget.PLIST_TEXTURE);
        cancle.loadTexturePressed("gy_anniu_anxia_01.png", ccui.Widget.PLIST_TEXTURE);
        cancle.setTitleColor({r: 255, g: 255, g: 255, a: 255});
        cancle.setTitleFontSize(14);
        cancle.setTitleText("取消");
        this.addChild(cancle);
        cancle.setPosition(-50, -135);
        cancle.addTouchEventListener(this.closePanel, this);

        mainData.mapData.cameraData.addListener("x", this.cameraChangePosition, this);
        mainData.mapData.cameraData.addListener("y", this.cameraChangePosition, this);

        //注册鼠标事件
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this),
            onTouchMoved: this.onTouchMoved.bind(this),
            onTouchEnded: this.onTouchEnded.bind(this)
        }, this);

        var castle = mainData.mapData.castleList.getItem("id", mainData.uiData.currentCastleId);
        this.setCoord(castle.coordX, castle.coordY);

        //jc.EnterFrame.add(this.update, this);
        EventMgr.inst().addEventListener("guide_event", this.doGuide, this);
    },
    cameraChangePosition: function (val) {
        var pos = MapUtils.transPointToPosition(this.coordX, this.coordY);
        this.setPosition(pos.x - mainData.mapData.cameraData.x, pos.y - mainData.mapData.cameraData.y);
    },
    /**
     * @param roler MapRolerData
     */
    show: function (data) {
        //this.roler = data.roler;
        this.point = data;
        this.setCoord(data.x, data.y);
    },
    setCoord: function (coordX, coordY) {
        this.coordX = coordX;
        this.coordY = coordY;
        var pos = MapUtils.transPointToPosition(this.coordX, this.coordY);
        this.setPosition(pos.x - mainData.mapData.cameraData.x, pos.y - mainData.mapData.cameraData.y);
        var coords;
        trace("可建筑点判定",coordX,coordY);
        if (this.coordY % 2 == 0) {
            coords = this.coords1;
        } else {
            coords = this.coords2;
        }
        var builds = mainData.mapData.castleList;
        var noDistance = true;
        var dis = modelMgr.call("Table", "getTableItemByValue", ["Public", 100008]).numerical;
        for (var i = 0; i < builds.length; i++) {
            if (MapUtils.getDistance(builds.getItemAt(i).coordX, builds.getItemAt(i).coordY, this.coordX, this.coordY) <= dis) {
                noDistance = false;
                break;
            }
        }
        for (var i = 0; i < coords.length; i++) {
            if (noDistance == false) {
                this.grids1[i].setVisible(false);
                this.grids2[i].setVisible(true);
            } else {
                var x = this.coordX + coords[i][0];
                var y = this.coordY + coords[i][1];
                var blockInfo = ServerMapConfig.getInstance().getBlock(x, y);
                var blockTableItem = modelMgr.call("Table", "getTableItemByValue", ["Territory_product", blockInfo.type]);
                trace("判断点是否可走?",x,y,ServerMapConfig.getInstance().isPath(x, y));
                if (ServerMapConfig.getInstance().isPath(x, y)  && blockTableItem.construction) {
                    this.grids1[i].setVisible(true);
                    this.grids2[i].setVisible(false);
                } else {
                    this.grids1[i].setVisible(false);
                    this.grids2[i].setVisible(true);
                }
            }
        }
    },
    destroy: function () {
        mainData.mapData.cameraData.removeListener("x", this.cameraChangePosition, this);
        mainData.mapData.cameraData.removeListener("y", this.cameraChangePosition, this);
        EventMgr.inst().removeEventListener("guide_event", this.doGuide, this);
        //jc.EnterFrame.del(this.update, this);
    },
    update: function () {
        if (this.speedX || this.speedY) {
            this.moveTime--;
            if (this.moveTime <= 0) {
                this.moveTime = 5;
                mainData.mapData.cameraData.x += this.speedX * MapUtils.width;
                mainData.mapData.cameraData.y += this.speedY * MapUtils.height;
                var posy = this.getPositionY();
                var cy = this.coordY;
                this.setCoord(this.coordX + this.speedX, this.coordY + this.speedY);
                //jc.EnterFrame.del(this.update, this);
            }
        }
    },
    touchPos: null,
    touchDownPos: null,
    speedX: 0,
    speedY: 0,
    moveTime: null,
    currentPos: null,
    onTouchBegan: function (touch, event) {
        this.touchPos = touch.getLocation();
        this.touchDownPos = {x: this.getPositionX(), y: this.getPositionY()};
        return true;
    },
    onTouchMoved: function (touch, event) {
        var currentPos = touch.getLocation();
        this.currentPos = currentPos;
        this.speedX = this.speedY = 0;
        if (currentPos.x < 180) {
            this.speedX = -1;
        }
        if (currentPos.x > mainData.systemData.screenWidth - 180 - MapUtils.width) {
            this.speedX = 1;
        }
        if (currentPos.y < MapUtils.width * 2) {
            this.speedY = -2;
        }
        if (currentPos.y > mainData.systemData.screenHeight - 50 - MapUtils.width * 2) {
            this.speedY = 2;
        }
        if (this.speedX || this.speedY) {
            this.moveTime = 5;
            return;
        }
        var pos = MapUtils.transPositionToPoint(this.touchDownPos.x + currentPos.x - this.touchPos.x + mainData.mapData.cameraData.x,
            this.touchDownPos.y + currentPos.y - this.touchPos.y + mainData.mapData.cameraData.y);
        if (pos.x != this.coordX || pos.y != this.coordY) {
            trace("移动后坐标:", pos.x, pos.y, currentPos.x, currentPos.y, this.touchDownPos.x, this.touchDownPos.y);
            this.setCoord(pos.x, pos.y);
        }
    },
    onTouchEnded: function (touch, event) {
        this.speedX = 0;
        this.speedY = 0;
    },
    buildCastle: function () {
        ModuleMgr.inst().closeModule("BuildEditerModule");
        //var path = ServerMapConfig.getInstance().astar.findPath(this.roler.coordX, this.roler.coordY, this.coordX, this.coordY);
        //roler.goDownTheRoad(path);

        //var msg = new SocketBytes();
        //msg.writeUint(303);
        //msg.writeString(this.roler.id);
        //msg.writeUint(path.length);
        //var lastPath = {x: this.roler.coordX, y: this.roler.coordY}
        //for (var p = 0; p < path.length; p++) {
        //    msg.writeInt(path[p].x - lastPath.x);
        //    msg.writeInt(path[p].y - lastPath.y);
        //    console.log((path[p].x - lastPath.x) + "," + (path[p].y - lastPath.y));
        //    lastPath = path[p];
        //}
        //msg.writeUint(2);
        //msg.writeString(this.getCastleName());//mainData.playerData.nick + "的分城" + (mainData.mapData.myCastleList.length - 1)
        //NetMgr.inst().send(msg);


        var msg = new SocketBytes();
        msg.writeUint(425);
        msg.writeString(mainData.uiData.currentCastleId);
        msg.writeInt(this.coordX);
        msg.writeInt(this.coordY);
        msg.writeString(mainData.playerData.nick + "的分城" + mainData.mapData.myCastleList.length);
        NetMgr.inst().send(msg);
        trace("新城点:",this.coordX,this.coordY);
    },
    closePanel: function () {
        ModuleMgr.inst().closeModule("BuildEditerModule");
    },
    //引导处理方法
    doGuide:function(type,guideId) {
        cc.log("BuildEditer引导触发操作doGuide" + guideId);
        if (guideId == "4_10") {
            this.closePanel();
        }
    },

    //城堡名称优化
    getCastleName: function () {
        var name = mainData.playerData.nick;
        if(name.length>3){
            name = name.substr(0,3);
        }
        name=name+ResMgr.inst().getString("castlename")+mainData.mapData.myCastleList.length;
        return name;
    }
});