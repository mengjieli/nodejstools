/**
 * Created by cgMu on 2016/1/27.
 */

var ShowBagModule = ModuleBase.extend({
    titleLabel:null,
    scrollview:null,
    itemRoot:null,
    data:null,

    ctor:function() {
        this._super();
    },

    initUI:function() {
        var root = ccs.load("res/images/ui/PayModule/showbag.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_2 = root.getChildByName("Panel_2");
        posAutoLayout(Panel_2,0.5);

        var Button_1 = Panel_2.getChildByName("Button_1");
        Button_1.addTouchEventListener(this.closeCallback,this);

        var Button_2 = Panel_2.getChildByName("Button_2");
        Button_2.addTouchEventListener(this.btnCallback,this);
        var btntxt = Button_2.getChildByName("Text_1");
        btntxt.setString(ResMgr.inst().getString("public_ok"));
        btntxt.ignoreContentAdaptWithSize(true);

        var Text_4 = Panel_2.getChildByName("Text_4");
        Text_4.ignoreContentAdaptWithSize(true);
        this.titleLabel = Text_4;

        var ScrollView_1 = Panel_2.getChildByName("ScrollView_1");
        this.scrollview = ScrollView_1;

        var Image_5 = ScrollView_1.getChildByName("Image_5");
        Image_5.setVisible(false);
        this.itemRoot = Image_5;

    },

    show:function( value ) {
        this.data = value;

        this.titleLabel.setString(ResMgr.inst().getString(value.icon+"0"));

        var list = this.getList(value.trading_id);
        cc.log("@礼包内道具数量",list.length,value.trading_id);

        var counts = list.length;
        var gap = 5;
        var width = this.itemRoot.getContentSize().width;
        for(var i = 0; i < counts; i++){
            var it = this.itemRoot.clone();
            it.setVisible(true);
            it.setPosition(cc.p(gap+width*0.5+(gap+width)*i,90));
            this.scrollview.addChild(it);
            this.setItem(it,list[i]);
        }

        var size = this.scrollview.getContentSize();
        var total = gap + (gap+width)*counts;
        total = total<size.width?size.width:total;


        this.scrollview.setInnerContainerSize(cc.size(total,size.height));
        this.scrollview.jumpToLeft();
    },

    close:function() {

    },

    destroy:function() {

    },

    closeCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            ModuleMgr.inst().closeModule("ShowBagModule");
        }
    },

    btnCallback: function (sender, type) {
        if(type==ccui.Widget.TOUCH_ENDED){
            ModuleMgr.inst().closeModule("ShowBagModule");
        }
    },

    getList: function (tradeid) {
        var list = [];

        var tradeData = modelMgr.call("Table", "getTableItemByValue", ["item_trading",tradeid]);
        if(tradeData){
            var temp = tradeData.obtain_item;
            var tempjson = eval("(" + temp + ")");
            var bagid = null;
            for (var i in tempjson) {
                bagid = i;
            }

            var itemData = modelMgr.call("Table", "getTableItemByValue", ["item", bagid]);
            var use_tradeid = itemData.canuse;

            var data = modelMgr.call("Table", "getTableItemByValue", ["item_trading",use_tradeid]);
            if(data){
                var datatemp = data.obtain_item;
                var json = eval("(" + datatemp + ")");
                for(var key in json) {
                    var item ={};
                    item.itemid = key;
                    item.counts = json[key];
                    list.push(item);
                }
            }
        }
        else{
            list.push({"itemid":2100033,"counts":1});
        }

        return list;
    },

    setItem: function (item, data) {
        var Image_5_0_0 = item.getChildByName("Image_5_0_0");
        Image_5_0_0.ignoreContentAdaptWithSize(true);
        Image_5_0_0.loadTexture(ResMgr.inst().getIcoPath(data.itemid));
        Image_5_0_0.setScale(0.55);

        var Text_2 = item.getChildByName('Text_2');
        Text_2.ignoreContentAdaptWithSize(true);
        Text_2.setString(data.counts);

        var Text_3 = item.getChildByName("Text_3");
        //Text_3.ignoreContentAdaptWithSize(true);
        Text_3.setString(ResMgr.inst().getString(data.itemid+"0"));
    }
});