/**
 * Created by Administrator on 2015/12/25/0025.
 */
var GuideData = DataBase.extend({


    _guideBean:null,//引导数据


    ctor: function () {

    },
    //初始化
    init: function () {

    },


});