var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var flower;
(function (flower) {
    var TextField = (function (_super) {
        __extends(TextField, _super);
        function TextField() {
            _super.call(this);
            this._TextField = { 0: 12, 1: 0, 2: "", 3: 0, 4: 0, 5: false, 6: true };
            this._show = System.getNativeShow("TextField");
            this.width = 100;
            this.height = 100;
            this._setSize(this._TextField[0]);
            this._setColor(this._TextField[1]);
        }
        TextField.prototype._setSize = function (val) {
            this._TextField[0] = val;
            this._invalidateNativeText();
        };
        TextField.prototype._setColor = function (val) {
            this._TextField[1] = val;
            var p = flower.TextField.textFieldProperty.color;
            if (p.atr) {
                this._show[p.atr] = val;
            }
            else if (p.func) {
                this._show[p.func].apply(this._show, [val]);
            }
            else if (p.exe) {
                p.exe(this._show, val);
            }
        };
        TextField.prototype._setText = function (val) {
            this._TextField[2] = val;
            this._invalidateNativeText();
        };
        TextField.prototype._setWidth = function (val) {
            this._width = +val & ~0;
            this._invalidateNativeText();
        };
        TextField.prototype._setHeight = function (val) {
            this._height = +val & ~0;
            this._invalidateNativeText();
        };
        TextField.prototype._setNativeText = function () {
            var p = flower.TextField.textFieldProperty.resetText;
            p(this._show, this._TextField[2], this._width, this._height, this._TextField[0], this._TextField[5], this._TextField[6]);
            p = flower.TextField.textFieldProperty.mesure;
            var size = p(this._show);
            this._TextField[3] = size.width;
            this._TextField[4] = size.height;
            this.$removeFlag(2);
        };
        TextField.prototype.$isMouseTarget = function (matrix, mutiply) {
            if (this.touchEnabled == false || this.visible == false)
                return false;
            matrix.save();
            matrix.translate(-this._x, -this._y);
            if (this.rotation)
                matrix.rotate(-this.radian);
            if (this.scaleX != 1 || this.scaleY != 1)
                matrix.scale(1 / this.scaleX, 1 / this.scaleY);
            this._touchX = matrix.tx;
            this._touchY = matrix.ty;
            if (this._touchX >= 0 && this._touchY >= 0 && this._touchX < this._TextField[3] && this._touchY < this._TextField[4]) {
                return true;
            }
            matrix.restore();
            return false;
        };
        TextField.prototype._invalidateNativeText = function () {
            this.$addFlag(1);
            if (!this.$getFlag(2)) {
                this.$addFlag(2);
            }
        };
        TextField.prototype.$getSize = function () {
            if (this.$getFlag(2)) {
                this._setNativeText();
            }
            this.$removeFlag(1);
        };
        TextField.prototype.$onFrameEnd = function () {
            if (this.$getFlag(2)) {
                this._setNativeText();
            }
        };
        Object.defineProperty(TextField.prototype, "size", {
            get: function () {
                return this._TextField[0];
            },
            set: function (val) {
                this._setSize(+val || 0);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "color", {
            get: function () {
                return this._TextField[1];
            },
            set: function (val) {
                this._setColor(+val || 0);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "text", {
            get: function () {
                return this._TextField[2];
            },
            set: function (val) {
                val = val + "";
                this._setText(val);
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "textWidth", {
            get: function () {
                return this._TextField[3];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "textHeight", {
            get: function () {
                return this._TextField[4];
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "wordWrap", {
            get: function () {
                return this._TextField[5];
            },
            set: function (val) {
                val = !!val;
                if (val == this._TextField[5]) {
                    return;
                }
                this._TextField[5] = val;
                this._invalidateNativeText();
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(TextField.prototype, "multiline", {
            get: function () {
                return this._TextField[6];
            },
            set: function (val) {
                val = !!val;
                if (val == this._TextField[6]) {
                    return;
                }
                this._TextField[6] = val;
                this._invalidateNativeText();
            },
            enumerable: true,
            configurable: true
        });
        return TextField;
    })(flower.DisplayObject);
    flower.TextField = TextField;
})(flower || (flower = {}));
flower.TextField.textFieldProperty = System.TextField;
//# sourceMappingURL=TextField.js.map