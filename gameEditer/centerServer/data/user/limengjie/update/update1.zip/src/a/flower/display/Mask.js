var flower;
(function (flower) {
    var Mask = (function () {
        function Mask() {
        }
        return Mask;
    })();
    flower.Mask = Mask;
})(flower || (flower = {}));
//# sourceMappingURL=Mask.js.map