var Event = {
    PROPERTY_CHANGE: "property_change",
    CHANGE:"change"
};

GameSDK.Event = Event;