/**
 * Created by cgMu on 2016/1/5.
 */

var AlertCostModule = ModuleBase.extend({
    callback:null,
    text:null,
    panel_1:null,//panel_1

    ctor:function() {
        this._super();
    },

    initUI:function() {
        var colorbg =  new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var root = ccs.load("res/images/ui/HeadModule/CostLayer.json","res/images/ui/").node;
        this.addChild(root);

        var size = cc.director.getVisibleSize();
        root.setContentSize(size);
        ccui.helper.doLayout(root);

        var Panel_1 = root.getChildByName("Panel_1");
        Panel_1.setScale( 1/GameMgr.inst().scaleX * GameMgr.inst().getMaxAndMinScale(false) );
        posAutoLayout(Panel_1,0.5);
        this.panel_1=Panel_1;
        var root_panel = Panel_1.getChildByName("Panel_4");

        var closebtn = root_panel.getChildByName("Button_1");
        closebtn.addTouchEventListener(this.touchCallback,this);

        var text = root_panel.getChildByName("Text_1");
        text.ignoreContentAdaptWithSize(true);
        //text.setString(this.textInfo(0));
        this.text = text;

        var left_btn = root_panel.getChildByName("Button_2");
        left_btn.addTouchEventListener(this.btnCallback,this);
        left_btn.setTag(1);
        var left_text = left_btn.getChildByName("Text_2");
        left_text.ignoreContentAdaptWithSize(true);
        left_text.setString(ResMgr.inst().getString("head_30"));

        var right_btn = root_panel.getChildByName("Button_2_0");
        right_btn.addTouchEventListener(this.btnCallback,this);
        right_btn.setTag(2);
        var right_text = right_btn.getChildByName("Text_2");
        right_text.ignoreContentAdaptWithSize(true);
        right_text.setString(ResMgr.inst().getString("head_31"));

        var confirm_btn = root_panel.getChildByName("Button_3");
        confirm_btn.addTouchEventListener(this.btnCallback,this);
        confirm_btn.setTag(1);
        var confirm_text = confirm_btn.getChildByName("Text_2");
        confirm_text.ignoreContentAdaptWithSize(true);
        confirm_text.setString(ResMgr.inst().getString("public_ok"));

    },

    destroy:function() {
        this._super();
    },

    //data {"text":"","func":callback,"oneBt":false,"title":"1234"}//后两参数可不填 oneBt参数 只显示确定按钮  title增加上方标题
    show:function( data ){
        if(this.text && data.text){
            this.text.setString(data.text);
        }
        if(data.func){
            this.callback = data.func;
        }
        //Panel_1=this.panel_1;
        var root_panel = this.panel_1.getChildByName("Panel_4");
        root_panel.getChildByName("Button_2").setVisible(!data.oneBt);
        root_panel.getChildByName("Button_2_0").setVisible(!data.oneBt);
        root_panel.getChildByName("Button_3").setVisible(data.oneBt);
        var title=root_panel.getChildByName("Text_title");
        if(data.title)  {
            title.setVisible(true);
            title.setString(data.title);
        }
        else title.setVisible(false);

    },

    close:function()
    {

    },

    touchCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;

        SoundPlay.playEffect( ResMgr.inst().getSoundPath(5));
        ModuleMgr.inst().closeModule("AlertCostModule");
    },

    btnCallback: function (sender, type) {
        if(type != ccui.Widget.TOUCH_ENDED) return;

        var tag = sender.getTag();
        if(tag == 1) {
            //left
            cc.log("left");
            if(this.callback!=null)   this.callback();
        }
        ModuleMgr.inst().closeModule("AlertCostModule");
    }
});