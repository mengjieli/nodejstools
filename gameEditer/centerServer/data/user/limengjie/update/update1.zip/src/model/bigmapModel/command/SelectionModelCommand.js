var SelectionModelCommand = (function (_super) {
    __extends(SelectionModelCommand, _super);

    function SelectionModelCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
    }

    var d = __define, c = SelectionModelCommand;
    p = c.prototype;

    /**
     * 初始化
     * @param params Object
     */
    p.init = function (params) {
        mainData.uiData.map.addListener("touchMovePoint", this.onTouchChange, this);
        mainData.uiData.addListener("operateMode",this.onOperateModeChange,this)
    }

    /**
     * 点击划过地图上的某个坐标点
     * @param p
     */
    p.onTouchChange = function (p) {
        if(mainData.uiData.map.selectionMode) { //多选模式下划过某个士兵即选择
            var army = mainData.mapData.myArmyList.getItem("coordX", p.x,"coordY", p.y);
            if(army) {
                if(army.castleId == mainData.uiData.currentCastleId) {
                    army.selected = true;
                } else {
                    ModuleMgr.inst().openModule("AlertString",{str:ResMgr.inst().getString("selectCurrentArmy"),color:null,time:null,pos:null});
                }
            }
        }
    }

    /**
     * 操作模式改变，普通模式与命令模式切换(点击主界面我的部队按钮)
     */
    p.onOperateModeChange = function(val) {
        trace("指令模式改变",val);
        if(val == "1") {
            var armys = mainData.mapData.myArmyList;
            for(var i = 0; i < armys.length; i++) {
                var army = armys.getItemAt(i);
                if(army.selected == true) {
                    army.selected = false;
                }
            }
        }
        mainData.uiData.map.showImage = "";
        mainData.uiData.map.shineGrid = "";
        ModuleMgr.inst().openModule("TileMenuModule", null);//关闭弹框
        mainData.uiData.clickMenuVisible = false;
    }

    return SelectionModelCommand;
})(CycleCommand);