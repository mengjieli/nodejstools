var flower;
(function (flower) {
    var TextureManager = (function () {
        function TextureManager() {
            this.list = new Array();
            if (flower.TextureManager.classLock == true) {
                flower.DebugInfo.debug("无法创建对象TextureManager，此类为单例模式，请访问TextureManager.getInstance()", flower.DebugInfo.WARN);
                return;
            }
        }
        TextureManager.prototype.createTexture = function (nativeTexture, url, nativeURL, w, h) {
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i].url == url) {
                    return null;
                }
            }
            flower.DebugInfo.debug("|加载纹理| " + url, flower.DebugInfo.TIP);
            var texture = new flower.Texture2D(nativeTexture, url, nativeURL, w, h);
            this.list.push(texture);
            return texture;
        };
        TextureManager.prototype.delTexture = function (texture) {
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i] == texture) {
                    flower.Texture2D.safeLock = false;
                    this.list.splice(i, 1)[0].$dispose();
                    flower.Texture2D.safeLock = true;
                    return;
                }
            }
            flower.DebugInfo.debug("|释放纹理| 未找到的纹理 : " + texture.url, flower.DebugInfo.WARN);
        };
        TextureManager.prototype.getTexture = function (url) {
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i].url == url) {
                    this.list[i].addCount();
                    return this.list[i];
                }
            }
            flower.DebugInfo.debug("|获取纹理| 未找到的纹理 : " + url, flower.DebugInfo.WARN);
            return null;
        };
        TextureManager.prototype.disposeTexure = function (texture) {
            for (var i = 0; i < this.list.length; i++) {
                if (this.list[i] == texture) {
                    this.list[i].delCount();
                    return;
                }
            }
            flower.DebugInfo.debug("|释放纹理| 未找到的纹理 " + texture.url, flower.DebugInfo.WARN);
        };
        TextureManager.getInstance = function () {
            if (!flower.TextureManager.ist) {
                flower.TextureManager.classLock = false;
                flower.TextureManager.ist = new flower.TextureManager();
                flower.TextureManager.classLock = true;
            }
            return flower.TextureManager.ist;
        };
        return TextureManager;
    })();
    flower.TextureManager = TextureManager;
})(flower || (flower = {}));
flower.TextureManager.classLock = true;
//# sourceMappingURL=TextureManager.js.map