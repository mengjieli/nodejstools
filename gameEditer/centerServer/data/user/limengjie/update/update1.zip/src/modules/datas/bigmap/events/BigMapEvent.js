/**
 * 大地图事件
 * @type {{Move: string}}
 */
var BigMapEvent = {
    "Move":"move"
}