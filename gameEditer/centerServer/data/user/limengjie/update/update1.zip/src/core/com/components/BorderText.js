var BorderText = cc.Sprite.extend({
    border1:null,
    border2:null,
    border3:null,
    border4:null,
    txt:null,
    ctor: function () {
        this._super();

        this.border1 = new ccui.Text();
        this.addChild(this.border1);
        this.border1.x = 1;

        this.border2 = new ccui.Text();
        this.addChild(this.border2);
        this.border2.x = -1;

        this.border3 = new ccui.Text();
        this.addChild(this.border3);
        this.border3.y = 1;

        this.border4 = new ccui.Text();
        this.addChild(this.border4);
        this.border4.y = -1;

        this.txt = new ccui.Text();
        this.addChild(this.txt);

        this.setBorderColor({r:0,g:0,b:0,a:255});

    },
    setText:function(val){
      this.setString(val);
    },
    setString:function(val){
        this.border1.setString(val);
        this.border2.setString(val);
        this.border3.setString(val);
        this.border4.setString(val);
        this.txt.setString(val);
    },
    setFontSize:function(val) {
        this.border1.setFontSize(val);
        this.border2.setFontSize(val);
        this.border3.setFontSize(val);
        this.border4.setFontSize(val);
        this.txt.setFontSize(val);
    },
    setColor:function(val){
        this.txt.setColor(val);
    },
    setAnchorPoint:function(val1,val2){
        this.txt.setAnchorPoint.apply(this.txt,arguments);
        this.border1.setAnchorPoint.apply(this.border1,arguments);
        this.border2.setAnchorPoint.apply(this.border2,arguments);
        this.border3.setAnchorPoint.apply(this.border3,arguments);
        this.border4.setAnchorPoint.apply(this.border4,arguments);
    },
    setBorderColor:function(val){
        this.border1.setColor(val);
        this.border2.setColor(val);
        this.border3.setColor(val);
        this.border4.setColor(val);
    }
});

BorderText.replace = function(label){
    var txt = new BorderText();
    var parent = label.getParent();
    parent.removeChild(label);
    parent.addChild(txt);
    txt.setString(label.getString());
    txt.setColor(label.getColor());
    txt.setFontSize(label.getFontSize());
    txt.setPosition(label.getPosition().x,label.getPosition().y);
    txt.setAnchorPoint(label.getAnchorPoint());
    return txt;
}