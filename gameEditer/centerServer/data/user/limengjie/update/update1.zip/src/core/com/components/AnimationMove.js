/**
 * yx.
 * 高级动画类
 */
AnimationSet = {};
AnimationSet.MOVE_RIGHTUP="move_rightup";//动作类型方向 移动右上方向
AnimationSet.MOVE_RIGHTDOWN="move_rightdown";
AnimationSet.MOVE_LEFTUP="move_leftup";
AnimationSet.MOVE_LEFTDOWN="move_leftdown";
AnimationSet.MOVE_UP="move_up";//往返巡逻 上下
AnimationSet.MOVE_DOWN="move_down";//往返巡逻 上下
var AnimationMove = cc.Sprite.extend({

    _isAdd:false,

    _callBack:null,
    _owner:null,
    _parameter:null,
    _animationConfig:null,

    ctor:function( )
    {
        this._super();
    },

    onEnter: function ()
    {
        this._super();
        this.scheduleUpdate();
    },

    onExit: function ()
    {
        this._super();
    },

    update:function( dt )
    {
        this._super( dt );

        if( this._isAdd )
        {
            this.setBlendFunc(gl.ONE,gl.ONE);
        }
    },

    setAdd:function( b )
    {
        this._isAdd = b;
    },

    _nameConfig:null,//动画基础名
    _arrConfig:null,//配置数组
    _dirType:null,//逆时针 同方向 顺时针 反方向    -1 0 1 2
    _dirCurrent:null,//当前方向  索引 0123 右上右下左下左上
    _isDisappear:null,//是否结束后渐隐消失
    //初始化
    initMove:function(name,arrPoint,arrTime,dirType,dirCurrent){//name：csv中的名  arrPoint：[ [起始，终点],[],[],[]]  arrTime：[时间秒，时间秒，时间秒，时间秒]，dirType：往返或行走方向  dirCurrent：当前方向（右上0）
        this._arrConfig=[];
        this._nameConfig=name;

        var arrDir=[AnimationSet.MOVE_RIGHTUP,AnimationSet.MOVE_RIGHTDOWN,AnimationSet.MOVE_LEFTDOWN,AnimationSet.MOVE_LEFTUP];
        var arrDir2=[AnimationSet.MOVE_UP,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_UP];
        for(var i=0;i<arrDir.length;i++){
            var csvEffect = ResMgr.inst().getCSV("animationConfig",name+arrDir[i]);
            //cc.error("csvEffect>>"+csvEffect);
            if(dirType==2&&csvEffect==undefined) csvEffect=ResMgr.inst().getCSV("animationConfig",name+arrDir2[i]);
            //cc.error(csvEffect+"<<<<<<<<<<<<<<<<name"+name+arrDir[i]);
            this._arrConfig.push([csvEffect,arrPoint[i],arrTime[i]]);
        }

        this._dirType=dirType;
        this._dirCurrent=dirCurrent;
        this.moveAnimation();
    },
    //逆时针 同方向 顺时针 反方向    -1 0 1 2
    moveAnimation:function(){//animationConfig, duration, callBack, owner, data
        this.removeData();
        var animationConfig=this._arrConfig[this._dirCurrent][0];
        var duration=this._arrConfig[this._dirCurrent][2];
        var startP=this._arrConfig[this._dirCurrent][1][0];
        var endP=this._arrConfig[this._dirCurrent][1][1];

        if (animationConfig == null) return;
        this._animationConfig=animationConfig;
        this.setAnchorPoint( animationConfig.anchorX, animationConfig.anchorY );
        this.setScale( animationConfig.scale );

        var lists = [];

        var num = Number( animationConfig.frameNum );
        var time = Number( animationConfig.time );
        var delay = time/num;
        duration = duration == undefined ? 0 : duration;
        var loop = duration > 0 ? duration : 1;

        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined  && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }

        if( lists.length == 0 ) return;

        var an = new cc.Animation( lists, delay );
        an.setLoops( loop );
        var animate = new cc.Animate( an );

        var action = cc.repeatForever( animate );
        this.runAction( action );

        this.setPosition(startP);
        var moveAction = cc.moveTo(duration,endP );
        this.runAction( moveAction );

        if( duration > 0 )
        {
            //this._callBack = callBack == undefined ? null : callBack;
            //this._owner = owner == undefined ? null : owner;
            //this._parameter = data == undefined ? null : data;

            var delayTime = cc.sequence( cc.delayTime(duration), cc.callFunc( this.moveAnimation, this ) );
            this.runAction( delayTime );
        }

        if(this._dirType==1){
            this._dirCurrent+=1;
            if(this._dirCurrent>3) this._dirCurrent=0;
        }else if(this._dirType==-1){
            this._dirCurrent-=1;
            if(this._dirCurrent<0) this._dirCurrent=3;
        }else if(this._dirType==2){
            this._dirCurrent+=2;
            if(this._dirCurrent==4) this._dirCurrent=0;
            if(this._dirCurrent==5) this._dirCurrent=1;
        }

    },

    //执行单次的飞行动画
    initMoveOnce:function(name,arrPoint,speed,isAppear,isDisappear){
        this._arrConfig=[];
        this._nameConfig=name;
        this._isDisappear=isDisappear;
        var csvEffect = ResMgr.inst().getCSV("animationConfig",name);
        var dis=MathUtils.twoPointsDistance(arrPoint[0],arrPoint[1]);
        var time=Number(dis/speed).toFixed(1);
        //角度旋转判断

        this._arrConfig.push([csvEffect,arrPoint,time]);

        this._dirCurrent=0;
        if(isAppear)this.movePathAppear(true);
        else this.movePathAnimation();
    },

    //路径动画  根据路径数组移动 距离都是等速   用法参数说明： name动画名（对应animationConfig）  arrPoint路径各点数组 speed速度每秒移动多少像素  isAppear/isDisappear 是否渐显渐隐
    initMovePathSpeed:function(name,arrPoint,speed,isAppear,isDisappear){
        this._arrConfig=[];
        this._nameConfig=name;
        this._isDisappear=isDisappear;
        var arrDir=[AnimationSet.MOVE_RIGHTUP,AnimationSet.MOVE_RIGHTDOWN,AnimationSet.MOVE_LEFTDOWN,AnimationSet.MOVE_LEFTUP];
        //var arrDir2=[AnimationSet.MOVE_UP,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_UP];
        for(var i=0;i<arrPoint.length-1;i++){
            var dirCurrent;
            var apartX=arrPoint[i].x-arrPoint[i+1].x;
            var apartY=arrPoint[i].y-arrPoint[i+1].y;
            if(apartX<0&&apartY<0)  dirCurrent=0;
            if(apartX<0&&apartY>0)  dirCurrent=1;
            if(apartX>0&&apartY>0)  dirCurrent=2;
            if(apartX>0&&apartY<0)  dirCurrent=3;
            var dis=MathUtils.twoPointsDistance(arrPoint[i],arrPoint[i+1]);
            var time=Number(dis/speed).toFixed(1);
            //cc.error(time);
            var csvEffect = ResMgr.inst().getCSV("animationConfig",name+arrDir[dirCurrent]);
            this._arrConfig.push([csvEffect,[arrPoint[i],arrPoint[i+1]],time]);
        }

        this._dirCurrent=0;

        if(isAppear)this.movePathAppear(true);
        else this.movePathAnimation();

    },

    //路径动画  根据路径数组移动 可不等速 用法参数说明： name动画名（对应animationConfig）  arrPoint路径各点数组 arrTime到下一点消耗时间(秒)注意数组长度比距离数组少一位  isAppear/isDisappear 是否渐显渐隐
    initMovePathTime:function(name,arrPoint,arrTime,isAppear,isDisappear){
        this._arrConfig=[];
        this._nameConfig=name;
        this._isDisappear=isDisappear;
        var arrDir=[AnimationSet.MOVE_RIGHTUP,AnimationSet.MOVE_RIGHTDOWN,AnimationSet.MOVE_LEFTDOWN,AnimationSet.MOVE_LEFTUP];
        //var arrDir2=[AnimationSet.MOVE_UP,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_DOWN,AnimationSet.MOVE_UP];
        for(var i=0;i<arrTime.length;i++){
            var dirCurrent;
            var apartX=arrPoint[i].x-arrPoint[i+1].x;
            var apartY=arrPoint[i].y-arrPoint[i+1].y;
            if(apartX<0&&apartY<0)  dirCurrent=0;
            if(apartX<0&&apartY>0)  dirCurrent=1;
            if(apartX>0&&apartY>0)  dirCurrent=2;
            if(apartX>0&&apartY<0)  dirCurrent=3;

            var csvEffect = ResMgr.inst().getCSV("animationConfig",name+arrDir[dirCurrent]);
            this._arrConfig.push([csvEffect,[arrPoint[i],arrPoint[i+1]],arrTime[i]]);

        }

        this._dirCurrent=0;

        if(isAppear)this.movePathAppear(true);
        else this.movePathAnimation();

    },
    //渐显  //渐隐    isAppear true/false
    movePathAppear:function(isAppear){
        this.removeData();
        if(!isAppear) this._dirCurrent=this._arrConfig.length-1;
        var animationConfig=this._arrConfig[this._dirCurrent][0];
        var duration=this._arrConfig[this._dirCurrent][2];
        var startP=this._arrConfig[this._dirCurrent][1][0];
        var endP=this._arrConfig[this._dirCurrent][1][1];

        if (animationConfig == null) return;
        this._animationConfig=animationConfig;
        this.setAnchorPoint( animationConfig.anchorX, animationConfig.anchorY );
        this.setScale( animationConfig.scale );

        var lists = [];

        var num = Number( animationConfig.frameNum );
        var time = Number( animationConfig.time );
        var delay = time/num;
        duration = duration == undefined ? 0 : duration;
        var loop = duration > 0 ? duration : 1;

        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined  && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }

        if( lists.length == 0 ) return;

        var an = new cc.Animation( lists, delay );
        an.setLoops( loop );
        var animate = new cc.Animate( an );

        var action = cc.repeatForever( animate );
        this.runAction( action );


        //var moveAction = cc.moveTo(duration,endP );
        if(isAppear){
            this.setPosition(startP);
            this.setOpacity(0);
            var moveAction=cc.fadeIn(2);
            var delayTime = cc.sequence( moveAction, cc.callFunc( this.movePathAnimation, this ) );
        }
        else{
            var moveAction=cc.fadeOut(2);
            var delayTime = cc.sequence( moveAction, cc.callFunc( this.disposeSelf, this ) );
        }

        this.runAction( delayTime );

        //if( duration > 0 )
        //{
        //    var delayTime = cc.sequence( cc.delayTime(duration), cc.callFunc( this.movePathAnimation, this ) );
        //    this.runAction( delayTime );
        //}


    },
    //移动动画多路径
    movePathAnimation:function(){
        //cc.log(this._arrConfig.length+"执行移动动画》》》》"+this._dirCurrent);
        this.removeAction();
        if(this._dirCurrent==this._arrConfig.length){
            //cc.error("最后一个路径完成 ");
            if(this._isDisappear) this.movePathAppear(false);
            else {
                this.disposeSelf();
            }
            return;
        }
        var animationConfig=this._arrConfig[this._dirCurrent][0];
        var duration=this._arrConfig[this._dirCurrent][2];
        var startP=this._arrConfig[this._dirCurrent][1][0];
        var endP=this._arrConfig[this._dirCurrent][1][1];

        if (animationConfig == null) return;
        this._animationConfig=animationConfig;
        this.setAnchorPoint( animationConfig.anchorX, animationConfig.anchorY );
        this.setScale( animationConfig.scale );

        var lists = [];

        var num = Number( animationConfig.frameNum );
        var time = Number( animationConfig.time );
        var delay = time/num;
        duration = duration == undefined ? 0 : duration;
        var loop = duration > 0 ? duration : 1;

        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined  && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }

        if( lists.length == 0 ) return;

        var an = new cc.Animation( lists, delay );
        an.setLoops( loop );
        var animate = new cc.Animate( an );

        var action = cc.repeatForever( animate );
        this.runAction( action );

        this.setPosition(startP);
        var moveAction = cc.moveTo(duration,endP );
        this.runAction( moveAction );

        if( duration > 0 )
        {
            //this._callBack = callBack == undefined ? null : callBack;
            //this._owner = owner == undefined ? null : owner;
            //this._parameter = data == undefined ? null : data;

            var delayTime = cc.sequence( cc.delayTime(duration), cc.callFunc( this.movePathAnimation, this ) );
            this.runAction( delayTime );
        }

        this._dirCurrent++;

        //if(this._dirType==1){
        //    this._dirCurrent+=1;
        //    if(this._dirCurrent>3) this._dirCurrent=0;
        //}else if(this._dirType==-1){
        //    this._dirCurrent-=1;
        //    if(this._dirCurrent<0) this._dirCurrent=3;
        //}else if(this._dirType==2){
        //    this._dirCurrent+=2;
        //    if(this._dirCurrent==4) this._dirCurrent=0;
        //    if(this._dirCurrent==5) this._dirCurrent=1;
        //}
    },
    /*
     * 设置动画, 按时间播发
     * animationConfig ：动画配置
     * duration ： 持续时间
     * callBack ：回调函数
     * owner ：回调对象
     * data ：数据
     */
    setAnimationByTime:function( animationConfig, duration, callBack, owner, data )
    {
        this.removeData();

        if (animationConfig == null) return;
        this._animationConfig=animationConfig;
        this.setAnchorPoint( animationConfig.anchorX, animationConfig.anchorY );
        this.setScale( animationConfig.scale );

        var lists = [];

        var num = Number( animationConfig.frameNum );
        var time = Number( animationConfig.time );
        var delay = time/num;
        duration = duration == undefined ? 0 : duration;
        var loop = duration > 0 ? duration : 1;

        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined  && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }

        if( lists.length == 0 ) return;

        var an = new cc.Animation( lists, delay );
        an.setLoops( loop );
        var animate = new cc.Animate( an );

        var ac=null;
        if( duration <= 0 ) {
            ac = cc.repeatForever(animate);
        }
        else{
            if (callBack)
            {
                this._callBack = callBack == undefined ? null : callBack;
                this._owner = owner == undefined ? null : owner;
                this._parameter = data == undefined ? null : data;
                ac =  cc.sequence( animate, cc.callFunc( this.endAnimation, this ) );
            }
            else
            {
                ac =  cc.sequence( animate );
            }
        }
        if( ac )
        {
            this.runAction( ac );
        }
    },

    /*
     * 设置动画, 按次数播发
     * animationConfig ：动画配置
     * count ： 播放次数
     * callBack ：回调函数
     * owner ：回调对象
     * data ：数据
     */
    setAnimationByCount:function( animationConfig, count, callBack, owner, data )
    {
        this.removeData();
        if (animationConfig == null) return;
        this._animationConfig=animationConfig;
        this.setAnchorPoint( animationConfig.anchorX, animationConfig.anchorY );
        this.setScale( animationConfig.scale );

        var lists = [];

        var num = Number( animationConfig.frameNum );
        var time = Number( animationConfig.time );
        var delay = time/num;
        count = count == undefined ? 0 : count;
        var loop = count > 0 ? count : 1;

        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }
        if( lists.length == 0 ) return;

        var an = new cc.Animation( lists, delay );
        an.setLoops( loop );
        var animate = new cc.Animate( an );

        var action = cc.repeatForever( animate );
        this.runAction( action );

        if( duration > 0 )
        {
            this._callBack = callBack == undefined ? null : callBack;
            this._owner = owner == undefined ? null : owner;
            this._parameter = data == undefined ? null : data;

            var delayTime = cc.sequence( cc.delayTime(duration), cc.callFunc( this.endAnimation, this ) );
            this.runAction( delayTime );
        }
    },


    disposeSelf:function(node){
        this.endAnimation();
        this.removeFromParent();
    },
    endAnimation:function( node )
    {
        if( this._callBack ) this._callBack.call( this._owner, this._parameter );
        this.removeData();
    },

    getSpriteFrameList:function( animationConfig )
    {
        var lists = [];
        var imgName = animationConfig.key + "_";
        if( animationConfig.imageName != undefined && animationConfig.imageName != "0" )
        {
            imgName = animationConfig.imageName;
        }
        for (var i = 0; i < num; i++)
        {
            var frameName = imgName + i + ".png";
            var spriteFrame = cc.spriteFrameCache.getSpriteFrame( frameName );
            lists.push( spriteFrame );
        }
        return lists;
    },

    removeData:function()
    {
        this._isAdd = false;
        this._callBack = null;
        this._owner = null;
        this._parameter = null;
        this._animationConfig=null;
        this.stopAllActions();
        this.removeAllChildren();
    },
    removeAction:function(){
        this.stopAllActions();
        this.removeAllChildren();
    }
});