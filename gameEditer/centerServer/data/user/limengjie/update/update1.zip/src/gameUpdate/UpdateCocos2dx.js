﻿var __failCount = 0;

var UpdateCocos2dx = cc.Scene.extend({
    _am: null,
    show: null,
    load: function () {
        this.run();
    },
    run: function () {
        if (!cc.sys.isNative) {
            this.loadGame();
            return;
        }

        var layer = new cc.Layer();
        this.layer = layer;
        this.addChild(layer);

        this.show = new UpdateSprite();
        layer.addChild(this.show);

        if (updateFlag == false) {
            console.log("热更新直接结束");
            this.loadGame();
            return;
        }


        // android: /data/data/com.huanle.magic/files/
        var storagePath = (jsb.fileUtils ? jsb.fileUtils.getWritablePath() : "./");
        //console.log("进入更新:" + storagePath);

        this._am = new jsb.AssetsManager("res/project.manifest", storagePath);
        this._am.retain();

        if (!this._am.getLocalManifest().isLoaded()) {
            console.log("Fail to update assets, step skipped.");
            this.error();
        }
        else {
            var that = this;
            var listener = new jsb.EventListenerAssetsManager(this._am, function (event) {
                switch (event.getEventCode()) {
                    case jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST:
                        console.log("No local manifest file found, skip assets update.");
                        that.error(null, jsb.EventAssetsManager.ERROR_NO_LOCAL_MANIFEST);
                        break;
                    case jsb.EventAssetsManager.UPDATE_PROGRESSION:
                        //that._percent = ;
                        //that._percentByFile = event.getPercentByFile();
                        cc.log(event.getPercent() + "%");
                        that.show.setPercent(event.getPercent());
                        var msg = event.getMessage();
                        if (msg) {
                            cc.log(msg);
                        }
                        break;
                    case jsb.EventAssetsManager.ERROR_DOWNLOAD_MANIFEST:
                    case jsb.EventAssetsManager.ERROR_PARSE_MANIFEST:
                        console.log("Fail to download manifest file, update skipped.");
                        that.error(null, jsb.EventAssetsManager.ERROR_PARSE_MANIFEST);
                        break;
                    case jsb.EventAssetsManager.ALREADY_UP_TO_DATE:
                    case jsb.EventAssetsManager.UPDATE_FINISHED:
                        console.log("Update finished.");
                        that.loadGame();
                        break;
                    case jsb.EventAssetsManager.UPDATE_FAILED:
                        console.log("Update failed. " + event.getMessage());

                        __failCount++;
                        if (__failCount < 5) {
                            that._am.downloadFailedAssets();
                        }
                        else {
                            console.log("Reach maximum fail count, exit update process");
                            __failCount = 0;
                            that.error(null, jsb.EventAssetsManager.UPDATE_FAILED);
                        }
                        break;
                    case jsb.EventAssetsManager.ERROR_UPDATING:
                        console.log("Asset update error: " + event.getAssetId() + ", " + event.getMessage());
                        that.error(null, jsb.EventAssetsManager.ERROR_UPDATING);
                        break;
                    case jsb.EventAssetsManager.ERROR_DECOMPRESS:
                        console.log("错误:" + event.getMessage());
                        that.error(null, jsb.EventAssetsManager.ERROR_DECOMPRESS);
                        break;
                    default:
                        break;
                }
            });

            cc.eventManager.addListener(listener, 1);
            this._am.update();
            cc.director.runScene(this);
        }

        this.schedule(this.updateProgress, 0.5);
    },
    loadGame: function () {
        var owner = this;
        cc.loader.loadJs(["src/files.js"], function (err) {
            if (err) {
            } else {
                var files = jsFiles;
                cc.loader.loadJs(files, function (err) {
                    if (err) {
                        cc.error("重新加载js文件出错");
                    }
                    else {
                        cc.log("游戏脚本加载完成 ");
                        owner.removeAllChildren();
                        owner.removeFromParent();
                        owner.show.updateComplete();
                    }
                });
            }
        });
    },
    updateProgress: function (dt) {
        //this._progress.string = "" + this._percent;
    },
    start: function (event) {
        cc.error("热更新开始");
        this._am.update();
    },
    error: function (event, msg) {
        var code = (parseInt)(msg);
        if (code != (jsb.EventAssetsManager.UPDATE_FINISHED) &&
            code != (jsb.EventAssetsManager.ALREADY_UP_TO_DATE)) {
            var value = ResMgr.inst().getString("denglu_72");
            ModuleMgr.inst().openModule("AlertPanel", {"txt": value, "type": 2});
            cc.error("热更新失败,错误代码:" + msg);
            //派克的需求，看是否删除//
        }
        else {
            cc.error("热更新完成");
        }
    },
    onExit: function () {
        cc.error("热更新结束本地");
        if (this._listener) cc.eventManager.removeListener(this._listener);
        this._listener = null;
        if (this._am) this._am.release();
        this._am = null;
        this._super();
    }
});