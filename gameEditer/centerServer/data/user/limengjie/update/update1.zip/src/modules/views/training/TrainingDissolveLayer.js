/**
 * Created by cgMu on 2016/3/3.
 */

var TrainingDissolveLayer = cc.Node.extend({
    slider:null,
    percent:null,
    //limite:null,
    max:null,
    got:null,//默认max
    remain:null,

    armyId:null,
    totalLabel:null,

    ctor: function (armyid) {
        this._super();
        this.armyId = armyid;

        var armydata = modelMgr.call("Table", "getTableItemByValue", ["Arm",this.armyId]);

        var colorbg = new cc.LayerColor(cc.color(0, 0, 0, 255*0.8));
        this.addChild(colorbg);

        var _root = ccs.load("res/images/ui/CorpsAssembled/supplementLayer.json","res/images/ui/").node;
        this.addChild(_root);

        var size = cc.director.getVisibleSize();
        _root.setContentSize(size);
        ccui.helper.doLayout(_root);

        var root = _root.getChildByName("Panel_1");
        sizeAutoLayout(root);
        posAutoLayout(root,0.5);

        var title = root.getChildByName("Text_1");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("train_28"));

        var icon = root.getChildByName("gy_wupingkuang_01_5_0");
        icon.setTexture(ResMgr.inst().getIcoPath(armydata.arm_type));

        var remain_counts = ModuleMgr.inst().getData("CastleModule").getNetArmy(null,this.armyId);
        var total_counts = root.getChildByName("Text_7");
        total_counts.ignoreContentAdaptWithSize(true);
        total_counts.setString(remain_counts);
        this.totalLabel = total_counts;

        this.remain = remain_counts;//data.attributes.getItem("type",2500011).value;
        //this.limite = armydata.force_mnax;
        this.max = remain_counts;
        this.got = 0;
        if(this.got>this.max+this.remain) this.got = this.max+this.remain;

        cc.log("@",this.remain,this.got,this.max);

        var name = root.getChildByName("Text_8");
        name.ignoreContentAdaptWithSize(true);
        name.setString(ResMgr.inst().getString(this.armyId+"0"));

        var closebtn = root.getChildByName("Button_1");
        closebtn.addTouchEventListener(this.closecallback,this);

        var confirm_btn = root.getChildByName("Button_2");
        confirm_btn.addTouchEventListener(this.confirmcallback,this);
        title = confirm_btn.getChildByName("Text_2");
        title.ignoreContentAdaptWithSize(true);
        title.setString(ResMgr.inst().getString("assembled_13"));

        var label1 = root.getChildByName("Text_9");
        label1.ignoreContentAdaptWithSize(true);
        label1.setString(ResMgr.inst().getString("train_29"));

        //数量
        var counts = root.getChildByName("Text_10");
        counts.ignoreContentAdaptWithSize(true);
        counts.setString(this.got);
        this.percent = counts;

        var slider = root.getChildByName("Slider_1");
        slider.addEventListener(this.sliderCall,this);
        slider.setPercent(this.got / this.max * 100);
        this.slider = slider;

        var sub = root.getChildByName("Panel_2");
        sub.addTouchEventListener(this.subcallback,this);
        var add = root.getChildByName("Image_5_0");
        add.setTouchEnabled(true);
        add.addTouchEventListener(this.addcallback,this);

        EventMgr.inst().addEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    onExit: function () {
        this._super();
        EventMgr.inst().removeEventListener(CastleEvent.NET_COMPLETE, this.netComplete, this);
    },

    confirmcallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        cc.log("解散部队数量",this.got);
        if(this.got>0){
            var msg = new SocketBytes();
            msg.writeUint(426);//丢弃已建造的部队
            msg.writeString(mainData.uiData.currentCastleId);
            msg.writeUint(this.armyId);
            msg.writeUint(this.got);
            NetMgr.inst().send(msg);
        }
    },

    sliderCall: function (sender,type) {
        if( type == ccui.Slider.EVENT_PERCENT_CHANGED ) {
            var num = sender.getPercent();
            var counts = parseInt(this.max*num/100);
            this.got = counts;
            if(this.got>this.max) this.got = this.max;
            if(this.percent){
                this.percent.setString(this.got);
            }
            this.slider.setPercent(this.got / this.max * 100);

            this.totalLabel.setString(this.max-this.got);
        }
    },

    subcallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.got--;
        if(this.got<0) this.got = 0;

        this.percent.setString(this.got);
        this.slider.setPercent(this.got / this.max * 100);

        this.totalLabel.setString(this.max-this.got);
    },

    addcallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.got++;
        if(this.got>this.max) this.got = this.max;

        this.percent.setString(this.got);
        this.slider.setPercent(this.got / this.max * 100);
        this.totalLabel.setString(this.max-this.got);
    },

    closecallback: function (sender, type) {
        if(type!=ccui.Widget.TOUCH_ENDED) return;
        this.removeFromParent(true);
    },

    netComplete: function (event,data) {
        if(data == 426){
            EventMgr.inst().dispatchEvent("dissolve_callback",this.armyId,this.got);
            this.removeFromParent(true);
        }
    }
});