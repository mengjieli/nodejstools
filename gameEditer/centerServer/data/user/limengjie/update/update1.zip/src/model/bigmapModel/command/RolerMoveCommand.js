var RolerMoveCommand = (function (_super) {
    __extends(RolerMoveCommand, _super);

    function RolerMoveCommand(name, cycler, cycleState) {
        _super.call(this, name, cycler, false);
        this.count = 0;
    }

    var d = __define, c = RolerMoveCommand;
    p = c.prototype;


    /**
     * 初始化
     * @param params Object
     *  @subparam x 点击的坐标 x
     *  @subparam y 点击的坐标 y
     *  @subparam action 移动动作 0 待机   1 攻击    2 移民展开    3 砍树    4 进入城堡   5 采集战略资源
     *  @subparam data 角色信息
     *  @subparam param 参数
     */
    p.init = function (params) {
        //trace("移动到",params.data.id,params.x,params.y);
        this.data = params.data;
        var x = params.x;
        var y = params.y;
        var action = params.action || 0;
        var param = params.param;
        param = param == null ? "" : param;
        var endPoint = null;
        if (action == 1) {
            var backPoint = this.getAttackPoint(x, y);
            if (backPoint == null) {
                return;
            }
            x = backPoint.x;
            y = backPoint.y;
        }
        if (action == 4) {
            var backPoint = this.getBackCastlePoint(x, y);
            if (backPoint == null) {
                return;
            }
            x = backPoint.x;
            y = backPoint.y;
            endPoint = backPoint.endPoint;
        }
        if (this.data.coordX < mainData.mapData.cameraData.viewPort.x ||
            this.data.coordX >= mainData.mapData.cameraData.viewPort.x + mainData.mapData.cameraData.viewPort.width ||
            this.data.coordY < mainData.mapData.cameraData.viewPort.y ||
            this.data.coordY >= mainData.mapData.cameraData.viewPort.y + mainData.mapData.cameraData.viewPort.height) {
            ModuleMgr.inst().openModule("AlertString", {
                str: ResMgr.inst().getString("moveOutRange"),
                color: null,
                time: null,
                pos: null
            });
            return;
        }

        var pos = {x: x, y: y};
        var rolerServer = ServerMapConfig.getInstance().getServerCoord(this.data.coordX, this.data.coordY);
        var touchServer = ServerMapConfig.getInstance().getServerCoord(pos.x, pos.y);
        if (rolerServer.x != touchServer.x || rolerServer.y != touchServer.y) {
            var dir = -1;
            if (rolerServer.y == touchServer.y && Math.abs(rolerServer.x - touchServer.x) == 1) {
                if (rolerServer.x < touchServer.x && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).x == ServerMapConfig.getInstance().serverCoordWidth - 3) {
                    dir = 0;
                } else if (rolerServer.x > touchServer.x && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).x == 2) {
                    dir = 2;
                }
            } else if (rolerServer.x == touchServer.x && Math.abs(rolerServer.y - touchServer.y) == 1) {
                if (rolerServer.y < touchServer.y && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).y == ServerMapConfig.getInstance().serverCoordHeight - 3) {
                    dir = 1;
                } else if (rolerServer.y > touchServer.y && ServerMapConfig.getInstance().changeToServerPoint(this.coordX, this.coordY).y == 2) {
                    dir = 3;
                }
            }
            //string      mapObjectUuid       // 部队 uuid
            //uint        direction           // 0, 1, 2, 3 对应 向右，向上，向左，向下。注意不同方向的跳跃对部队当前的坐标有限定。
            if (dir >= 0) {
                var msg = new SocketBytes();
                msg.writeUint(309);
                msg.writeString(this.id);
                msg.writeUint(dir);
                NetMgr.inst().send(msg);
                console.log("跨越服务器:" + dir);
            } else {
            }
            return;
        }
        ////trace("触摸点", x, y, pos.x, pos.y);
        var start = this.checkPathOutCastle(pos.x, pos.y);
        //周围所有的路都被堵死了
        trace("出城点", flower.ObjectDo.toString(start));
        if (!start) {
            return null;
        }
        var path;
        trace("是否在城内?", start.endInRange);
        if (start.endInRange) {
            path = start.path;
        } else {
            path = ServerMapConfig.getInstance().astar.findPath(start.x, start.y, pos.x, pos.y);
            if (!path || !path.length) {
                return;
            }
            if (endPoint) {
                path.push(endPoint);
            }
            if (start.path) {
                path = start.path.concat(path);
            }
        }
        //this.goDownTheRoad(path);

        var msg = new SocketBytes();
        msg.writeUint(303);
        msg.writeString(this.data.id);
        var str = "寻路结果: ";
        for (var i = 0; i < path.length; i++) {
            str += "(" + path[i].x + "," + path[i].y + ")" + (i < path.length - 1 ? "->" : "");
        }
        trace(str);
        msg.writeUint(path.length);
        var lastPath = {x: this.data.coordX, y: this.data.coordY};
        var searchPoint;
        for (var p = 0; p < path.length; p++) {
            msg.writeInt(path[p].x - lastPath.x);
            msg.writeInt(path[p].y - lastPath.y);
            console.log((path[p].x - lastPath.x) + "," + (path[p].y - lastPath.y));
            lastPath = path[p];
        }
        msg.writeUint(action);
        msg.writeString(param);
        trace("移动 Action", action, "Param", param, this.data.id);
        NetMgr.inst().send(msg);
    }


    //找一条从城堡范围出去的路
    p.checkPathOutCastle = function (endX, endY) {
        var checkX = this.data.coordX;
        var checkY = this.data.coordY;
        var castleList = mainData.mapData.myCastleList;
        var checkPoints = null;
        var startIndex = -1;
        for (var i = 0; i < castleList.length; i++) {
            var castle = castleList.getItemAt(i);
            var points = this.getCastleRoundPoints(castle.coordX, castle.coordY);
            var inRange = false;
            for (var f = 0; f < points.length; f++) {
                if (points[f].x == checkX && points[f].y == checkY) {
                    inRange = true;
                    startIndex = f;
                    break;
                }
            }
            if (inRange) {
                checkPoints = points;
                break;
            }
        }
        if (!checkPoints) {
            return {"x": checkX, "y": checkY};
        }
        var endInRange = false;
        for (var i = 0; i < checkPoints.length; i++) {
            if (checkPoints[i].x == endX && checkPoints[i].y == endY) {
                endInRange = true;
                break;
            }
        }
        //trace("终点是否在城堡范围?",endInRange);
        //逆时针寻找
        var index;
        var sm = ServerMapConfig.getInstance();
        var path1 = [];
        var outFlag = false;
        for (var i = 0; i < checkPoints.length; i++) {
            index = startIndex + i;
            index = index % checkPoints.length;
            var p = checkPoints[index];
            path1.push(p);
            //trace("加入结果1",index,path1.length, p.x, p.y);
            if (endInRange) {
                if (p.x == endX && p.y == endY) {
                    break;
                }
            } else {
                for (var a = 0; a < p.around.length; a++) {
                    if (sm.isPath(p.around[a].x, p.around[a].y)) {
                        outFlag = true;
                        break;
                    }
                }
                if (outFlag) {
                    break;
                }
            }
        }
        if (!endInRange && !outFlag) {
            return null;
        }
        var path2 = [];
        outFlag = false;
        for (var i = 0; i < checkPoints.length; i++) {
            index = startIndex - i;
            if (index < 0) {
                index = checkPoints.length - 1;
            }
            var p = checkPoints[index];
            path2.push(p);
            //trace("加入结果2",index,path2.length, p.x, p.y);
            if (endInRange) {
                if (p.x == endX && p.y == endY) {
                    break;
                }
            } else {
                for (var a = 0; a < p.around.length; a++) {
                    if (sm.isPath(p.around[a].x, p.around[a].y)) {
                        outFlag = true;
                        break;
                    }
                }
                if (outFlag) {
                    break;
                }
            }
        }
        //trace("城内结果111",path1.length,path2.length);
        var path = path1.length < path2.length ? path1 : path2;
        var outX = path[path.length - 1].x;
        var outY = path[path.length - 1].y;
        //trace("城内结果",path.length,outX,outY);
        ////trace("最终寻路节点",outX,outY,path.length,path[0].x,path[0].y);
        path.shift();
        return {"x": outX, "y": outY, path: path, "endInRange": endInRange};
    }

    p.getAttackPoint = function (x, y) {
        //return {x:x,y:y}
        var points = [];
        points.push({"x": x - 1, "y": y, "around": [{"x": x - 2, "y": y}]});
        if (y % 2 == 0) {
            points.push({"x": x - 1, "y": y - 1});
            points.push({"x": x + 0, "y": y - 1});
            points.push({"x": x + 1, "y": y});
            points.push({"x": x + 0, "y": y + 1});
            points.push({"x": x - 1, "y": y + 1});
        } else {
            points.push({"x": x + 0, "y": y - 1});
            points.push({"x": x + 1, "y": y - 1});
            points.push({"x": x + 1, "y": y});
            points.push({"x": x + 1, "y": y + 1});
            points.push({"x": x + 0, "y": y + 1});
        }
        var minDis = 2000000000;
        var minP = null;
        for (var i = 0; i < points.length; i++) {
            var p = points[i];
            if (ServerMapConfig.getInstance().isPath(p.x, p.y)) {
                var dis = Math.sqrt((this.data.coordX - p.x)*(this.data.coordX - p.x) + (this.data.coordY - p.y)*(this.data.coordY - p.y));
                if(dis < minDis) {
                    minP = p;
                    minDis = dis;
                    trace("找到啦啦");
                }
                //return p;
            }
        }
        return minP;
    }

    p.getBackCastlePoint = function (x, y) {
        var point = null;
        var castle = mainData.mapData.myCastleList.getItem("coordX", x, "coordY", y);
        var points = this.getCastleRoundPoints(x, y);
        points.sort(function (a, b) {
            var disa = (a.x - x) * (a.x - x) + (a.y - y) * (a.y - y) * 1.1;
            var disb = (b.x - x) * (b.x - x) + (b.y - y) * (b.y - y) * 1.1;
            trace("[dis]", a.x, a.y, disa, b.x, b.y, disb);
            return disa == disb ? 0 : (disa > disb ? 1 : -1);
        });
        for (var i = 0; i < points.length; i++) {
            if (mainData.mapData.myArmyList.getItem("coordX", points[i].x, "coordY", points[i].y) == null) {
                for (var a = 0; a < points[i].around.length; a++) {
                    if (mainData.mapData.myArmyList.getItem("coordX", points[i].around[a].x, "coordY", points[i].around[a].y) == null) {
                        point = points[i].around[a];
                        point.endPoint = {"x": points[i].x, "y": points[i].y};
                        break;
                    }
                }
                if (point) {
                    break;
                }
            }
        }
        //trace("回城点",flower.ObjectDo.toString(point));
        return point;
    }

    p.getCastleRoundPoints = function (coordX, coordY) {
        var x = coordX;
        var y = coordY;
        var points = [];
        points.push({"x": x - 1, "y": y, "around": [{"x": x - 2, "y": y}]});
        if (y % 2 == 0) {
            points.push({"x": x - 1, "y": y - 1, "around": [{"x": x - 2, "y": y - 1}, {"x": x - 1, "y": y - 2}]});
            points.push({"x": x + 0, "y": y - 1, "around": [{"x": x + 0, "y": y - 2}, {"x": x + 1, "y": y - 2}]});
            points.push({"x": x + 1, "y": y - 1, "around": [{"x": x + 2, "y": y - 2}, {"x": x + 2, "y": y - 1}]});
            points.push({"x": x + 2, "y": y, "around": [{"x": x + 3, "y": y}]});
            points.push({"x": x + 1, "y": y + 1, "around": [{"x": x + 2, "y": y + 2}, {"x": x + 2, "y": y + 1}]});
            points.push({"x": x + 0, "y": y + 1, "around": [{"x": x + 0, "y": y + 2}, {"x": x + 1, "y": y + 2}]});
            points.push({"x": x - 1, "y": y + 1, "around": [{"x": x - 2, "y": y + 1}, {"x": x - 1, "y": y + 2}]});
        } else {
            points.push({"x": x + 0, "y": y - 1, "around": [{"x": x - 1, "y": y - 1}, {"x": x - 1, "y": y - 2}]});
            points.push({"x": x + 1, "y": y - 1, "around": [{"x": x + 0, "y": y - 2}, {"x": x + 1, "y": y - 2}]});
            points.push({"x": x + 2, "y": y - 1, "around": [{"x": x + 2, "y": y - 2}, {"x": x + 3, "y": y - 1}]});
            points.push({"x": x + 2, "y": y, "around": [{"x": x + 3, "y": y}]});
            points.push({"x": x + 2, "y": y + 1, "around": [{"x": x + 2, "y": y + 2}, {"x": x + 3, "y": y + 1}]});
            points.push({"x": x + 1, "y": y + 1, "around": [{"x": x + 0, "y": y + 2}, {"x": x + 1, "y": y + 2}]});
            points.push({"x": x + 0, "y": y + 1, "around": [{"x": x - 1, "y": y + 1}, {"x": x - 1, "y": y + 2}]});
        }
        return points;
    }

    RolerMoveCommand.menuConfig = null;

    return RolerMoveCommand;
})(CycleCommand);