var IDE = (function () {
    function IDE() {
    }
    IDE.FLASH = "flash";
    IDE.COCOS2DX = "cocos2dx";
    return IDE;
})();
//# sourceMappingURL=IDE.js.map