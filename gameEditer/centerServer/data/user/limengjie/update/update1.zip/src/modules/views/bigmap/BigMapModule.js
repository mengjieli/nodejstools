var BigMapModule = ModuleBase.extend({
    data: null, //ModuleData
    layer: null, //地图层次
    camera: null,//镜头
    ctor: function () {
        this._super();
        this.lastCameraX = null;
        this.lastCameraY = null;
    },
    initUI: function () {
        cc.spriteFrameCache.addSpriteFrames("res/fight/ui/fightResource.plist");

        //初始化数据
        this.data = ModuleMgr.inst().getData("BigMapModule");

        //初始化显示
        this.addChild(this.layer = new BigMapLayerManager());
        this.camera = new MapCamera();
        this.camera.init(0, 0,
            -this.data.getServerMapWidth(), -this.data.getServerMapHeight(),
            this.data.getServerMapWidth(), this.data.getServerMapHeight());
        this.layer.setScale(this.camera.screenScaleX, this.camera.screenScaleY);

        modelMgr.call("BigMap", "registerCamera", [this.camera]);

        //注册鼠标事件
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegan: this.onTouchBegan.bind(this),
            onTouchMoved: this.onTouchMoved.bind(this),
            onTouchEnded: this.onTouchEnded.bind(this)
        }, this);

        //注册回调
        jc.EnterFrame.add(this.update, this);

        var castle = mainData.mapData.myCastleList.getItem("id", mainData.uiData.currentCastleId);
        var pos = MapUtils.transPointToPosition(castle.coordX, castle.coordY);
        this.camera.lookAt(pos.x, pos.y);

        //mainData.smallMapData.cameraX = pos.x;
        //mainData.smallMapData.cameraY = pos.y;

        cc.audioEngine.stopMusic();
        SoundPlay.playMusic(ResMgr.inst().getSoundPath(3));
    },
    destroy: function () {
        modelMgr.call("BigMap", "registerCamera", [null]);
        this.layer.dispose();
        jc.EnterFrame.del(this.update, this);

        //cc.spriteFrameCache.removeSpriteFrames("res/fight/ui/fightResource.plist");
        //cc.textureCache.removeTextureForKey("res/fight/ui/fightResource.png");
    },
    show: function (data) {
        mainData.uiData.showMapFinish = true;
        if (data) {
            trace("传入视点：", data.x, data.y);
            this.camera.lookAt(data.x, data.y);

            //mainData.smallMapData.cameraX = data.x;
            //mainData.smallMapData.cameraY = data.y;
        }
    },
    //更新
    lastCameraX: 1000000000,
    lastCameraY: 1000000000,
    update: function (dt) {
        if(this.clickFlag && mainData.uiData.operateMode == 2) {
            var now = (new Date()).getTime();
            if(now - this.lastTime > 500) {
                this.clickFlag = false;
                this.clickEndType = 2;
                this.layer.longTouch(this.touchPos.x, this.touchPos.y);
            }
        }
        if (this.camera.checkMove()) {

            //trace(this.lastCameraX,this.lastCameraY,bigGridX,bigGridY);
            if (Math.abs(this.camera.x - this.lastCameraX) > this.camera.width * 0.5 ||
                Math.abs(this.camera.y - this.lastCameraY) > this.camera.height * 0.5) {
                var start = MapUtils.transPositionToPoint(this.camera.x - this.camera.width, this.camera.y - this.camera.height);
                var end = MapUtils.transPositionToPoint(this.camera.x + this.camera.width * 2, this.camera.y + this.camera.height * 2);
                //设定视野
                var msg = new SocketBytes();
                msg.writeUint(301);
                msg.writeInt(start.x);
                msg.writeInt(start.y);
                msg.writeUint(end.x - start.x);
                msg.writeUint(end.y - start.y);
                NetMgr.inst().send(msg);
                //刷新视野
                msg = new SocketBytes();
                msg.writeUint(302);
                msg.writeInt(start.x);
                msg.writeInt(start.y);
                msg.writeUint(end.x - start.x);
                msg.writeUint(end.y - start.y);
                NetMgr.inst().send(msg);

                //记录上次视野范围
                this.lastCameraX = this.camera.x;
                this.lastCameraY = this.camera.y;

                var rectData = DataManager.getInstance().getNewData("RectData");
                rectData.x = start.x;
                rectData.y = start.y;
                rectData.width = end.x - start.x;
                rectData.height = end.y - start.y;
                mainData.mapData.cameraData.viewPort = rectData;
                //MapDataCommand.testResource();
                //trace("更新视野1",this.camera.x,this.camera.y, start.x, start.y, end.x, end.y);
                trace("更新视野2", mainData.mapData.cameraData.viewPort.x, mainData.mapData.cameraData.viewPort.y,
                    mainData.mapData.cameraData.viewPort.width, mainData.mapData.cameraData.viewPort.height);
            }
            this.layer.updateShow(this.camera);
        }
    },
    touchBeganPos: null,
    touchPos: null,
    clickFlag: null,
    lastTime: 0,
    clickEndType:0,
    onTouchBegan: function (touch, event) {
        mainData.uiData.map.touch = true;
        var pos = touch.getLocation();
        var now = (new Date()).getTime();
        if (now - this.lastTime < 250) {
            return false;
        }
        var p = DataManager.getInstance().getNewData("PointData");
        p.x = pos.x + this.camera.x;
        p.y = pos.y + this.camera.y;
        var point = MapUtils.transPositionToPoint(p.x, p.y);
        mainData.uiData.map.touchMovePoint = point;
        this.lastTime = now;
        this.touchPos = pos;
        this.touchBeganPos = cc.p(this.touchPos.x, this.touchPos.y);
        this.clickFlag = true;
        //trace("按下", this.touchBeganPos.x, this.touchBeganPos.y);
        this.touchPos.x /= this.camera.screenScaleX;
        this.touchPos.y /= this.camera.screenScaleY;
        this.layer.onTouchBegan(this.touchPos.x, this.touchPos.y);
        //trace("点击：", this.touchPos.x, this.touchPos.y,this.camera.x,this.camera.y,this.layer.getPosition().y);
        return true;
    },
    onTouchMoved: function (touch, event) {
        var pos = touch.getLocation();
        var p = DataManager.getInstance().getNewData("PointData");
        p.x = pos.x + this.camera.x;
        p.y = pos.y + this.camera.y;
        var point = MapUtils.transPositionToPoint(p.x, p.y);
        if(mainData.uiData.map.touchMovePoint.x != point.x || mainData.uiData.map.touchMovePoint.y != point.y) {
            mainData.uiData.map.touchMovePoint = point;
        }
        if(this.clickFlag == false && mainData.uiData.operateMode == 2 && this.clickEndType == 2) {
            return;
        }
        if (this.clickFlag && (Math.abs(pos.x - this.touchBeganPos.x) > 10 || Math.abs(pos.y - this.touchBeganPos.y > 10))) {
            this.clickFlag = false;
            this.clickEndType = 1;
            this.layer.dragMap();
            //trace("移动超出范围", this.touchBeganPos.x, this.touchBeganPos.y, pos.x, pos.y);
        }
        pos.x /= this.camera.screenScaleX;
        pos.y /= this.camera.screenScaleY;

        this.camera.move(this.touchPos.x - pos.x, this.touchPos.y - pos.y, true);

        this.touchPos = pos;
    },
    onTouchEnded: function (touch, event) {
        if (this.clickFlag) {
            this.layer.onTouchEnded(this.touchPos.x, this.touchPos.y);
        }
        this.clickFlag = false;
        mainData.uiData.map.touch = false;
    },
});